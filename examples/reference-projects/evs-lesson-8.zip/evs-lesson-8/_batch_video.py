"""Batch video generation for EVS Lesson 8 — keyframe pipeline.

Upgrade from direct text-to-video (prone to anatomy hallucination) to:
  Step 1: Flux.2 Dev text-to-image  → precise educational keyframe
  Step 2: ImageUpscaler             → 2× quality lift before animation
  Step 3: Wan2.2 image-to-video     → animate the designed keyframe

Fallback: if keyframe generation fails, falls back to h3-minimax-t2v
direct text-to-video (preserves original behaviour).

Resumable: existing .mp4 files are skipped automatically.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from dotenv import load_dotenv  # noqa: E402

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from tools.video.modelslab_video import ModelsLabVideo  # noqa: E402

ROOT  = Path(__file__).resolve().parents[2]
PROJ  = ROOT / "projects" / "evs-lesson-8"
ASSET = PROJ / "assets" / "video" / "scenes"

# ---------------------------------------------------------------------------
# Shared constraints — applied to every prompt
# ---------------------------------------------------------------------------
HARD = "no text, no watermark, fixed camera, no camera movement of any kind"

NEG = (
    "looping, loop, seamless loop, cyclic motion, repeating action, oscillation, "
    "bounce back, reverse motion, rewind, replay, back and forth, ping pong, "
    "repeated gesture, motion cycle, stutter, frame jump, freeze frame, static image, "
    "zoom in, zoom out, push in, pull out, Ken Burns, pan, dolly, camera movement, "
    "text, watermark, distorted anatomy, double image, blurry, low quality, overexposed, "
    "morphing background, flickering, colour shift, duplicate frames"
)

# Shared image-gen quality guard — added to every keyframe prompt
IMG_QUALITY = (
    "accurate anatomy, child-safe, bright natural lighting, no text, no watermark, "
    "clean edges, flat educational illustration style, consistent warm palette"
)

# Seed formula — keeps each clip deterministic and distinct
def _seed(section: str, idx: int) -> int:
    return (int(section[1:]) * 100 + idx) * 7919


# ---------------------------------------------------------------------------
# Clip specs
# Each entry: (section_id, clip_idx, keyframe_prompt, video_prompt, duration)
#
# keyframe_prompt  →  Flux.2 Dev text-to-image
# video_prompt     →  Wan2.2 image-to-video (animates the keyframe)
# ---------------------------------------------------------------------------
CLIPS = [
    # ── s01: Opening — fish, bird, rabbit ────────────────────────────────────
    ("s01", 0,
     f"Wide educational illustration: bright orange-and-white fish gliding in a "
     f"sun-dappled shallow pond, lily pads at edges, warm amber morning light. {IMG_QUALITY}",
     f"Fish glides once in smooth arc left to right, fins fanning, fixed camera. {HARD}",
     "5"),

    ("s01", 1,
     f"Medium educational illustration: small green-and-yellow bird landing on a "
     f"mossy branch in forest clearing, cool diffuse light. {IMG_QUALITY}",
     f"Bird flutters wings once and settles, feathers settle after landing. {HARD}",
     "5"),

    ("s01", 2,
     f"Medium-close educational illustration: fluffy white rabbit on short green grass "
     f"in sunlit garden, warm midday light. {IMG_QUALITY}",
     f"Rabbit hops forward twice then holds, nose twitches once. {HARD}",
     "5"),

    # ── s02: Animal needs ─────────────────────────────────────────────────────
    ("s02", 0,
     f"Wide educational illustration: brown calf stepping toward stone trough in golden "
     f"meadow, warm amber side light. {IMG_QUALITY}",
     f"Calf bends head once to drink, water ripples, holds still. {HARD}",
     "5"),

    ("s02", 1,
     f"Medium educational illustration: cream sheep resting in timber shelter on hay, "
     f"cool morning light through wooden slats. {IMG_QUALITY}",
     f"Sheep chest rises once in slow deep breath then settles. {HARD}",
     "5"),

    ("s02", 2,
     f"Medium-close educational illustration: tan goat walking into stone-walled pen, "
     f"dappled canopy light. {IMG_QUALITY}",
     f"Goat walks in and lies down on straw, tail gives one gentle flick. {HARD}",
     "5"),

    # ── s03: Water vs land ────────────────────────────────────────────────────
    ("s03", 0,
     f"Wide educational illustration: blue-and-silver fish in bright clear river, "
     f"teal-and-cream palette, cool overcast light. {IMG_QUALITY}",
     f"Fish cuts diagonally across river from lower-left to upper-right, fins fanning. {HARD}",
     "5"),

    ("s03", 1,
     f"Medium educational illustration: lion, elephant, and tiger on open golden savanna, "
     f"warm golden-hour side light, ochre-and-sky palette. {IMG_QUALITY}",
     f"Elephant sways trunk once left, lion blinks slowly, tiger shifts weight once. {HARD}",
     "5"),

    ("s03", 2,
     f"Medium-close educational illustration: tiger walking through tall amber grass, "
     f"dusk backlight, rose-and-sage palette. {IMG_QUALITY}",
     f"Tiger takes one deliberate stride, tail swings once. {HARD}",
     "5"),

    # ── s04: Birds ────────────────────────────────────────────────────────────
    ("s04", 0,
     f"Wide educational illustration: mallard duck on still green pond, reeds at edges, "
     f"warm midday overhead light, slate-and-gold palette. {IMG_QUALITY}",
     f"Duck paddles once across pond leaving a single V-shaped ripple. {HARD}",
     "5"),

    ("s04", 1,
     f"Medium educational illustration: grey pigeon on wooden fence post, cool overcast "
     f"light, teal-and-cream palette. {IMG_QUALITY}",
     f"Pigeon glides in from upper-right, lands, wings fold, turns head once left. {HARD}",
     "5"),

    ("s04", 2,
     f"Medium-close educational illustration: vivid green-and-red parrot on thick branch, "
     f"warm dappled canopy light, amber-and-green palette. {IMG_QUALITY}",
     f"Parrot lifts left foot once and sets it down, tilts head right. {HARD}",
     "5"),

    # ── s05: Insects ──────────────────────────────────────────────────────────
    ("s05", 0,
     f"Wide educational illustration: yellow-and-black butterfly on pink flowers in "
     f"sunlit meadow, warm golden-hour light, ochre-and-sky palette. {IMG_QUALITY}",
     f"Butterfly opens wings fully once and drifts forward past flowers, wings beating. {HARD}",
     "5"),

    ("s05", 1,
     f"Medium educational illustration: dark housefly and bright green grasshopper on "
     f"broad green leaf, cool diffuse light, teal-and-cream palette. {IMG_QUALITY}",
     f"Housefly lands once, antennae move; grasshopper makes one clean jump to nearby twig. {HARD}",
     "5"),

    ("s05", 2,
     f"Medium-close educational illustration: grasshopper gripping textured brown twig, "
     f"dappled forest light, slate-and-gold palette. {IMG_QUALITY}",
     f"Grasshopper extends hind legs once in single powerful jump to second twig. {HARD}",
     "5"),

    # ── s06: Domestic and pet animals ─────────────────────────────────────────
    ("s06", 0,
     f"Wide educational illustration: golden retriever beside red-brick house in garden, "
     f"warm midday light, amber-and-green palette. {IMG_QUALITY}",
     f"Dog wags tail once slowly then lies down on grass patch. {HARD}",
     "5"),

    ("s06", 1,
     f"Medium educational illustration: blue-and-yellow parrot on wooden perch inside "
     f"bright room, soft indoor window light, rose-and-sage palette. {IMG_QUALITY}",
     f"Parrot turns head once right and steps sideways one step along perch. {HARD}",
     "5"),

    ("s06", 2,
     f"Medium-close educational illustration: grey rabbit beside white garden fence on "
     f"clover patch, cool overcast morning light, teal-and-cream palette. {IMG_QUALITY}",
     f"Rabbit hops forward once and lowers head to nibble, ears twitching once. {HARD}",
     "5"),

    # ── s07: Wild animals ─────────────────────────────────────────────────────
    ("s07", 0,
     f"Wide educational illustration: Bengal tiger in sunlit forest clearing, tall golden "
     f"grass, warm golden-hour backlight, ochre-and-sky palette. {IMG_QUALITY}",
     f"Tiger walks one full stride through grass, tail arcing once. {HARD}",
     "5"),

    ("s07", 1,
     f"Medium educational illustration: male lion resting under acacia tree, cool "
     f"overcast savanna light, slate-and-gold palette. {IMG_QUALITY}",
     f"Lion takes one slow visible breath, chest rises and falls, eyes blink once. {HARD}",
     "5"),

    ("s07", 2,
     f"Medium-close educational illustration: two spotted deer in dappled forest "
     f"undergrowth, soft canopy light, amber-and-green palette. {IMG_QUALITY}",
     f"Each deer takes one careful step forward, ears rotating once. {HARD}",
     "5"),

    # ── s08: Animal homes map ─────────────────────────────────────────────────
    ("s08", 0,
     f"Wide educational illustration: top-down map of green valley with seven home icons "
     f"— cave den, burrow mound, nest on branch, anthill, kennel, shed, stable — "
     f"warm midday light, ochre-and-sky palette. {IMG_QUALITY}",
     f"Small fox trots once into cave opening, fixed camera on map. {HARD}",
     "5"),

    ("s08", 1,
     f"Medium educational illustration: woven bird nest on forked branch, cool overcast "
     f"light, teal-and-cream palette. {IMG_QUALITY}",
     f"Brown parent bird glides in from left and settles onto nest, wings folding. {HARD}",
     "5"),

    ("s08", 2,
     f"Medium-close educational illustration: sandy anthill beside green grass, dappled "
     f"morning light, amber-and-green palette. {IMG_QUALITY}",
     f"Line of red ants files in from right, each carrying sand grain to mound. {HARD}",
     "5"),

    # ── s09: Den and burrow ───────────────────────────────────────────────────
    ("s09", 0,
     f"Wide educational illustration: lion approaching cave opening in rocky hillside, "
     f"warm golden-hour side light, ochre-and-sky palette. {IMG_QUALITY}",
     f"Lion walks one stride toward cave and disappears inside. {HARD}",
     "5"),

    ("s09", 1,
     f"Medium educational illustration: rabbit emerging from round burrow entrance in "
     f"grassy bank, cool morning light, teal-and-cream palette. {IMG_QUALITY}",
     f"Rabbit emerges nose-first, sniffs once, takes one bite from leafy vegetable. {HARD}",
     "5"),

    ("s09", 2,
     f"Medium-close educational illustration: lion lying in softly lit cave on smooth "
     f"rock, warm amber glow, slate-and-gold palette, child-safe, no blood. {IMG_QUALITY}",
     f"Lion gnaws gently on bone once, mane settling. {HARD}",
     "5"),

    # ── s10: Nests and anthills ────────────────────────────────────────────────
    ("s10", 0,
     f"Wide educational illustration: small brown bird carrying twig to growing nest on "
     f"branch, warm golden-hour light, amber-and-green palette. {IMG_QUALITY}",
     f"Bird places one twig on nest, settles, adjusts twig once. {HARD}",
     "5"),

    ("s10", 1,
     f"Medium educational illustration: row of red berries on flat rock, cool overcast "
     f"light, rose-and-sage palette. {IMG_QUALITY}",
     f"Bird hops forward once, pecks a berry, swallows in one smooth motion. {HARD}",
     "5"),

    ("s10", 2,
     f"Medium-close educational illustration: column of black ants crossing sandy ground "
     f"toward anthill mound, dappled morning light, teal-and-cream palette. {IMG_QUALITY}",
     f"Ants move in single disciplined line, each carrying sand grain. {HARD}",
     "5"),

    # ── s11: Kennel, shed, stable ─────────────────────────────────────────────
    ("s11", 0,
     f"Wide educational illustration: brown dog and red wooden kennel in garden, warm "
     f"midday light, amber-and-green palette. {IMG_QUALITY}",
     f"Dog trots once toward kennel, enters, pokes head back out with tail wagging once. {HARD}",
     "5"),

    ("s11", 1,
     f"Medium educational illustration: black-and-white cow approaching timber shed, cool "
     f"morning light, slate-and-gold palette. {IMG_QUALITY}",
     f"Cow walks once through open shed door and settles on straw, tail swaying once. {HARD}",
     "5"),

    ("s11", 2,
     f"Medium-close educational illustration: chestnut horse at stable stall entrance, "
     f"warm lantern-like interior light, ochre-and-sky palette. {IMG_QUALITY}",
     f"Horse takes one deliberate step into stable, ears pricked forward. {HARD}",
     "5"),

    # ── s12–s16: Recall, glossary, assessment, activity ───────────────────────
    ("s12", 0,
     f"Wide educational illustration: winding path through landscape with animal icons "
     f"— fish, elephant, bird, insect, dog, tiger — warm golden-hour light. {IMG_QUALITY}",
     f"Icons glide along path in one continuous left-to-right flow, no loops. {HARD}",
     "5"),

    ("s13", 0,
     f"Wide educational illustration: five blank illustrated cards floating in a row, "
     f"bird beside first card, cool diffuse light, slate-and-gold palette. {IMG_QUALITY}",
     f"Cards settle into row one after another from right edge, bird flaps wing once. {HARD}",
     "5"),

    ("s14", 0,
     f"Wide educational illustration: dog beside wooden kennel in garden, two birds on "
     f"nearby fence, warm midday light, amber-and-green palette. {IMG_QUALITY}",
     f"Birds flap wings once on fence, dog stays calm beside kennel. {HARD}",
     "5"),

    ("s15", 0,
     f"Wide educational illustration: bright blue fish in sunlit underwater scene, "
     f"teal-and-cream palette, cool diffuse light. {IMG_QUALITY}",
     f"Fish swims once across scene, tail waving in continuous S-curve. {HARD}",
     "5"),

    ("s16", 0,
     f"Wide educational illustration: large blank drawing page on wooden desk in warm "
     f"lamp light, ochre-and-sky palette. {IMG_QUALITY}",
     f"Pencil moves once in single smooth arc drawing a simple animal outline. {HARD}",
     "5"),

    ("s16", 1,
     f"Wide educational illustration: peaceful green meadow at soft dusk with rabbit, "
     f"deer, and bird, rose-and-sage palette, warm dusk backlight. {IMG_QUALITY}",
     f"Rabbit nibbles, deer turns head, bird ruffles feathers — one calm continuous take. {HARD}",
     "5"),
]

print(f"Loaded {len(CLIPS)} clips across {sorted({c[0] for c in CLIPS})} sections")


def main() -> None:
    import os
    from tools.video.character_consistency import CharacterBible, CharacterConsistencyManager

    # ── Step 0: Build character bible (once) ──────────────────────────────────
    print("Building character reference bible for EVS...")
    dry = not os.environ.get("MODELSLAB_API_KEY")
    CharacterBible().generate(subject="evs", dry_run=dry)

    mgr  = CharacterConsistencyManager()
    tool = ModelsLabVideo()
    todo = [c for c in CLIPS if not (ASSET / c[0] / f"{c[0]}-{c[1]}.mp4").exists()]
    print(f"Already done: {len(CLIPS) - len(todo)} | To generate: {len(todo)}")

    for i, (section, idx, kf_prompt, vid_prompt, duration) in enumerate(todo, 1):
        out_mp4 = ASSET / section / f"{section}-{idx}.mp4"
        out_kf  = ASSET / section / f"{section}-{idx}-keyframe.png"
        out_mp4.parent.mkdir(parents=True, exist_ok=True)

        print(f"[{i}/{len(todo)}] {section}-{idx} ...", end=" ", flush=True)
        seed = _seed(section, idx)

        # ── Strategy A: h3-minimax-r2v with character references ──────────────
        # Uses the character bible to inject reference images for consistent identity
        result = mgr.generate_consistent_clip(
            subject="evs",
            section_id=section,
            scene_description=vid_prompt.replace(HARD, "").strip(),
            output_path=out_mp4,
            duration=int(duration),
            negative_prompt=NEG,
            seed=seed,
            dry_run=dry,
        )

        if result["success"]:
            print(f"OK ({result['model_used']}) ${result['cost_usd']:.4f}")
            time.sleep(0.5)
            continue

        print(f"r2v failed ({result['error'][:50]}), trying keyframe pipeline...")

        # ── Strategy B: Flux.2 Dev keyframe → Wan2.2 i2v ─────────────────────
        kf_res = tool.execute({
            "prompt":          kf_prompt,
            "negative_prompt": NEG,
            "model_id":        "flux-dev",
            "operation":       "text_to_image",
            "width":           1360,
            "height":          768,
            "seed":            seed,
            "output_path":     str(out_kf),
        })

        if kf_res.success and out_kf.exists():
            kf_hd = ASSET / section / f"{section}-{idx}-keyframe-hd.png"
            up_res = tool.execute({
                "prompt":      "",
                "model_id":    "ImageUpscaler",
                "operation":   "upscale",
                "init_image":  str(out_kf),
                "scale":       2,
                "output_path": str(kf_hd),
            })
            source_img = str(kf_hd) if up_res.success else str(out_kf)

            vid_res = tool.execute({
                "prompt":          vid_prompt,
                "negative_prompt": NEG,
                "model_id":        "wan2.2",
                "operation":       "image_to_video",
                "init_image":      source_img,
                "duration":        duration,
                "seed":            seed,
                "output_path":     str(out_mp4),
            })

            if vid_res.success:
                print(f"OK (wan2.2 i2v) ${vid_res.cost_usd:.4f}")
                time.sleep(0.5)
                continue
            print(f"wan2.2 failed, falling back to h3-minimax-t2v...")

        # ── Strategy C: h3-minimax-t2v direct fallback ────────────────────────
        fb_res = tool.execute({
            "prompt":          vid_prompt,
            "negative_prompt": NEG,
            "model_id":        "h3-minimax-t2v",
            "operation":       "text_to_video",
            "duration":        duration,
            "resolution":      "768P",
            "generate_audio":  False,
            "seed":            seed,
            "output_path":     str(out_mp4),
        })

        if fb_res.success:
            print(f"OK (h3-minimax fallback) ${fb_res.cost_usd:.4f}")
        else:
            print(f"FAIL | {fb_res.error[:100]}")

        time.sleep(0.5)


if __name__ == "__main__":
    main()
