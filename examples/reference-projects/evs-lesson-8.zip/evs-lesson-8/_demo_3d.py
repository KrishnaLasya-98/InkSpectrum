"""Generate one 10s 3D-cartoon style clip to preview 3D look for EVS Lesson 8.
Uses the same ModelLab pipeline + motion doctrine (linear, fixed camera, no
loop/replay/zoom/Ken Burns). Demo only — judge quality before committing the
full 3D batch."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from dotenv import load_dotenv  # noqa: E402

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from tools.video.modelslab_video import ModelsLabVideo  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "projects" / "evs-lesson-8" / "assets" / "video" / "demo3d" / "rabbit-3d.mp4"
OUT.parent.mkdir(parents=True, exist_ok=True)

PROMPT = (
    "A friendly 3D cartoon rabbit hops forward once across a sunny grassy hill, "
    "rounded Pixar-style forms, soft shadows, big expressive eyes, glossy fur, "
    "ears bounce naturally once, one continuous linear take, fixed camera, "
    "no looping, no camera movement, no zoom, no pan, "
    "child-safe, warm storybook colors, no text, no watermark"
)
NEG = (
    "loop, looping, seamless loop, replay, repeat, restart, rewind, cycle, cyclical, "
    "oscillation, bounce in place, back and forth, zoom in, zoom out, push in, pull out, "
    "Ken Burns, pan, dolly, camera movement, static image, text, watermark, distorted "
    "anatomy, extra limbs, stutter, frame jump, double image"
)

res = ModelsLabVideo().execute({
    "prompt": PROMPT,
    "negative_prompt": NEG,
    "model_id": "h3-minimax-t2v",
    "operation": "text_to_video",
    "duration": "10",
    "resolution": "768P",
    "generate_audio": True,
    "output_path": str(OUT),
})
print("success:", res.success)
if res.success:
    print({k: v for k, v in res.data.items() if k not in ("prompt",)})
print("cost_usd:", res.cost_usd, "| duration_s:", res.duration_seconds)
if not res.success:
    print("error:", res.error)