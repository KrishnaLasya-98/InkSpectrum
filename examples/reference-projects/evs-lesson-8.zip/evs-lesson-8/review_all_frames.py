"""Full-frame technical review for the requested HyperFrames render.
Reads every video frame at a compact analysis resolution and creates 1-second contact sheets.
"""
from __future__ import annotations
import json, subprocess
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw

PROJECT = Path(__file__).resolve().parent
VIDEO = PROJECT / "full-hyperframes" / "renders" / "evs-lesson-8-hyperframes-final.mp4"
OUT = PROJECT / "full-hyperframes" / "artifacts" / "all-frame-review"
OUT.mkdir(parents=True, exist_ok=True)
W, H = 192, 108
FPS = 30

def frames():
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", str(VIDEO), "-f", "rawvideo", "-pix_fmt", "gray", "-vf", f"scale={W}:{H}", "-"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    assert proc.stdout
    frame_bytes = W * H
    idx = 0
    previous = None
    changes=[]; means=[]; dark=[]; bright=[]
    while True:
        raw = proc.stdout.read(frame_bytes)
        if len(raw) != frame_bytes: break
        arr = np.frombuffer(raw, dtype=np.uint8).reshape(H,W)
        means.append(float(arr.mean()))
        dark.append(float((arr < 16).mean()))
        bright.append(float((arr > 245).mean()))
        changes.append(float(np.abs(arr.astype(np.int16) - previous.astype(np.int16)).mean()) if previous is not None else 0.0)
        previous = arr
        idx += 1
    proc.wait()
    return idx, np.array(means), np.array(dark), np.array(bright), np.array(changes)

def contact_sheets():
    # One frame per second, source-size thumbnails, split into manageable sheets.
    cmd=["ffmpeg","-hide_banner","-loglevel","error","-i",str(VIDEO),"-vf","fps=1,scale=320:180","-q:v","3",str(OUT/"second-%04d.jpg")]
    subprocess.run(cmd, check=True)
    files=sorted(OUT.glob("second-*.jpg"))
    for batch_start in range(0,len(files),80):
        batch=files[batch_start:batch_start+80]
        sheet=Image.new("RGB",(5*320,16*205),(245,245,245)); draw=ImageDraw.Draw(sheet)
        for j,path in enumerate(batch):
            im=Image.open(path).convert("RGB")
            x=(j%5)*320; y=(j//5)*205
            sheet.paste(im,(x,y)); draw.text((x+5,y+182),path.stem,fill=(0,0,0))
        sheet.save(OUT/f"contact-sheet-{batch_start//80:02d}.jpg",quality=90)
    return len(files)

def main():
    count, means, dark, bright, changes = frames()
    seconds=contact_sheets()
    # Identify high-change frames (cuts/crossfades) and pathological full-screen states.
    peaks=np.argsort(changes)[-100:][::-1]
    report={"video":str(VIDEO),"frames_read":int(count),"expected_frames":12073,"fps":FPS,"seconds_sampled":seconds,
      "mean_luma":{"min":float(means.min()),"max":float(means.max()),"mean":float(means.mean())},
      "dark_fraction":{"max":float(dark.max()),"frames_over_98pct":int((dark>.98).sum())},
      "bright_fraction":{"max":float(bright.max()),"frames_over_98pct":int((bright>.98).sum())},
      "temporal_change":{"max":float(changes.max()),"p95":float(np.percentile(changes,95)),"mean":float(changes.mean()),
        "top_frames_0based":[{"frame":int(i),"time_s":round(i/FPS,3),"change":float(changes[i])} for i in peaks[:100]]}}
    (OUT/"all_frame_metrics.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    print(json.dumps(report,indent=2))
if __name__ == "__main__": main()
