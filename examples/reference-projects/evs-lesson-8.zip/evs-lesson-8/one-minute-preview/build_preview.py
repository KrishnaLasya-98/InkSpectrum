"""Build the one-minute HyperFrames evaluation cut from existing assets."""
from __future__ import annotations

import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
PROJECT = ROOT / "projects" / "evs-lesson-8"
OUT = PROJECT / "one-minute-preview"
ART = PROJECT / "artifacts"


def read_words(section_id: str, offset_ms: int) -> list[dict]:
    source = json.loads((ART / f"{section_id}.norm_transcript.json").read_text(encoding="utf-8"))
    words: list[dict] = []
    for item in source["segments"]:
        for word in item.get("words", []):
            text = word["word"].strip()
            if not text:
                continue
            words.append(
                {
                    "word": text,
                    "start_ms": round(float(word["start"]) * 1000) + offset_ms,
                    "end_ms": round(float(word["end"]) * 1000) + offset_ms,
                    "confidence": word.get("probability"),
                }
            )
    return words


def main() -> None:
    sections = [
        {"id": "s01", "offset_ms": 3000, "duration_ms": 21408, "label": "Animal Life"},
        {"id": "s02", "offset_ms": 24408, "duration_ms": 20376, "label": "Animals Are Living Beings"},
        {"id": "s03", "offset_ms": 44784, "duration_ms": 13080, "label": "Land And Water Animals"},
    ]
    asset_map = {
        "s01": [
            "assets/video/scenes/s01/s01-0.mp4",
            "assets/video/scenes/s01/s01-1.mp4",
            "assets/video/scenes/s01/s01-2.mp4",
        ],
        "s02": [
            "assets/video/scenes/s02/s02-0.mp4",
            "assets/video/scenes/s02/s02-1.mp4",
            "assets/video/scenes/s02/s02-2.mp4",
        ],
        "s03": [
            "assets/video/scenes/s03/s03-0.mp4",
            "assets/video/scenes/s03/s03-1.mp4",
            "assets/video/scenes/s03/s03-2.mp4",
        ],
    }

    assets_dir = OUT / "assets" / "video"
    audio_dir = OUT / "assets" / "audio"
    assets_dir.mkdir(parents=True, exist_ok=True)
    audio_dir.mkdir(parents=True, exist_ok=True)
    timeline_sections: list[dict] = []
    words: list[dict] = []
    for section in sections:
        sid = section["id"]
        words.extend(read_words(sid, section["offset_ms"]))
        local_assets = []
        for index, source in enumerate(asset_map[sid]):
            source_path = PROJECT / source.replace("assets/video/", "assets/video/")
            dest_name = f"{sid}-{index}.mp4"
            shutil.copy2(source_path, assets_dir / dest_name)
            local_assets.append({
                "id": f"{sid}-motion-{index}",
                "source_path": source,
                "path": f"assets/video/{dest_name}",
                "source_type": "existing_modelslab_motion",
                "section_id": sid,
                "selection_reason": "matched existing generated motion assets to the narrated section",
            })
        timeline_sections.append({
            **section,
            "asset_ids": [item["id"] for item in local_assets],
            "assets": local_assets,
            "text_source": f"artifacts/{sid}_source_cards.json",
            "media_policy": "motion_first",
        })
        shutil.copy2(PROJECT / "renders" / "audio" / f"{sid}.norm.wav", audio_dir / f"{sid}.norm.wav")

    # The source manifest is canonical; the cards here select exact lines from it.
    source = json.loads((ART / "source_text_manifest.json").read_text(encoding="utf-8"))
    source_items = source["items"]
    cards = {
        "s01": [
            "Do you have any pet animals? _____________________________",
            "How do you look after you pet animal? _____________________________",
            "Animals around us",
            "Land Animals",
            "Water Animals",
            "Birds",
            "Insects",
            "Animal Homes",
        ],
        "s02": [
            "Animals are living beings like us which are found in nature.",
            "Animals are found all over the world and they need food, shelter, air, and water like other living beings, to grow and survive.",
            "Their size, eating habits, body colour, and body covering vary according to the place they are found in.",
            "All animals need care and protection.",
        ],
        "s03": [
            "Animals live both on land and in water.",
            "Animals that live in water are called “Water Animals or Aquatic Animals”.",
            "Animals that live on land are called “Land Animals”.",
            "Lion Elephant Tiger",
        ],
    }
    source_lookup = {item["source_text"]: item for item in source_items}
    source_cards = {}
    for sid, lines in cards.items():
        source_cards[sid] = [source_lookup[line] for line in lines if line in source_lookup]
        (OUT / "artifacts").mkdir(parents=True, exist_ok=True)
        (OUT / "artifacts" / f"{sid}_source_cards.json").write_text(
            json.dumps({"section_id": sid, "display_case": "Tt", "preserve_punctuation": True, "lines": source_cards[sid]}, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    timeline = {
        "version": "1.0",
        "duration_ms": 60000,
        "runtime": "hyperframes",
        "renderer_lock": "hyperframes",
        "opening": {"start_ms": 0, "end_ms": 3000, "media_policy": "graphics_only", "title": "Lesson 8: Animal Life"},
        "sections": timeline_sections,
        "closing": {"start_ms": 57864, "end_ms": 60000, "media_policy": "graphics_only", "title": "Animal Life"},
        "captions": words,
        "animal_beats": [
            {
                "name": "Water Animals",
                "spoken_start_ms": 47724,
                "spoken_end_ms": 51324,
                "asset_id": "s03-0-motion",
                "asset_path": "assets/video/s03-0.mp4",
                "reason": "Fish motion visibly represents animals living in water.",
            },
            {
                "name": "Land Animals",
                "spoken_start_ms": 51964,
                "spoken_end_ms": 54424,
                "asset_id": "s03-1-motion",
                "asset_path": "assets/video/s03-1.mp4",
                "reason": "The animated land scene contains recognizable lion, elephant, and tiger subjects.",
            },
            {
                "name": "Lion",
                "spoken_start_ms": 55244,
                "spoken_end_ms": 55364,
                "asset_id": "s03-1-motion",
                "asset_path": "assets/video/s03-1.mp4",
                "reason": "The shared land-animal shot visibly contains a lion while the name is spoken.",
            },
            {
                "name": "Elephant",
                "spoken_start_ms": 55364,
                "spoken_end_ms": 55844,
                "asset_id": "s03-1-motion",
                "asset_path": "assets/video/s03-1.mp4",
                "reason": "The shared land-animal shot visibly contains an elephant while the name is spoken.",
            },
            {
                "name": "Tiger",
                "spoken_start_ms": 56104,
                "spoken_end_ms": 56384,
                "asset_id": "s03-1-motion",
                "asset_path": "assets/video/s03-1.mp4",
                "reason": "The shared land-animal shot visibly contains a tiger while the name is spoken.",
            },
        ],
        "text_policy": {
            "source_authority": "artifacts/source_text_manifest.json",
            "display_case": "Tt",
            "preserve_punctuation": True,
            "max_content_lines": 3,
            "title_media_policy": "graphics_only",
            "content_media_policy": "motion_preferred",
            "image_policy": "fallback_only",
            "bridge_words": "audio_only_not_displayed",
        },
    }
    (OUT / "artifacts" / "timeline.json").write_text(json.dumps(timeline, indent=2, ensure_ascii=False), encoding="utf-8")
    (OUT / "timeline-data.js").write_text("window.ONE_MINUTE_TIMELINE = " + json.dumps(timeline, ensure_ascii=False) + ";\n", encoding="utf-8")
    (OUT / "artifacts" / "asset_manifest.json").write_text(json.dumps({"assets": [a for section in timeline_sections for a in section["assets"]]}, indent=2), encoding="utf-8")
    print(json.dumps({"duration_ms": 60000, "word_count": len(words), "sections": len(timeline_sections), "motion_assets": 9}, indent=2))


if __name__ == "__main__":
    main()
