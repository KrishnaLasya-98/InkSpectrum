"""Generate a short EVS narration sample using ModelsLab only."""
from __future__ import annotations

import base64
import json
import os
import time
from pathlib import Path

import requests
from dotenv import load_dotenv


PROJECT = Path(__file__).resolve().parents[1]
REPO = PROJECT.parents[1]
REFERENCE = PROJECT / "assets/audio/voice-reference/maya-friendly-cheerful-clone-reference-25s.mp3"
SAMPLE_DIR = PROJECT / "assets/audio/samples"
SOURCE_PATH = SAMPLE_DIR / "modelslab-source-performance.mp3"
OUTPUT_PATH = SAMPLE_DIR / "modelslab-maya-voice-to-voice-sample.mp3"
TTS_URL = "https://modelslab.com/api/v6/voice/text_to_speech"
VOICE_TO_VOICE_URL = "https://modelslab.com/api/v6/voice/voice_to_voice"
FETCH_URL = "https://modelslab.com/api/v6/voice/fetch"
SAMPLE_TEXT = (
    "Let us look closely at the animals around us. Animals are living beings like us, "
    "and they are found in nature. Animals need food, shelter, air, and water to grow "
    "and survive. Can you name one thing every animal needs?"
)


def fail(message: str, data: object | None = None) -> None:
    detail = f"\n{json.dumps(data, indent=2)}" if data is not None else ""
    raise SystemExit(f"{message}{detail}")


def get_url(data: dict) -> str | None:
    value = data.get("output") or data.get("proxy_links") or data.get("links") or data.get("url")
    if isinstance(value, list) and value:
        return str(value[0])
    return value if isinstance(value, str) and value else None


def await_audio(data: dict, api_key: str) -> str:
    direct = get_url(data)
    if data.get("status") == "success" and direct:
        return direct
    request_id = data.get("id") or data.get("request_id") or data.get("fetch_result")
    if not request_id:
        fail("ModelsLab returned neither audio nor a request id", data)
    deadline = time.monotonic() + 180
    while time.monotonic() < deadline:
        response = requests.post(
            f"{FETCH_URL}/{request_id}",
            json={"key": api_key},
            timeout=45,
        )
        polled = response.json()
        direct = get_url(polled)
        if polled.get("status") == "success" and direct:
            return direct
        if polled.get("status") in {"error", "failed"}:
            fail("ModelsLab generation failed", polled)
        time.sleep(3)
    fail("ModelsLab generation timed out", data)


def download(url: str, destination: Path) -> None:
    response = requests.get(url, timeout=120)
    response.raise_for_status()
    destination.write_bytes(response.content)


def as_data_url(path: Path) -> str:
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:audio/mpeg;base64,{encoded}"


def main() -> None:
    load_dotenv(REPO / ".env")
    api_key = os.environ.get("MODELSLAB_API_KEY", "")
    if not api_key:
        fail("MODELSLAB_API_KEY is not configured")
    if not REFERENCE.exists():
        fail(f"Voice reference is missing: {REFERENCE}")
    SAMPLE_DIR.mkdir(parents=True, exist_ok=True)

    tts_response = requests.post(
        TTS_URL,
        json={
            "key": api_key,
            "model_id": "text-to-speech",
            "prompt": SAMPLE_TEXT,
            "voice_id": "nova",
            "language": "american english",
            "speed": "0.82",
        },
        timeout=120,
    )
    tts_data = tts_response.json()
    if tts_response.status_code >= 400 or tts_data.get("status") in {"error", "failed"}:
        fail("ModelsLab source TTS failed", tts_data)
    download(await_audio(tts_data, api_key), SOURCE_PATH)

    conversion_response = requests.post(
        VOICE_TO_VOICE_URL,
        json={
            "key": api_key,
            "init_audio": as_data_url(SOURCE_PATH),
            "target_audio": as_data_url(REFERENCE),
            "base64": True,
            "stream": False,
            "temp": True,
        },
        timeout=180,
    )
    conversion_data = conversion_response.json()
    if conversion_response.status_code >= 400 or conversion_data.get("status") in {"error", "failed"}:
        fail("ModelsLab voice-to-voice conversion failed", conversion_data)
    download(await_audio(conversion_data, api_key), OUTPUT_PATH)
    print(json.dumps({
        "status": "success",
        "provider": "ModelsLab",
        "source_model": "text-to-speech/nova",
        "conversion_model": "voice_to_voice",
        "reference_path": str(REFERENCE),
        "source_path": str(SOURCE_PATH),
        "output_path": str(OUTPUT_PATH),
        "text": SAMPLE_TEXT,
    }, indent=2))


if __name__ == "__main__":
    main()
