"""Regenerate only the concise EVS Lesson 8 opening with the approved Tara voice."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

from dotenv import load_dotenv

from tools.voice.voice_synthesis_pipeline import VoiceSynthesisPipeline


ROOT = Path(__file__).resolve().parents[3]
PROJECT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")

TEXT = (
    "Hello students! Welcome to Lesson Eight, Animal Life. "
    "Do you have any pet animals? How do you look after your pet animal? "
    "In this chapter, we will discover animals around us, land animals, "
    "water animals, birds, and insects. Finally, we will learn where animals "
    "live and the homes they need."
)


def duration(path: Path) -> float:
    value = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
        check=True, capture_output=True, text=True,
    ).stdout.strip()
    return round(float(value), 3)


result = VoiceSynthesisPipeline().execute(
    {
        "narration_segments": [{"section_id": "s01", "text": TEXT, "source_block_type": "concept"}],
        "output_dir": str(PROJECT / "assets/audio/modelslab-tara-opening-v3"),
        "voice_id": "tara",
        "model_id": "text-to-speech",
        "language": "american english",
        "speed": 0.90,
        "enable_stt_qa": False,
        "seed": 8,
    }
)
if not result.success:
    raise SystemExit(result.error)

generated = Path(result.data["narration_manifest"]["segments"][0]["audio_path"])
final_audio = PROJECT / "assets/audio/modelslab-tara-final/s01.wav"
subprocess.run(
    ["ffmpeg", "-y", "-loglevel", "error", "-i", str(generated), "-af", "loudnorm=I=-14:TP=-1.5:LRA=11", "-ar", "48000", "-ac", "2", str(final_audio)],
    check=True,
)
shutil.copy2(final_audio, PROJECT / "hyperframes-agnes-final/assets/audio/s01.wav")

aligned_path = PROJECT / "artifacts/narration_aligned.json"
aligned = json.loads(aligned_path.read_text(encoding="utf-8"))
aligned["segments"][0]["text"] = TEXT
aligned["segments"][0]["words"] = [{"word": word} for word in TEXT.split()]

cursor = 0
for segment in aligned["segments"]:
    audio = PROJECT / f"hyperframes-agnes-final/assets/audio/{segment['section_id']}.wav"
    segment["start_ms"] = round(cursor * 1000)
    cursor += duration(audio)
    segment["end_ms"] = round(cursor * 1000)
aligned_path.write_text(json.dumps(aligned, indent=2), encoding="utf-8")

sync_path = PROJECT / "artifacts/multimedia_sync_plan.json"
sync = json.loads(sync_path.read_text(encoding="utf-8"))
sync["timeline_end_ms"] = round(cursor * 1000)
sync["total_audio_seconds"] = round(cursor, 3)
sync_path.write_text(json.dumps(sync, indent=2), encoding="utf-8")

print(json.dumps({"text": TEXT, "durationSeconds": duration(final_audio), "timelineSeconds": round(cursor, 3)}, indent=2))
