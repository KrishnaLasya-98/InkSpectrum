import json

from tools.audio.fal_elevenlabs_tts import FalElevenLabsTTS


result = FalElevenLabsTTS().execute(
    {
        "text": (
            "Let us look closely at the animals around us. Have you noticed that animals need "
            "many of the same things that we do? Animals are living beings like us which are "
            "found in nature. Animals are found all over the world, and they need food, shelter, "
            "air, and water, like other living beings, to grow and survive. Isn't that interesting?"
        ),
        "voice": "Maya - Friendly and Cheerful",
        "model_id": "multilingual-v2",
        "stability": 0.39,
        "similarity_boost": 1.0,
        "style": 0.2,
        "speed": 0.96,
        "timestamps": True,
        "output_format": "mp3_44100_128",
        "output_path": "projects/evs-lesson-8/assets/audio/samples/maya-reference-match.mp3",
    }
)
print(json.dumps({"success": result.success, "data": result.data, "error": result.error}, indent=2, default=str))
