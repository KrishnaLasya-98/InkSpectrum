"""Generate the clean land-animal establishing shot for EVS Lesson 8."""

from pathlib import Path

from dotenv import load_dotenv

from tools.video.agnes_video import AgnesVideo


ROOT = Path(__file__).resolve().parents[3]
load_dotenv(ROOT / ".env")

output = ROOT / "projects/evs-lesson-8/assets/video/agnes-final/s03-land-clean.mp4"
prompt = (
    "A polished cinematic 3D animated children's educational scene for Indian Class 1. "
    "In one sunny green grassland, show exactly three clearly separated land animals: "
    "one friendly lion on the left, one gentle elephant in the centre, and one friendly "
    "tiger on the right. Each animal appears exactly once. They walk naturally and calmly. "
    "Warm expressive faces, rounded child-friendly design, vibrant colours, soft sunlight, "
    "professional animated-story quality, smooth slow camera movement, wide 16:9 composition."
)
negative = (
    "duplicate animals, extra animals, two tigers, two lions, two elephants, merged bodies, "
    "malformed anatomy, aggression, text, labels, captions, logos, watermarks, borders, "
    "still image, loop, replay, stutter, camera jump"
)

result = AgnesVideo().execute(
    {
        "prompt": prompt,
        "negative_prompt": negative,
        "operation": "text_to_video",
        "model_id": "agnes-video-v2.0",
        "duration": "6",
        "resolution": "720P",
        "aspect_ratio": "16:9",
        "seed": 830318,
        "output_path": str(output),
    }
)

if not result.success:
    raise SystemExit(result.error)

print(output)
