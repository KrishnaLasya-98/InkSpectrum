import json

from tools.voice.voice_synthesis_pipeline import VoiceSynthesisPipeline


result = VoiceSynthesisPipeline().execute(
    {
        "narration_segments": [
            {
                "section_id": "modelslab-maya-sample",
                "source_block_type": "concept",
                "text": (
                    "Let us look closely at the animals around us. Animals are living beings like us "
                    "which are found in nature. Animals need food, shelter, air, and water to grow "
                    "and survive. Can you name one thing every animal needs?"
                ),
            }
        ],
        "output_dir": "projects/evs-lesson-8/assets/audio/samples/modelslab-tara",
        "voice_id": "tara",
        "model_id": "text-to-speech",
        "language": "american english",
        "speed": 0.90,
        "seed": 8,
    }
)

print(json.dumps({"success": result.success, "data": result.data, "error": result.error}, indent=2, default=str))
