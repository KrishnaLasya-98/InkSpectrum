"""Generate the approved representative Agnes 2.5 visual sample."""
from __future__ import annotations

import json

from tools.video.agnes_video import AgnesVideo


result = AgnesVideo().execute({
    "prompt": (
        "A polished 3D animated educational scene for Class 1 children about animal homes. "
        "One friendly brown rabbit with correct anatomy emerges once from a round earthen "
        "burrow entrance, takes one small forward hop, picks up one orange carrot, and begins "
        "one gentle nibble. The rabbit then holds naturally with subtle breathing and one ear "
        "twitch. Bright soft daylight, green grass, small wildflowers, warm soil, uncluttered "
        "storybook-quality 3D environment, rounded appealing forms, accurate four legs and two "
        "ears. Fixed medium-wide camera, fixed focal length, stable background geometry, one "
        "continuous shot, physically plausible motion, clean ending frame. No dialogue and no text."
    ),
    "negative_prompt": (
        "loop, looping, seamless loop, replay, repeat, restart, rewind, cycle, cyclical, "
        "back and forth, oscillation, pendulum, bounce in place, zoom in, zoom out, push in, "
        "pull out, Ken Burns, pan, tilt, dolly, camera movement, cuts, scene changes, morphing, "
        "extra limbs, extra ears, duplicate rabbit, distorted anatomy, stutter, frame jump, "
        "double image, photorealistic footage, scary expression, captions, labels, letters, "
        "words, logo, watermark, interface"
    ),
    "operation": "text_to_video",
    "model_id": "agnes-video-v2.0",
    "duration": "5",
    "resolution": "720P",
    "aspect_ratio": "16:9",
    "seed": 8109,
    "output_path": "projects/evs-lesson-8/assets/video/agnes-samples/s09-rabbit-burrow-v20-sample-16x9.mp4",
})

print(json.dumps({"success": result.success, "data": result.data, "error": result.error}, indent=2, default=str))
