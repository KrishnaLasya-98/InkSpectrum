"""Generate and normalize all approved EVS Lesson 8 narration sections."""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

from tools.voice.voice_synthesis_pipeline import VoiceSynthesisPipeline


PROJECT = Path(__file__).resolve().parents[1]
SOURCE = PROJECT / "artifacts/narration_manifest.json"
RAW_DIR = PROJECT / "assets/audio/modelslab-tara-raw"
FINAL_DIR = PROJECT / "assets/audio/modelslab-tara-final"
OUTPUT_MANIFEST = PROJECT / "artifacts/narration_manifest_modelslab_tara.json"


def probe_duration(path: Path) -> float:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
        check=True, capture_output=True, text=True,
    )
    return round(float(result.stdout.strip()), 3)


def main() -> None:
    source = json.loads(SOURCE.read_text(encoding="utf-8"))
    segments = [
        {
            "section_id": item["section_id"],
            "text": item["text"],
            "source_block_type": "concept",
        }
        for item in source["segments"]
    ]
    result = VoiceSynthesisPipeline().execute({
        "narration_segments": segments,
        "output_dir": str(RAW_DIR),
        "voice_id": "tara",
        "model_id": "text-to-speech",
        "language": "american english",
        "speed": 0.90,
        "enable_stt_qa": False,
        "seed": 8,
    })
    if not result.success:
        raise SystemExit(result.error)

    FINAL_DIR.mkdir(parents=True, exist_ok=True)
    normalized = []
    for segment in result.data["narration_manifest"]["segments"]:
        source_path = Path(segment["audio_path"])
        destination = FINAL_DIR / f"{segment['section_id']}.wav"
        subprocess.run([
            "ffmpeg", "-y", "-loglevel", "error", "-i", str(source_path),
            "-af", "loudnorm=I=-14:TP=-1.5:LRA=11", "-ar", "48000", "-ac", "2",
            str(destination),
        ], check=True)
        segment["audio_path"] = str(destination)
        segment["duration_seconds"] = probe_duration(destination)
        segment["provider_text_used"] = segment["text"]
        segment["qa_status"] = "technical_pass_transcript_pending"
        normalized.append(segment)

    manifest = result.data["narration_manifest"]
    manifest["segments"] = normalized
    manifest["total_duration_seconds"] = round(sum(x["duration_seconds"] for x in normalized), 3)
    manifest["voice_name"] = "tara"
    manifest["metadata"].update({
        "provider": "ModelsLab",
        "sample_approved_by_user": True,
        "normalization": "loudnorm=I=-14:TP=-1.5:LRA=11; 48kHz stereo PCM",
        "transcript_qa": "pending repaired STT adapter",
    })
    OUTPUT_MANIFEST.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps({
        "status": "success",
        "segments": len(normalized),
        "total_duration_seconds": manifest["total_duration_seconds"],
        "manifest": str(OUTPUT_MANIFEST),
    }, indent=2))


if __name__ == "__main__":
    main()
