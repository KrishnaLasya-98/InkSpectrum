"""Align the approved narration audio to the exact textbook-derived script words."""

from __future__ import annotations

import json
import re
import wave
from difflib import SequenceMatcher
from pathlib import Path

from faster_whisper import WhisperModel


PROJECT = Path(__file__).resolve().parents[1]
ARTIFACTS = PROJECT / "artifacts"
COMPOSITION = PROJECT / "hyperframes-agnes-final"


def norm(value: str) -> str:
    return re.sub(r"[^a-z0-9']+", "", value.lower())


def interpolate(words: list[dict], section_start: int, section_end: int) -> None:
    known = [index for index, word in enumerate(words) if "startMs" in word]
    anchors = [(-1, section_start)] + [(i, words[i]["startMs"]) for i in known] + [(len(words), section_end)]
    for (left_i, left_t), (right_i, right_t) in zip(anchors, anchors[1:]):
        missing = right_i - left_i - 1
        if missing <= 0:
            continue
        step = max(80, (right_t - left_t) / (missing + 1))
        for offset in range(1, missing + 1):
            index = left_i + offset
            start = round(left_t + step * offset)
            words[index]["startMs"] = start
            words[index]["endMs"] = round(min(right_t, start + step * 0.86))
    for index, word in enumerate(words):
        next_start = words[index + 1]["startMs"] if index + 1 < len(words) else section_end
        word["endMs"] = max(word["startMs"] + 60, min(word.get("endMs", next_start), next_start))


aligned = json.loads((ARTIFACTS / "narration_aligned.json").read_text(encoding="utf-8"))
captions = []
model = WhisperModel("small.en", device="cpu", compute_type="int8")

# Audio is authoritative. Rebuild the sequential section clock from the WAV
# frame counts before aligning words; retaining historical segment boundaries
# after a silence trim reintroduces the exact onset/offset drift this script is
# meant to remove.
cursor_ms = 0
for segment in aligned["segments"]:
    audio_path = COMPOSITION / "assets" / "audio" / f"{segment['section_id']}.wav"
    with wave.open(str(audio_path), "rb") as wav:
        duration_ms = round(wav.getnframes() * 1000 / wav.getframerate())
    segment["start_ms"] = cursor_ms
    segment["end_ms"] = cursor_ms + duration_ms
    cursor_ms += duration_ms

report = []
for segment in aligned["segments"]:
    section_id = segment["section_id"]
    start_ms = segment["start_ms"]
    end_ms = segment["end_ms"]
    audio_path = COMPOSITION / "assets" / "audio" / f"{section_id}.wav"
    parts, _ = model.transcribe(
        str(audio_path),
        language="en",
        beam_size=5,
        vad_filter=False,
        word_timestamps=True,
        condition_on_previous_text=False,
    )
    heard = []
    for part in parts:
        for item in part.words or []:
            token = norm(item.word)
            if token:
                heard.append({"token": token, "start": start_ms + round(item.start * 1000), "end": start_ms + round(item.end * 1000)})

    refs = [{"text": word["word"], "token": norm(word["word"])} for word in segment["words"]]
    matcher = SequenceMatcher(None, [word["token"] for word in refs], [word["token"] for word in heard], autojunk=False)
    output = [{"word": word["text"]} for word in refs]
    matched = 0
    for block in matcher.get_matching_blocks():
        for offset in range(block.size):
            ref_index = block.a + offset
            heard_word = heard[block.b + offset]
            output[ref_index]["startMs"] = heard_word["start"]
            output[ref_index]["endMs"] = heard_word["end"]
            matched += 1
    interpolate(output, start_ms, end_ms)
    segment["words"] = output

    for index, word in enumerate(output):
        captions.append({
            "word": word["word"],
            "startMs": word["startMs"],
            "endMs": word["endMs"],
            "pageBreakAfter": bool(re.search(r"[.!?]$", word["word"])) or (index + 1) % 10 == 0,
        })
    report.append({"section": section_id, "referenceWords": len(refs), "heardWords": len(heard), "matchedWords": matched})

(ARTIFACTS / "narration_aligned.json").write_text(json.dumps(aligned, indent=2), encoding="utf-8")
(ARTIFACTS / "word_captions.json").write_text(json.dumps(captions, indent=2), encoding="utf-8")
(ARTIFACTS / "actual_alignment_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")

sync_path = ARTIFACTS / "multimedia_sync_plan.json"
if sync_path.exists():
    sync = json.loads(sync_path.read_text(encoding="utf-8"))
    segments_by_id = {segment["section_id"]: segment for segment in aligned["segments"]}
    sync["timeline_end_ms"] = cursor_ms
    sync["total_audio_seconds"] = round(cursor_ms / 1000, 3)
    for section in sync.get("sections", []):
        segment = segments_by_id.get(section.get("section_id"))
        if not segment:
            continue
        section["audio_duration_seconds"] = round((segment["end_ms"] - segment["start_ms"]) / 1000, 3)
        for cue in section.get("cues", []):
            wanted = [norm(token) for token in cue.get("phrase", "").split() if norm(token)]
            tokens = [norm(word["word"]) for word in segment["words"]]
            match_index = next((
                index for index in range(len(tokens) - len(wanted) + 1)
                if wanted and tokens[index:index + len(wanted)] == wanted
            ), None)
            if match_index is None:
                continue
            start = segment["words"][match_index]["startMs"]
            duration = round(float(cue.get("suggested_duration_seconds", 0)) * 1000)
            cue["start_seconds_relative"] = round((start - segment["start_ms"]) / 1000, 3)
            cue["start_ms_absolute"] = start
            cue["end_ms_absolute"] = min(segment["end_ms"], start + duration)
            cue["alignment_status"] = "actual_audio_word_aligned"
    sync_path.write_text(json.dumps(sync, indent=2), encoding="utf-8")
print(json.dumps(report, indent=2))
