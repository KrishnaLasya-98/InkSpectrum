import json
import subprocess
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[1]
manifest = json.loads((PROJECT / "artifacts" / "narration_manifest.json").read_text(encoding="utf-8"))
out_dir = PROJECT / "assets" / "audio" / "indian-english-final"
out_dir.mkdir(parents=True, exist_ok=True)

hooks = {
    "s01": ("Hello, young explorers! Are you ready to meet the amazing animals around us? ", " Let us begin our animal adventure!"),
    "s02": ("Look around you. Animals are living beings, just like us. ", " Can you name one thing every animal needs?"),
    "s03": ("Now let us discover where animals live. ", " Watch carefully and notice the difference between land and water animals."),
    "s04": ("Look up! Here come the birds. ", " Can you flap your arms like a bird's wings?"),
    "s05": ("Now let us meet some tiny creatures. ", " Count carefully: how many legs does an insect have?"),
    "s06": ("Some animals live close to people. ", " Which pet would you like to care for?"),
    "s07": ("Let us quietly enter the forest. ", " Remember, wild animals belong in the wild."),
    "s08": ("Every animal needs a safe place and suitable food. ", " Let us match each animal with its home and food."),
    "s09": ("First, let us visit a lion and a rabbit. ", " Their homes and food are very different, aren't they?"),
    "s10": ("Next, look at birds and busy ants. ", " These animals build very different homes."),
    "s11": ("People make special homes for some domestic animals. ", " Listen carefully to the name of each home."),
    "s12": ("Great learning! Let us quickly remember the main ideas. ", " Well done! You remembered the lesson."),
    "s13": ("New words become easy when we explain them clearly. ", " Say each new word with me."),
    "s14": ("It is question time! Think before you answer. ", " Take your time and say your answer aloud."),
    "s15": ("Now choose the correct answer. Listen to every option carefully. ", " Excellent effort!"),
    "s16": ("Let us finish with a creative activity and an important promise. ", " Be kind, be gentle, and always protect animals."),
}

result_segments = []
for segment in manifest["segments"]:
    sid = segment["section_id"]
    prefix, suffix = hooks[sid]
    text = prefix + segment["text"].strip() + suffix
    raw = out_dir / f"{sid}.raw.mp3"
    wav = out_dir / f"{sid}.wav"
    vtt = out_dir / f"{sid}.vtt"
    subprocess.run([
        "edge-tts", "--voice", "en-IN-PrabhatNeural", "--rate=-10%", "--pitch=+0Hz",
        "--text", text, "--write-media", str(raw), "--write-subtitles", str(vtt)
    ], check=True)
    subprocess.run([
        "ffmpeg", "-y", "-loglevel", "error", "-i", str(raw),
        "-af", "loudnorm=I=-14:TP=-1.5:LRA=11", "-ar", "48000", "-ac", "2", str(wav)
    ], check=True)
    probe = subprocess.run([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=nw=1:nk=1", str(wav)
    ], check=True, capture_output=True, text=True)
    result_segments.append({
        "section_id": sid,
        "textbook_text": segment["text"],
        "engaging_narration_text": text,
        "audio_path": str(wav.relative_to(PROJECT)).replace("\\", "/"),
        "subtitle_path": str(vtt.relative_to(PROJECT)).replace("\\", "/"),
        "duration_seconds": round(float(probe.stdout.strip()), 3),
        "voice": "en-IN-PrabhatNeural",
        "rate": "-10%",
    })

output_manifest = {
    "version": "2.0",
    "provider": "edge-tts",
    "voice": "en-IN-PrabhatNeural",
    "language": "en-IN",
    "content_policy": "textbook text preserved; short teacher hooks and transitions added",
    "segments": result_segments,
    "total_duration_seconds": round(sum(s["duration_seconds"] for s in result_segments), 3),
}
(PROJECT / "artifacts" / "narration_manifest_indian.json").write_text(
    json.dumps(output_manifest, indent=2, ensure_ascii=False), encoding="utf-8"
)
print(json.dumps({"segments": len(result_segments), "total_duration_seconds": output_manifest["total_duration_seconds"]}, indent=2))
