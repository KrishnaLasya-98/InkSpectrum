"""Generate two normal-speed semantic bridge clips for EVS Lesson 8."""
from __future__ import annotations

from pathlib import Path
import time

from dotenv import load_dotenv

from tools.video.modelslab_video import ModelsLabVideo


ROOT = Path(__file__).resolve().parents[3]
load_dotenv(ROOT / ".env")
OUTPUT_DIR = ROOT / "projects/evs-lesson-8/assets/video/agnes-final"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

STYLE = (
    "Polished cinematic 3D animation for Indian Class 1 children, warm colourful storybook world, "
    "rounded appealing forms, soft natural daylight, expressive friendly characters with correct anatomy, "
    "clean layered environment, professional animated-film quality, wide 16:9 composition. Normal real-time "
    "motion at natural speed for the full six seconds. Fixed medium-wide camera, stable background geometry, "
    "one continuous shot, no cuts, no dialogue and no text. "
)

NEGATIVE = (
    "slow motion, frozen pose, still image, time lapse, fast motion, loop, replay, repeat, restart, rewind, "
    "back and forth, camera jump, cuts, scene changes, zoom, pan, tilt, dolly, morphing, disappearing character, "
    "duplicate character, duplicate animal, extra animal, merged body, extra limbs, malformed hands, malformed "
    "anatomy, aggression, frightening expression, photorealistic live-action footage, captions, labels, letters, "
    "words, logo, watermark, border, interface"
)

JOBS = [
    {
        "name": "s01-homes-extra.mp4",
        "seed": 801171,
        "prompt": (
            "One cohesive cheerful countryside panorama presents animal homes in a clear left-to-right layout. "
            "At upper left, one small bird tends a twig nest on a low branch. At lower left, one friendly rabbit "
            "takes two natural hops beside a round earthen burrow. In the centre, one friendly dog walks beside "
            "a wooden kennel. On the right, one gentle cow stands beside a clean shed and one friendly horse "
            "stands beside a stable. Every animal and home remains visible, separated, and correctly paired. "
        ),
    },
    {
        "name": "s02-care-protection-extra.mp4",
        "seed": 802271,
        "prompt": (
            "In one sunny school garden, one kind Indian woman teacher and two cheerful Indian children gently "
            "care for friendly animals. The teacher places a bowl of fresh food beside one calm dog, one child "
            "refills a clean blue water bowl for one rabbit, and the other child places soft dry straw inside a "
            "small safe wooden shelter. All people and animals remain clearly visible and separate. Their actions "
            "are calm, purposeful, and easy for young children to understand. Natural ordinary-speed movement. "
        ),
    },
]


def generate(job: dict[str, object]) -> tuple[str, bool, str]:
    output = OUTPUT_DIR / str(job["name"])
    result = ModelsLabVideo().execute(
        {
            "prompt": STYLE + str(job["prompt"]),
            "negative_prompt": NEGATIVE,
            "operation": "text_to_video",
            "model_id": "h3-minimax-t2v",
            "duration": "6",
            "resolution": "768P",
            "seed": int(job["seed"]),
            "output_path": str(output),
        }
    )
    return output.name, result.success, str(result.error or result.data)


def main() -> None:
    failures: list[str] = []
    for job in JOBS:
        for attempt in range(1, 4):
            name, success, detail = generate(job)
            print(f"{name}: {'OK' if success else 'FAILED'}", flush=True)
            if success:
                break
            print(detail, flush=True)
            if attempt < 3:
                time.sleep(20 * attempt)
        else:
            failures.append(str(job["name"]))
        time.sleep(12)
    if failures:
        raise SystemExit(f"Generation failed: {', '.join(failures)}")


if __name__ == "__main__":
    main()
