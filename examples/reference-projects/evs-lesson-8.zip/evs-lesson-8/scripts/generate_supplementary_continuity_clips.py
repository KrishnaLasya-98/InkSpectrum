"""Generate normal-speed supplementary clips for EVS Lesson 8.

Agnes is preferred. The current run uses the project's ModelsLab fallback after
the Agnes API repeatedly returned HTTP 429 during submission and polling.
"""
from __future__ import annotations

from pathlib import Path
import time

from dotenv import load_dotenv

from tools.video.modelslab_video import ModelsLabVideo


ROOT = Path(__file__).resolve().parents[3]
load_dotenv(ROOT / ".env")

OUTPUT_DIR = ROOT / "projects/evs-lesson-8/assets/video/agnes-final"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

STYLE = (
    "Polished cinematic 3D animation for Indian Class 1 children, warm colourful "
    "storybook world, rounded appealing forms, soft natural daylight, expressive friendly "
    "animals with correct anatomy, clean layered environment, professional animated-film "
    "quality, wide 16:9 composition. Normal real-time motion at natural speed throughout "
    "the full six seconds, with clear purposeful movement and no slow motion. Fixed medium-wide "
    "camera, stable background geometry, one continuous shot, no cuts, no dialogue and no text. "
)

NEGATIVE = (
    "slow motion, slowed motion, frozen pose, still image, lingering shot, time lapse, fast motion, "
    "loop, looping, replay, repeat, restart, rewind, back and forth, camera jump, cuts, scene changes, "
    "zoom, pan, tilt, dolly, morphing, disappearing animal, duplicate animal, extra animal, merged body, "
    "extra limbs, malformed anatomy, aggression, frightening expression, photorealistic live-action footage, "
    "captions, labels, letters, words, logo, watermark, border, interface"
)

JOBS = [
    {
        "name": "s07-wild-extra.mp4",
        "seed": 807071,
        "prompt": (
            "A friendly tiger and a friendly lion walk side by side along one broad path in a cohesive "
            "sunlit forest. Both animals remain clearly visible and separate for the entire shot. They take "
            "several natural steps at ordinary walking speed while leaves move gently in the breeze. "
            "The lion stays on the left and the tiger stays on the right. "
        ),
    },
    {
        "name": "s09-homes-extra.mp4",
        "seed": 809091,
        "prompt": (
            "One readable woodland clearing showing two animal homes at the same time: on the left, one "
            "friendly lion stands calmly beside a rocky den entrance; on the right, one friendly rabbit "
            "takes two natural hops beside a round earthen burrow entrance. The lion and rabbit remain "
            "separate and clearly visible, with no chase and no aggression. "
        ),
    },
    {
        "name": "s10-homes-extra.mp4",
        "seed": 810101,
        "prompt": (
            "One cohesive sunny garden displays three animal-built homes in a clear triangular composition: "
            "a small bird tending a twig nest on a low branch at upper left, ants walking naturally around a "
            "rounded anthill at lower centre, and a few gentle bees flying near a hanging beehive at upper "
            "right. All three homes stay visible throughout; actions are natural and easy for young children to read. "
        ),
    },
    {
        "name": "s11-human-homes-extra.mp4",
        "seed": 811111,
        "prompt": (
            "One cohesive cheerful farmyard with three clearly separated human-made animal homes: a friendly "
            "dog walking normally beside its wooden kennel on the left, one gentle cow beside an open clean shed "
            "in the centre, and one friendly horse beside a stable on the right. All animals and homes remain "
            "visible and correctly paired throughout the shot. "
        ),
    },
]


def generate(job: dict[str, object]) -> tuple[str, bool, str]:
    output = OUTPUT_DIR / str(job["name"])
    result = ModelsLabVideo().execute(
        {
            "prompt": STYLE + str(job["prompt"]),
            "negative_prompt": NEGATIVE,
            "operation": "text_to_video",
            "model_id": "h3-minimax-t2v",
            "duration": "6",
            "resolution": "768P",
            "seed": int(job["seed"]),
            "output_path": str(output),
        }
    )
    return output.name, result.success, str(result.error or result.data)


def main() -> None:
    failures: list[str] = []
    for job in JOBS:
        for attempt in range(1, 4):
            name, success, detail = generate(job)
            print(f"{name}: {'OK' if success else 'FAILED'}")
            if success:
                break
            print(detail)
            if attempt < 3:
                time.sleep(20 * attempt)
        else:
            failures.append(str(job["name"]))
        time.sleep(12)
    if failures:
        raise SystemExit(f"Generation failed: {', '.join(failures)}")


if __name__ == "__main__":
    main()
