"""EVS Lesson 8 final audio, subtitle, and atomic output stages.

This module deliberately keeps the script timeline as the source of truth.  It
does not infer timing from the Remotion plan or from generated media lengths.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import textwrap
from pathlib import Path
from typing import Any

W, H, FPS = 1920, 1080, 30
_PROJECT_ROOT = Path(__file__).resolve().parents[2]
_PROJ = _PROJECT_ROOT / "projects" / "evs-lesson-8"


def sh(cmd: list[str], timeout: int = 900) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=_PROJECT_ROOT)
    if result.returncode != 0:
        raise RuntimeError(
            f"cmd failed ({result.returncode}): {' '.join(cmd)}\n"
            f"{result.stderr[-1200:]}"
        )
    return result


def probe_media(path: Path) -> dict[str, Any]:
    """Return ffprobe JSON, raising for missing/corrupt media."""
    result = subprocess.run(
        [
            "ffprobe", "-v", "error", "-show_streams", "-show_format",
            "-of", "json", str(path),
        ],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"ffprobe failed for {path}: {result.stderr[-500:]}")
    data = json.loads(result.stdout or "{}")
    streams = data.get("streams", [])
    duration = float(data.get("format", {}).get("duration", 0) or 0)
    return {
        "duration": duration,
        "has_video": any(s.get("codec_type") == "video" for s in streams),
        "has_audio": any(s.get("codec_type") == "audio" for s in streams),
        "streams": streams,
    }


def probe_duration(path: Path) -> float:
    return float(probe_media(path)["duration"])


def _duration_to_ts(secs: float) -> str:
    # Round the complete timestamp first so 59.9999 carries into the minute.
    total_ms = max(0, int(round(float(secs) * 1000)))
    hours, rem = divmod(total_ms, 3_600_000)
    minutes, rem = divmod(rem, 60_000)
    seconds, millis = divmod(rem, 1_000)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d},{millis:03d}"


def _escape_subtitle_path(path: Path) -> str:
    """Build an absolute path safe inside ffmpeg's subtitles filter.

    ``subprocess.run`` does not invoke a shell, so shell quoting is not used.
    The filter parser still requires the Windows drive colon and spaces to be
    escaped in the single argv value.
    """
    value = path.resolve().as_posix()
    value = re.sub(r"^([A-Za-z]):/", r"\1\\:/", value)
    return value.replace(" ", r"\ ")


def subtitle_filter(subtitle: Path, style: str | None = None) -> str:
    style = style or (
        "FontName=Arial,FontSize=22,PrimaryColour=&H00FFFFFF,"
        "OutlineColour=&H00000000,Outline=2,Alignment=2,MarginV=36"
    )
    # subprocess passes this as one argv token, so shell quoting is not
    # available here. Escape commas explicitly because they otherwise delimit
    # filter options on Windows builds of FFmpeg.
    escaped_style = style.replace("\\", r"\\").replace(",", r"\,")
    return f"subtitles={_escape_subtitle_path(subtitle)}:force_style={escaped_style}"


def _subtitle_cues(subtitle: Path) -> list[tuple[float, float, str]]:
    """Parse the canonical SRT into drawtext-ready timed cues."""
    raw = subtitle.read_text(encoding="utf-8-sig")
    cues: list[tuple[float, float, str]] = []
    pattern = re.compile(
        r"(?:^|\n)\s*\d+\s*\n"
        r"(?P<start>\d{2}:\d{2}:\d{2},\d{3})\s+-->\s+"
        r"(?P<end>\d{2}:\d{2}:\d{2},\d{3})\s*\n"
        r"(?P<text>.*?)(?=\n\s*\n|\Z)",
        flags=re.S,
    )

    def seconds(value: str) -> float:
        hours, minutes, rest = value.split(":")
        whole, millis = rest.split(",")
        return int(hours) * 3600 + int(minutes) * 60 + int(whole) + int(millis) / 1000

    for match in pattern.finditer(raw):
        text = " ".join(line.strip() for line in match.group("text").splitlines()).strip()
        if text:
            cues.append((seconds(match.group("start")), seconds(match.group("end")), text))
    if not cues:
        raise RuntimeError(f"subtitle file contains no cues: {subtitle}")
    return cues


def drawtext_subtitle_filter(subtitle: Path) -> tuple[str, list[Path]]:
    """Build a libass-free subtitle filter using the available drawtext filter."""
    cue_dir = subtitle.parent / f"{subtitle.stem}_drawtext"
    cue_dir.mkdir(parents=True, exist_ok=True)
    filters: list[str] = []
    cue_files: list[Path] = []
    for index, (start, end, text) in enumerate(_subtitle_cues(subtitle), 1):
        cue_path = cue_dir / f"cue_{index:03d}.txt"
        wrapped = "\n".join(textwrap.wrap(text, width=72, break_long_words=False, break_on_hyphens=False))
        cue_path.write_text(wrapped, encoding="utf-8", newline="\n")
        cue_files.append(cue_path)
        filters.append(
            "drawtext="
            "fontfile='C\\:/Windows/Fonts/arial.ttf':"
            f"textfile='{_escape_subtitle_path(cue_path)}':"
            "fontcolor=white:fontsize=30:line_spacing=8:"
            "borderw=2:bordercolor=black@0.85:box=1:"
            "boxcolor=0x102A43@0.78:boxborderw=18:"
            "x=(w-text_w)/2:y=h-text_h-42:"
            f"enable='between(t\\,{start:.3f}\\,{end:.3f})'"
        )
    return ",".join(filters), cue_files


def build_subtitles(script: dict[str, Any], out_srt: Path) -> Path:
    """Generate subtitles from canonical script section windows."""
    lines: list[str] = []
    for index, section in enumerate(script["sections"], 1):
        start = float(section["start_seconds"])
        end = float(section["end_seconds"])
        lines.extend([
            str(index),
            f"{_duration_to_ts(start)} --> {_duration_to_ts(end)}",
            str(section.get("text", "")).strip(),
            "",
        ])
    out_srt.parent.mkdir(parents=True, exist_ok=True)
    out_srt.write_text("\n".join(lines), encoding="utf-8", newline="\n")
    return out_srt


def _resolve_audio_path(value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else _PROJ / path


def add_audio_and_mix(
    full: Path,
    narration: dict[str, Any],
    script: dict[str, Any],
    out_mix: Path,
) -> Path:
    """Place narration at script section offsets into exact-length stereo audio."""
    del full  # The script timeline, not video probing, controls the audio length.
    total_dur = float(script["total_duration_seconds"])
    out_mix.parent.mkdir(parents=True, exist_ok=True)
    base = out_mix.with_name("base.wav")
    sh([
        "ffmpeg", "-y", "-f", "lavfi",
        "-i", "anullsrc=channel_layout=stereo:sample_rate=48000",
        "-t", str(total_dur), "-ar", "48000", "-ac", "2", str(base),
    ])

    nar_by_sid = {item["section_id"]: item for item in narration.get("segments", [])}
    inputs: list[str] = ["ffmpeg", "-y", "-i", str(base)]
    filters: list[str] = []
    for index, section in enumerate(script["sections"], 1):
        sid = section["id"]
        segment = nar_by_sid.get(sid)
        if not segment:
            raise RuntimeError(f"narration segment missing for {sid}")
        audio_path = _resolve_audio_path(str(segment["audio_path"]))
        if not audio_path.exists():
            raise RuntimeError(f"narration audio missing for {sid}: {audio_path}")
        inputs.extend(["-i", str(audio_path)])
        delay_ms = int(round(float(section["start_seconds"]) * 1000))
        filters.append(
            f"[{index}:a]aformat=sample_fmts=fltp:sample_rates=48000:"
            f"channel_layouts=stereo,adelay={delay_ms}:all=1[nar{index}]"
        )

    labels = "".join(f"[nar{i}]" for i in range(1, len(filters) + 1))
    filters.append(
        f"[0:a]{labels}amix=inputs={len(filters) + 1}:normalize=0:"
        f"dropout_transition=0,atrim=duration={total_dur:.3f},asetpts=N/SR/TB[am]"
    )
    sh(inputs + [
        "-filter_complex", ";".join(filters), "-map", "[am]",
        "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le", "-t", str(total_dur),
        str(out_mix),
    ])
    return out_mix


def _atomic_replace_valid(path: Path, expected_duration: float, require_audio: bool = False) -> None:
    info = probe_media(path)
    if not info["has_video"]:
        raise RuntimeError(f"output has no video stream: {path}")
    if require_audio and not info["has_audio"]:
        raise RuntimeError(f"output has no audio stream: {path}")
    if abs(float(info["duration"]) - expected_duration) > 2.0:
        raise RuntimeError(
            f"output duration {info['duration']:.3f}s is outside target "
            f"{expected_duration:.3f}s: {path}"
        )


def final_encode(
    mix: Path,
    subtitle: Path,
    out_mp4: Path,
    full: Path,
    target_duration: float | None = None,
) -> Path:
    """Normalize, mux, subtitle-burn, validate, and atomically publish final MP4."""
    total_dur = float(target_duration or probe_duration(full))
    norm = mix.with_name("mix_norm.wav")
    sh([
        "ffmpeg", "-y", "-i", str(mix),
         "-af", f"loudnorm=I=-17.5:TP=-2.5:LRA=10.3,atrim=duration={total_dur:.3f}",
        "-ar", "48000", "-ac", "2", "-t", str(total_dur),
        "-c:a", "pcm_s16le", str(norm),
    ])

    # Keep the prior no-subtitle artifact intact. On Windows it may still be
    # open in a media previewer, which makes replacing it fail with WinError 5.
    nosub_part = out_mp4.with_name("final_nosub.current.part.mp4")
    nosub = out_mp4.with_name("final_nosub.current.mp4")
    out_mp4.parent.mkdir(parents=True, exist_ok=True)
    if nosub_part.exists():
        nosub_part.unlink()
    sh([
        "ffmpeg", "-y", "-i", str(full), "-i", str(norm),
        "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy",
        "-c:a", "aac", "-b:a", "192k", "-t", str(total_dur),
        "-movflags", "+faststart", str(nosub_part),
    ])
    _atomic_replace_valid(nosub_part, total_dur, require_audio=True)
    nosub_part.replace(nosub)

    final_part = out_mp4.with_name(out_mp4.stem + ".part.mp4")
    if final_part.exists():
        final_part.unlink()
    subtitle_video_filter, _cue_files = drawtext_subtitle_filter(subtitle)
    sh([
        "ffmpeg", "-y", "-i", str(nosub), "-vf", subtitle_video_filter,
        "-c:v", "libx264", "-crf", "18", "-preset", "medium",
        "-pix_fmt", "yuv420p", "-c:a", "copy", "-t", str(total_dur),
        "-movflags", "+faststart", str(final_part),
    ])
    _atomic_replace_valid(final_part, total_dur, require_audio=True)
    final_part.replace(out_mp4)
    return out_mp4
