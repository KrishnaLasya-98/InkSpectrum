"""EVS Lesson 8 deterministic compositor.

The canonical inputs are ``artifacts/script.json`` and
``artifacts/narration_manifest.json``.  Generated clips are normalized into
script section windows, then educational overlays are applied on top of the
video before the audio/subtitle stage runs.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
PROJ = ROOT / "projects" / "evs-lesson-8"
ART = PROJ / "artifacts"
ASSET = PROJ / "assets" / "video" / "scenes"
TMP = PROJ / "renders" / "compose_tmp"
OUT = PROJ / "renders" / "final_render.mp4"
REPORT = PROJ / "renders" / "render_report.json"

W, H, FPS = 1920, 1080, 30
CLIP_DURATION_S = 10
TARGET_TOLERANCE_S = 2.0

_COMMANDS: list[str] = []


def _command_text(cmd: list[str]) -> str:
    return " ".join(f'"{part}"' if " " in part else part for part in cmd)


def sh(cmd: list[str], timeout: int = 900) -> None:
    _COMMANDS.append(_command_text(cmd))
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=ROOT)
    if result.returncode != 0:
        raise RuntimeError(
            f"cmd failed ({result.returncode}): {_command_text(cmd)}\n"
            f"{result.stderr[-1200:]}"
        )


def probe_media(path: Path) -> dict[str, Any]:
    result = subprocess.run(
        [
            "ffprobe", "-v", "error", "-show_streams", "-show_format",
            "-of", "json", str(path),
        ],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"ffprobe failed for {path}: {result.stderr[-500:]}")
    data = json.loads(result.stdout or "{}")
    streams = data.get("streams", [])
    return {
        "duration": float(data.get("format", {}).get("duration", 0) or 0),
        "has_video": any(s.get("codec_type") == "video" for s in streams),
        "has_audio": any(s.get("codec_type") == "audio" for s in streams),
    }


def probe_duration(path: Path) -> float:
    return float(probe_media(path)["duration"])


def probe_ok(
    path: Path,
    min_seconds: float = 4.0,
    max_seconds: float = 120.0,
) -> bool:
    """Require readable MP4 media with a video stream and sane duration."""
    if not path.is_file() or path.suffix.lower() != ".mp4":
        return False
    try:
        info = probe_media(path)
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError):
        return False
    duration = float(info["duration"])
    return bool(info["has_video"] and min_seconds <= duration <= max_seconds)


def clips_for_section(sid: str) -> list[Path]:
    directory = ASSET / sid
    if not directory.is_dir():
        return []
    return [
        clip for clip in sorted(directory.glob(f"{sid}-*.mp4"))
        if clip.stat().st_size > 100_000 and probe_ok(clip)
    ]


def _concat_list(path: Path, files: list[Path]) -> None:
    path.write_text(
        "\n".join(f"file '{item.resolve().as_posix()}'" for item in files),
        encoding="utf-8",
        newline="\n",
    )


def build_section_segment(
    section_id: str,
    clips: list[Path],
    out_seg: Path,
    target_dur: float,
) -> None:
    """Normalize, trim, and cycle usable clips to exactly one section window."""
    if not clips:
        raise RuntimeError(
            f"No usable video clips found for {section_id}; expected MP4 clips "
            f"under {ASSET / section_id}"
        )
    for clip in clips:
        if not probe_ok(clip):
            raise RuntimeError(f"clip failed MP4/video-stream validation: {clip}")

    TMP.mkdir(parents=True, exist_ok=True)
    slot_count = max(1, round(target_dur / CLIP_DURATION_S))
    per_slot = target_dur / slot_count
    normalized: list[Path] = []
    for index in range(slot_count):
        source = clips[index % len(clips)]
        normalized_path = TMP / f"{section_id}_clip_{index}.mp4"
        sh([
            "ffmpeg", "-y", "-i", str(source),
            "-vf", (
                f"trim=duration={per_slot:.3f},setpts=PTS-STARTPTS,"
                f"scale={W}:{H}:force_original_aspect_ratio=increase,"
                f"crop={W}:{H},setsar=1,fps={FPS}"
            ),
            "-t", f"{per_slot:.3f}", "-an", "-c:v", "libx264", "-crf", "18",
            "-preset", "medium", "-pix_fmt", "yuv420p", str(normalized_path),
        ])
        normalized.append(normalized_path)

    concat_path = TMP / f"{section_id}_list.txt"
    _concat_list(concat_path, normalized)
    out_part = out_seg.with_name(out_seg.stem + ".part.mp4")
    if out_part.exists():
        out_part.unlink()
    sh([
        "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_path),
        "-c", "copy", str(out_part),
    ])
    if not probe_ok(out_part, min_seconds=max(1.0, target_dur - TARGET_TOLERANCE_S)):
        raise RuntimeError(f"section segment failed duration validation: {out_part}")
    out_part.replace(out_seg)


def _scene_plan_by_section() -> dict[str, dict[str, Any]]:
    path = ART / "scene_plan.json"
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return {
        item["script_section_id"]: item
        for item in data.get("scenes", [])
        if isinstance(item, dict) and item.get("script_section_id")
    }


def _safe_project_path(value: str) -> Path:
    candidate = Path(value)
    resolved = candidate.resolve() if candidate.is_absolute() else (PROJ / candidate).resolve()
    try:
        resolved.relative_to(PROJ.resolve())
    except ValueError as exc:
        raise RuntimeError(f"overlay path escapes project root: {value}") from exc
    return resolved


def overlay_manifest() -> list[dict[str, Any]]:
    path = ART / "overlay_manifest.json"
    if not path.exists():
        return []
    data = json.loads(path.read_text(encoding="utf-8"))
    items = data.get("overlays", data) if isinstance(data, dict) else data
    if not isinstance(items, list):
        raise RuntimeError("overlay_manifest.json must contain an overlays list")
    return [item for item in items if isinstance(item, dict)]


def _escape_drawtext(value: str) -> str:
    # drawtext is passed as one argv token; escape its filter separators, not
    # with shell quoting.  Newlines are intentionally avoided for portability.
    return (
        str(value).replace("\\", r"\\").replace(":", r"\:")
        .replace("'", r"\'").replace("%", r"\%")
        .replace("\n", " ").replace("\r", " ")
    )


def _escape_filter_path(path: Path) -> str:
    resolved = path.resolve()
    try:
        # Relative paths avoid the drive-colon ambiguity in drawtext. FFmpeg
        # runs from ROOT, so the path remains deterministic and project-local.
        value = resolved.relative_to(ROOT.resolve()).as_posix()
    except ValueError:
        value = re.sub(r"^([A-Za-z]):/", r"\1\\:/", resolved.as_posix())
    return value.replace(" ", r"\ ")


def _cue_text(cue: dict[str, Any]) -> str:
    for key in ("text", "label", "title", "answer"):
        if cue.get(key):
            return str(cue[key])
    description = str(cue.get("description", "")).strip()
    # The artifact descriptions are the educational copy available when no
    # concrete UI asset exists. Keep cards concise enough for a 1920x1080 frame.
    description = re.sub(r"^(post-composed|post-composed labels?|title card:)\s*", "", description, flags=re.I)
    return description[:180]


def _cue_items(section: dict[str, Any], scene: dict[str, Any] | None) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for cue in section.get("enhancement_cues", []):
        if isinstance(cue, dict) and cue.get("type") in {"title", "label", "callout", "question", "answer", "highlight", "card", "overlay"}:
            item = dict(cue)
            timestamp = float(item.get("timestamp_seconds", 1.0)) - float(section["start_seconds"])
            item["local_start"] = max(0.0, min(timestamp, float(section["end_seconds"]) - float(section["start_seconds"]) - 0.1))
            items.append(item)
    if scene and scene.get("overlay_notes"):
        notes = str(scene["overlay_notes"])
        items.append({"type": "label", "text": notes, "local_start": 1.0, "source": "scene_plan"})
    if not items:
        items.append({"type": "label", "text": section.get("label", section["id"]), "local_start": 0.5, "source": "fallback"})
    return items


def _asset_overlays_for_section(
    section_id: str,
    section_duration: float,
    manifest: list[dict[str, Any]],
    report: dict[str, Any],
) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    for item in manifest:
        if item.get("section_id") not in (None, section_id):
            continue
        raw_path = item.get("path") or item.get("asset")
        if not raw_path:
            report["missing_assets"].append({"section_id": section_id, "path": None, "required": bool(item.get("required"))})
            continue
        path = _safe_project_path(str(raw_path))
        if not path.is_file():
            missing = {"section_id": section_id, "path": str(raw_path), "required": bool(item.get("required"))}
            report["missing_assets"].append(missing)
            if item.get("required"):
                raise RuntimeError(f"required overlay asset missing: {path}")
            continue
        start = float(item.get("start_seconds", item.get("timestamp_seconds", 0)))
        if item.get("global", False):
            start -= float(report["section_starts"][section_id])
        found.append({
            **item,
            "path": path,
            "local_start": max(0.0, min(start, section_duration - 0.1)),
            "duration": min(float(item.get("duration_seconds", section_duration - start)), section_duration),
        })
    return found


def apply_overlays(
    section_id: str,
    segment: Path,
    out_seg: Path,
    section: dict[str, Any],
    scene: dict[str, Any] | None,
    manifest: list[dict[str, Any]],
    report: dict[str, Any],
) -> None:
    """Apply readable cards and optional image/video overlays over a section."""
    duration = float(section["end_seconds"]) - float(section["start_seconds"])
    cues = _cue_items(section, scene)
    assets = _asset_overlays_for_section(section["id"], duration, manifest, report)
    report["overlay_counts"][section["id"]] = {"text": len(cues), "assets": len(assets)}

    inputs: list[str] = ["ffmpeg", "-y", "-i", str(segment)]
    filters: list[str] = ["[0:v]format=yuv420p[base]"]
    current = "base"
    for index, item in enumerate(assets, 1):
        path = Path(item["path"])
        is_image = path.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"}
        if is_image:
            inputs.extend(["-loop", "1", "-i", str(path)])
        else:
            inputs.extend(["-i", str(path)])
        next_label = f"asset{index}"
        x = int(item.get("x", 1280))
        y = int(item.get("y", 120))
        width = int(item.get("width", 480))
        height = int(item.get("height", 270))
        end = float(item["local_start"]) + float(item["duration"])
        filters.append(
            f"[{index}:v]scale={width}:{height}:force_original_aspect_ratio=decrease,"
            f"format=rgba[{next_label}src]"
        )
        filters.append(
            f"[{current}][{next_label}src]overlay=x={x}:y={y}:"
            f"enable='between(t,{float(item['local_start']):.3f},{end:.3f})'[{next_label}]"
        )
        current = next_label

    # Cards use only a partial-width translucent panel, preserving the video.
    for index, cue in enumerate(cues):
        text = _cue_text(cue)
        if not text:
            continue
        text_path = TMP / f"{section_id}_overlay_{index}.txt"
        text_path.write_text(text.replace("\r", " ").replace("\n", " "), encoding="utf-8", newline="")
        start = float(cue["local_start"])
        end = min(duration, start + float(cue.get("duration_seconds", 5.0)))
        x = int(cue.get("x", 96))
        y = int(cue.get("y", 76 if index % 2 == 0 else 820))
        box_w = int(cue.get("width", 900))
        box_h = int(cue.get("height", 150))
        next_label = f"text{index}"
        enable = f"between(t,{start:.3f},{end:.3f})"
        filters.append(
            f"[{current}]drawbox=x={x}:y={y}:w={box_w}:h={box_h}:"
            f"color=0x102A43@0.82:t=fill:enable='{enable}'[{next_label}box]"
        )
        filters.append(
            f"[{next_label}box]drawtext=font='Arial':textfile={_escape_filter_path(text_path)}:"
            f"x={x + 28}:y={y + 42}:fontsize=38:fontcolor=white:"
            f"borderw=2:bordercolor=black@0.75:enable='{enable}'[{next_label}]"
        )
        current = next_label

    out_part = out_seg.with_name(out_seg.stem + ".part.mp4")
    if out_part.exists():
        out_part.unlink()
    sh(inputs + [
        "-filter_complex", ";".join(filters), "-map", f"[{current}]",
        "-an", "-t", str(duration), "-c:v", "libx264", "-crf", "18",
        "-preset", "medium", "-pix_fmt", "yuv420p", str(out_part),
    ])
    if not probe_ok(out_part, min_seconds=max(1.0, duration - TARGET_TOLERANCE_S)):
        raise RuntimeError(f"overlay section failed validation: {out_part}")
    out_part.replace(out_seg)


def _write_report(report: dict[str, Any]) -> None:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, indent=2), encoding="utf-8")


def _base_report(script: dict[str, Any] | None = None) -> dict[str, Any]:
    sections = (script or {}).get("sections", [])
    return {
        "version": "2.0",
        "project_id": "evs-lesson-8",
        "canonical_inputs": {
            "script": str(ART / "script.json"),
            "narration_manifest": str(ART / "narration_manifest.json"),
            "scene_plan_metadata": str(ART / "scene_plan.json") if (ART / "scene_plan.json").exists() else None,
            "overlay_manifest": str(ART / "overlay_manifest.json") if (ART / "overlay_manifest.json").exists() else None,
        },
        "expected_duration_seconds": (script or {}).get("total_duration_seconds"),
        "actual_duration_seconds": None,
        "final_path": str(OUT),
        "completion_status": "not_started",
        "stage_status": {"validation": "pending", "sections": "pending", "overlays": "pending", "audio": "pending", "subtitles": "pending", "final": "pending"},
        "sections": [],
        "overlay_counts": {},
        "scene_required_assets": {},
        "missing_assets": [],
        "commands": [],
        "error": None,
        "section_starts": {item.get("id"): item.get("start_seconds") for item in sections if item.get("id")},
    }


def load_inputs() -> tuple[dict[str, Any], dict[str, Any]]:
    script_path = ART / "script.json"
    narration_path = ART / "narration_manifest.json"
    script = json.loads(script_path.read_text(encoding="utf-8"))
    narration = json.loads(narration_path.read_text(encoding="utf-8"))
    if not script.get("sections") or not narration.get("segments"):
        raise RuntimeError("canonical script/narration inputs have no sections or segments")
    return script, narration


def render(dry_run: bool = False) -> dict[str, Any]:
    global _COMMANDS
    _COMMANDS = []
    report: dict[str, Any] = _base_report()
    try:
        script, narration = load_inputs()
        report = _base_report(script)
        expected = float(script["total_duration_seconds"])
        report["stage_status"]["validation"] = "passed"
        scenes = _scene_plan_by_section()
        manifest = overlay_manifest()
        nar_by_sid = {item["section_id"]: item for item in narration.get("segments", [])}
        section_segments: list[Path] = []

        for section in script["sections"]:
            sid = section["id"]
            target = float(section["end_seconds"]) - float(section["start_seconds"])
            clips = clips_for_section(sid)
            row = {"section": sid, "target_seconds": target, "clip_count": len(clips), "status": "planned" if dry_run else "pending"}
            report["sections"].append(row)
            scene = scenes.get(sid)
            report["scene_required_assets"][sid] = len((scene or {}).get("required_assets", []))
            if sid not in nar_by_sid:
                raise RuntimeError(f"narration segment missing for {sid}")
            if float(nar_by_sid[sid].get("duration_seconds", 0)) > target + 0.5:
                raise RuntimeError(f"narration for {sid} exceeds section window")
            if not clips:
                raise RuntimeError(f"no usable clips exist for {sid}")
            segment = TMP / f"seg_{sid}.mp4"
            if dry_run:
                cue_count = len(_cue_items(section, scene))
                asset_count = len(_asset_overlays_for_section(sid, target, manifest, report))
                report["overlay_counts"][sid] = {"text": cue_count, "assets": asset_count}
                section_segments.append(segment)
                continue
            overlay_segment = segment.with_name(f"overlay_{sid}.mp4")
            if not probe_ok(segment, min_seconds=max(1.0, target - TARGET_TOLERANCE_S)):
                print(f"building {sid}: {len(clips)} clips -> {target}s")
                build_section_segment(sid, clips, segment, target)
            if not probe_ok(overlay_segment, min_seconds=max(1.0, target - TARGET_TOLERANCE_S)):
                apply_overlays(sid, segment, overlay_segment, section, scenes.get(sid), manifest, report)
            else:
                report["overlay_counts"][sid] = {"text": len(_cue_items(section, scenes.get(sid))), "assets": 0, "resumed": True}
            row["status"] = "passed"
            row["actual_seconds"] = round(probe_duration(overlay_segment), 3)
            section_segments.append(overlay_segment)

        report["stage_status"]["sections"] = "planned" if dry_run else "passed"
        report["stage_status"]["overlays"] = "planned" if dry_run else "passed"
        report["overlay_manifest_entries"] = len(manifest)
        if dry_run:
            report["completion_status"] = "dry_run"
            report["commands"] = _COMMANDS
            _write_report(report)
            print(json.dumps({"dry_run": True, "sections": report["sections"], "missing_assets": report["missing_assets"]}, indent=2))
            return report

        full = TMP / "video_track.mp4"
        full_part = full.with_name(full.stem + ".part.mp4")
        _concat_list(TMP / "all_list.txt", section_segments)
        if full_part.exists():
            full_part.unlink()
        sh(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(TMP / "all_list.txt"), "-c", "copy", str(full_part)])
        if not probe_ok(
            full_part,
            min_seconds=expected - TARGET_TOLERANCE_S,
            max_seconds=expected + TARGET_TOLERANCE_S,
        ):
            raise RuntimeError("concatenated video track failed validation")
        full_part.replace(full)
        actual_video = probe_duration(full)
        if abs(actual_video - expected) > TARGET_TOLERANCE_S:
            raise RuntimeError(f"video track duration {actual_video:.3f}s differs from target {expected:.3f}s")

        sys.path.insert(0, str(PROJ))
        import _compose2 as c2  # noqa: PLC0415
        subtitle = c2.build_subtitles(script, TMP / "final.srt")
        report["stage_status"]["subtitles"] = "passed"
        mix = c2.add_audio_and_mix(full, narration, script, TMP / "mix.wav")
        report["stage_status"]["audio"] = "passed"
        c2.final_encode(mix, subtitle, OUT, full, target_duration=expected)
        report["stage_status"]["final"] = "passed"
        report["actual_duration_seconds"] = round(probe_duration(OUT), 3)
        report["completion_status"] = "completed"
        print(f"final_render.mp4 {report['actual_duration_seconds']:.2f}s -> {OUT}")
        return report
    except Exception as exc:
        report["completion_status"] = "failed"
        report["error"] = str(exc)
        raise
    finally:
        report["commands"] = _COMMANDS[-50:]
        _write_report(report)


def main() -> None:
    parser = argparse.ArgumentParser(description="Compose EVS Lesson 8 with deterministic overlays")
    parser.add_argument("--dry-run", action="store_true", help="validate assets and write the render plan without encoding")
    args = parser.parse_args()
    try:
        render(dry_run=args.dry_run)
    except Exception as exc:
        print(f"compose failed: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
