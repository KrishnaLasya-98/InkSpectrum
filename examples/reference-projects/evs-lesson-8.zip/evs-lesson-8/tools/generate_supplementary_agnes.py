"""Generate normal-speed supplementary Agnes clips for EVS Lesson 8."""
from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv  # noqa: E402

load_dotenv(ROOT / ".env")

from tools.video.agnes_video import AgnesVideo  # noqa: E402


OUTPUT_DIR = ROOT / "projects" / "evs-lesson-8" / "assets" / "video" / "agnes-final"

STYLE = (
    "Polished cinematic 3D animated children's educational film, warm friendly rounded "
    "characters, expressive eyes, bright natural colors, soft global illumination, detailed "
    "but child-safe environments, smooth natural real-time movement at normal speed, one "
    "continuous six-second shot, stable camera with a very gentle cinematic drift. "
)

NEGATIVE = (
    "slow motion, time lapse, frozen pose, static image, sluggish motion, looping, repeated "
    "action, replay, reverse motion, jump cut, stutter, flicker, duplicate animals, extra limbs, "
    "malformed anatomy, fused bodies, aggressive behavior, text, letters, captions, logo, "
    "watermark, border, split screen, collage, camera shake"
)

CLIPS = {
    "s01-pet-care-extra.mp4": (
        "A bright cheerful garden with one friendly Class 1 child and one healthy golden pet dog. "
        "The child gently places a clean water bowl and a small bowl of healthy dog food beside the "
        "dog, then softly brushes the dog's fur with a pet brush. The dog drinks naturally, wags "
        "its tail once, and remains calm and happy. One cohesive caring action, correct child hands "
        "and dog anatomy, uncluttered composition."
    ),
    "s01-highlights-extra.mp4": (
        "A clean cinematic frame with absolutely no interface, labels, captions, viewfinder marks, "
        "documentary graphics, corner text, or overlays. One cohesive wide 3D animated nature "
        "panorama for young children, not a collage: grassy "
        "riverbank and clear pond in the same landscape. A deer and a rabbit walk naturally on land; "
        "two colorful fish visibly swim underwater; two small birds fly across the blue sky; a "
        "butterfly and a grasshopper move beside foreground flowers. Every animal group is clearly "
        "visible at the same time with correct anatomy and gentle natural motion."
    ),
    "s02-needs-extra.mp4": (
        "A cohesive sunny meadow scene where a friendly young deer naturally chews fresh grass, "
        "a small rabbit drinks from a clean shallow stream, and a calm calf walks into the shade "
        "of a leafy tree and rests. All animals remain clearly separated with correct anatomy; "
        "their gentle actions unfold naturally together without rushing."
    ),
    "s03-water-extra.mp4": (
        "A clear underwater river world with several distinct aquatic animals: two colorful fish "
        "swim smoothly past aquatic plants, a turtle paddles calmly below, and a small octopus "
        "moves gently near a rock. Natural currents sway plants and bubbles rise; each animal is "
        "easy for Class 1 children to identify."
    ),
    "s05-insects-extra.mp4": (
        "A cheerful flower garden with exactly three large, clearly separated insects visible "
        "together for the entire shot. On the left, one orange butterfly flaps its wings above a "
        "pink flower. In the center, one small black housefly walks on a yellow flower. On the "
        "right, one unmistakable bright green grasshopper with long folded hind legs stands on a "
        "broad leaf and makes one short natural hop. No other insects."
    ),
    "s06-pets-extra.mp4": (
        "A warm garden scene where two cheerful primary-school children gently care for pets: one "
        "child fills a water bowl for a friendly dog, the other offers leafy food to a rabbit, "
        "while a colorful parrot sits safely on a wooden perch. Respectful, calm care and natural "
        "movement, with consistent healthy characters and no crowded composition."
    ),
    "s10-bird-food-extra.mp4": (
        "A polished warm 3D animated woodland scene with one woven bird nest clearly visible on a "
        "sturdy branch. Two small friendly birds naturally eat beside the nest: one pecks a few "
        "seeds and berries while the other takes a small bite from a bright fruit piece. They make "
        "gentle head movements and one brief wing flutter, then settle beside the nest. Keep both "
        "birds separate with correct anatomy and keep seeds, berries, fruit, and nest easy for "
        "Class 1 children to identify."
    ),
}


def generate(name: str, scene: str) -> tuple[str, bool, str]:
    output = OUTPUT_DIR / name
    result = AgnesVideo().execute(
        {
            "prompt": STYLE + scene,
            "negative_prompt": NEGATIVE,
            "operation": "text_to_video",
            "model_id": "agnes-video-v2.0",
            "duration": "6",
            "resolution": "720P",
            "aspect_ratio": "16:9",
            "output_path": str(output),
        }
    )
    return name, result.success, "ok" if result.success else str(result.error)


def main() -> int:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    failures = 0
    for name, scene in CLIPS.items():
        if (OUTPUT_DIR / name).exists():
            print(f"{name}: SKIPPED - existing output", flush=True)
            continue
        name, success, message = generate(name, scene)
        print(f"{name}: {'OK' if success else 'FAILED'} - {message}", flush=True)
        failures += not success
        time.sleep(10)
    return int(failures > 0)


if __name__ == "__main__":
    raise SystemExit(main())
