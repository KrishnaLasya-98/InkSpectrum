"""Generate the clean EVS opening highlights panorama with ModelsLab."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv  # noqa: E402

load_dotenv(ROOT / ".env")

from tools.video.modelslab_video import ModelsLabVideo  # noqa: E402


OUTPUT = (
    ROOT
    / "projects"
    / "evs-lesson-8"
    / "assets"
    / "video"
    / "agnes-final"
    / "s01-highlights-extra.mp4"
)

PROMPT = (
    "Polished child-friendly 3D animated educational film, one cohesive wide nature landscape, "
    "warm professional storybook lighting. A grassy riverbank and clear pond share the same scene. "
    "One deer and one rabbit move gently on land. Two colorful fish visibly swim below the clear "
    "water surface. Two small birds fly naturally across the open blue sky. One butterfly flutters "
    "and one green grasshopper moves beside foreground flowers. Every animal group stays clearly "
    "visible and anatomically correct. Smooth normal-speed natural motion, one continuous six-second "
    "take, stable wide camera with only subtle cinematic drift. Clean unbranded image."
)

NEGATIVE = (
    "text, letters, words, captions, subtitles, labels, credits, title, watermark, logo, brand, "
    "interface, user interface, HUD, viewfinder, camera overlay, documentary overlay, corner marks, "
    "frame border, split screen, collage, duplicated animals, malformed anatomy, fused bodies, "
    "extra limbs, slow motion, frozen frame, static image, looping, replay, reverse movement, "
    "stutter, flicker, camera shake, jump cut"
)


def main() -> int:
    result = ModelsLabVideo().execute(
        {
            "prompt": PROMPT,
            "negative_prompt": NEGATIVE,
            "model_id": "h3-minimax-t2v",
            "operation": "text_to_video",
            "duration": "6",
            "resolution": "768P",
            "generate_audio": False,
            "output_path": str(OUTPUT),
        }
    )
    print("OK" if result.success else f"FAILED: {result.error}", flush=True)
    return 0 if result.success else 1


if __name__ == "__main__":
    raise SystemExit(main())
