import json, os

sp = json.load(open(r"D:\InkSpectrum\OpenMontage\projects\evs-lesson-8\artifacts\scene_plan_nonlinear.json"))
wa_path = r"D:\InkSpectrum\OpenMontage\projects\evs-lesson-8\artifacts\word_alignment_remotion.json"
wa_rel = os.path.relpath(wa_path, r"D:\InkSpectrum\OpenMontage\remotion-composer")
script = json.load(open(r"D:\InkSpectrum\OpenMontage\projects\evs-lesson-8\artifacts\script.json"))
sections = {s["id"]: s for s in script["sections"]}
rr = r"D:\InkSpectrum\OpenMontage\remotion-composer"

glossary = {
    "s13-0": [
        {"term":"Birds","definition":"Animals with feathers, beaks, and wings","start":0,"end":5},
        {"term":"Insects","definition":"Animals with six legs and three body parts","start":5,"end":10},
        {"term":"Domestic","definition":"Animals that live with humans","start":10,"end":15},
        {"term":"Wild","definition":"Animals that live in nature","start":15,"end":20},
        {"term":"Den/Burrow","definition":"A home that animals dig underground","start":20,"end":25},
    ]
}

activity = {"s16-0": ["Draw your favorite animal and its home", "Can you name three ways to protect animals?"]}

out = []
for s in sp["scenes"]:
    sid = s["section_id"]
    sec = sections.get(sid, {})
    clip_rel = os.path.relpath(s["clip_path"], rr)
    nar = s.get("narration_url")
    nar_rel = os.path.relpath(nar, rr) if nar and os.path.exists(nar) else None
    cid = s["clip_id"]
    out.append({
        "id": s["id"], "type": s["topic"], "description": sec.get("label",""),
        "start_seconds": s["start_frame"]/30, "end_seconds": (s["start_frame"]+s["duration_frames"])/30,
        "start_frame": s["start_frame"], "duration_frames": s["duration_frames"],
        "loop_required": s["loop_required"],
        "particle_effect": s["visual"]["particle_effect"],
        "lighting_from": s["visual"]["lighting_from"],
        "lighting_to": s["visual"]["lighting_to"],
        "camera_motion": s["visual"]["camera_motion"],
        "narration_url": nar_rel, "word_alignment_path": wa_rel,
        "video_clip": clip_rel,
        "assessment_type": "fill_blank" if sid=="s14" else ("mcq" if sid=="s15" else None),
        "glossary_terms": glossary.get(cid),
        "activity_prompts": activity.get(cid),
    })

result = {
    "version":"2.0-adapted","runtime":"remotion","fps":30,
    "resolution":{"width":1920,"height":1080},
    "topic_order": sp["topic_order"],"total_frames":sp["total_frames"],
    "total_duration_s": sp["total_duration_s"],"scenes":out,
}
o = r"D:\InkSpectrum\OpenMontage\projects\evs-lesson-8\artifacts\scene_plan_adapted.json"
json.dump(result, open(o,"w"), indent=2)
print(f"Written {o} | Scenes: {len(out)} | Duration: {result['total_duration_s']}s")
print(json.dumps(out[:2], indent=2))
