﻿"""Build nonlinear scene_plan for EVS Lesson 8.
Groups 39 clips by topic, probes durations, maps narrations and cues,
loops single-clip sections to 30s, and emits artifacts/scene_plan_nonlinear.json.
"""
from __future__ import annotations

import json
import math
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ASSETS = ROOT / "assets" / "video" / "scenes"
ART = ROOT / "artifacts"
RENDERS_AUDIO = ROOT / "renders" / "audio"
STYLE_PATH = ROOT.parent / "styles" / "sunshine-classroom.yaml"
sys.path.insert(0, str(ROOT.parents[2]))
from tools.structure.source_fidelity import display_policy  # noqa: E402

FPS = 30
RES = {"width": 1920, "height": 1080}
LOOP_TARGET_S = 30.0

TOPIC_ORDER = [
    "intro", "needs", "habitats", "birds", "insects",
    "homes", "review", "glossary", "assessment", "activity",
]

SECTION_TOPIC = {
    "s01": "intro",
    "s02": "needs",
    "s03": "habitats",
    "s04": "birds",
    "s05": "insects",
    "s06": "habitats",
    "s07": "habitats",
    "s08": "homes",
    "s09": "homes",
    "s10": "homes",
    "s11": "homes",
    "s12": "review",
    "s13": "glossary",
    "s14": "assessment",
    "s15": "assessment",
    "s16": "activity",
}

QA_SECTIONS = {"s14", "s15"}
QA_FORMAT = {"s14": "short_answer", "s15": "multiple_choice"}

TOPIC_VISUALS = {
    "intro": {
        "camera_motion": "slow_zoom_in",
        "background_color": "#FFFDF0",
        "lighting_from": "#FF8C42",
        "lighting_to": "#FFFDF0",
        "particle_effect": "sparkle",
        "particle_color": "#FFD93D",
        "vignette": False,
    },
    "needs": {
        "camera_motion": "static",
        "background_color": "#FFFDF0",
        "lighting_from": "#4ECDC4",
        "lighting_to": "#FFFDF0",
        "particle_effect": "none",
        "particle_color": "#4ECDC4",
        "vignette": False,
    },
    "habitats": {
        "camera_motion": "gentle_pan",
        "background_color": "#FFFDF0",
        "lighting_from": "#6BCB77",
        "lighting_to": "#FFFDF0",
        "particle_effect": "dust_motes",
        "particle_color": "#6BCB77",
        "vignette": False,
    },
    "birds": {
        "camera_motion": "slow_tilt_up",
        "background_color": "#FFFDF0",
        "lighting_from": "#4ECDC4",
        "lighting_to": "#FFFDF0",
        "particle_effect": "feathers",
        "particle_color": "#4ECDC4",
        "vignette": False,
    },
    "insects": {
        "camera_motion": "static",
        "background_color": "#FFFDF0",
        "lighting_from": "#FFD93D",
        "lighting_to": "#FFFDF0",
        "particle_effect": "pollen",
        "particle_color": "#FFD93D",
        "vignette": False,
    },
    "homes": {
        "camera_motion": "map_pan",
        "background_color": "#FFFDF0",
        "lighting_from": "#FF8C42",
        "lighting_to": "#FFFDF0",
        "particle_effect": "none",
        "particle_color": "#FF8C42",
        "vignette": False,
    },
    "review": {
        "camera_motion": "path_follow",
        "background_color": "#FFFDF0",
        "lighting_from": "#FF8C42",
        "lighting_to": "#FFFDF0",
        "particle_effect": "sparkle",
        "particle_color": "#FFD93D",
        "vignette": False,
    },
    "glossary": {
        "camera_motion": "static",
        "background_color": "#FFFDF0",
        "lighting_from": "#4ECDC4",
        "lighting_to": "#FFFDF0",
        "particle_effect": "none",
        "particle_color": "#4ECDC4",
        "vignette": False,
    },
    "assessment": {
        "camera_motion": "static",
        "background_color": "#FFFDF0",
        "lighting_from": "#FF6B9D",
        "lighting_to": "#FFFDF0",
        "particle_effect": "none",
        "particle_color": "#FF6B9D",
        "vignette": False,
    },
    "activity": {
        "camera_motion": "slow_zoom_out",
        "background_color": "#FFFDF0",
        "lighting_from": "#FFD93D",
        "lighting_to": "#FFFDF0",
        "particle_effect": "sparkle",
        "particle_color": "#FFD93D",
        "vignette": False,
    },
}


def ffprobe_duration(path: Path) -> float:
    result = subprocess.run(
        [
            "ffprobe",
            "-v", "error",
            "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1",
            str(path),
        ],
        capture_output=True,
        text=True,
        check=True,
    )
    return float(result.stdout.strip())


def extract_keywords(text: str, limit: int = 6) -> list[str]:
    words = [w.strip(".,!?;:\"'()[]") for w in text.split()]
    return [w for w in words if len(w) > 3 and w[0].isupper()][:limit]


def load_spec_transitions() -> dict:
    sys.path.insert(0, str(ROOT))
    try:
        from _spec_a import SCENE_SPEC  # type: ignore
        return {
            sid: {
                "transition_in": spec.get("transition_in", "fade"),
                "transition_out": spec.get("transition_out", "fade"),
            }
            for sid, spec in SCENE_SPEC.items()
        }
    except Exception:
        return {}


def main() -> None:
    script = json.loads((ART / "script.json").read_text(encoding="utf-8"))
    sections = {sec["id"]: sec for sec in script["sections"]}
    narration = json.loads((ART / "narration_manifest.json").read_text(encoding="utf-8"))
    narr_map = {seg["section_id"]: seg for seg in narration["segments"]}
    source_manifest_path = ART / "source_text_manifest.json"
    source_manifest = (
        json.loads(source_manifest_path.read_text(encoding="utf-8"))
        if source_manifest_path.exists()
        else {"cards": [], "text_policy": {}}
    )

    transitions = load_spec_transitions()

    scenes: list[dict] = []
    topic_sections: dict[str, list[str]] = {t: [] for t in TOPIC_ORDER}

    for sid, sec in sections.items():
        topic = SECTION_TOPIC[sid]
        topic_sections[topic].append(sid)

    total_frames = 0
    total_duration_s = 0.0

    for topic in TOPIC_ORDER:
        for sid in topic_sections[topic]:
            sec = sections[sid]
            sdir = ASSETS / sid
            clip_paths = sorted(sdir.glob("*.mp4"))
            clip_paths.sort(key=lambda p: p.name)

            narration_seg = narr_map.get(sid, {})
            narration_url = narration_seg.get("audio_path", f"renders/audio/{sid}.norm.wav")
            if Path(narration_url).is_absolute():
                narration_url = str(Path(narration_url).relative_to(ROOT))

            is_qa = sid in QA_SECTIONS
            qa_format = QA_FORMAT.get(sid)

            trans = transitions.get(sid, {})
            trans_in = trans.get("transition_in", "fade")
            trans_out = trans.get("transition_out", "fade")

            for clip_idx, clip_path in enumerate(clip_paths):
                raw_duration = ffprobe_duration(clip_path)
                clip_count = len(clip_paths)

                if clip_count == 1:
                    duration_s = LOOP_TARGET_S
                    loop_required = True
                    loop_count = max(1, math.ceil(LOOP_TARGET_S / raw_duration))
                else:
                    duration_s = raw_duration
                    loop_required = False
                    loop_count = 1

                duration_frames = round(duration_s * FPS)
                start_frame = total_frames

                clip_id = clip_path.stem
                scene_id = f"evs-{sid}-p{clip_idx}"

                visual = dict(TOPIC_VISUALS.get(topic, TOPIC_VISUALS["intro"]))

                scene = {
                    "id": scene_id,
                    "clip_id": clip_id,
                    "section_id": sid,
                    "topic": topic,
                    "clip_path": str(clip_path.relative_to(ROOT)),
                    "start_frame": start_frame,
                    "duration_frames": duration_frames,
                    "duration_s": round(duration_s, 3),
                    "narration_url": narration_url,
                    "narration_offset_s": 0.0,
                    "loop_required": loop_required,
                    "loop_count": loop_count,
                    "is_qa": is_qa,
                    "qa_format": qa_format,
                    "keywords": extract_keywords(sec.get("text", "")),
                    "enhancement_cues": sec.get("enhancement_cues", []),
                    "delivery_cues": sec.get("delivery_cues", {}),
                    "text_policy": display_policy(source_manifest_path),
                    "source_text_cards": [
                        card for card in source_manifest.get("cards", [])
                        if card.get("title") == sec.get("label")
                        or card.get("title") == sec.get("title")
                    ],
                    "visual": visual,
                    "transition_in": trans_in,
                    "transition_out": trans_out,
                }

                scenes.append(scene)
                total_frames += duration_frames
                total_duration_s += duration_s

    plan = {
        "version": "2.0-nonlinear",
        "runtime": "hyperframes",
        "fps": FPS,
        "resolution": RES,
        "topic_order": TOPIC_ORDER,
        "total_frames": total_frames,
        "total_duration_s": round(total_duration_s, 3),
        "text_policy": {
            **display_policy(
                Path(str(source_manifest_path.relative_to(ROOT)))
                if source_manifest_path.exists() else None
            ),
            "display_case": "Tt",
            "preserve_punctuation": True,
            "max_content_lines_per_screen": 3,
            "title_cards": "hyperframes_graphics_only",
            "content_visuals": "motion_first_modelslab_or_stock_video",
        },
        "scenes": scenes,
    }

    out = ART / "scene_plan_nonlinear.json"
    out.write_text(json.dumps(plan, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"wrote {out}")
    print(f"scenes: {len(scenes)} | topics: {len(TOPIC_ORDER)} | total_frames: {total_frames} | duration: {round(total_duration_s, 2)}s")
    for topic in TOPIC_ORDER:
        count = len([s for s in scenes if s["topic"] == topic])
        print(f"  {topic}: {count} scenes")


if __name__ == "__main__":
    main()
