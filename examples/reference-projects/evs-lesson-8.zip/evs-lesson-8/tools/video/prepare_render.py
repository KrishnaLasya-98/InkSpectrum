import json
from pathlib import Path

PROJ = Path(__file__).resolve().parents[2]
ART = PROJ / "artifacts"
AUDIO = PROJ / "renders" / "audio"

scene_plan = json.loads((ART / "scene_plan_adapted.json").read_text(encoding="utf-8"))
wa = json.loads((ART / "word_alignment_remotion.json").read_text(encoding="utf-8"))


def fix_paths(obj):
    if isinstance(obj, str):
        return obj.replace("\\", "/")
    if isinstance(obj, dict):
        return {k: fix_paths(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [fix_paths(v) for v in obj]
    return obj


def narration_url(section_id):
    if section_id is None:
        return None
    for ext in (".norm.wav", ".mp3"):
        candidate = AUDIO / f"{section_id}{ext}"
        if candidate.exists():
            return (Path("../../renders/audio") / f"{section_id}{ext}").as_posix()
    return None


for scene in scene_plan["scenes"]:
    sid = scene["id"].split("-")[1]
    scene["word_alignment_data"] = wa.get(sid)
    scene["narration_url"] = narration_url(sid)

scene_plan = fix_paths(scene_plan)
out = ART / "scene_plan_render.json"
out.write_text(json.dumps(scene_plan, indent=2, ensure_ascii=False), encoding="utf-8")

scenes = scene_plan["scenes"]
with_wa = sum(1 for s in scenes if s.get("word_alignment_data") is not None)
first_wa = scenes[0].get("word_alignment_data") or {}
word_count = len(first_wa.get("word_timestamps", []))
size_kb = out.stat().st_size / 1024

print(f"scenes: {len(scenes)}")
print(f"with word_alignment_data: {with_wa}")
print(f"first scene word count: {word_count}")
print(f"file size: {size_kb:.1f} KB")
