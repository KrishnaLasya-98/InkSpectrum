"""Generate additional normal-speed 3D continuity clips for EVS Lesson 8."""
from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv  # noqa: E402

load_dotenv(ROOT / ".env")

from tools.video.agnes_video import AgnesVideo  # noqa: E402


OUTPUT_DIR = ROOT / "projects" / "evs-lesson-8" / "assets" / "video" / "agnes-final"

STYLE = (
    "Polished cinematic 3D animated children's educational film for Class 1, "
    "friendly rounded characters, appealing expressive eyes, bright natural colors, "
    "soft global illumination, cohesive high-quality animated-story look, correct clean "
    "anatomy, smooth natural movement at normal speed, one continuous six-second shot, "
    "stable camera with a gentle cinematic drift. "
)

NEGATIVE = (
    "slow motion, time lapse, frozen pose, static image, sluggish motion, looping, repeated "
    "action, replay, reverse motion, jump cut, stutter, flicker, duplicate animals, cloned "
    "characters, extra limbs, malformed anatomy, fused bodies, aggressive behavior, text, "
    "letters, captions, logo, watermark, border, split screen, collage, camera shake"
)

CLIPS = {
    "s01-animal-ensemble-extra.mp4": (
        "A bright connected nature world beside a clear pond. A friendly young elephant and "
        "rabbit walk gently on the grassy bank while two colorful fish swim visibly in the "
        "water, a small parrot glides to a low tree branch, and one butterfly flutters over "
        "flowers. Keep land, water, bird, and insect animals clearly separated and recognizable; "
        "the scene feels like the opening of one joyful animal adventure."
    ),
    "s04-birds-extra.mp4": (
        "A sunny village pond and garden showing exactly three distinct birds. One yellow duck "
        "paddles naturally across the pond, one grey pigeon takes two small steps on the bank, "
        "and one green parrot gently turns its head on a nearby branch. All three remain visible, "
        "properly proportioned, and easy for young children to identify."
    ),
    "s08-food-homes-extra.mp4": (
        "A single wide cheerful woodland clearing with exactly two stable animals that never "
        "change identity. On the left, one brown rabbit calmly nibbles one carrot beside a neat "
        "round burrow entrance. On the right, one red squirrel calmly eats one nut beside a tree "
        "with a visible hollow. Both animals stay in their separate zones for the whole shot. "
        "No birds, no additional animals, no new animal enters, no transformation, no disappearance."
    ),
    "s09-rabbits-extra.mp4": (
        "A warm grassy hillside with a clean round rabbit burrow. Two friendly rabbits with "
        "correct anatomy hop toward the entrance; one rabbit enters the burrow naturally while "
        "the other stays outside and nibbles a carrot and leafy vegetables. Smooth purposeful "
        "motion, stable environment, no sudden appearance or disappearance."
    ),
    "s09-lion-eating-extra.mp4": (
        "A warm child-friendly forest clearing with exactly one gentle healthy lion. The lion "
        "calmly lowers its head and takes small bites from a neat prepared piece of cooked meat "
        "on a clean flat wooden feeding board, then looks up peacefully. The food is simple and "
        "non-frightening: no prey animal, no carcass, no bones, no blood, no gore. Keep the lion's "
        "face, mouth, paws, tail, and full body anatomically stable throughout the natural action."
    ),
    "s03-land-water-extra.mp4": (
        "A single cohesive bright 3D nature habitat with both land and water clearly visible at "
        "the same time. On the grassy riverbank, exactly one friendly young elephant walks slowly "
        "beside exactly one small rabbit. In the broad clear water below, exactly two colorful "
        "fish swim naturally beside exactly one turtle. Keep every animal clearly separated, "
        "recognizable, anatomically stable, and continuously in its correct habitat. Gentle ripples, "
        "moving leaves, normal-speed action, no underwater split screen and no new animals entering."
    ),
}


def generate(name: str, scene: str) -> tuple[str, bool, str]:
    output = OUTPUT_DIR / name
    result = AgnesVideo().execute(
        {
            "prompt": STYLE + scene,
            "negative_prompt": NEGATIVE,
            "operation": "text_to_video",
            "model_id": "agnes-video-v2.0",
            "duration": "6",
            "resolution": "720P",
            "aspect_ratio": "16:9",
            "output_path": str(output),
        }
    )
    return name, result.success, "ok" if result.success else str(result.error)


def main() -> int:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    failures = 0
    for name, scene in CLIPS.items():
        if (OUTPUT_DIR / name).exists():
            print(f"{name}: SKIPPED - existing output", flush=True)
            continue
        name, success, message = generate(name, scene)
        print(f"{name}: {'OK' if success else 'FAILED'} - {message}", flush=True)
        failures += not success
        time.sleep(10)
    return int(failures > 0)


if __name__ == "__main__":
    raise SystemExit(main())
