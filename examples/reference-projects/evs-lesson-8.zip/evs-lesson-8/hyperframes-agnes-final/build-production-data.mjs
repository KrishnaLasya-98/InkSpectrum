import fs from 'node:fs';
import path from 'node:path';

const here = path.dirname(new URL(import.meta.url).pathname.replace(/^\/(.:)/, '$1'));
const project = path.resolve(here, '..');
const read = (name) => JSON.parse(fs.readFileSync(path.join(project, 'artifacts', name), 'utf8'));
const narration = read('narration_aligned.json');
const sync = read('multimedia_sync_plan.json');
const words = read('word_captions.json');
// All narration and ASR timestamps are already expressed on the final timeline.
// Subtracting the historical three-second title-card pad a second time caused
// narration, captions and visuals to overlap the previous section.
const timelineOffsetMs = 0;

const metadata = {
  s01: ['Welcome', 'Animal Life', 'Meet the animals that share our world.'],
  s02: ['We Learn', 'Animals are living beings', 'Every animal needs food, water, air, shelter, care and protection.'],
  s03: ['Discover', 'Land and water animals', 'Animals live in different habitats.'],
  s04: ['We Learn', 'Birds', 'Feathers, wings, two legs and a beak.'],
  s05: ['Look Closely', 'Insects', 'Small animals with six legs.'],
  s06: ['Around Us', 'Domestic and pet animals', 'Animals that live with and help people.'],
  s07: ['In the Forest', 'Wild animals', 'Wild animals live freely in forests.'],
  s08: ['Animal Homes', 'Homes and food', 'Every animal needs a safe place to live.'],
  s09: ['Explore', 'Dens and burrows', 'Lions and rabbits make different homes.'],
  s10: ['Explore', 'Nests, anthills and hives', 'Animals build homes that suit their needs.'],
  s11: ['Around Us', 'Human-made animal homes', 'Kennels, sheds and stables keep animals safe.'],
  s12: ["Let's Recall", "Let's Recall", ''],
  s13: ['Glossary', 'Glossary', ''],
  s14: ['Assessment', 'Assessment', ''],
  s15: ['Assessment', 'Assessment', ''],
  s16: ['Activity', 'ACTIVITY', '']
};

const storyCues = {
  // The title artwork covers s01 until the first question. Every subsequent
  // boundary is tied to a spoken phrase so visuals change with the concept.
  s01: [['s01-rabbit', 'Do you have'], ['s01-pet-care-extra', 'How do you look'], ['s01-highlights-extra', 'In this chapter'], ['s01-animal-ensemble-extra', 'and insects'], ['s01-homes-extra', 'Finally']],
  s02: [['s03-elephant-clean', null], ['s02-animal-eating-clean', 'nature'], ['s02-eat-drink', 'food'], ['s02-rest-shelter', 'survive'], ['s14-features-review', 'Their size'], ['s02-needs-extra', 'place they are found'], ['s02-care-protection-extra', 'All animals']],
  s03: [['s03-land-water-extra', null], ['s03-water', 'Animals that live in water'], ['s03-land-clean', 'Animals that live on land'], ['s03-land', 'Lion']],
  s04: [['s04-duck', null], ['s01-bird', 'and a beak'], ['s04-pigeon-parrot', 'The duck']],
  s05: [['s05-butterfly', null], ['s05-insects-extra', 'Insects'], ['s05-housefly-clean', 'Some insects'], ['s05-fly-grasshopper', 'housefly']],
  s06: [['s06-pets-extra', null], ['s06-domestic-pets', 'They are'], ['s14-homes-review', 'Some animals'], ['s16-care', 'pets']],
  s07: [['s07-tiger-clean', null], ['s07-wild-extra', 'They are']],
  s08: [['s08-habitats-clean', null], ['s08-food-homes-extra', 'Different animals']],
  s09: [['s09-lion-den', null], ['s09-homes-extra', 'These caves'], ['s09-lion-eating-extra', 'Lions eat'], ['s09-rabbit-burrow', 'Rabbits'], ['s09-rabbits-extra', 'live in burrows']],
  s10: [['s10-nest', null], ['s10-bird-food-extra', 'They eat'], ['s10-homes-extra', 'and so on'], ['s10-anthill', 'Ants make'], ['s10-bees-clean', 'Ants live']],
  s11: [['s11-human-homes-extra', null], ['s11-kennel', 'A dog'], ['s11-shed-stable', 'A cow']]
};

const normalise = (value) => String(value).toLowerCase().replace(/[^a-z0-9']+/g, '');
const phraseStart = (segment, phrase) => {
  if (!phrase) return segment.start_ms;
  const wanted = phrase.split(/\s+/).map(normalise).filter(Boolean);
  const tokens = segment.words.map((word) => normalise(word.word));
  for (let index = 0; index <= tokens.length - wanted.length; index += 1) {
    if (wanted.every((token, offset) => tokens[index + offset] === token)) return segment.words[index].startMs;
  }
  throw new Error(`Phrase not found in ${segment.section_id}: ${phrase}`);
};

const sentenceBoundaries = (segment) => {
  const sentences = [];
  let sentenceWords = [];
  for (const word of segment.words) {
    sentenceWords.push(word);
    if (/[.!?][\"']?$/.test(word.word)) {
      sentences.push(sentenceWords);
      sentenceWords = [];
    }
  }
  if (sentenceWords.length) sentences.push(sentenceWords);
  return sentences.map((group, index) => ({
    text: group.map((word) => word.word).join(' '),
    startMs: group[0].startMs,
    endMs: sentences[index + 1]?.[0]?.startMs ?? segment.end_ms
  }));
};

// Text is transcribed from textbook pages 12-14. Anchors are phrases in the
// approved narration, so exactly one teaching item is visible while it is read.
const teachingSpecs = {
  s12: [
    { heading: "Let's Recall", anchor: null, text: 'Animals live both on land and in water.', marker: true },
    { heading: "Let's Recall", anchor: 'Animals are of', text: 'Animals are of different sizes.', marker: true },
    { heading: "Let's Recall", anchor: 'Animals that can fly', text: 'Animals that can fly are called birds.', marker: true },
    { heading: "Let's Recall", anchor: 'Very small animals', text: 'Very small animals are called insects.', marker: true },
    { heading: "Let's Recall", anchor: 'Animals that can be kept', text: 'Animals that can be kept at home are domestic animals.', marker: true },
    { heading: "Let's Recall", anchor: 'Animals that live in jungle', text: 'Animals that live in jungle are called wild animals.', marker: true },
    { heading: "Let's Recall", anchor: 'Different animals live', text: 'Different animals live in different homes and eat different foods.', marker: true }
  ],
  s13: [
    { heading: 'Glossary', anchor: null, term: 'Birds', text: 'Animals that can fly are called birds.' },
    { heading: 'Glossary', anchor: 'Insects are very', term: 'Insects', text: 'Very small animals are called insects.' },
    { heading: 'Glossary', anchor: 'Domestic animals are', term: 'Domestic animals', text: 'animals that can be kept at home.' },
    { heading: 'Glossary', anchor: 'Wild animals are', term: 'Wild animals', text: 'Animals that live in jungle.' },
    { heading: 'Glossary', anchor: 'A den is', term: 'Den', text: 'Place where lions live.' }
  ],
  s14: [
    { heading: 'Assessment', anchor: null, group: 'I. Answer the following question.', text: '' },
    { heading: 'Assessment', anchor: 'Name any two', group: 'I. Answer the following question.', number: '1.', text: 'Name any two pet animals.' },
    { heading: 'Assessment', anchor: 'Where are dogs', group: 'I. Answer the following question.', number: '2.', text: 'Where are dogs kept?' },
    { heading: 'Assessment', anchor: 'What do the birds', group: 'I. Answer the following question.', number: '3.', text: 'What do the birds build?' },
    { heading: 'Assessment', anchor: 'Fill in the blanks', group: 'II. Fill in the blanks.', text: '' },
    { heading: 'Assessment', anchor: 'Rabbits live', group: 'II. Fill in the blanks.', number: '1.', text: 'Rabbits live in _______________________.' },
    { heading: 'Assessment', anchor: 'Birds have', group: 'II. Fill in the blanks.', number: '2.', text: 'Birds have _______________________ to fly.' },
    { heading: 'Assessment', anchor: 'Animals that live in water', group: 'II. Fill in the blanks.', number: '3.', text: 'Animals that live in water are called _______________________.' },
    { heading: 'Assessment', anchor: 'Insects have', group: 'II. Fill in the blanks.', number: '4.', text: 'Insects have _______________________ legs.' },
    { heading: 'Assessment', anchor: 'Ants live', group: 'II. Fill in the blanks.', number: '5.', text: 'Ants live in a group like _______________________.' }
  ],
  s15: [
    { heading: 'Assessment', anchor: null, group: 'III. Choose the correct answer.', text: '' },
    { heading: 'Assessment', anchor: 'Fish live', group: 'III. Choose the correct answer.', number: '1.', text: 'Fish live in _______________________.', options: ['a) water', 'b) land', 'c) both water and land'] },
    { heading: 'Assessment', anchor: 'Animals that live on land', group: 'III. Choose the correct answer.', number: '2.', text: 'Animals that live on land are called _______________________ animals.', options: ['a) land', 'b) water', 'c) none of these'] },
    { heading: 'Assessment', anchor: 'A butterfly is', group: 'III. Choose the correct answer.', number: '3.', text: 'Butterfly is a _______________________.', options: ['a) bird', 'b) insect', 'c) none of these'] },
    { heading: 'Assessment', anchor: 'Parrot and rabbit', group: 'III. Choose the correct answer.', number: '4.', text: 'Parrot and rabbit are _______________________ animals.', options: ['a) wild', 'b) pet', 'c) insect'] },
    { heading: 'Assessment', anchor: 'A tiger is', group: 'III. Choose the correct answer.', number: '5.', text: 'Tiger is a _______________________ animal.', options: ['a) Domestic', 'b) Wild', 'c) Pet'] }
  ],
  s16: [
    { heading: 'ACTIVITY', anchor: null, text: 'Draw any animal of your choice and name it.' },
    { heading: 'Life Skills', anchor: 'Life Skills', text: 'Animals also have feelings. Do not hurt animals. They will be friendly to us. Protect animals.' }
  ]
};

const captions = [];
let page = [];
for (const word of words) {
  page.push(word);
  if (word.pageBreakAfter) {
    captions.push({
      id: `caption-${captions.length + 1}`,
      startMs: Math.max(0, page[0].startMs - timelineOffsetMs),
      endMs: Math.max(0, page.at(-1).endMs - timelineOffsetMs),
      words: page.map((item) => ({ text: item.word, startMs: Math.max(0, item.startMs - timelineOffsetMs), endMs: Math.max(0, item.endMs - timelineOffsetMs) }))
    });
    page = [];
  }
}
if (page.length) captions.push({ id: `caption-${captions.length + 1}`, startMs: Math.max(0, page[0].startMs - timelineOffsetMs), endMs: Math.max(0, page.at(-1).endMs - timelineOffsetMs), words: page.map((item) => ({ text: item.word, startMs: Math.max(0, item.startMs - timelineOffsetMs), endMs: Math.max(0, item.endMs - timelineOffsetMs) })) });

const syncById = Object.fromEntries(sync.sections.map((section) => [section.section_id, section]));
const sections = narration.segments.map((originalSegment, index) => {
  const segment = {
    ...originalSegment,
    start_ms: Math.max(0, originalSegment.start_ms - timelineOffsetMs),
    end_ms: Math.max(0, originalSegment.end_ms - timelineOffsetMs),
    words: originalSegment.words.map((word) => ({ ...word, startMs: Math.max(0, word.startMs - timelineOffsetMs), endMs: Math.max(0, word.endMs - timelineOffsetMs) }))
  };
  const [label, title, summary] = metadata[segment.section_id];
  const coverage = [];
  const pool = storyCues[segment.section_id] || [];
  const boundaries = pool.map(([, phrase]) => phraseStart(segment, phrase));
  for (let slot = 0; slot < pool.length; slot += 1) {
    const baseStart = boundaries[slot];
    const hasFollowingStorySection = Boolean(storyCues[narration.segments[index + 1]?.section_id]);
    // Keep the outgoing story visible while the next section fades in. Ending
    // both clips at opacity zero on the same frame created pale blank flashes.
    const baseEnd = slot === pool.length - 1
      ? segment.end_ms + (hasFollowingStorySection ? 120 : 0)
      : boundaries[slot + 1];
    const startMs = slot === 0 ? baseStart : baseStart - 120;
    const endMs = slot === pool.length - 1 ? baseEnd : baseEnd + 120;
    const sourceAssetId = pool[slot][0];
    coverage.push({ id: `${segment.section_id}-story-${slot + 1}`, sourceAssetId, src: `assets/video/story/${segment.section_id}-story-${slot + 1}.mp4`, startMs, endMs });
  }
  const specs = teachingSpecs[segment.section_id] || [];
  const teachingSequence = specs.map((item, itemIndex) => ({
    ...item,
    id: `${segment.section_id}-teaching-${itemIndex + 1}`,
    startMs: phraseStart(segment, item.anchor),
    endMs: itemIndex + 1 < specs.length ? phraseStart(segment, specs[itemIndex + 1].anchor) : segment.end_ms
  }));
  return {
    id: segment.section_id,
    number: index + 1,
    label,
    title,
    summary,
    teachingSequence,
    startMs: segment.start_ms,
    endMs: segment.end_ms,
    audio: `assets/audio/${segment.section_id}.wav`,
    sentences: sentenceBoundaries(segment),
    coverage,
    cues: (syncById[segment.section_id]?.cues || []).map((cue, cueIndex) => ({
      id: `${segment.section_id}-cue-${cueIndex + 1}`,
      assetId: cue.asset_id,
      src: `assets/video/${cue.asset_id}.mp4`,
      startMs: Math.max(0, cue.start_ms_absolute - timelineOffsetMs),
      endMs: Math.max(0, cue.end_ms_absolute - timelineOffsetMs)
    }))
  };
});

const openingSegment = sections.find((section) => section.id === 's01');
const openingSource = narration.segments.find((section) => section.section_id === 's01');
const opening = {
  introEndMs: phraseStart(openingSource, 'Do you have'),
  questionsStartMs: phraseStart(openingSource, 'Do you have'),
  questionsEndMs: phraseStart(openingSource, 'In this chapter'),
  highlightsStartMs: phraseStart(openingSource, 'In this chapter'),
  highlightsEndMs: openingSegment.endMs
};
const data = { durationMs: sync.timeline_end_ms - timelineOffsetMs, sections, captions, opening };
fs.writeFileSync(path.join(here, 'production-data.js'), `window.PRODUCTION_DATA = ${JSON.stringify(data)};\n`);
fs.writeFileSync(path.join(here, 'story-render-plan.json'), JSON.stringify(sections.flatMap((section) => section.coverage.map((cue) => ({ id: cue.id, sourceAssetId: cue.sourceAssetId, durationSeconds: (cue.endMs - cue.startMs) / 1000, output: cue.src }))), null, 2));
const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
const makeVideoMarkup = (section, sectionIndex, cue, cueIndex, kind) => {
  const start = cue.startMs / 1000;
  const duration = (cue.endMs - cue.startMs) / 1000;
  const track = kind === 'story' ? 20 + sectionIndex * 20 + cueIndex : 500 + sectionIndex * 20 + cueIndex;
  return `<div id="${cue.id}" class="video-cue video-${kind}"><video id="media-${cue.id}" src="${cue.src}" muted playsinline preload="auto" data-start="${start}" data-duration="${duration}" data-track-index="${track}"></video></div>`;
};
const videoMarkup = sections.flatMap((section, sectionIndex) => [
  ...section.coverage.map((cue, cueIndex) => makeVideoMarkup(section, sectionIndex, cue, cueIndex, 'story'))
]).join('');
const audioMarkup = sections.map((section, index) => `<audio id="narration-${section.id}" src="${section.audio}" preload="auto" data-start="${section.startMs / 1000}" data-duration="${(section.endMs - section.startMs) / 1000}" data-track-index="${100 + index}" data-volume="1"></audio>`).join('');
const indexPath = path.join(here, 'index.html');
const currentIndex = fs.readFileSync(indexPath, 'utf8');
const openingUi = `<div id="opening-ui"><div class="opening-badge">We Learn</div><div id="opening-questions" class="opening-card"><h3>We Learn</h3><p>Do you have any pet animals?</p><p>How do you look after your pet animal?</p></div><div id="opening-highlights" class="opening-card"><h3>Highlights of the Lesson</h3><ul><li>Animals around us</li><li>Land animals</li><li>Water animals</li><li>Birds</li><li>Insects</li><li>Animal homes</li></ul></div></div>`;
const staticMedia = `<!-- GENERATED_MEDIA_START -->${openingUi}<div id="section-card-layer"></div><div id="cues">${videoMarkup}</div><div id="audio">${audioMarkup}</div><!-- GENERATED_MEDIA_END -->`;
const nextIndex = currentIndex.replace(/<!-- GENERATED_MEDIA_START -->[\s\S]*?<!-- GENERATED_MEDIA_END -->/, staticMedia);
if (nextIndex === currentIndex && !currentIndex.includes('<!-- GENERATED_MEDIA_START -->')) throw new Error('Generated media markers are missing from index.html');
fs.writeFileSync(indexPath, nextIndex.replace(/data-duration="[\d.]+"/, `data-duration="${data.durationMs / 1000}"`));
console.log(`Wrote ${sections.length} sections, ${sections.reduce((n, s) => n + s.coverage.length, 0)} unique story clips and ${captions.length} captions.`);
