import json
d = json.load(open(r'D:\InkSpectrum\OpenMontage\projects\evs-lesson-8\artifacts\word_alignment.json'))
s = [sec for sec in d['sections'] if sec['section_id'] == 's03'][0]
for sent in s['sentences']:
    for w in sent['words']:
        if w['is_emphasis']:
            print(f"  EMPHASIS: {w['word']}")
