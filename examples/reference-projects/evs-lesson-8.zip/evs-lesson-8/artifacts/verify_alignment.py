import json
d = json.load(open(r'D:\InkSpectrum\OpenMontage\projects\evs-lesson-8\artifacts\word_alignment.json'))
s = d['sections'][0]
print(f"s01: {s['start_s']} -> {s['end_s']} dur: {s['duration_s']}")
for sent in s['sentences']:
    print(f"  {sent['start_s']:7.3f} -> {sent['end_s']:7.3f}  {sent['role']:12s}  {sent['text'][:60]}")
print()
# Check all sections end times match start + duration
for sec in d['sections']:
    expected_end = sec['start_s'] + sec['duration_s']
    if abs(sec['end_s'] - expected_end) > 0.01:
        print(f"MISMATCH {sec['section_id']}: end_s={sec['end_s']} expected={expected_end}")
print("All section end times verified.")
