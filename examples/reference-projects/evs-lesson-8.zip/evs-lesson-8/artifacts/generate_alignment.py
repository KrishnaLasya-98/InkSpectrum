#!/usr/bin/env python3
"""Generate word-level timestamps for EVS Lesson 8 narration."""

import json
import re
import os

WORKDIR = r"D:\InkSpectrum\OpenMontage\projects\evs-lesson-8"

with open(os.path.join(WORKDIR, "artifacts", "script.json"), "r", encoding="utf-8") as f:
    script = json.load(f)

with open(os.path.join(WORKDIR, "artifacts", "narration_manifest.json"), "r", encoding="utf-8") as f:
    manifest = json.load(f)

# Build manifest lookup by section_id
manifest_by_section = {seg["section_id"]: seg for seg in manifest["segments"]}

def split_sentences(text):
    """Split text into sentences by . ? ! while keeping the delimiter."""
    # Split on sentence-ending punctuation followed by space or end of string
    raw_sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    # Filter out empty strings
    return [s.strip() for s in raw_sentences if s.strip()]

def split_words(sentence):
    """Split sentence into words, stripping punctuation."""
    # Split on whitespace and remove surrounding punctuation
    words = re.findall(r"\b[\w']+\b", sentence)
    return words

def classify_role(sentence):
    """Classify the role of a sentence."""
    stripped = sentence.strip()
    lower = stripped.lower()
    
    # question: ends with ?
    if stripped.endswith("?"):
        return "question"
    
    # definition patterns
    if re.match(r'^(definition|define|what is|a\s+\w+\s+is)', lower):
        return "definition"
    
    # example patterns
    if re.match(r'^(for example|example|e\.g\.|like\b)', lower):
        return "example"
    
    # emphasis patterns
    if re.match(r'^(important|key|note|remember|watch)', lower):
        return "emphasis"
    
    # character_name: starts with emoji or punctuation (other than letter)
    if re.match(r'^[^\w]', stripped):
        return "character_name"
    
    return "statement"

def find_emphasis_for_word(word, emphasis_phrases, sentence_lower):
    """Check if a word is part of any emphasis phrase."""
    word_lower = word.lower()
    for phrase in emphasis_phrases:
        phrase_lower = phrase.lower()
        if word_lower in phrase_lower.split():
            # Verify the phrase appears in the sentence
            if phrase_lower in sentence_lower:
                return True
    return False

output_sections = []
total_words = 0
total_duration = 0.0

for section in script["sections"]:
    section_id = section["id"]
    manifest_seg = manifest_by_section.get(section_id, {})
    audio_duration = manifest_seg.get("duration_seconds", section["end_seconds"] - section["start_seconds"])
    
    text = section["text"]
    sentences = split_sentences(text)
    
    emphasis_phrases = section.get("delivery_cues", {}).get("emphasis_words", [])
    pause_after = section.get("delivery_cues", {}).get("pause_after_seconds", 1)
    
    # Calculate word counts per sentence
    sentence_word_counts = []
    total_words_in_section = 0
    for sent in sentences:
        words = split_words(sent)
        sentence_word_counts.append(len(words))
        total_words_in_section += len(words)
    
    if total_words_in_section == 0:
        continue
    
    # Distribute section duration proportionally by word count
    # We don't explicitly add pause_after_seconds as dead time;
    # the TTS audio duration already includes natural pauses.
    # We distribute the total audio duration among sentences by word count.
    current_time = section["start_seconds"]
    
    section_sentences = []
    for idx, sent in enumerate(sentences):
        words = split_words(sent)
        word_count = len(words)
        if word_count == 0:
            continue
        
        # Time for this sentence = proportion of total words * total duration
        sentence_duration = (word_count / total_words_in_section) * audio_duration
        sentence_end = current_time + sentence_duration
        
        role = classify_role(sent)
        sent_lower = sent.lower()
        
        # Build word list
        word_list = []
        word_duration = sentence_duration / word_count
        for w_idx, word in enumerate(words):
            word_start = current_time + (w_idx * word_duration)
            word_end = word_start + word_duration
            is_emphasis = find_emphasis_for_word(word, emphasis_phrases, sent_lower)
            word_list.append({
                "word": word,
                "start_s": round(word_start, 3),
                "end_s": round(word_end, 3),
                "is_emphasis": is_emphasis
            })
            total_words += 1
        
        # emphasis_words for the sentence: find which emphasis phrases fully match this sentence
        sentence_emphasis = []
        for phrase in emphasis_phrases:
            if phrase.lower() in sent_lower:
                sentence_emphasis.append(phrase)
        
        section_sentences.append({
            "text": sent,
            "start_s": round(current_time, 3),
            "end_s": round(sentence_end, 3),
            "role": role,
            "emphasis_words": sentence_emphasis,
            "words": word_list
        })
        
        current_time = sentence_end
    
    output_sections.append({
        "section_id": section_id,
        "start_s": section["start_seconds"],
        "end_s": round(section["start_seconds"] + audio_duration, 3),
        "duration_s": round(audio_duration, 3),
        "sentences": section_sentences
    })
    
    total_duration += audio_duration

result = {
    "sections": output_sections,
    "total_words": total_words,
    "total_duration_s": round(total_duration, 3)
}

output_path = os.path.join(WORKDIR, "artifacts", "word_alignment.json")
with open(output_path, "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)

print(f"Generated word_alignment.json: {total_words} words, {round(total_duration, 2)}s total")
for sec in output_sections:
    wc = sum(len(s["words"]) for s in sec["sentences"])
    print(f"  {sec['section_id']}: {wc} words, {sec['duration_s']}s, {len(sec['sentences'])} sentences")
