"""EVS Lesson 8 — end-to-end production runner.

Usage:
    python _produce.py [--skip-batch] [--skip-compose]

Steps:
    1. Preflight  — verify all artifacts exist and are schema-consistent
    2. Narration  — skip if all .norm.wav files already exist
    3. Batch      — generate missing video clips via _run_batch.py
    4. Compose    — assemble final_render.mp4 via _compose1.py

Pass --skip-batch  to go straight to compose (all clips must exist).
Pass --skip-compose to stop after batch generation.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT  = Path(__file__).resolve().parents[2]
PROJ  = ROOT / "projects" / "evs-lesson-8"
ART   = PROJ / "artifacts"
ASSET = PROJ / "assets" / "video" / "scenes"
AUDIO = PROJ / "renders" / "audio"


# ── helpers ──────────────────────────────────────────────────────────────────

def _probe_duration(path: Path) -> float:
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
        capture_output=True, text=True,
    )
    if r.returncode != 0:
        return 0.0
    try:
        return float(r.stdout.strip())
    except ValueError:
        return 0.0


def _ok(path: Path, min_s: float = 4.0) -> bool:
    return path.exists() and _probe_duration(path) >= min_s


def _run(script: str) -> None:
    result = subprocess.run(
        [sys.executable, str(PROJ / script)],
        cwd=str(ROOT),
    )
    if result.returncode != 0:
        raise SystemExit(f"{script} exited with code {result.returncode}")


# ── preflight ─────────────────────────────────────────────────────────────────

def preflight() -> dict:
    print("\n── Preflight ──────────────────────────────────────────────────")
    errors: list[str] = []

    # required artifact files
    for name in ("script.json", "narration_manifest.json"):
        if not (ART / name).exists():
            errors.append(f"missing artifact: {name}")

    if errors:
        for e in errors:
            print(f"  ERROR: {e}")
        raise SystemExit("Preflight failed — fix errors above before continuing.")

    script     = json.loads((ART / "script.json").read_text(encoding="utf-8"))
    narration  = json.loads((ART / "narration_manifest.json").read_text(encoding="utf-8"))
    nar_by_sid = {s["section_id"]: s for s in narration["segments"]}

    sections = script["sections"]

    # contiguity check (all pairs)
    for a, b in zip(sections, sections[1:]):
        if a["end_seconds"] != b["start_seconds"]:
            errors.append(
                f"gap between {a['id']} ({a['end_seconds']}) "
                f"and {b['id']} ({b['start_seconds']})"
            )
    if sections[0]["start_seconds"] != 0:
        errors.append("first section does not start at 0")
    if sections[-1]["end_seconds"] != script["total_duration_seconds"]:
        errors.append("last section does not end at total_duration_seconds")

    # narration duration vs window
    for sec in sections:
        sid    = sec["id"]
        window = sec["end_seconds"] - sec["start_seconds"]
        seg    = nar_by_sid.get(sid)
        if seg and seg["duration_seconds"] > window:
            errors.append(
                f"{sid} narration {seg['duration_seconds']:.2f}s "
                f"exceeds window {window}s"
            )

    if errors:
        for e in errors:
            print(f"  ERROR: {e}")
        raise SystemExit("Preflight failed.")

    # clip inventory
    clip_status: dict[str, dict] = {}
    for sec in sections:
        sid = sec["id"]
        target = float(sec["end_seconds"] - sec["start_seconds"])
        clips = [c for c in sorted((ASSET / sid).glob(f"{sid}-*.mp4")) if _ok(c)]
        needed = max(1, round(target / 10))
        # The compositor cycles valid clips when a storyboard intentionally
        # provides fewer source clips than ten-second slots.
        clip_status[sid] = {
            "needed": needed,
            "have": len(clips),
            "missing": 0 if clips else 1,
        }

    total_needed  = sum(v["needed"]  for v in clip_status.values())
    total_have    = sum(v["have"]    for v in clip_status.values())
    total_missing = sum(v["missing"] for v in clip_status.values())

    print(f"  artifacts   : OK")
    print(f"  sections    : {len(sections)}")
    print(f"  clips       : {total_have}/{total_needed} present, {total_missing} missing")

    # narration audio
    nar_missing = [
        sid for sec in sections
        for sid in [sec["id"]]
        if not _ok(AUDIO / f"{sid}.norm.wav", min_s=1.0)
    ]
    print(f"  narration   : {len(sections) - len(nar_missing)}/{len(sections)} wav files present")

    print("  Preflight   : PASSED")
    return {
        "script": script,
        "narration": narration,
        "clip_status": clip_status,
        "total_missing_clips": total_missing,
        "missing_narration": nar_missing,
    }


# ── narration ─────────────────────────────────────────────────────────────────

def ensure_narration(state: dict) -> None:
    missing = state["missing_narration"]
    if not missing:
        print("\n── Narration ── all wav files present, skipping")
        return
    print(f"\n── Narration ── generating {len(missing)} missing segments")
    _run("_gen_narration.py")


# ── batch video ───────────────────────────────────────────────────────────────

def run_batch(state: dict) -> None:
    if state["total_missing_clips"] == 0:
        print("\n── Batch ── all clips present, skipping")
        return
    print(f"\n── Batch ── generating {state['total_missing_clips']} missing clips")
    _run("_run_batch.py")


# ── compose ───────────────────────────────────────────────────────────────────

def run_compose() -> None:
    print("\n── Compose ── assembling final_render.mp4")
    _run("_compose1.py")


# ── main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="EVS Lesson 8 production runner")
    parser.add_argument("--skip-batch",   action="store_true",
                        help="Skip video clip generation (all clips must exist)")
    parser.add_argument("--skip-compose", action="store_true",
                        help="Stop after batch generation, do not compose")
    args = parser.parse_args()

    state = preflight()
    ensure_narration(state)

    if not args.skip_batch:
        run_batch(state)
    else:
        print("\n── Batch ── skipped (--skip-batch)")

    if not args.skip_compose:
        run_compose()
    else:
        print("\n── Compose ── skipped (--skip-compose)")

    out = PROJ / "renders" / "final_render.mp4"
    if out.exists():
        dur = _probe_duration(out)
        print(f"\n✓ Done — {out}  ({dur:.1f}s)")
    else:
        print("\n✓ Done — compose was skipped or batch still running.")


if __name__ == "__main__":
    main()
