"""Build scene_plan.json for EVS Lesson 8 from script.json + _spec_a.SCENE_SPEC.
Emits only scene_plan.schema.json-allowed keys."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _spec_a import SCENE_SPEC  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
ART = ROOT / "projects" / "evs-lesson-8" / "artifacts"

script = json.loads((ART / "script.json").read_text(encoding="utf-8"))
sections = script["sections"]

SHOT_IDS = {
    "s01": "evs-s01-open", "s02": "evs-s02-needs", "s03": "evs-s03-waterland",
    "s04": "evs-s04-birds", "s05": "evs-s05-insects", "s06": "evs-s06-domestic",
    "s07": "evs-s07-wild", "s08": "evs-s08-homemap", "s09": "evs-s09-denburrow",
    "s10": "evs-s10-nestanthill", "s11": "evs-s11-homemade", "s12": "evs-s12-recall",
    "s13": "evs-s13-glossary", "s14": "evs-s14-assessment", "s15": "evs-s15-mcq",
    "s16": "evs-s16-close",
}

assert set(SHOT_IDS) == set(SCENE_SPEC), "scene spec must cover all script sections"


def build() -> list[dict]:
    scenes = []
    for sec in sections:
        sid = sec["id"]
        spec = SCENE_SPEC[sid]
        asset_note = spec.get("asset_note", "")
        scenes.append({
            "id": SHOT_IDS[sid],
            "type": "animation" if asset_note else "diagram",
            "description": spec["description"],
            "start_seconds": sec["start_seconds"],
            "end_seconds": sec["end_seconds"],
            "script_section_id": sid,
            "framing": spec["framing"],
            "movement": spec["movement"],
            "transition_in": spec["transition_in"],
            "transition_out": spec["transition_out"],
            "overlay_notes": spec["overlay_notes"],
            "shot_language": {
                "shot_size": spec["shot_size"],
                "camera_movement": "static",
                "lens_mm": 50,
                "lighting_key": "high_key",
                "depth_of_field": "deep",
                "color_temperature": "neutral",
            },
            "shot_intent": asset_note,
            "narrative_role": spec["narrative_role"],
            "information_role": spec["information_role"],
            "hero_moment": spec.get("hero_moment", False),
            "required_assets": [
                {"type": "video", "description": asset_note, "source": "generate"},
                {"type": "overlay", "description": spec["overlay_notes"], "source": "provided"},
            ],
        })
    return scenes


def main() -> None:
    scenes = build()
    # contiguity check
    for a, b in zip(scenes, scenes[1:]):
        assert a["end_seconds"] == b["start_seconds"], f"{a['id']} -> {b['id']} gap"
    assert scenes[0]["start_seconds"] == 0
    assert scenes[-1]["end_seconds"] == script["total_duration_seconds"]

    plan = {
        "version": "1.0",
        "style_playbook": "flat-motion-graphics",
        "scenes": scenes,
        "metadata": {
            "project_id": "evs-lesson-8",
            "title": "EVS Class 1 - Lesson 8: Animal Life",
            "total_duration_seconds": script["total_duration_seconds"],
            "grid_system": "6x6 rows A-F cols 1-6; composition-only placement",
            "motion_policy": ("Animation-first, linear subject motion. No looping, no replays, "
                              "no camera movement, no zoom, no Ken Burns."),
            "text_policy": "All labels, titles, definitions, questions, and answers added during composition.",
        },
    }
    out = ART / "scene_plan.json"
    out.write_text(json.dumps(plan, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"wrote {out}")
    print(f"scenes: {len(scenes)} | 0..{scenes[-1]['end_seconds']}s | types: "
          f"{sorted({s['type'] for s in scenes})}")


if __name__ == "__main__":
    main()