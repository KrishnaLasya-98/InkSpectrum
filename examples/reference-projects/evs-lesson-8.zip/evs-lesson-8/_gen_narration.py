"""Generate narration for EVS Lesson 8 using Edge TTS (free, local).
Writes renders/audio/sXX.mp3 + narration_manifest.json; measures real durations."""
from __future__ import annotations

import asyncio
import json
import subprocess
from pathlib import Path

import edge_tts

ROOT = Path(__file__).resolve().parents[2]
ART = ROOT / "projects" / "evs-lesson-8" / "artifacts"
AUDIO_DIR = ROOT / "projects" / "evs-lesson-8" / "renders" / "audio"
AUDIO_DIR.mkdir(parents=True, exist_ok=True)

VOICE = "en-US-EmmaNeural"


def probe_duration(path: Path) -> float:
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
        capture_output=True, text=True, check=True,
    )
    return float(r.stdout.strip())


async def synth(text: str, out: Path) -> None:
    await edge_tts.Communicate(text, voice=VOICE).save(str(out))


def normalize(path: Path) -> Path:
    norm = path.with_suffix(".norm.wav")
    subprocess.run(
        ["ffmpeg", "-y", "-i", str(path), "-af",
         "loudnorm=I=-14:TP=-1.5:LRA=11", "-ar", "44100", "-ac", "1",
         "-c:a", "pcm_s16le", str(norm)],
        capture_output=True, text=True, check=True,
    )
    return norm


def main() -> None:
    script = json.loads((ART / "script.json").read_text(encoding="utf-8"))

    segments = []
    total_dur = 0.0
    for sec in script["sections"]:
        sid = sec["id"]
        text = sec["text"]
        mp3 = AUDIO_DIR / f"{sid}.mp3"
        norm = AUDIO_DIR / f"{sid}.norm.wav"
        if norm.exists():
            dur = probe_duration(norm)
            print(f"{sid}: {dur:6.2f}s (cached)")
        else:
            asyncio.run(synth(text, mp3))
            normalize(mp3)
            dur = probe_duration(norm)
            print(f"{sid}: {dur:6.2f}s | target {sec['end_seconds'] - sec['start_seconds']}s")
        window = sec["end_seconds"] - sec["start_seconds"]
        if dur > window:
            raise RuntimeError(
                f"{sid} narration {dur:.2f}s exceeds section window {window}s. "
                "Shorten the script text or widen the section window."
            )
        total_dur += dur
        cues = sec["delivery_cues"]
        segments.append({
            "section_id": sid,
            "text": text,
            "audio_path": f"renders/audio/{sid}.norm.wav",
            "duration_seconds": round(dur, 2),
            "delivery_cues_applied": {
                "pace": cues["pace"],
                "energy": cues["energy"],
                "pause_before_seconds": cues["pause_before_seconds"],
                "pause_after_seconds": cues["pause_after_seconds"],
            },
            "cost_usd": 0.0,
        })

    manifest = {
        "version": "1.0",
        "engine_used": "edge_tts",
        "voice_name": VOICE,
        "voice_characteristics": {
            "child_friendly": True,
            "gender": "female",
            "accent": "us",
            "pace": "conversational",
            "energy": "warm",
        },
        "segments": segments,
        "total_duration_seconds": round(total_dur, 2),
        "total_cost_usd": 0.0,
        "metadata": {
            "project_id": "evs-lesson-8",
            "target_lufs": -14.0,
            "normalization": "loudnorm=I=-14:TP=-1.5:LRA=11",
            "note": "durations measured by ffprobe on normalized wav",
        },
    }
    (ART / "narration_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"\nwrote narration_manifest.json | total narration {manifest['total_duration_seconds']}s")


if __name__ == "__main__":
    main()