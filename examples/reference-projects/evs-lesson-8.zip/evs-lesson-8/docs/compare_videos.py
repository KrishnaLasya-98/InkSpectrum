import cv2, numpy as np, json, os

videos = {
    'main': r'C:\Users\user\Downloads\Lesson_8__Animal_Life.mp4',
    'pet_care': r'C:\Users\user\Downloads\Animal_Life__Pet_Care.mp4',
    'safari': r'C:\Users\user\Downloads\Animal_Life_Safari.mp4',
}

for name, path in videos.items():
    cap = cv2.VideoCapture(path)
    fps = cap.get(cv2.CAP_PROP_FPS)
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    dur = total / fps

    intervals = []
    prev_gray = None

    for t in np.arange(0, dur, 1.5):
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(t * fps))
        ret, frame = cap.read()
        if not ret:
            break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray_small = cv2.resize(gray, (80, 45))
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        if prev_gray is not None:
            diff = cv2.absdiff(gray_small, prev_gray)
            motion = float(np.mean(diff))
        else:
            motion = 0.0
        prev_gray = gray_small.copy()

        brightness = float(np.mean(gray))
        contrast = float(np.std(gray))
        colorfulness = float(np.mean(hsv[:,:,1].astype(float) * hsv[:,:,2].astype(float) / 65025.0))
        edges = cv2.Canny(gray, 50, 150)
        edge_density = float(np.count_nonzero(edges) / edges.size)

        h = gray.shape[0]
        top_sob = cv2.Sobel(gray[:int(h*0.12),:], cv2.CV_64F, 0, 1, ksize=3)
        bot_sob = cv2.Sobel(gray[int(h*0.88):,:], cv2.CV_64F, 0, 1, ksize=3)
        top_text = float(np.count_nonzero(np.abs(top_sob) > 30) / top_sob.size)
        bot_text = float(np.count_nonzero(np.abs(bot_sob) > 30) / bot_sob.size)

        hue_hist = np.histogram(hsv[:,:,0].flatten(), bins=8, range=(0,180))[0]
        hue_dom = int(np.argmax(hue_hist))

        pixels = frame.reshape(-1,3).astype(np.float32)
        criteria = (cv2.TERM_CRITERIA_EPS+cv2.TERM_CRITERIA_MAX_ITER, 5, 1.0)
        _, labels, centers = cv2.kmeans(pixels, 3, None, criteria, 5, cv2.KMEANS_RANDOM_CENTERS)
        centers = np.uint8(centers)
        counts = np.bincount(labels.flatten())
        sorted_idx = np.argsort(-counts)
        top_colors = centers[sorted_idx[:3]].tolist()

        intervals.append({
            't': round(t, 1), 'motion': round(motion, 1),
            'bright': round(brightness, 1), 'contrast': round(contrast, 1),
            'color': round(colorfulness, 3), 'edges': round(edge_density, 3),
            'top_text': round(top_text, 3), 'bot_text': round(bot_text, 3),
            'hue_dom': hue_dom, 'colors_bgr': top_colors,
        })

    cap.release()

    # Detect scene boundaries
    transitions = []
    for i in range(1, len(intervals)):
        if intervals[i]['motion'] > 40 and intervals[i-1]['motion'] < 5:
            dur_s = round(intervals[i]['t'] - intervals[i-1]['t'], 1)
            transitions.append({'at': round(intervals[i]['t'], 1), 'prev_scene_dur': dur_s})

    scene_durs = []
    prev_t = 0
    for tr in transitions:
        scene_durs.append(round(tr['prev_scene_dur'], 1))
        prev_t = tr['at']
    scene_durs.append(round(dur - prev_t, 1))

    top_text_frames = [i for i in intervals if i['top_text'] > 0.05]
    bot_text_frames = [i for i in intervals if i['bot_text'] > 0.05]

    avg_bright = np.mean([i['bright'] for i in intervals])
    avg_contrast = np.mean([i['contrast'] for i in intervals])
    avg_color = np.mean([i['color'] for i in intervals])

    print(f'=== {name.upper()} ({dur:.0f}s) ===')
    print(f'Scenes: {len(transitions)+1}')
    print(f'Avg scene dur: {np.mean(scene_durs):.1f}s, Min/Max: {min(scene_durs):.0f}s/{max(scene_durs):.0f}s')
    print(f'Scene durations: {[round(d) for d in scene_durs]}')
    print(f'Transition points: {[round(t["at"]) for t in transitions]}')
    print(f'Top text: {len(top_text_frames)}/{len(intervals)} ({100*len(top_text_frames)/len(intervals):.0f}%)')
    print(f'Bottom text: {len(bot_text_frames)}/{len(intervals)} ({100*len(bot_text_frames)/len(intervals):.0f}%)')
    print(f'Brightness: avg={avg_bright:.0f}, contrast: avg={avg_contrast:.0f}')
    print(f'Colorfulness: avg={avg_color:.3f}')
    print(f'Dom hues: {[i["hue_dom"] for i in intervals[::8]]}')
    print()

    # Detailed frame-by-frame for scene mapping
    print(f'  Frame-by-frame (t, bright, contrast, motion, top_text, bot_text, color):')
    for i in intervals[::4]:  # every 6s
        print(f'  t={i["t"]:5.1f}s  B={i["bright"]:5.1f}  C={i["contrast"]:5.1f}  M={i["motion"]:5.1f}  T={i["top_text"]:.3f}  B={i["bot_text"]:.3f}  Col={i["color"]:.3f}')
    print()
