# Anime-Style Automated Video Pipeline Architecture

## Reference Analysis: `Lesson_8__Animal_Life.mp4`

---

### 1.1 Technical Profile

| Property | Value |
|---|---|
| Format | MP4 (H.264 / AAC) |
| Resolution | 1280×720 (720p HD) |
| Frame rate | 24 fps |
| Duration | 421.02s (~7 min 1s) |
| Audio | AAC LC, mono, 44100 Hz, mean volume −21.7 dB |
| Container metadata | Encoded by Google (YouTube/Drive origin) |
| File size | 49.3 MB |
| Bitrate | 937 kbps video + 96 kbps audio |

### 1.2 Audio Characteristics

- **Speech density**: 94% of timeline has audible speech (26 silence gaps detected, mostly brief breath marks)
- **RMS energy**: 0.04–0.13 throughout, with peaks at t≈185s (intensified emphasis) and t≈300s (assessment section)
- **No background music**: Pure TTS narration, no music/SFX layer
- **Voice profile**: Clear, child-friendly narrator, conversational pacing with pauses after vocabulary words and questions

### 1.3 Visual Structure

**Scene cadence**: New scene every ~15–30 seconds (detected via frame-to-frame motion spikes at t = 13, 21, 38, 51, 65, 75, 89, 95, 115, 135, 155, 165, 190, 220, 240, 260, 280, 300, 315, 340, 355, 390)

**Brightness/Contrast pattern**:
| Range (sec) | Brightness | Contrast | Colorfulness | Description |
|---|---|---|---|---|
| 0–25 | 237–243 | 47–51 | 0.02 | White/opening screen |
| 25–38 | 197–220 | 58–73 | 0.12 | Bright content begins |
| 38–75 | 176–220 | 43–64 | 0.08–0.33 | Warm/blue themes |
| 75–120 | 184–220 | 64–71 | 0.11–0.21 | Transition + purple accent |
| 120–165 | 187–222 | 56–62 | 0.21 | Bright neutral |
| 165–195 | 203–222 | 53–67 | 0.05–0.19 | Neutral themes |
| 195–240 | 168–204 | 52–85 | 0.06–0.22 | Cooler tones, higher contrast |
| 240–300 | 192–216 | 46–74 | 0.06–0.14 | Moderate contrast |
| 300–360 | 179–206 | 59–64 | 0.08–0.10 | Green/teal themes |
| 360–421 | 169–246 | 21–69 | 0.05–0.17 | Fade to white (end card) |

**Text presence**: Consistent text in both top and bottom bands of the frame (edge density in top band: 0.05–0.20, bottom band: 0.03–0.24)

**White text ratio**: 0.37–0.99 across frames — light-colored text on dark/colored backgrounds

**Animation intensity**: Very low frame-to-frame motion within scenes (0.0–1.0 RMS difference), with high-motion spikes (40–100+) at scene transitions — indicating animated transitions (fades, wipes, slides) between static or slowly-animated content

### 1.4 Content Themes (Inferred from Visual Data)

Based on color palette shifts, brightness changes, and scene cadence:

| Time | Theme | Visual indicators |
|---|---|---|
| 0–25s | Opening/title screen | Brightness 237–243, white_text_ratio 0.90+, purple accent (BGR 235,143,231) |
| 25–75s | Animal introduction | Blue/teal dominant (BGR 87-147, 130-192), high edge density |
| 75–120s | Habitats | Warm yellow/beige, then purple/magenta themes |
| 120–195s | Animal behaviors | Neutral bright backgrounds, low edge density |
| 195–240s | Assessment/exercises | Higher contrast (85), cooler tones |
| 240–300s | Recap | Moderate contrast, green/teal themes |
| 300–420s | Review/Quiz | Varied themes, fade to white at end |

### 1.5 Existing System Mapping

| Reference Video Feature | OpenMontage Capability | Gap |
|---|---|---|
| Bright colorful backgrounds | `AnimeScene` (backgroundColor, lightingFrom/To) | Theme palette needs anime-specific colors |
| Camera motion (zoom/pan) | `AnimeScene` (8 motion types) | ✓ Matches |
| Crossfade transitions | `AnimeScene` (image crossfade) | ✓ Partial match |
| Kinetic typography (word-level) | `KineticTypography` + `KineticWord` | ✓ Matches exactly |
| Audio-reactive animations | `KineticWord` (amplitudeScaleRange) | ✓ Matches |
| Anime effects (sparkles, speed lines) | `AnimeEffectsLayer` (6 effect types) | ✓ Matches |
| Q&A assessment cards | `EduQAScene` (4 card formats) | ✓ Matches |
| Character reactions | `AnimeEffectsLayer` (reaction-pop) | ✓ Matches |
| Color themes | `Root.tsx` (5 themes incl. anime-ghibli) | Need "sunshine classroom" theme |
| Audio narration | `_gen_narration.py` (edge_tts) | ✓ Matches |
| Video assets | `_batch_video.py` (ModelsLab) | Used as source imagery in Remotion |

---

## 2. Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                             INPUT LAYER                                 │
│  ┌─────────────┐  ┌──────────────┐  ┌─────────────┐  ┌─────────────┐  │
│  │ script.json │  │ narration.wav │  │ video clips │  │ character   │  │
│  │ (sections,   │  │ (TTS audio,  │  │ (.mp4 from  │  │ images (.png│  │
│  │  text, cues) │  │  44100Hz)    │  │  ModelsLab)  │  │  with alpha)│  │
│  └─────────────┘  └──────────────┘  └─────────────┘  └─────────────┘  │
└────────────────────────────────┬───────────────────────────────────────┘
                                 │
┌────────────────────────────────┴───────────────────────────────────────┐
│                    ANALYSIS & PLANNING LAYER                            │
│                                                                         │
│  1. Audio Segmentation Engine ──► segmentation.json                    │
│     • stable-ts (Whisper) word alignment                              │
│     • auditok + silero VAD pause detection                             │
│     • parselmouth prosody (pitch/intensity)                            │
│     • Text heuristics fallback for flat TTS                           │
│                                                                         │
│  2. Asset Registry Builder ──► asset_registry.json                     │
│     • Scan video clips, character images, backgrounds                    │
│     • Probe metadata (duration, dimensions, alpha, checksum)            │
│     • Validate availability, resolve fallbacks                         │
│                                                                         │
│  3. Scene Planner ──► scene_plan.json                                  │
│     • Map audio segments → visual assets via narrative tags             │
│     • Resolve layering (base/character/exercise, max 3 layers)          │
│     • Compute frame-exact timing (startFrame/endFrame)                  │
│     • Generate typography layout (word wrapping, hierarchy)             │
│     • Identify Q&A segments → EduQACard plan                            │
└────────────────────────────────┬───────────────────────────────────────┘
                                 │
┌────────────────────────────────┴───────────────────────────────────────┐
│                          RENDER LAYER (Remotion)                       │
│                                                                         │
│  EduVideoComposition (root)                                             │
│  ├── AnimeScene (background + camera motion + particles)                │
│  ├── KineticTypography (word-level synced captions)                   │
│  │   ├── KineticWord (entrance/exit/audio-reactive)                    │
│  │   └── AnimeEffectsLayer (sparkles, speed-lines, reaction-pops)       │
│  ├── AssetLayer (character images, chapter videos as overlays)          │
│  ├── EduQAScene (for assessment/recall sections)                        │
│  └── EndTag (closing card)                                              │
│                                                                         │
│  Output: 1920×1080 @ 30fps, H.264, AAC                              │
└────────────────────────────────┬───────────────────────────────────────┘
                                 │
┌────────────────────────────────┴───────────────────────────────────────┐
│                       QUALITY ASSURANCE & OUTPUT                        │
│                                                                         │
│  4. QA Validator                                                       │
│     • AV sync check (max 50ms drift)                                   │
│     • Audio levels (−18 to −14 LUFS, peak < −1 dBFS)                   │
│     • Frame integrity (no drops, no blank > 2s)                         │
│     • Typography readability (contrast, minimum size)                  │
│     • Child-intelligibility heuristic                                   │
│                                                                         │
│  5. Output: final_render_1080p.mp4 + qa_report.json                     │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Pillar 1: Audio-Driven Temporal Segmentation

### 3.1 Library Stack

| Task | Primary Library | Fallback |
|---|---|---|
| Word-level alignment | `stable-ts` (Whisper `small.en`) | `torchaudio` MMS_FA |
| Pause/silence detection | `auditok` (Otsu adaptive) + `silero-vad` | `pydub` fixed thresh |
| Prosody analysis | `parselmouth` (Praat) | `librosa` (RMS energy) |

### 3.2 Segmentation Pipeline

```
script.json [text] + narration.wav [audio]
    │
    ├──► stable-ts align(audio, text) ──► word_timestamps [{word, start_s, end_s, prob}]
    ├──► auditok(audio) ──► pause_regions [{start_s, end_s, duration_s, type}]
    │     type = "breath_mark" (150-300ms) | "sentence_boundary" (300ms+) | "scene_gap" (1000ms+)
    ├──► parselmouth(audio) ──► per-phrase F0/intensity
    │     f0_std < 15 Hz → flat TTS → activate text heuristics
    └──► Text heuristics (punctuation + keyword density) ──► text_beats []
    │
    └──► segmentation.json
         ┌─ segments: [{id, text, start_s, end_s, words[], pause_before, pause_after, prosody}]
         ├─ pause_regions: [...]
         └─ global_prosody: {monotony_score, fallback_used}
```

### 3.3 Remotion Timing Mapping

```
segment.start_s  →  Sequence from={round(start_s * 30)}
segment.duration_s →  Sequence durationInFrames={round(duration_s * 30)}
```

**Cut decisions based on pause_after_s**:
- `pause_after < 0.15s` → No cut, within-sentence animation only
- `0.15 ≤ pause_after < 0.5s` → Scene transition (15-frame crossfade)
- `pause_after ≥ 0.5s` → Hard cut with swirl transition (24 frames)

**Fallback for flat TTS** (`monotony_score > 0.6`):
1. Sentence boundaries (`.` `!` `?` punctuation) become scene cuts
2. Keyword emphasis words trigger animation pops
3. Every 7 seconds, force a subtle visual refresh (lighting shift)

### 3.4 Integration with Existing System

The existing `_gen_narration.py` produces the audio. A new `_analyze_audio.py` script will:
1. Load `script.json` and `narration_manifest.json`
2. Run stable-ts alignment on each section's `.wav` file
3. Merge all sections into a global timeline
4. Write `artifacts/segmentation.json`

---

## 4. Pillar 2: Dynamic Asset Orchestration & Scene Logic

### 4.1 Asset Registry

Built from existing directories:

```json
{
  "assets": {
    "s01-0_video": {
      "id": "s01-0_video",
      "kind": "chapter_video",
      "source": {"type": "file", "path": "assets/video/scenes/s01/s01-0.mp4"},
      "duration_s": 10.0,
      "tags": ["introduction", "welcome"],
      "visual_priority": 80,
      "z_preference": "base",
      "fallback_chain": ["s01-1_video", "s01-2_video", "solid:#FFE8D1"]
    },
    "s05-butterfly": {
      "id": "s05-butterfly",
      "kind": "character",
      "source": {"type": "file", "path": "assets/video/smoke/s05-butterfly.mp4"},
      "duration_s": null,
      "tags": ["insect", "example"],
      "visual_priority": 90,
      "z_preference": "character",
      "fallback_chain": ["char_ladybug", "solid:#4ECDC4"]
    }
  },
  "families": {
    "fish": {
      "primary": "s03-0_video",
      "alternatives": ["s10-0_video"]
    }
  }
}
```

### 4.2 Mapping Engine

```typescript
// Pure function: (segment, section, registry, fps) -> SceneLayer[]
function mapScenePlan(segment, section, registry, fps) {
  const layers = [];
  
  // 1. Base layer: chapter video(s) for this section
  const baseAssets = registry.assets.filter(a => 
    a.section === segment.section_id && 
    a.z_preference === "base" && 
    a.availability === "available"
  );
  const baseAsset = baseAssets[0] || fallbackToSolid(section.theme_color);
  layers.push({...baseAsset, role: "base", z: 0});
  
  // 2. Character layer: from enhancement_cues
  const charCues = section.enhancement_cues.filter(c => c.type === "character");
  if (charCues.length > 0) {
    const charAsset = registry.assets.find(a => 
      a.tags.includes(charCues[0].character) && a.kind === "character"
    ) || registry.assets.find(a => a.familyId === "character.default");
    if (charAsset) layers.push({...charAsset, role: "character", z: 1});
  }
  
  // 3. Exercise layer: for Q&A/recall sections
  if (section.tags.includes("assessment") || section.tags.includes("activity")) {
    layers.push({role: "exercise", z: 2, synthetic: true});
  }
  
  // Enforce max 3 layers — drop lowest priority non-mandatory
  if (layers.length > 3) {
    layers.sort((a, b) => (b.visual_priority || 50) - (a.priority || 50));
    layers.splice(3);
  }
  
  return layers;
}
```

### 4.3 Integration with Existing System

The existing `script.json` has `enhancement_cues` that specify animations and overlays at specific timestamps. The mapping engine will:
1. Parse `section.enhancement_cues` to find character/video references
2. Cross-reference with the asset registry
3. Output `scene_plan.json` with frame-exact layer assignments

---

## 5. Pillar 3: Kinetic Typography & Motion Design

### 5.1 Ready-to-Use Components

The `KineticTypography.tsx`, `KineticWord.tsx`, and `AnimeEffectsLayer.tsx` components (29KB combined) are production-ready:

**KineticWord** provides:
- Word-level timing (uses `word.start`/`word.end` from alignment)
- State machine: `enter` (150ms spring) → `active` (highlight) → `exit` (200ms fade)
- Audio-reactive scaling: `amplitudeScaleRange: [0, 0.15]` (0–15% based on RMS)
- Consonant pop: `consonantPopScale: 0.20` on plosive consonants (p, t, k, b, d, g)
- Idle animations: floating (500ms ease-in-out) + breathing (1200ms, 1.0→1.03→1.0)
- Sentence-role positioning:
  - `statement` → top-left
  - `question` → bounce center
  - `definition` → center-scale
  - `character_name` → bottom-left
  - `emphasis` → center

**AnimeEffectsLayer** provides:
- `sparkles` (word-level, 10 particles, 600ms lifespan)
- `burst` (sentence-level, radial)
- `swirl` (scene transitions, 4× full rotation)
- `stardust` (character name reveals, twinkling)
- `reaction-pop` (emoji pop, spring enter/exit)
- `screen-shake` (emphasis moments, decaying)

### 5.2 Theme System

The existing `THEMES` in `Root.tsx` includes `"anime-ghibli"`:
```typescript
"anime-ghibli": {
  primaryColor: "#2D5016",   // Forest green
  accentColor: "#FFB347",    // Warm orange
  backgroundColor: "#0A0A1A", // Dark navy
  textColor: "#F0E6D3",      // Parchment
  chartColors: ["#FFB347", "#2D5016", "#FF6B9D", "#A8E6CF", "#6B4C8A", "#E8927C"],
  springConfig: { damping: 18, stiffness: 60, mass: 1 },
  transitionDuration: 1.0,
}
```

**Recommended child-friendly theme** (new, matches reference video):
```typescript
"sunshine-classroom": {
  primaryColor: "#FF8C42",   // Warm orange
  accentColor: "#4ECDC4",    // Teal
  backgroundColor: "#FFFDF0", // Near-white
  surfaceColor: "#FFFFFF",
  textColor: "#2D2D2D",      // Dark gray
  mutedTextColor: "#9CA3AF",
  chartColors: ["#FF8C42", "#4ECDC4", "#FFD93D", "#FF6B9D", "#6BCB77", "#A8E6CF"],
  springConfig: { damping: 20, stiffness: 100, mass: 0.8 },
  transitionDuration: 0.6,
}
```

### 5.3 Enhancement Cues Integration

The `script.json` contains `enhancement_cues` like:
```json
{"type": "animation", "description": "Three distinct animated animal actions appear in sequence: fish swims, bird flutters, rabbit hops.", "timestamp_seconds": 4}
```

These map directly to `AnimeEffectsLayer` triggers:
- "fish swims" → `particles-swirl` (blue, at bottom)
- "bird flutters" → `reaction-pop` with 🐦 emoji
- "rabbit hops" → `screen-shake` (gentle)

---

## 6. Pillar 4: Aesthetic Flow & Visual Continuity

### 6.1 Transition Library

| Transition | Duration | Trigger | Components |
|---|---|---|---|
| Soft crossfade | 15 frames (0.5s) | Sentence boundary, natural pause | `AnimeScene` image crossfade |
| Slide push | 30 frames (1.0s) | Scene change, different animal category | `Sequence` + transform |
| Swirl dissolve | 24 frames (0.8s) | Chapter boundary | `AnimeEffectsLayer` swirl |
| Color wash | 30 frames (1.0s) | Theme change | `AnimeScene` lightingFrom/To |
| Wipe (gradient) | 36 frames (1.2s) | Assessment → content | Custom mask animation |

### 6.2 Motion Interpolation

Using Remotion's `spring()` and `interpolate()`:

```typescript
// Ken Burns camera motion (AnimeScene default)
const scale = 1 + progress * 0.15;  // 15% zoom over scene duration
const translateX = interpolate(progress, [0, 1], [0, -22]);  // 22px pan
const translateY = interpolate(progress, [0, 1], [0, -14]);  // 14px pan

// Easing presets for children's content
const CHILD_EASINGS = {
  enter: { damping: 18, stiffness: 80 },   // Bouncy but controlled
  exit: { damping: 20, stiffness: 120 },   // Smooth exit
  emphasis: { damping: 10, stiffness: 200 }, // Sharp pop
  transition: { damping: 25, stiffness: 150 }, // Natural flow
};
```

### 6.3 Visual Continuity

- **Background color**: Persists across transitions with 800ms color wash
- **Text position**: Stays in top/bottom bands (matching reference video analysis)
- **Character persistence**: Character images stay for 3-5 seconds minimum, even across scene cuts
- **Particle trails**: 30-frame fade-out prevents abrupt removal of effects

---

## 7. Pillar 5: Automated QA & Rendering Pipeline

### 7.1 QA Validation Suite

| Check | Tool | Threshold |
|---|---|---|
| AV sync | `ffmpeg -async` + audio cross-correlation | Max 50ms drift |
| Audio LUFS | `librosa` + `pyloudnorm` | −18 to −14 LUFS |
| Audio peak | `pydub` | < −1 dBFS |
| Frame drops | `ffprobe` frame count vs expected | 0% drops |
| Blank screens | OpenCV frame analysis | < 2s per occurrence |
| Text contrast | `PIL.ImageStat` on sampled regions | ≥ 4.5:1 ratio |
| Font size | Check pixel height of text regions | ≥ 24px (720p) |
| Word timing | Compare SRT to audio alignment | Within ±50ms |

### 7.2 Rendering Configuration

```json
{
  "resolution": {"width": 1920, "height": 1080},
  "fps": 30,
  "codec": "libx264",
  "crf": 18,
  "preset": "medium",
  "audio_codec": "aac",
  "audio_bitrate": "192k",
  "pixel_format": "yuv420p"
}
```

### 7.3 End-to-End Pipeline

```
1. preflight.py
   → Verify script.json, narration_manifest.json, clips, assets
   → Generate asset_registry.json

2. _gen_narration.py
   → TTS audio per section (edge_tts, en-US-EmmaNeural)
   → Loudnorm I=-14:TP=-1.5:LRA=11
   → Write narration_manifest.json

3. _analyze_audio.py  (NEW)
   → stable-ts alignment → word_timestamps
   → auditok pauses → pause_regions
   → parselmouth prosody → beat_scores
   → Write segmentation.json

4. _plan_scenes.py  (NEW)
   → Map segmentation.json + script.json + asset_registry.json
   → Generate scene_plan.json with frame-exact timing

5. _remotion_render.py  (NEW)
   → remotion render --props=scene_plan.json
   → Output: final_render_1080p.mp4

6. _qa_validate.py  (NEW)
   → Run all QA checks
   → Write qa_report.json
   → Auto-fix: adjust audio levels, extend short clips
```

---

## 8. Capability Assessment: Can We Create a Video Like This?

### 8.1 What Already Exists (Production-Ready)

| Feature | Status | Source |
|---|---|---|
| Anime-style backgrounds | ✓ Ready | `AnimeScene.tsx`, `Root.tsx` themes |
| 8 camera motion types | ✓ Ready | `AnimeScene.tsx` (zoom, pan, ken-burns, parallax, drift) |
| Crossfade transitions | ✓ Ready | `AnimeScene.tsx` (multi-image crossfade) |
| Particle effects | ✓ Ready | `AnimeEffectsLayer.tsx` (6 effect types) |
| Reaction pops (emoji) | ✓ Ready | `AnimeEffectsLayer.tsx` (ReactionPop) |
| Kinetic typography | ✓ Ready | `KineticTypography.tsx`, `KineticWord.tsx` |
| Word-level audio sync | ✓ Ready | `KineticWord.tsx` (uses word timestamps) |
| Audio-reactive scaling | ✓ Ready | `KineticWord.tsx` (amplitudeScaleRange) |
| Consonant emphasis pops | ✓ Ready | `KineticWord.tsx` (detectPlosives) |
| Sentence role positioning | ✓ Ready | `KineticTypography.tsx` (5 roles) |
| Q&A assessment cards | ✓ Ready | `EduQAScene.tsx` (4 formats) |
| Animated reveal for Q&A | ✓ Ready | `EduQAScene.tsx` (spring animations) |
| Sparky mascot | ✓ Ready | `EduQAScene.tsx` (inline SVG) |
| Theme system | ✓ Ready | `Root.tsx` (5 themes) |
| Typography hierarchy | ✓ Ready | `KineticTypography.tsx` (4 levels) |
| Screen shake | ✓ Ready | `AnimeEffectsLayer.tsx` (ScreenShake) |

### 8.2 What Needs to Be Built

| Component | Effort | Files to Create |
|---|---|---|
| Audio segmentation engine | Medium | `_analyze_audio.py` |
| Asset registry builder | Medium | `_build_asset_registry.py` |
| Scene planner | Medium | `_plan_scenes.py` |
| Remotion composition root | Medium | `EduVideoComposition.tsx` |
| Audio layer integration | Low | Modify `KineticTypography.tsx` |
| QA validator | Medium | `_qa_validate.py` |
| Pipeline orchestrator | Low | Update `_produce.py` |

### 8.3 Integration with Existing Pipeline

The existing `_produce.py` orchestrator currently runs:
1. `preflight` → verify clips, narration
2. `ensure_narration` → generate TTS via edge_tts
3. `run_batch` → ModelsLab video generation
4. `run_compose` → ffmpeg-based composition

The new pipeline replaces steps 3–4 with:
3. `run_batch` → ModelsLab video generation (unchanged — clips become source assets)
4. `run_analysis` → Audio segmentation + scene planning
5. `run_remotion` → Remotion render with animation + text

### 8.4 Animation & Text Coverage

**Animation**: The existing `AnimeScene` component covers all detected animation types:
- Camera motion: zoom, pan, ken-burns, drift, parallax ✓
- Crossfade transitions ✓
- Particle effects (sparkles, swirl, burst, stardust) ✓
- Reaction pops (emoji) ✓
- Screen shake ✓

**Text**: The existing `KineticTypography` + `KineticWord` covers extensive text rendering:
- Word-by-word reveal synchronized to audio ✓
- Sentence role-based positioning ✓
- Audio-reactive scaling ✓
- Consonant pop animations ✓
- Idle animations (floating, breathing) ✓
- 4-level typographic hierarchy ✓
- Anime-style colors and fonts ✓

**Gap: Child-friendly theme**: Need to add `"sunshine-classroom"` theme to `Root.tsx` matching the reference video's bright, warm aesthetic (near-white backgrounds, orange/teal accents, dark text).

---

## 9. Implementation Roadmap

### Phase 1: Audio Segmentation & Analysis (Week 1)

```
pip install stable-ts parselmouth auditok numpy

python _analyze_audio.py \
  --script artifacts/script.json \
  --audio renders/audio/ \
  --output artifacts/segmentation.json
```

Deliverables: `segmentation.json` with word timestamps, pause regions, prosody scores, and scene cut points.

### Phase 2: Asset Registry & Scene Planning (Week 1-2)

```
python _build_asset_registry.py \
  --assets-dir projects/evs-lesson-8/assets \
  --output artifacts/asset_registry.json

python _plan_scenes.py \
  --segmentation artifacts/segmentation.json \
  --script artifacts/script.json \
  --registry artifacts/asset_registry.json \
  --output artifacts/scene_plan.json
```

Deliverables: `asset_registry.json`, `scene_plan.json` with frame-exact layer assignments.

### Phase 3: Remotion Composition (Week 2-3)

Create `EduVideoComposition.tsx` that:
- Reads `scene_plan.json` as props
- Uses `TransitionSeries` for scene cuts
- Composes `AnimeScene` (background) + `KineticTypography` (text) + `AssetLayer` (characters) + `AnimeEffectsLayer` (effects)
- Integrates `EduQAScene` for assessment sections
- Uses `"sunshine-classroom"` theme

### Phase 4: QA & Orchestration (Week 3)

- Implement `_qa_validate.py` with all checks from §7.1
- Update `_produce.py` to call Remotion render instead of ffmpeg compose
- Add resumability (skip completed scenes)
- Add progress tracking with ETA

### Phase 5: Testing & Tuning (Week 4)

- Render test video for s01-s05 (first 3 minutes)
- Compare visual output to reference `Lesson_8__Animal_Life.mp4`
- Adjust timing, colors, and animation parameters
- Validate child intelligibility heuristic

---

## 10. Recommendations

1. **Start with the EVS Lesson 8 project** — all assets and narration are ready
2. **Implement audio segmentation first** — it drives all timing decisions
3. **Use the `"anime-ghibli"` theme as base** — just change colors to brighten it
4. **Repurpose existing `AnimeScene` for backgrounds** — feed ModelsLab clips as image arrays for crossfading
5. **Use `KineticTypography` directly** — it already handles word-level sync
6. **Trigger `AnimeEffectsLayer` from `enhancement_cues`** in `script.json`
7. **Use `EduQAScene` for s12 (recall) and s14 (assessment)** — already designed for this
8. **Render at 1920×1080** for higher quality than the reference video
9. **Add bed music** — the reference has none, but children's content benefits from subtle background music with ducking
10. **Run QA validation** before final output to catch any sync or readability issues
