# Non-Linear Video Composition Architecture
## Dynamic Topic-Based Sequencing with Remotion & HyperFrames

### Project Context
- **39 video clips** across 16 sections, organized into 10 thematic topics
- **16 narration tracks** (edge_tts, en-US-EmmaNeural, ~224s total, loudnorm'd)
- **Available runtimes**: Remotion (React-based, 30 components ready) + HyperFrames (HTML/GSAP via `npx hyperframes`)
- **Style system**: `sunshine-classroom.yaml` — child-optimised (ages 5-7), warm palette, Nunito font, bouncy motion
- **Existing components**: AnimeScene, KineticTypography, AnimeEffectsLayer, EduQAScene, etc.

---

## Topic-to-Asset Mapping

| Topic | Sections | Clips | Visual Identity | Runtime Preference |
|---|---|---|---|---|
| intro | s01 | 3 | Opening/title card | HyperFrames (title card) |
| needs | s02 | 3 | Orange/teal, food/water/air icons | Remotion (AnimeScene) |
| habitats | s03, s06, s07 | 9 | Blue/green biomes, landscape videos | Remotion (AnimeScene crossfade) |
| birds | s04 | 3 | Sky blue, flying animations | Remotion + AnimeEffectsLayer |
| insects | s05 | 3 | Warm yellow, macro animations | Remotion (AnimeScene parallax) |
| homes | s08-s11 | 12 | Earth tones, house/building structures | Remotion (ComparisonCard, AssetLayer) |
| review | s12 | 1 | Recall summary, Sparky mascot | Remotion (EduQAScene) |
| glossary | s13 | 1 | Definition cards, text focus | HyperFrames (kinetic typography) |
| assessment | s14 | 1 | Interactive quiz, 40s duration | Remotion (EduQAScene) |
| activity | s16 | 2 | Hands-on, life skills | Remotion (EduQAScene) |

**Key insight**: `habitats` topic spans 3 sections (s03, s06, s07) with 9 clips total — a non-linear sequence would group all 9 together rather than playing them as s03→s06→s07 in chronological order.

---

## 1. Programmatic Non-Linear Video Composition with Remotion

### 1.1 Architecture

```
topic_sequence.json         asset_metadata.json
     │                            │
     ▼                            ▼
┌──────────────────────────────────────────┐
│  NonLinearComposer (Python orchestrator)  │
│                                          │
│  1. Resolve sequence order from topics    │
│  2. Look up clips per topic from registry │
│  3. Assign frame ranges (cumulative)     │
│  4. Emit scene_plan.json                 │
└──────────────────────────────────────────┘
                        │
                        ▼
scene_plan.json ──► Remotion EduVideoComposition
                        │
                        ▼
    ┌─────────────────────────────────────┐
    │  Remotion EduVideoScene (Remotion)   │
    │                                      │
    │  For each scene_plan entry:          │
    │  ┌───────────────────────────────┐   │
    │  │ <Sequence from={start} dur>   │   │
    │  │   <AnimeScene                 │   │
    │  │     images={topic_clips_url}  │   │
    │  │     animation={topic_motion}  │   │
    │  │     backgroundColor=theme     │   │
    │  │   />                          │   │
    │  │   <KineticTypography          │   │
    │  │     transcript={word_data}   │   │
    │  │     config={theme_kt_config}│   │
    │  │   />                          │   │
    │  │   <EduQAScene cards={...}    │   │
    │  │     visible={is_assessment}  │   │  │
    │  │   />                          │   │
    │  │   <AnimeEffectsLayer          │   │
    │  │     effect={topic_effect}    │   │
    │  │   />                          │   │
    │  └───────────────────────────────┘   │
    │                                      │
    │  <TransitionSeries> between topics  │
    └─────────────────────────────────────┘
                        │
                        ▼
              final_render.mp4 (1920×1080, 30fps)
```

### 1.2 NonLinearComposer (Python Orchestrator)

```python
# File: tools/video/nonlinear_compose.py

class NonLinearComposer:
    """Orchestrates non-linear, topic-based video composition."""

    def __init__(self, project_dir: str, render_runtime: str = "remotion"):
        self.project_dir = Path(project_dir)
        self.runtime = render_runtime  # "remotion" or "hyperframes"
        self.assets_dir = self.project_dir / "assets" / "video" / "scenes"
        self.script = self._load_json("artifacts/script.json")
        self.segmentation = self._load_json("artifacts/segmentation.json")
        self.registry = self._build_registry()
        self.topic_map = self._build_topic_hierarchy()

    def _build_registry(self) -> AssetRegistry:
        """Scan all video clips and build asset metadata registry."""
        registry = {}
        for section_dir in sorted(self.assets_dir.iterdir()):
            if not section_dir.is_dir():
                continue
            clips = sorted(section_dir.glob("*.mp4"))
            for clip in clips:
                if clip.stat().st_size < 100_000:
                    continue
                dur = self._probe_duration(clip)
                registry[clip.stem] = {
                    "id": clip.stem,
                    "path": str(clip),
                    "kind": "chapter_video",
                    "section_id": section_dir.name,
                    "duration_s": dur,
                    "size_bytes": clip.stat().st_size,
                    "topic_tags": self._extract_topic_tags(clip.stem),
                    "theme_tags": self._extract_theme_tags(section_dir.name),
                    "visual_priority": self._compute_priority(clip.stem),
                }
        return registry

    def _build_topic_hierarchy(self) -> dict[str, TopicInfo]:
        """Group sections into broader topics for non-linear sequencing."""
        # Read topic mapping from styles/sunshine-classroom.yaml or a config
        # This groups related sections thematically
        return {
            "intro":      {"sections": ["s01"], "motion": "static",    "effect": "none"},
            "needs":      {"sections": ["s02"], "motion": "zoom-in",    "effect": "particles-sparkles"},
            "habitats":   {"sections": ["s03", "s06", "s07"], "motion": "ken-burns", "effect": "swirl"},
            "birds":      {"sections": ["s04"], "motion": "drift-up",   "effect": "particles-stardust"},
            "insects":    {"sections": ["s05"], "motion": "pan-right",  "effect": "speed-lines"},
            "homes":      {"sections": ["s08", "s09", "s10", "s11"], "motion": "zoom-in", "effect": "sparkles"},
            "review":     {"sections": ["s12"], "motion": "parallax",   "effect": "reaction-pop"},
            "glossary":   {"sections": ["s13"], "motion": "static",     "effect": "particles-stardust"},
            "assessment": {"sections": ["s14", "s15"], "motion": "zoom-in", "effect": "screen-shake"},
            "activity":   {"sections": ["s16"], "motion": "ken-burns",   "effect": "particles-burst"},
        }

    def build_sequence(self, topic_order: list[str]) -> list[SceneEntry]:
        """Build a non-linear scene sequence from topic ordering.

        Example:
            topic_order = ["intro", "needs", "habitats", "birds",
                          "insects", "homes", "review", "assessment", "activity"]
        """
        scenes = []
        cumulative_frames = 0
        fps = 30

        for topic in topic_order:
            topic_info = self.topic_map[topic]
            clips_for_topic = self._get_clips_for_topic(topic_info)

            for clip in clips_for_topic:
                duration_frames = int(clip["duration_s"] * fps)
                scenes.append(SceneEntry(
                    id=f"{topic}_{clip['id']}",
                    clip_id=clip["id"],
                    topic=topic,
                    start_frame=cumulative_frames,
                    duration_frames=duration_frames,
                    narration_segment=self._find_narration_for(clip["section_id"]),
                    config={
                        "animation": topic_info["motion"],
                        "effect": topic_info["effect"],
                        "backgroundColor": self._get_theme_bg(topic),
                        "lightingFrom": self._get_theme_lighting_from(topic),
                        "lightingTo": self._get_theme_lighting_to(topic),
                        "particleColor": self._get_topic_particle_color(topic),
                    },
                ))
                cumulative_frames += duration_frames

        return scenes

    def emit_scene_plan(self, scenes: list[SceneEntry]) -> dict:
        """Write scene_plan.json for Remotion to consume."""
        return {
            "version": "2.0-nonlinear",
            "runtime": self.runtime,
            "fps": 30,
            "resolution": {"width": 1920, "height": 1080},
            "total_frames": scenes[-1].start_frame + scenes[-1].duration_frames,
            "scenes": [s.to_dict() for s in scenes],
        }
```

### 1.3 Remotion Composition Component

```tsx
// File: remotion-composer/src/EduVideoComposition.tsx

export interface EduVideoScene {
  id: string;
  clip_path: string;        // URL to the video clip
  topic: string;
  start_frame: number;
  duration_frames: number;
  config: {
    animation: CameraMotion;
    effect?: AnimeEffectType;
    backgroundColor: string;
    lightingFrom?: string;
    lightingTo?: string;
    particleColor?: string;
  };
  narration?: {
    audio_url: string;
    word_timestamps: WordTimestamp[];
  };
  assessment?: QAConfig;
}

export const EduVideoComposition: React.FC<{
  scenes: EduVideoScene[];
  theme: ThemeConfig;
}> = ({ scenes, theme }) => {
  const { fps, durationInFrames } = useVideoConfig();

  return (
    <AbsoluteFill style={{ background: theme.backgroundColor }}>
      <TransitionSeries>
        {scenes.map((scene) => (
          <TransitionSeries.Sequence
            key={scene.id}
            from={scene.start_frame}
            durationInFrames={scene.duration_frames}
            name={scene.id}
          >
            <EduVideoSceneRenderer scene={scene} theme={theme} />
          </TransitionSeries.Sequence>
        ))}
      </TransitionSeries>
    </AbsoluteFill>
  );
};

const EduVideoSceneRenderer: React.FC<{
  scene: EduVideoScene;
  theme: ThemeConfig;
}> = ({ scene, theme }) => {
  const { fps } = useVideoConfig();
  const duration_s = scene.duration_frames / fps;

  return (
    <AbsoluteFill style={{ overflow: "hidden", background: scene.config.backgroundColor }}>
      {/* Background: video clip with camera motion */}
      <OffthreadVideo
        src={scene.clip_path}
        style={{
          width: "100%",
          height: "100%",
          objectFit: "cover",
          objectPosition: "center",
        }}
      />

      {/* Camera motion overlay (simulates zooming, panning) */}
      <CameraMotionOverlay
        type={scene.config.animation}
        durationFrames={scene.duration_frames}
        fps={fps}
      />

      {/* Lighting gradient shift */}
      {scene.config.lightingFrom && scene.config.lightingTo && (
        <AnimatedLightingGradient
          from={scene.config.lightingFrom}
          to={scene.config.lightingTo}
          durationFrames={scene.duration_frames}
          fps={fps}
        />
      )}

      {/* Particle effects */}
      {scene.config.effect && (
        <AnimeEffectsLayer
          type="scene"
          effect={scene.config.effect}
          frame={useCurrentFrame()}
          fps={fps}
          durationInFrames={scene.duration_frames}
          color={scene.config.particleColor}
        />
      )}

      {/* Kinetic typography (if narration exists) */}
      {scene.narration && (
        <KineticTypography
          transcript={{
            word_timestamps: scene.narration.word_timestamps,
            sentences: [{
              text: scene.narration.text,
              start: 0,
              end: duration_s,
            }],
            audio_metadata: {
              sample_rate: 44100,
              duration_seconds: duration_s,
            },
          }}
          currentTime={0}
          config={{
            textColor: theme.textColor,
            highlightColor: theme.captionHighlightColor,
            fontFamily: theme.headingFont,
            backgroundColor: "transparent",
          }}
        />
      )}

      {/* Assessment overlay (if applicable) */}
      {scene.assessment && (
        <EduQAScene
          cards={scene.assessment.cards}
          seconds_per_card={scene.assessment.secondsPerCard}
          theme={scene.assessment.theme}
        />
      )}
    </AbsoluteFill>
  );
};
```

### 1.4 Non-Linear Transition Strategy

```tsx
// Transitions between topics (not between individual clips)
const TOPIC_TRANSITIONS: Record<string, TransitionSpec> = {
  "intro→needs": { type: "crossfade", duration: 30 },      // 1s fade
  "needs→habitats": { type: "swirl", duration: 24 },       // 0.8s swirl
  "habitats→birds": { type: "slide", duration: 30 },        // 1s slide
  "birds→insects": { type: "color-wash", duration: 30 },  // 1s color transition
  "insects→homes": { type: "swirl", duration: 24 },
  "homes→review": { type: "crossfade", duration: 30 },
  "review→glossary": { type: "slide", duration: 30 },
  "glossary→assessment": { type: "wipe", duration: 36 },   // 1.2s wipe
  "assessment→activity": { type: "swirl", duration: 24 },
  "activity→outro": { type: "fade-to-white", duration: 45 },
};

// Within a topic: clips crossfade (AnimeScene multi-image mode handles this)
// The AnimeScene component accepts `images: string[]` and crossfades internally
```

---

## 2. HyperFrames Integration

### 2.1 Role in the Pipeline

Per `AGENT_GUIDE.md` §387 and `tools/video/video_compose.py`, both Remotion and HyperFrames are available runtimes. HyperFrames is preferred for:

- **Title cards & chapter breaks** — kinetic typography, clean HTML/CSS
- **Glossary definitions** — text-focused, registry-block style
- **Transition bumpers** — HTML/GSAP animated transitions between topic groups
- **End tags & credits** — clean typographic animations

```python
# From tools/video/hyperframes_compose.py (summary)
class HyperFramesCompose:
    """HyperFrames runtime: HTML/CSS/GSAP → MP4 via headless Chrome + FFmpeg."""

    def render(self, workspace: dict, props: dict) -> RenderResult:
        # 1. Materialize workspace (index.html + CSS + JS)
        # 2. Run `npx hyperframes lint` (syntax/style check)
        # 3. Run `npx hyperframes validate` (timing/check constraints)
        # 4. Run `npx hyperframes render` (headless Chrome → PNG sequence → FFmpeg → MP4)
        pass
```

### 2.2 HyperFrames + Style Bridge

```python
# From lib/hyperframes_style_bridge.py
css_vars, design_md = style_bridge(playbook=yaml.safe_load(open("styles/sunshine-classroom.yaml")))

# css_vars output for sunshine-classroom:
{
    "--color-bg": "#FFFDF0",
    "--color-fg": "#2D2D2D",
    "--color-primary": "#FF8C42",
    "--color-accent": "#FFD93D",
    "--color-secondary": "#4ECDC4",
    "--color-surface": "#FFFFFF",
    "--color-muted": "#9CA3AF",
    "--font-heading": "Nunito",
    "--font-body": "Nunito",
    "--ease-entrance": "cubic-bezier(0.34, 1.56, 0.64, 1)",
    "--duration-entrance": "0.6s",
}
```

### 2.3 Hybrid Composition: Remotion + HyperFrames

```
scene_plan.json
        │
        ├── Topic: "intro" ──► HyperFrames (title card, kinetic typography)
        ├── Topic: "needs" ──► Remotion (AnimeScene with orange/teal palette)
        ├── Topic: "habitats" ──► Remotion (9 clips crossfaded, ken-burns)
        │   └── HyperFrames bumper between s03/s06/s07 (slide transition)
        ├── Topic: "birds" ──► Remotion (drift-up animation, stardust particles)
        ├── Topic: "insects" ──► Remotion (pan-right, speed-lines on emphasis)
        ├── Topic: "homes" ──► Remotion (12 clips, parallax + sparkles)
        ├── Topic: "review" ──► Remotion (EduQAScene with Sparky)
        ├── Topic: "glossary" ──► HyperFrames (definition cards, registry-block style)
        ├── Topic: "assessment" ──► Remotion (EduQAScene, 40s)
        ├── Topic: "activity" ──► Remotion (EduQAScene, hands-on demo)
        └── Outro ──► HyperFrames (end tag, fade to white)
        │
        ▼
ffmpeg concat (all segments) ──► final_render.mp4
```

### 2.4 HyperFrames Composition for Title Card

```html
<!-- hyperframes-workspaces/intro_title/index.html -->
<div id="root">
  <div class="scene">
    <div class="bg" style="background: var(--color-accent)"></div>
    
    <div class="title-group" data-animation="stagger">
      <h1 class="title">Animal Life</h1>
      <p class="subtitle">Class 1 • Lesson 8</p>
    </div>

    <div class="scene-elements">
      <img src="assets/fish.svg" class="float" style="--delay: 0s; --x: 10%">
      <img src="assets/bird.svg" class="float" style="--delay: 0.5s; --x: 80%">
      <img src="assets/rabbit.svg" class="bounce" style="--delay: 1s; --x: 50%">
    </div>
  </div>
</div>

<style>
.title {
  font-family: var(--font-heading);
  font-size: clamp(64px, 8vw, 96px);
  font-weight: 800;
  color: var(--color-fg);
}
.subtitle {
  font-family: var(--font-body);
  font-size: 36px;
  color: var(--color-muted);
}
</style>

<script>
// GSAP timeline — deterministic, seek-safe
gsap.timeline({defaults: {ease: "cubic-bezier(0.34,1.56,0.64,1)"}})
  .from(".title", {y: 40, opacity: 0, duration: 0.8})
  .from(".subtitle", {y: 20, opacity: 0, duration: 0.6}, "+=0.2")
  .from(".scene-elements img", {
    stagger: 0.3,
    y: 30, opacity: 0,
    duration: 0.7
  }, "+=0.3");
</script>
```

---

## 3. Topic-to-Asset Metadata Mapping Logic

### 3.1 Asset Registry Schema

```typescript
// Built by NonLinearComposer._build_registry()
interface AssetRecord {
  id: string;              // e.g. "s05-2"
  path: string;            // absolute path to .mp4
  kind: "chapter_video" | "character" | "background" | "generated";
  section_id: string;       // e.g. "s05"
  duration_s: number;      // probed via ffprobe
  size_bytes: number;      // for integrity check
  topic_tags: string[];    // e.g. ["insects", "example"]
  theme_tags: string[];    // e.g. ["warm", "macro"]
  visual_priority: number; // 0-100, higher = more important
}
```

### 3.2 Topic Tag Extraction

Tags are derived from `script.json` section labels, text keywords, and `enhancement_cues`:

```python
def _extract_topic_tags(self, clip_id: str) -> list[str]:
    """Extract topic tags from clip ID + script metadata."""
    section_id = clip_id.split('-')[0]  # e.g. "s05-2" → "s05"
    section = next(s for s in self.script["sections"] if s["id"] == section_id)
    
    tags = []
    # From label
    label = section["label"].lower()
    if "bird" in label: tags.append("birds")
    if "insect" in label: tags.append("insects")
    if "water" in label: tags.append("water_animals")
    if "land" in label: tags.append("land_animals")
    if "home" in label: tags.append("homes")
    if "domestic" in label: tags.append("domestic")
    if "wild" in label: tags.append("wild")
    
    # From text keywords
    text_words = section["text"].lower().split()
    keyword_categories = {
        "food": ["food", "eat", "eating"],
        "shelter": ["shelter", "home", "den", "burrow"],
        "water": ["water", "aquatic"],
        "air": ["air", "breath"],
        "care": ["care", "protection", "protect"],
    }
    for category, keywords in keyword_categories.items():
        if any(kw in text_words for kw in keywords):
            tags.append(category)
    
    # From enhancement types
    for cue in section.get("enhancement_cues", []):
        if cue["type"] == "diagram":
            tags.append("diagram")
        if cue["type"] == "animation":
            tags.append("animated")
    
    return list(set(tags))
```

### 3.3 Theme-to-Asset Resolution

```typescript
// Remotion: resolve assets for a topic
function resolveTopicAssets(
  topic: string,
  sequence: TopicSequence,
  registry: AssetRegistry
): VideoAsset[] {
  const topicSections = getTopicSections(topic); // e.g., habitats → [s03, s06, s07]

  // Gather all clips from all sections in this topic
  const allClips = topicSections.flatMap(sid =>
    filterAssets(registry, a => a.section_id === sid && a.kind === "chapter_video")
  );

  // Sort by visual_priority then by original section order
  return allClips
    .sort((a, b) => b.visual_priority - a.visual_priority)
    .slice(0, sequence.maxConcurrentClips); // e.g., max 3 per transition
}
```

### 3.4 Validation: Contextually Accurate Playback

```python
def validate_mapping(self, scene_plan: dict) -> list[str]:
    """Ensure each clip plays in a contextually appropriate segment."""
    issues = []
    
    for scene in scene_plan["scenes"]:
        clip_id = scene["clip_id"]
        clip_section = clip_id.split('-')[0]  # "s05-2" → "s05"
        
        # Cross-reference with original section topic
        expected_topic = self._section_to_topic(clip_section)
        actual_topic = scene["topic"]
        
        if expected_topic != actual_topic:
            issues.append(
                f"MISMATCH: clip {clip_id} from {clip_section} "
                f"(topic={expected_topic}) placed in topic={actual_topic}"
            )
    
    return issues
```

---

## 4. Asset Synchronization & Dynamic Transitions

### 4.1 Frame-Accurate Sync Engine

```typescript
// Remotion: synchronize narration, video, and effects to frame-accurate timing
class SyncEngine {
  private frame: number;
  private fps: number;
  private scene: SceneEntry;
  
  constructor(scene: SceneEntry, fps: number = 30) {
    this.scene = scene;
    this.fps = fps;
  }
  
  // Word-level sync: find which word is active at a given frame
  getActiveWord(frame: number): WordAlignment | null {
    const timeS = frame / this.fps;
    return this.scene.narration?.word_timestamps.find(
      w => timeS >= w.start && timeS <= w.end
    ) ?? null;
  }
  
  // Narration-video sync: advance video playback to match audio position
  getVideoTimeOffset(frame: number): number {
    const timeS = frame / this.fps;
    const narrationStart = this.scene.narration?.start_s ?? 0;
    return timeS - narrationStart;
  }
  
  // Transition boundary: return progress (0-1) during transition window
  getTransitionProgress(frame: number, transition: TransitionSpec): number {
    const transitionStart = transition.from_frame;
    const transitionEnd = transitionStart + Math.round(transition.duration * this.fps / 1000);
    return interpolate(frame, [transitionStart, transitionEnd], [0, 1], 
      { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  }
}
```

### 4.2 Transition Manager

```typescript
class TransitionManager {
  private static TRANSITION_PRESETS = {
    crossfade: {
      duration: 30, // frames (1s at 30fps)
      ease: "linear",
      render: (progress: number) => (
        <>
          <div style={{ opacity: 1 - progress }} />
          <div style={{ opacity: progress }} />
        </>
      )
    },
    swirl: {
      duration: 24, // frames
      ease: "easeInOut",
      render: (progress: number) => (
        <AnimeEffectsLayer
          type="scene"
          effect="swirl"
          frame={Math.round(progress * 24)}
          fps={30}
          durationInFrames={24}
        />
      )
    },
    slide: {
      duration: 30,
      ease: "easeOut",
      render: (progress: number) => (
        <div style={{
          transform: `translateX(${-progress * 100}%)`,
          transition: "transform 0.8s cubic-bezier(0.25,0.46,0.45,0.94)"
        }} />
      )
    },
    wipe: {
      duration: 36,
      ease: "easeInOut",
      render: (progress: number) => (
        <div style={{
          clipPath: `polygon(0 0, ${progress * 100}% 0, ${progress * 100}% 100%, 0 100%)`
        }} />
      )
    },
    color_wash: {
      duration: 30,
      render: (progress: number) => (
        <div style={{
          background: `linear-gradient(135deg, 
            ${interpolateColor(progress, fromColor, toColor)})`
        }} />
      )
    }
  };
  
  static buildTransition(fromTopic: string, toTopic: string): TransitionSpec {
    const key = `${fromTopic}→${toTopic}`;
    return this.TRANSITIONS[key] ?? this.TRANSITIONS["default"];
  }
  
  private static TRANSITIONS: Record<string, TransitionSpec> = {
    "intro→needs": { type: "crossfade", frames: 30 },
    "needs→habitats": { type: "swirl", frames: 24 },
    "habitats→birds": { type: "slide", frames: 30 },
    ...TOPIC_TRANSITIONS,
    "default": { type: "crossfade", frames: 30 },
  };
}
```

### 4.3 Dynamic Asset Loading

```typescript
// Preload next topic's assets while current topic plays
function useAssetPreloader(scenes: SceneEntry[], currentTopic: string) {
  const preloadRef = useRef<Set<string>>(new Set());
  
  useEffect(() => {
    const nextTopics = getNextTwoTopics(currentTopic);
    nextTopics.forEach(topic => {
      const assets = getTopicAssets(topic);
      assets.forEach(asset => {
        if (!preloadRef.current.has(asset.id)) {
          preloadRef.current.add(asset.id);
          // Preload video
          const video = document.createElement("video");
          video.src = asset.path;
          video.preload = "auto";
          video.load();
        }
      });
    });
  }, [currentTopic]);
}
```

### 4.4 Resumability & Checkpointing

```python
class CheckpointManager:
    """Manages render checkpoints for resumable non-linear composition."""
    
    CHECKPOINTS = [
        "topic_sequence_resolved",     # topic_order validated
        "asset_registry_built",        # all 39 clips probed
        "scene_plan_generated",        # non-linear sequence with frame ranges
        "audio_aligned",               # word timestamps for all topics
        "topic_intro_rendered",        # HyperFrames title card
        "topic_needs_rendered",        # Remotion AnimeScene
        "topic_habitats_rendered",     # 9 clips crossfaded
        ...
        "final_composed",              # all topics concat'd
    ]
    
    def render_with_checkpoints(self, scene_plan, topic_order):
        rendered = []
        for topic in topic_order:
            if self.is_checkpoint_done(f"topic_{topic}_rendered"):
                segment = self.load_segment(f"topic_{topic}")
                rendered.append(segment)
                continue
            
            # Render this topic's segment
            segment = self._render_topic(topic, scene_plan)
            self.save_checkpoint(f"topic_{topic}_rendered", segment)
            rendered.append(segment)
        
        # Concat all segments
        final = self._concat_segments(rendered)
        self.save_checkpoint("final_composed", final)
        return final
```

---

## 5. End-to-End Pipeline Integration

```
┌─────────────────────────────────────────────────────────────────────┐
│                    INPUT ARTIFACTS                                   │
│                                                                      │
│  script.json      segmentation.json   39 video clips                │
│  narration_manifest.json               16 .wav files               │
│  styles/sunshine-classroom.yaml                                    │
└────────────┬─────────────────────────────────┬───────────────────────┘
             │                                 │
┌────────────▼──────────┐    ┌───────────────▼──────────────────┐
│  NonLinearComposer     │    │  _produce.py (updated)            │
│  (tools/video/)        │    │                                  │
│                        │    │  def run_compose():              │
│  1. Build registry     │    │    scenes = composer.build_seq(  │
│  2. Build topic tree   │    │      topic_order=user_input       │
│  3. Resolve sequence   │    │    )                              │
│  4. Assign frame ranges│    │    # Remotion or HyperFrames       │
│  5. Emit scene_plan    │    │    render_runtime = decide_runtime()│
│                        │    │    if remotion:                   │
│  Output: scene_plan.json                        │
│          (non-linear, frame-accurate)           │
└────────────┬───────────┘                       │
             │                                     │
             ▼                                     ▼
┌──────────────────────────┐  ┌──────────────────────────────┐
│  Runtime Router           │  │  _analyze_audio.py            │
│  (video_compose.py)       │  │  (Pillar 1 pipeline)          │
│                           │  │                               │
│  if remotion:             │  │  Outputs: segmentation.json   │
│    → remotion render      │  │  (word timestamps, pauses,     │
│    → EduVideoComposition  │  │   prosody, beat scores)       │
│                           │  │                               │
│  if hyperframes:          │  └──────────────────────────────┘
│    → hyperframes_compose  │
│    → HTML/GSAP workspace  │
└────────────┬─────────────┘
             │
             ▼
┌──────────────────────────┐
│  QA Validator             │
│  (_qa_validate.py)        │
│                           │
│  • AV sync (max 50ms)     │
│  • Audio LUFS (-18 to -14)│
│  • Frame integrity        │
│  • Text readability       │
│  • Topic sequencing check │
│  • Asset coverage (39/39)│
│                           │
│  Output: qa_report.json  │
└────────────┬─────────────┘
             │
             ▼
┌──────────────────────────┐
│  final_render.mp4         │
│  1920×1080, 30fps, H.264  │
│  remuxed audio (AAC 192k)  │
└──────────────────────────┘
```

---

## 6. Implementation Roadmap

### Phase 1: Core Sequencing Engine (Week 1)

1. **Create `tools/video/nonlinear_compose.py`**:
   - `NonLinearComposer` class with registry builder, topic hierarchy, and sequence resolver
   - `SceneEntry` dataclass for frame-accurate scene representation
   - CLI: `python -m nonlinear_compose --topics intro,needs,habitats,birds,insects,homes,review,assessment,activity`

2. **Create `remotion-composer/src/EduVideoComposition.tsx`**:
   - Root composition that reads `scene_plan.json`
   - `EduVideoSceneRenderer` dispatching to AnimeScene/KineticTypography/EduQAScene
   - Transition manager for inter-topic transitions

3. **Register the composition in `Root.tsx`**:
   ```tsx
   <Composition
     id="EduVideo"
     component={EduVideoComposition}
     durationInFrames={30 * 480}  // 8 min max
     fps={30}
     width={1920}
     height={1080}
     defaultProps={{ scenes: [], theme: resolveTheme({theme: "sunshine-classroom"}) }}
   />
   ```

4. **Wire into `_produce.py`**: Add `--nonlinear` flag that bypasses linear compose and uses Remotion

### Phase 2: HyperFrames Integration (Week 2)

1. **Create HyperFrames workspace templates**:
   - `hyperframes-workspaces/intro_title/` (title card)
   - `hyperframes-workspaces/glossary_cards/` (definition cards)
   - `hyperframes-workspaces/end_tag/` (closing screen)

2. **Integrate `hyperframes_style_bridge.py`**: Auto-generate CSS variables from `sunshine-classroom.yaml`

3. **Add runtime selection to `NonLinearComposer`**:
   - Topics that are text-heavy → HyperFrames
   - Topics with video clips → Remotion
   - Transition bumpers → HyperFrames or Remotion (user choice)

4. **Create segment concat pipeline**: Render each topic as separate segment, concat with ffmpeg

### Phase 3: QA & Validation (Week 2-3)

1. **Add non-linear-specific QA checks**:
   - Topic sequencing validation (no clips from wrong topic)
   - Asset coverage (39/39 clips used)
   - Transition timing verification
   - Visual continuity check (color palette consistency within topics)

2. **Integration with `_qa_validate.py`**: Add topic-based checks

3. **Checkpoint system**: Save per-topic render state for resumability

### Phase 4: Testing & Tuning (Week 3)

1. **Render test**: Non-linear sequence of `intro → needs → habitats → birds`
2. **Compare**: Output quality vs. reference `Lesson_8__Animal_Life.mp4`
3. **Tune**: Transition durations, camera motion parameters, particle effects
4. **Performance**: Verify Remotion rendering speed (frame cache, OffthreadVideo)

---

## 7. Runtime Selection (Per AGENT_GUIDE.md)

Per the **HARD RULE** in AGENT_GUIDE.md (§125, §301-303):

```
YOUR CAPABILITIES — Composition

  Composition: 2/2 configured (Remotion, HyperFrames)
  
  Remotion: 30fps, 1920×1080, 30+ React scene components ready
           • AnimeScene (camera motion, crossfade, particles)
           • KineticTypography (word-level sync, audio-reactive)
           • EduQAScene (assessment cards with spring animations)
           • AnimeEffectsLayer (6 effect types)
           
  HyperFrames: HTML/CSS/GSAP via npx
           • Title cards, transition bumpers, glossary definitions
           • Registry-block-driven content
           • Style bridge from sunshine-classroom.yaml
  
  Recommendation: Use Hybrid — Remotion for video-heavy topics,
  HyperFrames for text/title-card topics.
  
  Select render_runtime for this project:
  [1] Remotion only (simplest, all-in-one)
  [2] HyperFrames only (kinetic typography, no video clips)
  [3] Hybrid (Remotion + HyperFrames, concat segments)
```
