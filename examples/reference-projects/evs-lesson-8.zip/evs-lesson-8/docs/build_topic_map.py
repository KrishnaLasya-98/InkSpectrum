import json, os

clippath = r'D:\InkSpectrum\OpenMontage\projects\evs-lesson-8\artifacts'
script_path = os.path.join(clippath, 'script.json')
with open(script_path) as f:
    script = json.load(f)

topics = {}
for sec in script['sections']:
    sid = sec['id']
    label = sec['label']
    text = sec['text'][:100]
    keywords = [w.strip('.,!?') for w in text.split() if len(w) > 4 and w[0].isupper()]
    topics[sid] = {
        'label': label,
        'duration': sec['end_seconds'] - sec['start_seconds'],
        'keywords': keywords[:5],
        'enh_types': [c['type'] for c in sec.get('enhancement_cues', [])]
    }

assets_dir = r'D:\InkSpectrum\OpenMontage\projects\evs-lesson-8\assets\video\scenes'
asset_map = {}
for section in sorted(os.listdir(assets_dir)):
    sdir = os.path.join(assets_dir, section)
    if not os.path.isdir(sdir): continue
    clips = sorted([f for f in os.listdir(sdir) if f.endswith('.mp4')])
    asset_map[section] = clips

# Build topic hierarchy
topic_hierarchy = {}
for sid, info in topics.items():
    label = info['label']
    # Classify into broader topics
    if 'Welcome' in label or 'Highlights' in label:
        topic = 'intro'
    elif 'what animals need' in label.lower():
        topic = 'needs'
    elif 'water' in label.lower() or 'land' in label.lower():
        topic = 'habitats'
    elif 'birds' in label.lower():
        topic = 'birds'
    elif 'insect' in label.lower():
        topic = 'insects'
    elif 'home' in label.lower() or 'den' in label.lower() or 'nest' in label.lower() or 'kennel' in label.lower():
        topic = 'homes'
    elif 'domestic' in label.lower() or 'pet' in label.lower() or 'wild' in label.lower():
        topic = 'habitats'
    elif 'recall' in label.lower():
        topic = 'review'
    elif 'glossary' in label.lower():
        topic = 'glossary'
    elif 'quiz' in label.lower() or 'assessment' in label.lower() or 'question' in label.lower():
        topic = 'assessment'
    elif 'activity' in label.lower():
        topic = 'activity'
    else:
        topic = 'general'

    if topic not in topic_hierarchy:
        topic_hierarchy[topic] = []
    topic_hierarchy[topic].append({
        'section_id': sid,
        'label': label,
        'duration': info['duration'],
        'clips': asset_map.get(sid, []),
        'keywords': info['keywords'],
        'enhancement_types': info['enh_types']
    })

print("=== TOPIC HIERARCHY ===")
for topic, sections in topic_hierarchy.items():
    print(f"\n  [{topic}]")
    for s in sections:
        print(f"    {s['section_id']}: {s['label'][:40]}")
        print(f"      clips={s['clips']}, duration={s['duration']}s")
        print(f"      keywords={s['keywords']}")
        print(f"      enhancements={s['enhancement_types']}")

print(f"\n=== SUMMARY ===")
print(f"Total sections: {len(topics)}")
print(f"Total clips: {sum(len(c) for c in asset_map.values())}")
print(f"Topics: {list(topic_hierarchy.keys())}")
print(f"Clips per topic: {json.dumps({t: len(v) for t,v in topic_hierarchy.items()})}")
