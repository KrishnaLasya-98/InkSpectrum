"""Audit source, assessment, timing, and frame-review coverage for Lesson 8."""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

PROJECT = Path(__file__).resolve().parent
ART = PROJECT / "artifacts"
MATRIX = ART / "lesson8_coverage_matrix.json"
SOURCE = ART / "source_text_manifest.json"
RENDER_TRANSCRIPT = PROJECT / "full-hyperframes" / "artifacts" / "lesson-8-animal-life-final-clean_transcript.json"
RENDER = PROJECT / "full-hyperframes" / "renders" / "lesson-8-animal-life-final-clean.mp4"
REPORT = PROJECT / "full-hyperframes" / "artifacts" / "final_coverage_audit.json"


def probe_duration(path: Path) -> float:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "json", str(path)],
        capture_output=True,
        text=True,
        check=True,
    )
    return float(json.loads(result.stdout)["format"]["duration"])


def main() -> None:
    matrix = json.loads(MATRIX.read_text(encoding="utf-8"))
    source = json.loads(SOURCE.read_text(encoding="utf-8"))
    transcript = json.loads(RENDER_TRANSCRIPT.read_text(encoding="utf-8")) if RENDER_TRANSCRIPT.exists() else {}

    source_lines = [item["source_text"] for item in source["items"]]
    planned_lines = [line for section in matrix["sections"] for line in section.get("source_lines", [])]
    assessment_ids = [
        question["id"]
        for group in matrix["assessment"]["groups"]
        for question in group["questions"]
    ]
    transcript_words = transcript.get("word_timestamps", [])
    frame_checkpoints = [time for section in matrix["sections"] for time in section["review_frame_times"]]

    # Exact source lines are authoritative; a source line can be rendered by a
    # subtitle, a dedicated study panel, or an exercise card.
    missing_planned = [line for line in source_lines if line not in planned_lines]
    report = {
        "render": {
            "path": str(RENDER),
            "exists": RENDER.exists(),
            "duration_seconds": probe_duration(RENDER) if RENDER.exists() else None,
            "target_duration_seconds": matrix["render_contract"]["duration_seconds"],
        },
        "source": {
            "source_item_count": len(source_lines),
            "planned_source_line_references": len(planned_lines),
            "missing_exact_source_lines": missing_planned,
            "source_coverage_passed": not missing_planned,
        },
        "assessment": {
            "expected_question_count": 13,
            "planned_question_count": len(assessment_ids),
            "question_ids": assessment_ids,
            "unique_ids": len(set(assessment_ids)) == len(assessment_ids),
            "prediction_pause_seconds": matrix["render_contract"]["interactive_prediction_pause_seconds"],
            "answer_reveal_seconds": matrix["render_contract"]["answer_reveal_duration_seconds"],
            "sequential_state_order": matrix["render_contract"]["exercise_state_order"],
        },
        "narration": {
            "render_transcript_exists": RENDER_TRANSCRIPT.exists(),
            "rendered_word_count": len(transcript_words),
            "timing_source": "actual rendered audio ASR",
        },
        "review": {
            "pdf_page_count": matrix["source"]["page_count"],
            "pdf_image_reference_count": matrix["source"]["image_reference_count"],
            "frame_checkpoint_count": len(frame_checkpoints),
            "frame_checkpoints_seconds": frame_checkpoints,
            "required_manual_check": "Compare each checkpoint frame against the corresponding PDF page/image region.",
        },
        "style": {
            "manifest": str(ART / "hyperframes_style.json"),
            "runtime": matrix["render_contract"]["runtime"],
            "subtitle_rule": "progressive word reveal with future words hidden",
        },
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({
        "render_exists": report["render"]["exists"],
        "duration": report["render"]["duration_seconds"],
        "missing_source_lines": len(missing_planned),
        "assessment_questions": len(assessment_ids),
        "rendered_words": len(transcript_words),
        "report": str(REPORT),
    }, indent=2))
    if missing_planned or len(assessment_ids) != 13 or len(set(assessment_ids)) != 13:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
