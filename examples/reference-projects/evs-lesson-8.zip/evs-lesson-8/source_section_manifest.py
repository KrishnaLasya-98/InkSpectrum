"""Build the EVS Lesson 8 semantic section map from the authoritative source."""
from __future__ import annotations

from typing import Any


# This map contains only semantic source-line IDs. Display text is always read
# from source_text_manifest.json by build_full_hyperframes.py.
SECTION_SOURCE_MAP: dict[str, dict[str, Any]] = {
    "s01": {"title": 1, "subtitle": [3], "content": [1, 3, 4, 5, 8, 10, 11, 12, 13, 14, 15]},
    "s02": {"title": 10, "subtitle": [18], "content": [18]},
    "s03": {"title": 11, "subtitle": [22], "content": [22, 24, 26, 30, 32, 40]},
    "s04": {"title": 13, "subtitle": [44], "content": [42, 44, 52]},
    "s05": {"title": 14, "subtitle": [56], "content": [54, 56, 64]},
    "s06": {"title": 66, "subtitle": [70], "content": [66, 70]},
    "s07": {"title": 72, "subtitle": [72], "content": [72]},
    "s08": {"title": 15, "subtitle": [78], "content": [76, 78]},
    "s09": {"title": 82, "subtitle": [84], "content": [82, 84, 85, 86, 91, 93, 94]},
    "s10": {"title": 96, "subtitle": [98], "content": [96, 98, 99, 101, 103, 104]},
    "s11": {"title": 115, "subtitle": [123], "content": [115, 123]},
    "s12": {"title": 127, "subtitle": [129], "content": [127, 129, 130, 131, 132, 133, 134, 135]},
    "s13": {"title": 140, "subtitle": [142], "content": [140, 142, 143, 144, 145, 146]},
    "s14": {"title": 151, "subtitle": [153], "content": [151, 153, 155, 156, 159, 162, 164, 165, 166, 167, 168]},
    "s15": {"title": 171, "subtitle": [173], "content": [171, 173, 174, 175, 176, 177]},
    "s16": {"title": 182, "subtitle": [184], "content": [182, 184, 188, 190]},
}


def build_section_manifest(source: dict[str, Any]) -> list[dict[str, Any]]:
    by_line = {int(item["source_line"]): item for item in source["items"]}
    result: list[dict[str, Any]] = []
    for section_id, mapping in SECTION_SOURCE_MAP.items():
        ids = [int(mapping["title"]), *[int(x) for x in mapping["subtitle"]], *[int(x) for x in mapping["content"]]]
        missing = sorted(set(ids) - set(by_line))
        if missing:
            raise ValueError(f"{section_id} references missing source lines: {missing}")
        title = by_line[int(mapping["title"])]
        subtitle_items = [by_line[int(line_id)] for line_id in mapping["subtitle"]]
        result.append({
            "id": section_id,
            "title": title["source_text"],
            "title_source_line_ids": [int(mapping["title"])],
            "subtitle": " ".join(item["source_text"] for item in subtitle_items),
            "subtitle_source_line_ids": [int(line_id) for line_id in mapping["subtitle"]],
            "content_source_line_ids": [int(line_id) for line_id in mapping["content"]],
            "source_line_ids": sorted(set(ids)),
            "source_items": [by_line[line_id] for line_id in sorted(set(ids))],
            "media_policy": "graphics_only" if section_id in {"s12", "s13", "s14", "s15", "s16"} else "motion_preferred",
        })
    return result
