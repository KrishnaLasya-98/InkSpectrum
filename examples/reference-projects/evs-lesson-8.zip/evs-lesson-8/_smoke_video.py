"""Single ModelSlab video generation smoke test for EVS Lesson 8.
Verifies the live cloud path once before batch generation."""
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

from tools.video.modelslab_video import ModelsLabVideo  # noqa: E402

OUT = Path("projects/evs-lesson-8/assets/video/smoke/s05-butterfly.mp4")

result = ModelsLabVideo().execute({
    "prompt": (
        "A bright butterfly opens its wings once and floats a short distance "
        "across a flower, one continuous linear shot, fixed camera, "
        "accurate six-legged insect anatomy, child-safe illustrated style, "
        "no looping, no repeating motion, no camera movement, no text, no watermark"
    ),
    "negative_prompt": (
        "loop, looping, seamless loop, replay, repeat, restart, cycle, "
        "back and forth, oscillation, zoom in, zoom out, Ken Burns, pan, "
        "dolly, camera movement, static image, text, watermark, stutter"
    ),
    "model_id": "h3-minimax-t2v",
    "operation": "text_to_video",
    "duration": "5",
    "resolution": "768P",
    "seed": 20240910,
    "generate_audio": True,
    "output_path": str(OUT),
})
print("success:", result.success)
print("data:", {k: v for k, v in result.data.items() if k not in ("prompt",)} if result.success else {})
print("cost_usd:", result.cost_usd, "| duration_s:", result.duration_seconds)
if not result.success:
    print("error:", result.error)