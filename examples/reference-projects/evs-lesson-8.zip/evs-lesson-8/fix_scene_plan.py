"""Fix scene_plan_render.json: absolute paths, camera_motion mapping, particle_effect mapping, remove word_alignment_path."""
import json
import os

PROJECT_ROOT = r"D:\InkSpectrum\OpenMontage\projects\evs-lesson-8"
INPUT = os.path.join(PROJECT_ROOT, "artifacts/scene_plan_render.json")
OUTPUT = os.path.join(PROJECT_ROOT, "artifacts/scene_plan_render_fixed.json")

CAMERA_MAP = {
    "slow_zoom_in": "zoom-in",
    "static": "static",
    "gentle_pan": "ken-burns",
    "slow_tilt_up": "drift-up",
    "map_pan": "parallax",
    "path_follow": "ken-burns",
    "slow_zoom_out": "zoom-out",
}

PARTICLE_MAP = {
    "sparkle": "particles-sparkles",
    "none": "",
    "dust_motes": "particles-stardust",
    "feathers": "particles-swirl",
    "pollen": "particles-sparkles",
}

with open(INPUT, "r") as f:
    plan = json.load(f)

for scene in plan["scenes"]:
    # Fix video_clip path → relative path for staticFile() (served from public/)
    vc = scene.get("video_clip")
    if vc:
        # Strip "../../" and leading "./" to get path relative to project root
        clean = vc.replace("\\", "/").lstrip("./")
        if clean.startswith("../../"):
            clean = clean[6:]
        scene["video_clip"] = clean

    # narration_url: keep as truthy string (used only as conditional flag in component)
    nu = scene.get("narration_url")
    if nu:
        clean = nu.replace("\\", "/").lstrip("./")
        if clean.startswith("../../"):
            clean = clean[6:]
        scene["narration_url"] = clean

    # Map camera_motion to valid CameraMotion type
    cam = scene.get("camera_motion")
    if cam and cam in CAMERA_MAP:
        scene["camera_motion"] = CAMERA_MAP[cam]

    # Map particle_effect to valid AnimeEffectType
    pe = scene.get("particle_effect")
    if pe and pe in PARTICLE_MAP:
        mapped = PARTICLE_MAP[pe]
        if mapped:
            scene["particle_effect"] = mapped
        else:
            scene["particle_effect"] = None

    # Remove stale word_alignment_path
    scene.pop("word_alignment_path", None)

with open(OUTPUT, "w") as f:
    json.dump(plan, f, indent=2)

print(f"Fixed scene plan written to {OUTPUT}")
print(f"Scenes: {len(plan['scenes'])}")
# Print sample
s0 = plan["scenes"][0]
print(f"  Sample scene: {s0['id']}")
print(f"  video_clip: {s0['video_clip']}")
print(f"  narration_url: {s0['narration_url']}")
print(f"  camera_motion: {s0['camera_motion']}")
print(f"  particle_effect: {s0.get('particle_effect')}")
print(f"  has word_alignment_data: {bool(s0.get('word_alignment_data'))}")
print(f"  has word_alignment_path: {'word_alignment_path' in s0}")
