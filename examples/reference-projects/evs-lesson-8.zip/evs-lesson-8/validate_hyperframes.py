"""Validate generated EVS Lesson 8 HyperFrames artifacts without rendering."""
from __future__ import annotations

import json
import re
from pathlib import Path

PROJECT = Path(__file__).resolve().parent
OUT = PROJECT / "full-hyperframes"


def load_timeline() -> dict:
    raw = (OUT / "timeline-data.js").read_text(encoding="utf-8")
    return json.loads(raw.split("=", 1)[1].strip().rstrip(";"))


def validate() -> dict:
    data = load_timeline()
    errors: list[str] = []
    if data["duration"] != data["sections"][-1]["end"]:
        errors.append("duration does not equal final section end")
    for previous, current in zip(data["sections"], data["sections"][1:]):
        if previous["end"] > current["start"]:
            errors.append(f"section overlap: {previous['id']} -> {current['id']}")
    for section in data["sections"]:
        if section["title_end"] > section["audio_start"]:
            errors.append(f"title overlaps narration: {section['id']}")
        if section["title_card"]["media_policy"] != "graphics_only":
            errors.append(f"title card has media: {section['id']}")
        for previous, current in zip(section["beats"], section["beats"][1:]):
            if previous["end"] > current["start"]:
                errors.append(f"beat overlap: {previous['id']} -> {current['id']}")
    intervals = data["assessment_intervals"]["intervals"]
    for previous, current in zip(intervals, intervals[1:]):
        if previous["handoff_end"] > current["prompt_start"]:
            errors.append(f"exercise overlap: {previous['id']} -> {current['id']}")
    if data["coverage_audit"]["uncovered_source_lines"]:
        errors.append("source lines are uncovered")
    if data["slogan"] != ["Animals also have feelings. Do not hurt animals. They will be friendly to us. Protect animals."]:
        errors.append("final slogan drift")
    html = (OUT / "index.html").read_text(encoding="utf-8")
    if "data-media-policy=\"graphics-only\"" not in html or "visible_word_indices" not in html:
        errors.append("composition does not declare graphics-only/progressive caption paths")
    style = json.loads((PROJECT / "artifacts" / "hyperframes_style.json").read_text(encoding="utf-8"))
    if style["font"]["subtitle_px"] < 42:
        errors.append("subtitle font is below the approved 42px minimum")
    if style["font"]["body_px"] < 40:
        errors.append("body font is below the approved 40px minimum")
    if not re.search(r"\.caption-card\s*\{[^}]*font-size:\s*var\(--subtitle-size\)", html):
        errors.append("caption card does not use the canonical subtitle size")
    if not re.search(r"\.source-card \.line\s*\{[^}]*font-size:\s*var\(--body-size\)", html):
        errors.append("source text does not use the canonical body size")
    option_rule = re.search(r"\.exercise-option\s*\{([^}]*)\}", html)
    if not option_rule or not re.search(r"display:\s*(?:flex|grid)", option_rule.group(1)):
        errors.append("exercise options are not separate flex/grid rows")
    if not re.search(r"tl\.set\(words,\s*\{\s*opacity:\s*0", html):
        errors.append("caption words are not explicitly hidden at phrase start")
    return {"valid": not errors, "errors": errors, "duration": data["duration"], "section_boundaries": [{"id": section["id"], "start": section["start"], "end": section["end"]} for section in data["sections"]], "covered_source_lines": data["coverage_audit"]["covered_source_line_count"]}


if __name__ == "__main__":
    result = validate()
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["valid"] else 1)
