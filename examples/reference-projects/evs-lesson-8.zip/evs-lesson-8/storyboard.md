# EVS Lesson 8 - Animal Life Storyboard

## Production contract

- Source of truth: `RPS - EVS - CLASS 1 - INDIVIDUAL - B (2026) PRINTFILE-pages-2.pdf`
- Runtime: HyperFrames
- Format: 1920x1080, 30 fps, approximately 300.3 seconds
- Narration starts at 0:00 on the animated lesson-title card.
- Subtitle words are aligned from the approved narration audio using Faster-Whisper.
- Audio, subtitle highlighting, UI changes, and visual cues share the same timing map.
- Generated clip audio is muted; the approved narration tracks are authoritative.

## Visual language

- Opening: full-frame child-friendly 3D animal ensemble with the lesson title.
- We Learn: pale-blue PDF-derived question card with navy heading and green rule.
- Highlights: warm cream PDF-derived card with orange heading and cyan rule.
- Story/explanation: continuous 3D animated footage with compact PDF-derived labels.
- Recall: pale-green box with red title tab.
- Glossary: pale-pink box with blue heading rule.
- Assessment: light-blue worksheet label with clean question space.
- Activity: amber title treatment.
- Life Skills: white panel with blue dotted border.
- Subtitles: stable cream safe-area lane with the currently spoken word highlighted.

## Timeline

| Section | Approx. time | Narration/topic | Visual and UI direction |
|---|---:|---|---|
| Opening | 00:00-00:07 | Welcome and chapter introduction | 3D ensemble of land animals, bird, butterfly, and fish; title overlay; narration begins immediately. |
| We Learn | 00:07-00:11 | Pet-animal questions | Rabbit and pet-care animation; pale-blue question box. |
| Highlights | 00:11-00:32 | Chapter topics | Animated animal-world footage; cream highlights box populated from the PDF topics. |
| Living beings | 00:32-00:54 | Needs and differences | Eating, shelter, water, and animal-feature clips triggered by the corresponding spoken words. |
| Land and water | 00:54-01:12 | Aquatic and land animals | Pond scene until land animals are spoken, then exactly one lion, elephant, and tiger. |
| Birds | 01:12-01:22 | Bird features and examples | Duck followed by pigeon and parrot at their spoken examples. |
| Insects | 01:22-01:39 | Six legs, wings, examples | Butterfly followed by housefly and grasshopper when named. |
| Domestic and pets | 01:39-01:54 | Domestic animals and pets | Domestic-animal group followed by pet-care footage. |
| Wild animals | 01:54-02:04 | Forest animals | Tiger then lion at the exact spoken example. |
| Homes and food | 02:04-02:12 | Basic needs | Animated habitat overview. |
| Dens and burrows | 02:12-02:29 | Lion and rabbit homes | Lion den followed by rabbit burrow when rabbits are spoken. |
| Nests, anthills, hives | 02:29-02:45 | Animal-built homes | Nest, anthill, and bees triggered by their aligned phrases. |
| Human-made homes | 02:45-02:58 | Kennel, shed, stable | Kennel during dog; shed/stable scene beginning with cow. |
| Let's Recall | 02:58-03:26 | Lesson recap | Stable pale-green PDF-derived reading box and word-highlight subtitles. |
| Glossary | 03:26-03:45 | Key definitions | Stable pale-pink PDF-derived glossary box and word highlighting. |
| Assessment | 03:45-04:12 | Questions and blanks | Worksheet-style panel; each prompt follows the narration. |
| Choose | 04:12-04:45 | Multiple choice | PDF-derived MCQ panel with synchronized reading. |
| Activity and Life Skills | 04:45-05:00 | Drawing, care, protection | Amber activity label and dotted life-skills panel; final words highlighted. |

## QA gates

1. No silent opening card; narration begins at frame zero.
2. Every subtitle word highlight follows measured speech timing.
3. Named animals and homes appear at their spoken phrase boundaries.
4. No blank screens, embedded media text, repeated loops, or generated audio.
5. PDF-derived boxes remain within title-safe and subtitle-safe areas.
6. Final MP4 contact-sheet and transition frames must be inspected after encoding.
