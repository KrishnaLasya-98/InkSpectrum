#!/usr/bin/env python3
"""Comprehensive analysis of timeline.json for asset, text, and UI issues."""
import json
from collections import defaultdict
from pathlib import Path

PROJECT = Path(r"D:\InkSpectrum\OpenMontage\projects\evs-lesson-8")
TIMELINE = PROJECT / "full-hyperframes" / "timeline.json"
INDEX_HTML = PROJECT / "full-hyperframes" / "index.html"
BUILD_SCRIPT = PROJECT / "build_full_hyperframes.py"

def analyze():
    data = json.loads(TIMELINE.read_text(encoding="utf-8"))
    
    # === ASSET ANALYSIS ===
    print("=" * 70)
    print("ASSET VARIETY ANALYSIS")
    print("=" * 70)
    
    asset_usage = defaultdict(list)
    asset_info = {}
    
    for section in data["sections"]:
        section_id = section["id"]
        for beat in section.get("beats", []):
            asset_id = beat.get("asset_id")
            if asset_id:
                asset_usage[asset_id].append({
                    "section": section_id,
                    "beat_id": beat["id"],
                    "purpose": beat.get("observed_purpose", ""),
                    "start": beat.get("start", 0),
                    "end": beat.get("end", 0),
                })
                if asset_id not in asset_info:
                    asset_info[asset_id] = beat.get("observed_subject", "unknown")
    
    # Check for repeated assets
    for asset_id, usages in sorted(asset_usage.items()):
        if len(usages) > 1:
            print(f"\n*** REUSED ASSET: {asset_id} ({asset_info.get(asset_id, 'unknown')}) - used {len(usages)} times ***")
            for u in usages:
                print(f"  {u['section']}/{u['beat_id']}: {u['purpose']} at {u['start']:.1f}-{u['end']:.1f}s")
    
    # Check for asset mismatches (bird video used for land animals etc)
    print("\n" + "=" * 70)
    print("ASSET-TO-CONTENT MISMATCH ANALYSIS")
    print("=" * 70)
    
    subject_map = {
        "s03-beat-04": ("s04-2", "parrot on branch", "Lion Elephant Tiger (land animals)"),
        "s11-beat-01": ("s10-2", "dog beside fenced enclosure", "Human-made homes intro"),
        "s10-beat-03": ("s08-2", "ants on anthill", "Ant group"),
    }
    for beat_id, (asset, subject, expected) in subject_map.items():
        print(f"\n*** MISMATCH: {beat_id} uses {asset} ({subject}) for: {expected}")
    
    # Similar subject detection
    print("\n" + "=" * 70)
    print("SIMILAR SUBJECT DETECTION (within same section)")
    print("=" * 70)
    
    for section in data["sections"]:
        section_id = section["id"]
        beats = section.get("beats", [])
        subjects = []
        for beat in beats:
            asset_id = beat.get("asset_id", "")
            # Find subject from build script mapping
            subjects.append((beat["id"], asset_id, beat.get("observed_purpose", "")))
        
        # Check for similar subjects
        for i in range(len(subjects)):
            for j in range(i+1, len(subjects)):
                bid1, aid1, purp1 = subjects[i]
                bid2, aid2, purp2 = subjects[j]
                if aid1 and aid2:
                    # Check if same base animal/subject
                    if aid1.split("-")[0] == aid2.split("-")[0] and aid1 != aid2:
                        print(f"\n*** SIMILAR SUBJECT in {section_id}: {bid1}({aid1}) vs {bid2}({aid2})")
    
    # === TEXT ANALYSIS ===
    print("\n" + "=" * 70)
    print("TEXT REDUNDANCY ANALYSIS")
    print("=" * 70)
    
    # Check for duplicate source lines across sections
    line_occurrences = defaultdict(list)
    for section in data["sections"]:
        for line in section.get("source_lines", []):
            line_occurrences[line].append(section["id"])
    
    print("\nLines appearing in multiple sections:")
    for line, sections in line_occurrences.items():
        if len(sections) > 1:
            print(f"  '{line[:80]}'... in {sections}")
    
    # Check for title==subtitle duplication
    print("\nTitle == Subtitle (identical):")
    for section in data["sections"]:
        title = section.get("title", "")
        subtitle = section.get("subtitle", "")
        if title == subtitle and title:
            print(f"  {section['id']}: title == subtitle == '{title[:80]}'")
    
    # === UI LAYOUT ANALYSIS ===
    print("\n" + "=" * 70)
    print("UI LAYOUT ANALYSIS")
    print("=" * 70)
    
    html = INDEX_HTML.read_text(encoding="utf-8")
    
    issues = []
    
    # Check source card vs highlights box overlap
    if 'top: 170px; right: 92px; width: 720px' in html and 'top: 170px; right: 92px; width: 720px' in html:
        issues.append("source-card and highlights-box have identical positioning (top:170px, right:92px, width:720px)")
    
    # Check animal name positions
    if '#animal-lion' in html and '#animal-elephant' in html:
        # lion at left:180, elephant at left:790, tiger at right:180
        # lion: 180px to ~480px, elephant: 790px to ~1090px, tiger: ~1560px to ~1860px
        print("\nAnimal name positions: lion(left:180), elephant(left:790), tiger(right:180)")
        print("  Potential overlap: lion ends ~480px, elephant starts 790px - OK")
        print("  elephant ends ~1090px, tiger starts ~1560px - OK")
    
    # Check caption positions
    if 'bottom: 242px' in html and 'bottom: 72px' in html:
        issues.append("Two caption positions exist: bottom:242px and bottom:72px - may show simultaneously")
    
    # Exercise inner width
    if 'width: 1450px' in html:
        issues.append("exercise-inner width 1450px at 1920px canvas = 235px total margin (tight)")
    
    # Recall panel has hardcoded HTML + JS data population (duplication)
    if 'Animals live both on land and in water' in html and 'let recall' in html.lower():
        issues.append("recall-panel has hardcoded <li> items that duplicate JS module data population")
    
    for issue in issues:
        print(f"  *** UI ISSUE: {issue}")

if __name__ == "__main__":
    analyze()
