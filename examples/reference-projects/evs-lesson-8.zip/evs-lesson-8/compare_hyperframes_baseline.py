"""Compare the full composition's shared UI CSS with the approved baseline."""
from __future__ import annotations

import json
import re
from pathlib import Path

PROJECT = Path(__file__).resolve().parent
CONTRACT = PROJECT / "artifacts" / "hyperframes_ui_contract.json"
BASELINE = PROJECT / "one-minute-preview" / "hyperframes" / "index.html"
FULL = PROJECT / "full-hyperframes" / "index.html"


def css_rules(path: Path) -> dict[str, dict[str, str]]:
    html = path.read_text(encoding="utf-8")
    style = re.search(r"<style>(.*?)</style>", html, flags=re.DOTALL)
    if not style:
        raise ValueError(f"missing style block: {path}")
    rules: dict[str, dict[str, str]] = {}
    for selector_text, body in re.findall(r"([^{}]+)\{([^{}]*)\}", style.group(1)):
        declarations = {}
        for declaration in body.split(";"):
            if ":" in declaration:
                name, value = declaration.split(":", 1)
                declarations[name.strip()] = re.sub(r"\s+", " ", value.strip())
        for selector in selector_text.split(","):
            rules[selector.strip()] = declarations
    return rules


def resolve(value: str | None, rules: dict[str, dict[str, str]]) -> str | None:
    if value is None:
        return None
    for _ in range(4):
        match = re.search(r"var\((--[\w-]+)\)", value)
        if not match:
            break
        value = value.replace(match.group(0), rules[":root"][match.group(1)])
    return value


def compare() -> dict:
    contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
    baseline = css_rules(BASELINE)
    full = css_rules(FULL)
    differences = []
    for selector, expected in contract["shared_selectors"].items():
        for name, contract_value in expected.items():
            expected_value = resolve(contract_value, baseline)
            if resolve(baseline.get(selector, {}).get(name), baseline) != expected_value or resolve(full.get(selector, {}).get(name), full) != expected_value:
                differences.append({"selector": selector, "property": name, "expected": expected_value, "baseline": baseline.get(selector, {}).get(name), "full": full.get(selector, {}).get(name)})
    return {"valid": not differences, "differences": differences, "baseline": str(BASELINE), "full": str(FULL)}


if __name__ == "__main__":
    result = compare()
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["valid"] else 1)
