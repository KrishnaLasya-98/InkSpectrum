"""Generate the narration-driven EVS Lesson 8 HyperFrames schedule.

The source manifest owns all displayed educational wording. Transcript word
timestamps own timing. This module deliberately contains only semantic source
line mappings and observed-media metadata, never replacement lesson prose.
"""
from __future__ import annotations

import json
import re
import shutil
import wave
from pathlib import Path
from typing import Any

from source_section_manifest import SECTION_SOURCE_MAP, build_section_manifest

PROJECT = Path(__file__).resolve().parent
ART = PROJECT / "artifacts"
OUT = PROJECT / "full-hyperframes"
ASSET_ROOT = OUT / "assets"
HTML_PATH = OUT / "index.html"
SECTION_IDS = [f"s{index:02d}" for index in range(1, 17)]

TRANSITION_HOLD = 0.5
TITLE_HOLD = 3.0
PAUSE_SECONDS = 5.0
REVEAL_SECONDS = 4.0
ACTIVITY_DRAWING_HOLD = 4.0
FINAL_SLOGAN_HOLD = 4.0
ASSESSMENT_ANSWERS = {
    "q01": "Answer: Dog and rabbit (any two pet animals).",
    "q02": "Answer: Dogs are kept in kennels.",
    "q03": "Answer: Birds build nests.",
    "q04": "Answer: burrows",
    "q05": "Answer: wings",
    "q06": "Answer: aquatic animals",
    "q07": "Answer: six",
    "q08": "Answer: bees",
    "q09": "Correct answer: a) water",
    "q10": "Correct answer: a) land",
    "q11": "Correct answer: b) insect",
    "q12": "Correct answer: b) pet",
    "q13": "Correct answer: b) Wild",
}

# Segment-to-source relationships are semantic only. Text is always looked up
# from the manifest after these IDs are selected.
CONTENT_SEGMENTS: dict[str, list[tuple[int, list[int], str]]] = {
    "s01": [(0, [1], "opening"), (1, [4, 5], "pet-prompt"), (2, [8, 10], "lesson-highlights"), (3, [11, 12, 13, 14, 15], "lesson-highlights")],
    "s02": [(0, [18], "animals-around-us"), (1, [18], "animals-around-us"), (2, [18], "animals-around-us"), (3, [18], "animals-around-us")],
    "s03": [(0, [22], "land-water-comparison"), (1, [24, 26], "water-animals"), (2, [30, 32], "land-animals"), (3, [40], "named-land-animals")],
    "s04": [(0, [42, 44], "birds"), (1, [52], "named-birds")],
    "s05": [(0, [54, 56], "insects"), (1, [64], "named-insects")],
    "s06": [(0, [66], "domestic-animals"), (1, [70], "pet-animals"), (2, [70], "pet-care")],
    "s07": [(0, [72], "wild-animals"), (1, [72], "wild-animals"), (2, [72], "wild-animals")],
    "s08": [(0, [76, 78], "animal-homes"), (1, [78], "animal-homes")],
    "s09": [(0, [82, 84, 85], "lion-den"), (1, [86], "lion-food"), (2, [91, 93], "rabbit-burrow"), (3, [94], "rabbit-food")],
    "s10": [(0, [96, 98], "bird-nest"), (1, [99], "bird-food"), (2, [101, 103], "ant-anthill"), (3, [104], "ant-group")],
    "s11": [(0, [115], "human-made-homes"), (1, [115], "kennel"), (2, [123], "shed"), (3, [123], "stable")],
}

MODULE_LINES = {
    "recall": [127, 129, 130, 131, 132, 133, 134, 135],
    "glossary": [140, 142, 143, 144, 145, 146],
    "assessment": [151, 153, 155, 156, 159, 162, 164, 165, 166, 167, 168, 171, 173, 174, 175, 176, 177],
    "activity": [182, 184],
    "life_skills": [188, 190],
}

QUESTION_LINES = {
    "s14": [155, 156, 159, 164, 165, 166, 167, 168],
    "s15": [173, 174, 175, 176, 177],
}
QUESTION_TOKENS = {
    155: ["name", "any", "two", "pet", "animals"],
    156: ["where", "are", "dogs", "kept"],
    159: ["what", "do", "the", "birds", "build"],
    164: ["rabbits", "live", "in", "a", "blank"],
    165: ["birds", "have", "a", "blank", "to", "fly"],
    166: ["animals", "that", "live", "in", "water", "are", "called", "a", "blank"],
    167: ["insects", "have", "blank", "legs"],
    168: ["ants", "live", "in", "a", "group", "like", "blank"],
    173: ["fish", "live", "in", "water", "land", "or", "both", "water", "and", "land"],
    174: ["animals", "that", "live", "on", "land", "are", "called"],
    175: ["butterfly", "is", "a", "bird", "insect", "or", "none", "of", "these"],
    176: ["parrot", "and", "rabbit", "are", "wild", "pet", "or", "insect", "animals"],
    177: ["tiger", "is", "a", "domestic", "wild", "or", "pet", "animal"],
}

OBSERVED_MEDIA = {
    "s01-0": ("existing_modelslab_motion", "fish over aquatic water", "animal-life introduction", [1, 12]),
    "s01-1": ("existing_modelslab_motion", "bird on branch", "animal-life introduction", [1, 13]),
    "s01-2": ("existing_modelslab_motion", "rabbit in meadow", "animal-life introduction", [1, 11]),
    "s02-0": ("existing_modelslab_motion", "cow at water trough", "animals need water", [18]),
    "s03-0": ("existing_modelslab_motion", "fish in water with aquatic setting", "water animals", [22, 24, 26]),
    "s03-1": ("existing_modelslab_motion", "lion elephant tiger on land", "land animals", [30, 32, 40]),
    "s03-2": ("existing_modelslab_motion", "tiger walking", "named land animals", [40]),
    "s04-0": ("existing_modelslab_motion", "duck on pond", "birds", [42, 44, 52]),
    "s04-1": ("existing_modelslab_motion", "pigeon with wings", "birds", [42, 44, 52]),
    "s05-0": ("existing_modelslab_motion", "grasshopper insect", "insects", [54, 56, 64]),
    "s05-1": ("existing_modelslab_motion", "grasshopper insect close-up", "named insects", [64]),
    "s06-0": ("existing_modelslab_motion", "parrots", "pet animals", [66, 70]),
    "s06-1": ("existing_modelslab_motion", "rabbit", "pet animals", [70]),
    "s07-0": ("existing_modelslab_motion", "lion", "wild animals", [72]),
    "s07-1": ("existing_modelslab_motion", "deer in natural setting", "wild animals", [72]),
    "s08-0": ("existing_modelslab_motion", "bird nest in tree", "animal homes", [76, 78]),
    "s08-1": ("existing_modelslab_motion", "anthill with ants", "animal homes", [76, 78]),
    "s09-0": ("existing_modelslab_motion", "lion at recognizable cave den", "lion den", [82, 84, 85]),
    "s09-1": ("existing_modelslab_motion", "bird building nest", "bird nest", [96, 98]),
    "s10-0": ("existing_modelslab_motion", "bird by nest", "bird nest", [96, 98]),
    "s10-1": ("existing_modelslab_motion", "ants around anthill", "ant anthill", [101, 103, 104]),
    "s10-2": ("existing_modelslab_motion", "dog beside fenced human-made enclosure", "kennel candidate", [115]),
    "s11-0": ("existing_modelslab_motion", "cow in shed", "human-made shed", [123]),
    "s11-1": ("existing_modelslab_motion", "horse in stable", "human-made stable", [123]),
    # Alternate takes were present in the source package but were not mapped by
    # the first assembly pass.  Keeping them explicit prevents the renderer
    # from looping a single shot merely to fill a narration beat.
    "s02-1": ("existing_modelslab_motion", "sheep in a sheltered farm setting", "animals around us", [18]),
    "s02-2": ("existing_modelslab_motion", "cow in a pasture", "animals around us", [18]),
    "s04-2": ("existing_modelslab_motion", "parrot on a branch", "named birds", [52]),
    "s05-2": ("existing_modelslab_motion", "grasshopper close-up", "named insects", [64]),
    "s06-2": ("existing_modelslab_motion", "rabbit in a field", "pet animals", [70]),
    "s07-2": ("existing_modelslab_motion", "deer in woodland", "wild animals", [72]),
    "s08-2": ("existing_modelslab_motion", "ants on an anthill", "animal homes", [78]),
    "s09-2": ("existing_modelslab_motion", "lion eating prey", "lion food", [86]),
    "s11-2": ("existing_modelslab_motion", "horse at a stable", "human-made stable", [123]),
}

# A source-card is a visual aid, not a second transcript.  These concise,
# sequential cards preserve each source idea while avoiding repeated blocks of
# text alongside the word-synchronised captions.
CARD_TEXT_OVERRIDES: dict[str, list[str]] = {
    "s02-beat-01": ["Animals are living beings found in nature."],
    "s02-beat-02": ["They need food, shelter, air and water to survive."],
    "s02-beat-03": ["Their size, eating habits, colour and body covering vary."],
    "s02-beat-04": ["All animals need care and protection."],
    "s06-beat-01": ["Domestic animals are kept at or around our homes."],
    "s06-beat-02": ["Dogs, parrots and rabbits can be pet animals."],
    "s06-beat-03": ["We love pets and take care of them."],
    "s07-beat-01": ["Wild animals are found in forests."],
    "s07-beat-02": ["Animals that live in forests are called wild animals."],
    "s07-beat-03": ["Some wild animals eat the flesh of other animals."],
    "s08-beat-01": ["Animals need a home to live and food to grow."],
    "s08-beat-02": ["Different animals eat different food and live in different homes."],
    "s09-beat-02": ["Lions eat the flesh of other animals."],
    "s10-beat-01": ["Birds build their own nests."],
    "s10-beat-02": ["Birds eat seeds, berries, fruit and insects."],
    "s10-beat-03": ["Ants make sand structures called anthills."],
    "s10-beat-04": ["Ants live in groups, like bees."],
    "s11-beat-01": ["Domestic and pet animals live in human-made homes."],
    "s11-beat-02": ["A dog lives in a kennel."],
    "s11-beat-03": ["A cow lives in a shed."],
    "s11-beat-04": ["A horse lives in a stable."],
}


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def wav_duration(path: Path) -> float:
    with wave.open(str(path), "rb") as reader:
        return reader.getnframes() / reader.getframerate()


def normalize_token(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", value.lower())


def transcript_words(transcript: dict[str, Any]) -> list[dict[str, Any]]:
    return [word for segment in transcript.get("segments", []) for word in segment.get("words", []) if word.get("word", "").strip()]


def find_phrase_window(transcript: dict[str, Any], tokens: list[str]) -> tuple[float, float]:
    words = transcript_words(transcript)
    wanted = [normalize_token(token) for token in tokens]
    normalized = [normalize_token(word["word"]) for word in words]
    for start in range(len(words) - len(wanted) + 1):
        if normalized[start:start + len(wanted)] == wanted:
            return float(words[start]["start"]), float(words[start + len(wanted) - 1]["end"])
    raise ValueError(f"could not align source phrase: {' '.join(tokens)}")


def copy_video(source: Path, asset_id: str, source_type: str, observed_subject: str, purpose: str, source_line_ids: list[int]) -> dict[str, Any]:
    destination = ASSET_ROOT / "video" / f"{asset_id}.mp4"
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    return {
        "id": asset_id,
        "path": f"assets/video/{destination.name}",
        "source": str(source),
        "source_type": source_type,
        "observed_subject": observed_subject,
        "purpose": purpose,
        "source_line_ids": source_line_ids,
        "observed_frame_checked": True,
    }


def copy_assets() -> dict[str, dict[str, Any]]:
    assets: dict[str, dict[str, Any]] = {}
    scene_root = PROJECT / "assets" / "video" / "scenes"
    for asset_id, (source_type, subject, purpose, line_ids) in OBSERVED_MEDIA.items():
        if not asset_id.startswith("s"):
            continue
        section_id, index = asset_id.rsplit("-", 1)
        source = scene_root / section_id / f"{asset_id}.mp4"
        if source.exists():
            assets[asset_id] = copy_video(source, asset_id, source_type, subject, purpose, line_ids)
    stock_root = PROJECT / "assets" / "video" / "stock-animated"
    for source in sorted(stock_root.glob("*.mp4")):
        asset_id = f"stock-{source.stem}"
        # Candidates are copied for auditable preview/reference use only. They
        # are not scheduled unless an observed semantic match is proven.
        assets[asset_id] = copy_video(source, asset_id, "animated_stock_candidate", {
            "pixabay_video_13895": "butterfly-like insect in stylized landscape",
            "pixabay_video_161765": "dog in outdoor setting; kennel not proven",
            "pixabay_video_31922": "rabbit-like animal",
            "pixabay_video_84687": "fish/aquatic subject",
            "pixabay_video_92718": "birds in stylized landscape",
        }.get(source.stem, "observed stock subject"), "candidate only", [])
    return assets


def prepare_audio_assets() -> dict[str, float]:
    """Copy narration and insert only the explicit assessment holds."""
    durations: dict[str, float] = {}
    audio_root = ASSET_ROOT / "audio"
    audio_root.mkdir(parents=True, exist_ok=True)
    for section_id in SECTION_IDS:
        source = PROJECT / "renders" / "audio" / f"{section_id}.norm.wav"
        destination = audio_root / source.name
        if section_id in QUESTION_LINES:
            transcript = load_json(ART / f"{section_id}.norm_transcript.json")
            boundaries = [find_phrase_window(transcript, QUESTION_TOKENS[line_id])[1] for line_id in QUESTION_LINES[section_id]]
            durations[section_id] = insert_assessment_pauses(source, destination, boundaries)
        else:
            shutil.copy2(source, destination)
            durations[section_id] = wav_duration(source)
    return durations


def beat_for(section_id: str, transcript: dict[str, Any], by_line: dict[int, str], assets: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    beats: list[dict[str, Any]] = []
    for index, line_ids, purpose in CONTENT_SEGMENTS.get(section_id, []):
        segment = transcript["segments"][index]
        asset_id = f"{section_id}-{index}"
        if section_id == "s01":
            asset_id = {0: "s01-0", 1: "s01-1", 2: "s01-2", 3: "s03-1"}[index]
        elif section_id == "s02":
            asset_id = {0: "s02-0", 1: "s02-1", 2: "s02-2", 3: "s07-1"}[index]
        elif section_id == "s03":
            # Keep the land-animal examples on land-animal footage.  The old
            # mapping used the parrot take from s04 for this beat.
            asset_id = {0: "s03-1", 1: "s03-0", 2: "s02-2", 3: "s03-2"}[index]
        elif section_id == "s04":
            asset_id = "s04-0" if index == 0 else "s04-1"
        elif section_id == "s05":
            asset_id = "s05-0" if index == 0 else "s05-2"
        elif section_id == "s06":
            asset_id = {0: "s06-0", 1: "s06-1", 2: "s06-2"}[index]
        elif section_id == "s07":
            asset_id = {0: "s07-0", 1: "s07-1", 2: "s07-2"}[index]
        elif section_id == "s09":
            asset_id = {0: "s09-0", 1: "s09-2", 2: "s06-1", 3: "s06-2"}[index]
        elif section_id == "s10":
            asset_id = {0: "s10-0", 1: "s09-1", 2: "s10-1", 3: "s08-2"}[index]
        elif section_id == "s11":
            # Keep each home beat on a distinct take; the overview uses the
            # enclosure shot, followed by the dog, cow, and horse examples.
            asset_id = {0: "s11-2", 1: "s10-2", 2: "s11-0", 3: "s11-1"}[index]
        elif asset_id not in assets:
            asset_id = next((candidate for candidate in assets if candidate.startswith(section_id + "-")), None)
        beats.append({
            "id": f"{section_id}-beat-{len(beats) + 1:02d}",
            "start_local": round(float(segment["start"]), 3),
            "end_local": round(float(segment["end"]), 3),
            "audio_start_local": round(float(segment["start"]), 3),
            "audio_end_local": round(float(segment["end"]), 3),
            "asset_id": asset_id if asset_id in assets else None,
            "observed_purpose": purpose,
            "source_line_ids": line_ids,
            "source_lines": CARD_TEXT_OVERRIDES.get(f"{section_id}-beat-{len(beats) + 1:02d}", [by_line[line_id] for line_id in line_ids]),
            "media_policy": "motion_first" if asset_id in assets else "graphics_fallback",
        })
    return beats


def make_modules(by_line: dict[int, str]) -> dict[str, Any]:
    return {
        "recall": {"title": by_line[127], "source_line_ids": MODULE_LINES["recall"], "entries": [by_line[x] for x in MODULE_LINES["recall"][1:]], "media_policy": "graphics_only"},
        "glossary": {"title": by_line[140], "source_line_ids": MODULE_LINES["glossary"], "entries": [by_line[x] for x in MODULE_LINES["glossary"][1:]], "media_policy": "graphics_only"},
        "activity": {"title": by_line[182], "instruction": by_line[184], "source_line_ids": MODULE_LINES["activity"], "media_policy": "graphics_only"},
        "life_skills": {"title": by_line[188], "message": by_line[190], "source_line_ids": MODULE_LINES["life_skills"], "media_policy": "graphics_only"},
        "assessment": {"title": by_line[151], "headers": [by_line[153], by_line[162], by_line[171]], "source_line_ids": MODULE_LINES["assessment"], "media_policy": "graphics_only"},
    }


def insert_assessment_pauses(source: Path, destination: Path, boundaries: list[float]) -> float:
    with wave.open(str(source), "rb") as reader:
        params = reader.getparams()
        frames = reader.readframes(reader.getnframes())
    bytes_per_frame = params.sampwidth * params.nchannels
    pieces: list[bytes] = []
    cursor = 0
    for boundary in boundaries:
        end = min(len(frames), round(boundary * params.framerate) * bytes_per_frame)
        pieces.extend([frames[cursor:end], b"\x00" * round((PAUSE_SECONDS + REVEAL_SECONDS) * params.framerate) * bytes_per_frame])
        cursor = end
    pieces.append(frames[cursor:])
    payload = b"".join(pieces)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(destination), "wb") as writer:
        writer.setparams(params)
        writer.writeframes(payload)
    return len(payload) / bytes_per_frame / params.framerate


def make_questions(by_line: dict[int, str], sections: dict[str, dict[str, Any]], assessment_durations: dict[str, float]) -> list[dict[str, Any]]:
    questions: list[dict[str, Any]] = []
    number = 1
    for section_id in ("s14", "s15"):
        transcript = load_json(ART / f"{section_id}.norm_transcript.json")
        raw_windows = [(line_id, *find_phrase_window(transcript, QUESTION_TOKENS[line_id])) for line_id in QUESTION_LINES[section_id]]
        boundaries = [end for _line_id, _start, end in raw_windows]
        for line_id, raw_start, raw_end in raw_windows:
            preceding_holds = sum(1 for boundary in boundaries if raw_start > boundary)
            ending_holds = sum(1 for boundary in boundaries if raw_end > boundary)
            local_start = raw_start + preceding_holds * (PAUSE_SECONDS + REVEAL_SECONDS)
            local_end = raw_end + ending_holds * (PAUSE_SECONDS + REVEAL_SECONDS)
            section_start = sections[section_id]["start"]
            prompt = by_line[line_id]
            options: list[str] = []
            if section_id == "s15":
                parts = re.split(r"\s+(?=[abc]\)\s)", prompt, flags=re.I)
                prompt, *options = [part.strip() for part in parts]
            questions.append({
                "id": f"q{number:02d}",
                "section": section_id,
                "assessment_id": {"s14": "assessment_i_ii", "s15": "assessment_iii"}[section_id],
                "header": by_line[153] if number <= 3 else by_line[162] if number <= 8 else by_line[171],
                "prompt_start": round(section_start + local_start, 3),
                "question_end": round(section_start + local_end, 3),
                "prediction_start": round(section_start + local_end, 3),
                "prediction_end": round(section_start + local_end + PAUSE_SECONDS, 3),
                "reveal_start": round(section_start + local_end + PAUSE_SECONDS, 3),
                "reveal_end": round(section_start + local_end + PAUSE_SECONDS + REVEAL_SECONDS, 3),
                "handoff_end": round(section_start + local_end + PAUSE_SECONDS + REVEAL_SECONDS, 3),
                "prompt": prompt,
                "answer": ASSESSMENT_ANSWERS[f"q{number:02d}"],
                "source_line_ids": [line_id],
                "pause_seconds": PAUSE_SECONDS,
                "reveal_seconds": REVEAL_SECONDS,
                "audio_duration": round(local_end - local_start, 3),
                "options": options,
                "timing_source": "word-level-ASR phrase alignment",
            })
            number += 1
    return questions


def make_caption_phrases(words: list[dict[str, Any]], section_id: str, offset: float) -> list[dict[str, Any]]:
    section_words = [word for word in words if word["section"] == section_id]
    phrases: list[list[dict[str, Any]]] = []
    current: list[dict[str, Any]] = []
    for word in section_words:
        current.append(word)
        following = section_words[section_words.index(word) + 1] if section_words.index(word) + 1 < len(section_words) else None
        gap = (following["start_ms"] - word["end_ms"]) if following else 9999
        if re.search(r"[.!?]$", word["word"].strip()) or gap > 520 or len(current) >= 8 or following is None:
            phrases.append(current)
            current = []
    output = []
    for phrase_index, phrase in enumerate(phrases):
        steps = []
        for index, word in enumerate(phrase):
            steps.append({"at_ms": word["start_ms"], "visible_word_indices": list(range(index + 1)), "active_word_index": index})
        output.append({"id": f"{section_id}-phrase-{phrase_index + 1:02d}", "start_ms": phrase[0]["start_ms"], "end_ms": phrase[-1]["end_ms"], "words": [word["word"] for word in phrase], "steps": steps})
    return output


def validate_assessment_intervals(exercises: list[dict[str, Any]]) -> dict[str, Any]:
    errors = []
    intervals = []
    for item in exercises:
        interval = {key: item[key] for key in ("id", "section", "prompt_start", "handoff_end", "prediction_start", "prediction_end", "reveal_start", "reveal_end")}
        intervals.append(interval)
        if item["prompt_start"] >= item["handoff_end"]:
            errors.append(f"{item['id']} is empty")
        if abs(item["reveal_end"] - item["reveal_start"] - REVEAL_SECONDS) > 0.001:
            errors.append(f"{item['id']} reveal is not four seconds")
    for previous, current in zip(intervals, intervals[1:]):
        if previous["handoff_end"] > current["prompt_start"]:
            errors.append(f"{previous['id']} overlaps {current['id']}")
    return {"valid": not errors, "intervals": intervals, "errors": errors}


def build_data() -> dict[str, Any]:
    source = load_json(ART / "source_text_manifest.json")
    style = load_json(ART / "hyperframes_style.json")
    by_line = {int(item["source_line"]): item["source_text"] for item in source["items"]}
    section_manifest = build_section_manifest(source)
    assets = copy_assets()
    audio_durations = prepare_audio_assets()

    sections: list[dict[str, Any]] = []
    words: list[dict[str, Any]] = []
    cursor = 0.0
    for manifest in section_manifest:
        section_id = manifest["id"]
        transcript = load_json(ART / f"{section_id}.norm_transcript.json")
        raw_audio_duration = wav_duration(PROJECT / "renders" / "audio" / f"{section_id}.norm.wav")
        title_start = cursor
        title_end = title_start + TITLE_HOLD
        audio_start = title_end
        audio_end = audio_start + audio_durations[section_id]
        end = audio_end + (ACTIVITY_DRAWING_HOLD + FINAL_SLOGAN_HOLD if section_id == "s16" else TRANSITION_HOLD)
        beats = beat_for(section_id, transcript, by_line, assets)
        for beat in beats:
            beat["start"] = round(audio_start + beat.pop("start_local"), 3)
            beat["end"] = round(audio_start + beat.pop("end_local"), 3)
            beat["audio_start"] = round(audio_start + beat.pop("audio_start_local"), 3)
            beat["audio_end"] = round(audio_start + beat.pop("audio_end_local"), 3)
            beat["card_window"] = [beat["start"], beat["end"]]
        for word in transcript_words(transcript):
            local_start = float(word["start"])
            local_end = float(word["end"])
            if section_id in QUESTION_LINES:
                boundaries = [find_phrase_window(transcript, QUESTION_TOKENS[line_id])[1] for line_id in QUESTION_LINES[section_id]]
                local_start += sum(1 for boundary in boundaries if local_start > boundary) * (PAUSE_SECONDS + REVEAL_SECONDS)
                local_end += sum(1 for boundary in boundaries if local_end > boundary) * (PAUSE_SECONDS + REVEAL_SECONDS)
            words.append({"section": section_id, "word": word["word"].strip(), "start_ms": round((audio_start + local_start) * 1000), "end_ms": round((audio_start + local_end) * 1000)})
        if section_id == "s16":
            beats = [
                {"id": "s16-activity", "start": round(audio_start, 3), "end": round(audio_end, 3), "audio_start": round(audio_start, 3), "audio_end": round(audio_end, 3), "asset_id": None, "observed_purpose": "source activity instruction", "source_line_ids": [182, 184], "source_lines": [], "media_policy": "graphics_only"},
                {"id": "s16-activity-hold", "start": round(audio_end, 3), "end": round(audio_end + ACTIVITY_DRAWING_HOLD, 3), "audio_start": round(audio_end, 3), "audio_end": round(audio_end, 3), "asset_id": None, "observed_purpose": "explicit activity hold", "source_line_ids": [182, 184], "source_lines": [by_line[182], by_line[184]], "media_policy": "graphics_only"},
                {"id": "s16-slogan-hold", "start": round(audio_end + ACTIVITY_DRAWING_HOLD, 3), "end": round(end, 3), "audio_start": round(audio_end + ACTIVITY_DRAWING_HOLD, 3), "audio_end": round(audio_end + ACTIVITY_DRAWING_HOLD, 3), "asset_id": None, "observed_purpose": "exact final slogan hold", "source_line_ids": [188, 190], "source_lines": [by_line[188], by_line[190]], "media_policy": "graphics_only"},
            ]
        elif section_id in {"s12", "s13", "s14", "s15"}:
            beats = []
        display_title = manifest["title"]
        display_subtitle = manifest["subtitle"]
        # Avoid presenting the same long source sentence twice on the s07
        # title card. The narration/captions retain the verbatim source text.
        if section_id == "s07" and display_title == display_subtitle:
            display_subtitle = "Wild animals live in forests."
        sections.append({
            "id": section_id,
            "title": display_title,
            "subtitle": display_subtitle,
            "title_source_line_ids": manifest["title_source_line_ids"],
            "subtitle_source_line_ids": manifest["subtitle_source_line_ids"],
            "source_line_ids": manifest["source_line_ids"],
            "source_lines": [by_line[line_id] for line_id in manifest["source_line_ids"]],
            "start": round(title_start, 3),
            "title_start": round(title_start, 3),
            "title_end": round(title_end, 3),
            "audio_start": round(audio_start, 3),
            "audio_end": round(audio_end, 3),
            "end": round(end, 3),
            "audio_duration": round(audio_durations[section_id], 3),
            "beats": beats,
            "caption_phrases": make_caption_phrases(words, section_id, audio_start),
            "media_policy": manifest["media_policy"],
            "title_card": {"media_policy": "graphics_only", "centered": True, "source_line_ids": manifest["title_source_line_ids"] + manifest["subtitle_source_line_ids"]},
        })
        cursor = end

    section_by_id = {section["id"]: section for section in sections}
    exercises = make_questions(by_line, section_by_id, audio_durations)
    assessment_intervals = validate_assessment_intervals(exercises)
    if not assessment_intervals["valid"]:
        raise ValueError("invalid generated assessment intervals: " + "; ".join(assessment_intervals["errors"]))
    modules = make_modules(by_line)
    slogan = [by_line[190]]

    assigned: dict[int, list[str]] = {}
    for section in sections:
        for line_id in section["source_line_ids"]:
            assigned.setdefault(line_id, []).append(section["id"])
    for question in exercises:
        for line_id in question["source_line_ids"]:
            assigned.setdefault(line_id, []).append(question["id"])
    for module_name, line_ids in MODULE_LINES.items():
        for line_id in line_ids:
            assigned.setdefault(line_id, []).append(module_name)
    coverage_lines = [
        {
            "source_line": int(item["source_line"]),
            "source_text": item["source_text"],
            "status": "covered" if assigned.get(int(item["source_line"])) else "uncovered",
            "locations": sorted(set(assigned.get(int(item["source_line"]), []))),
        }
        for item in source["items"]
    ]
    asset_report = {
        "matches": [asset for asset in assets.values() if asset["source_type"] == "existing_modelslab_motion"],
        "stock_candidates": [asset for asset in assets.values() if asset["source_type"] == "animated_stock_candidate"],
        "mismatches": [
            {"location": "s11 kennel", "issue": "dog enclosure is observed but kennel identity is not visually certain", "asset_id": "s10-2", "stock_candidate": "stock-pixabay_video_161765", "stock_query": "dog kennel animated video"},
            {"location": "s10 bird nest", "issue": "bird and nest are observed in separate candidate scenes; no single confirmed combined action shot", "asset_id": "s10-0", "stock_candidate": "stock-pixabay_video_92718", "stock_query": "bird building nest animated video"},
            {"location": "s09 rabbit burrow", "issue": "rabbit subject is observed but burrow habitat is not confirmed in the selected motion", "asset_id": "s06-1", "stock_candidate": "stock-pixabay_video_31922", "stock_query": "rabbit burrow animated video"},
        ],
    }
    coverage_audit = {
        "version": "3.0",
        "source_manifest": "../artifacts/source_text_manifest.json",
        "source_line_count": len(coverage_lines),
        "covered_source_line_count": sum(item["status"] == "covered" for item in coverage_lines),
        "uncovered_source_lines": [item for item in coverage_lines if item["status"] == "uncovered"],
        "source_lines": coverage_lines,
        "assessment_ids": [item["id"] for item in exercises],
        "titles": [{"section": section["id"], "title": section["title"], "subtitle": section["subtitle"], "title_source_line_ids": section["title_source_line_ids"], "subtitle_source_line_ids": section["subtitle_source_line_ids"]} for section in sections],
        "image_references": source.get("image_references", []),
        "rendered_transcript_word_count": None,
        "manual_frame_checks": [{"section": section["id"], "checks": ["title boundary", "content boundary", "subtitle gap"]} for section in sections] + [{"assessment_id": item["id"], "checks": ["prediction 5s", "reveal 4s", "handoff"]} for item in exercises] + [{"section": "s16", "checks": ["Activity start", "Activity hold", "Life Skills slogan", "final slogan clear"]}],
        "asset_report": asset_report,
    }
    duration = round(sections[-1]["end"], 3)
    schedule = {"duration": duration, "opening_hold": TITLE_HOLD, "title_card_windows": [{"section": section["id"], "start": section["title_start"], "end": section["title_end"], "source_line_ids": section["title_card"]["source_line_ids"], "media_policy": "graphics_only"} for section in sections], "content_card_windows": [{"section": section["id"], "beat_id": beat["id"], "start": beat["start"], "end": beat["end"], "source_line_ids": beat["source_line_ids"]} for section in sections for beat in section["beats"]], "word_captions": words, "phrase_visual_beats": [{"section": section["id"], "phrases": section["caption_phrases"]} for section in sections], "exercise_states": exercises, "gaps": [{"section": section["id"], "start": section["audio_start"], "end": section["audio_end"], "policy": "word-level ASR gaps clear phrase"} for section in sections], "audio_driven": True, "assessment_audio_hold_seconds": PAUSE_SECONDS + REVEAL_SECONDS, "activity_drawing_hold_seconds": ACTIVITY_DRAWING_HOLD, "final_slogan_hold_seconds": FINAL_SLOGAN_HOLD}
    data = {"version": 3, "duration": duration, "opening_hold": TITLE_HOLD, "sections": sections, "section_manifest": section_manifest, "words": words, "exercises": exercises, "modules": modules, "assets": list(assets.values()), "style": style, "source_policy": source["text_policy"], "slogan": slogan, "assessment_policy": "The PDF has no verified answer key; display the exact safe fallback.", "schedule": schedule, "assessment_intervals": assessment_intervals, "coverage_audit": coverage_audit}
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "timeline-data.js").write_text("window.LESSON8 = " + json.dumps(data, ensure_ascii=False) + ";\n", encoding="utf-8")
    (OUT / "schedule-data.js").write_text("window.LESSON8_SCHEDULE = " + json.dumps(schedule, ensure_ascii=False) + ";\n", encoding="utf-8")
    (OUT / "style-data.js").write_text("window.LESSON8_STYLE = " + json.dumps(style, ensure_ascii=False) + ";\n", encoding="utf-8")
    (OUT / "timeline.json").write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    (OUT / "coverage_audit.json").write_text(json.dumps(coverage_audit, indent=2, ensure_ascii=False), encoding="utf-8")
    (OUT / "coverage_manifest.json").write_text(json.dumps(coverage_audit, indent=2, ensure_ascii=False), encoding="utf-8")
    (OUT / "assessment_intervals.json").write_text(json.dumps(assessment_intervals, indent=2, ensure_ascii=False), encoding="utf-8")
    (OUT / "hyperframes.json").write_text(json.dumps({"version": 3, "name": "lesson-8-animal-life-complete", "width": 1920, "height": 1080, "fps": 30, "duration": duration, "media": {"autoProxy": True}, "schedule": "schedule-data.js", "timeline": "timeline.json", "coverage_audit": "coverage_audit.json", "baseline": {"source": "../one-minute-preview/hyperframes/hyperframes.json", "renderer": "hyperframes", "width": 1920, "height": 1080, "fps": 30, "style_lock": "one-minute-approved-ui", "style_manifest": "../artifacts/hyperframes_style.json", "ui_contract": "../artifacts/hyperframes_ui_contract.json", "font_family": style["font"]["family"]}}, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    html = HTML_PATH.read_text(encoding="utf-8")
    html = re.sub(r'data-duration="[^"]+"', f'data-duration="{duration:.3f}"', html, count=1)
    HTML_PATH.write_text(html, encoding="utf-8")
    (OUT / "artifacts").mkdir(exist_ok=True)
    (OUT / "artifacts" / "coverage_audit.json").write_text(json.dumps(coverage_audit, indent=2, ensure_ascii=False), encoding="utf-8")
    return data


if __name__ == "__main__":
    result = build_data()
    print(json.dumps({"duration": result["duration"], "sections": len(result["sections"]), "words": len(result["words"]), "exercises": len(result["exercises"]), "covered_source_lines": result["coverage_audit"]["covered_source_line_count"]}, indent=2))
