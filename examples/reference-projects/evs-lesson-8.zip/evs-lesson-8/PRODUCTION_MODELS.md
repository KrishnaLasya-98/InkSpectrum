# EVS Lesson 8 Production Models

## Confirmed narration

- Provider: ModelsLab
- Endpoint family: v6 `text-to-speech`
- Voice: `tara`
- Language: American English
- Speed: `0.90`
- Target audience: Class 1, ages 5-7
- Output normalization: 48 kHz stereo PCM, -14 LUFS, -1.5 dBTP ceiling
- Status: sample approved by the user on 2026-09-18

## Confirmed visual pipeline

- Primary animated-video provider: Agnes, model `agnes-video-2.5`
- ModelsLab controlled fallback: `wan2.2` image-to-video
- ModelsLab secondary fallback: `ltx-2-3-pro-i2v`
- Generated media contains no embedded text, labels, subtitles, or UI.
- HyperFrames owns titles, source headings, subtitles, questions, and answer reveals.
- FFmpeg/FFprobe handle normalization, encoding, and technical QA.

## Content rules

- Preserve complete textbook topic coverage.
- Use only necessary textbook labels and narration subtitles.
- Do not introduce decorative labels, filler cards, repeated text, or invented slogans.
- Delivery settings are selected from the chapter's grade profile.
