"""Hardened EVS Lesson 8 batch runner: resumable, logged to disk, retried.
Imports the clip prompt list from _batch_video.py; writes progress to
renders/batch_progress.log; probes output; retries failures up to 5x
with exponential backoff. poll_modelslab now retries transient network
errors (connection reset, pool exhaustion) up to 5x per poll cycle."""
from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from dotenv import load_dotenv  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
load_dotenv(ROOT / ".env")

from tools.video.modelslab_video import ModelsLabVideo  # noqa: E402
from _batch_video import CLIPS, NEG, _seed  # noqa: E402

MAX_ATTEMPTS = 5
RETRY_BACKOFF = [5, 15, 30, 60]

PROJ = ROOT / "projects" / "evs-lesson-8"
ASSET = PROJ / "assets" / "video" / "scenes"
LOG = PROJ / "renders" / "batch_progress.log"
DURATION = "10"


def probe_ok(path: Path) -> bool:
    if not path.exists():
        return False
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
        capture_output=True, text=True,
    )
    if r.returncode != 0:
        return False
    try:
        return float(r.stdout.strip()) >= 4.0
    except ValueError:
        return False


def log(msg: str) -> None:
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with LOG.open("a", encoding="utf-8") as f:
        f.write(f"{time.strftime('%H:%M:%S')} {msg}\n")
    print(msg, flush=True)


def generate_one(tool: ModelsLabVideo, section: str, idx: int, video_prompt: str) -> bool:
    out = ASSET / section / f"{section}-{idx}.mp4"
    tmp = out.with_suffix(".part.mp4")
    out.parent.mkdir(parents=True, exist_ok=True)
    for attempt in range(1, MAX_ATTEMPTS + 1):
        try:
            res = tool.execute({
                "prompt": video_prompt, "negative_prompt": NEG,
                "model_id": "h3-minimax-t2v", "operation": "text_to_video",
                "duration": DURATION, "resolution": "768P",
                "generate_audio": True, "seed": _seed(section, idx),
                "output_path": str(tmp),
            })
            if res.success and tmp.exists():
                tmp.replace(out)
                log(f"OK {section}-{idx} (attempt {attempt}) cost={res.cost_usd}")
                return True
            log(f"FAIL {section}-{idx} attempt {attempt}: {(res.error or '')[:200]}")
        except Exception as exc:  # noqa: BLE001
            log(f"EXC {section}-{idx} attempt {attempt}: {str(exc)[:200]}")
        if attempt < MAX_ATTEMPTS:
            sleep_s = RETRY_BACKOFF[attempt - 1] if attempt - 1 < len(RETRY_BACKOFF) else RETRY_BACKOFF[-1]
            log(f"  retry {section}-{idx} in {sleep_s}s...")
            time.sleep(sleep_s)
    return False


def main() -> None:
    done = skipped = 0
    failed: list[str] = []
    tool = ModelsLabVideo()
    for i, (section, idx, kf_prompt, vid_prompt, duration) in enumerate(CLIPS, 1):
        if probe_ok(ASSET / section / f"{section}-{idx}.mp4"):
            skipped += 1
            continue
        if generate_one(tool, section, idx, vid_prompt):
            done += 1
        else:
            failed.append(f"{section}-{idx}")
    log(f"RESULT done={done} skipped={skipped} failed={failed}")


if __name__ == "__main__":
    main()