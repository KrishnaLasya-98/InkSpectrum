"""Build compact word-highlight ASS subtitles for the approved V3 reference render."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "artifacts" / "lesson-8-animal-life-final_transcript.json"
OUTPUT = ROOT / "artifacts" / "lesson-8-animal-life-final-v4.ass"
JS_OUTPUT = ROOT / "artifacts" / "lesson-8-animal-life-final-v4-captions.js"


def ass_time(seconds: float) -> str:
    centiseconds = max(0, round(seconds * 100))
    hours, remainder = divmod(centiseconds, 360000)
    minutes, remainder = divmod(remainder, 6000)
    secs, cs = divmod(remainder, 100)
    return f"{hours}:{minutes:02d}:{secs:02d}.{cs:02d}"


def clean(text: str) -> str:
    return text.strip().replace("{", "(").replace("}", ")")


data = json.loads(SOURCE.read_text(encoding="utf-8"))
words = [word for segment in data["segments"] for word in segment.get("words", [])]

groups: list[list[dict]] = []
current: list[dict] = []
for index, word in enumerate(words):
    current.append(word)
    following = words[index + 1] if index + 1 < len(words) else None
    gap = (following["start"] - word["end"]) if following else 0
    punctuation = clean(word["word"]).endswith((".", "?", "!", ":", ";"))
    if len(current) >= 8 or punctuation or gap >= 0.55 or following is None:
        groups.append(current)
        current = []

header = """[Script Info]
Title: EVS Lesson 8 - Animal Life
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Lesson,Nunito,38,&H00594B17,&H007B8B91,&H00FFFDF6,&HD8FFFDF6,-1,0,0,0,100,100,0,0,3,2,0,2,165,165,48,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""

events: list[str] = []
caption_data: list[dict] = []
for group in groups:
    start = float(group[0]["start"])
    end = float(group[-1]["end"]) + 0.16
    pieces: list[str] = []
    for index, word in enumerate(group):
        next_start = float(group[index + 1]["start"]) if index + 1 < len(group) else float(word["end"])
        duration_cs = max(1, round((next_start - float(word["start"])) * 100))
        pieces.append(f"{{\\kf{duration_cs}}}{clean(word['word'])}")
    text = " ".join(pieces)
    events.append(f"Dialogue: 0,{ass_time(start)},{ass_time(end)},Lesson,,0,0,0,,{text}")
    caption_data.append({
        "start": start,
        "end": end,
        "words": [
            {"text": clean(word["word"]), "start": float(word["start"]), "end": float(word["end"])}
            for word in group
        ],
    })

OUTPUT.write_text(header + "\n".join(events) + "\n", encoding="utf-8-sig")
JS_OUTPUT.write_text("window.V3_CAPTIONS=" + json.dumps(caption_data, ensure_ascii=False) + ";\n", encoding="utf-8")
print(f"Wrote {len(events)} subtitle phrases from {len(words)} timed words to {OUTPUT}")
