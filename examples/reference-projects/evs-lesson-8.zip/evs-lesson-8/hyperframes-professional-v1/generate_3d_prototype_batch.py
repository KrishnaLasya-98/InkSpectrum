"""Generate only the missing paid clips for the EVS Lesson 8 3D prototype.

The command is dry-run by default. A live run requires both ``--execute`` and
an explicit approved dollar ceiling so an agent cannot accidentally launch a
paid batch. The existing fish style test is reused and is not regenerated.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

from dotenv import load_dotenv


WORKSPACE = Path(__file__).resolve().parent
PROJECT = WORKSPACE.parents[2]
PLAN = WORKSPACE / "prototype_3d_media_plan.json"
OUTPUT_DIR = WORKSPACE / "assets" / "video" / "generated" / "prototype-3d"

sys.path.insert(0, str(PROJECT))
load_dotenv(PROJECT / ".env")

from tools.video.modelslab_video import ModelsLabVideo  # noqa: E402


NEGATIVE_PROMPT = (
    "flat 2D illustration, photoreal wildlife documentary, live action, static image, "
    "still frame, slideshow, loop, replay, repeated action, frozen ending, morphing, "
    "flicker, jump cut, camera shake, fast zoom, extra limbs, missing limbs, fused legs, "
    "distorted face, duplicate animal, unsafe contact, distress, aggression, predation, "
    "blood, carcass, cage, text, letters, numbers, caption, logo, watermark, HUD"
)


def probe_ok(path: Path) -> bool:
    if not path.exists():
        return False
    result = subprocess.run(
        [
            "ffprobe", "-v", "error", "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1", str(path),
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    try:
        return result.returncode == 0 and float(result.stdout.strip()) >= 4.0
    except ValueError:
        return False


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute", action="store_true", help="Run paid generation")
    parser.add_argument(
        "--approved-cost-usd",
        type=float,
        default=0.0,
        help="User-approved maximum cost for this invocation",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    plan = json.loads(PLAN.read_text(encoding="utf-8"))
    batch = plan["generation_batch"]
    pending = [
        clip for clip in plan["generated_clips"]
        if clip["generation_status"] == "pending_paid_generation"
    ]
    tool = ModelsLabVideo()
    inputs = []
    for clip in pending:
        output = OUTPUT_DIR / f"{clip['id']}.mp4"
        inputs.append(
            {
                "clip": clip,
                "output": output,
                "request": {
                    "prompt": f"{plan['shared_style_prompt']} {clip['required_action']}",
                    "negative_prompt": NEGATIVE_PROMPT,
                    "model_id": batch["model"],
                    "operation": "text_to_video",
                    "duration": str(batch["duration_seconds_each"]),
                    "resolution": batch["resolution"],
                    "generate_audio": batch["generate_audio"],
                    "seed": clip["seed"],
                    "output_path": str(output),
                },
            }
        )

    missing = [item for item in inputs if not probe_ok(item["output"])]
    estimate = round(sum(tool.estimate_cost(item["request"]) for item in missing), 2)
    print(f"provider={batch['provider']}")
    print(f"tool={batch['tool']}")
    print(f"model={batch['model']}")
    print("scope=3D prototype sample, not full chapter")
    print(f"pending_clips={len(missing)}")
    print(f"estimated_cost_usd={estimate:.2f}")
    for item in missing:
        print(f"  {item['clip']['id']} -> {item['output']}")

    if not args.execute:
        print("dry_run=true (use --execute with --approved-cost-usd after approval)")
        return 0
    if estimate > args.approved_cost_usd + 1e-9:
        raise SystemExit(
            f"Refusing paid generation: estimate ${estimate:.2f} exceeds "
            f"approved ceiling ${args.approved_cost_usd:.2f}"
        )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    failures = []
    for item in missing:
        clip_id = item["clip"]["id"]
        print(f"generating={clip_id}", flush=True)
        result = tool.execute(item["request"])
        if not result.success or not probe_ok(item["output"]):
            failures.append({"id": clip_id, "error": result.error})
            print(f"failed={clip_id}: {result.error}", flush=True)
            continue
        print(f"completed={clip_id} cost_usd={result.cost_usd:.2f}", flush=True)

    if failures:
        print(json.dumps({"failures": failures}, indent=2))
        return 1
    print("batch_complete=true")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
