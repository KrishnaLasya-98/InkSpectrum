import { readFileSync } from "node:fs";

for (const file of process.argv.slice(2)) {
  const value = JSON.parse(readFileSync(file, "utf8"));
  const count = value.assets?.length ?? value.generated_clips?.length ?? value.shots?.length ?? 0;
  console.log(`${file}: valid JSON (${count} primary records)`);
}
