import { readFileSync } from "node:fs";
import vm from "node:vm";

const sandbox = { window: {} };
vm.runInNewContext(readFileSync(process.argv[2], "utf8"), sandbox);
const showCaptions = process.argv.includes("--captions");
for (const section of sandbox.window.LESSON8.sections) {
  console.log(`${section.id}\t${section.title}`);
  console.log(`  SOURCE: ${section.source_lines.join(" | ")}`);
  for (const beat of section.beats || []) {
    console.log(`  ${beat.asset_id}: ${beat.observed_purpose} -> ${beat.source_lines.join(" ")}`);
  }
  if (showCaptions) {
    for (const phrase of section.caption_phrases || []) {
      console.log(`  CAPTION ${phrase.start_ms}-${phrase.end_ms}: ${phrase.words.join(" ")}`);
    }
  }
}
