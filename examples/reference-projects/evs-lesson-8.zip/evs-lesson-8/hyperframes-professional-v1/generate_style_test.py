"""Generate one animation-first visual style test for EVS Lesson 8.

The output is deliberately narration-free. HyperFrames owns narration,
subtitles, labels, and the final audio mix.
"""
from __future__ import annotations

import sys
from pathlib import Path

from dotenv import load_dotenv


PROJECT = Path(__file__).resolve().parents[3]
WORKSPACE = Path(__file__).resolve().parent
OUTPUT = WORKSPACE / "assets" / "video" / "generated" / "style-test-fish-3d.mp4"

sys.path.insert(0, str(PROJECT))
load_dotenv(PROJECT / ".env")

from tools.video.modelslab_video import ModelsLabVideo  # noqa: E402


PROMPT = (
    "One friendly stylized 3D fish swims smoothly from left to right through "
    "clear blue freshwater, soft rounded storybook forms, warm educational "
    "children's animation, correct fish anatomy with exactly two eyes and "
    "natural fins, gentle tail movement, simple aquatic plants moving slowly, "
    "one continuous shot, fixed wide camera, full fish always visible, calm "
    "pace for a Class 1 science lesson, clean uncluttered composition, no text, "
    "no letters, no logo, no watermark, no audio"
)

NEGATIVE_PROMPT = (
    "static image, still frame, slideshow, photorealistic, frightening, attack, "
    "predation, dead fish, distorted body, extra eyes, extra fins, missing fins, "
    "split body, duplicate fish, morphing, flicker, jump cut, loop, replay, "
    "camera shake, zoom, pan, fast motion, murky water, text, caption, logo, watermark"
)


def main() -> int:
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    tool = ModelsLabVideo()
    inputs = {
        "prompt": f"{PROMPT}. Avoid: {NEGATIVE_PROMPT}",
        "operation": "text_to_video",
        "model_id": "h3-minimax-t2v",
        "duration": "5",
        "resolution": "768P",
        "generate_audio": False,
        "output_path": str(OUTPUT),
    }
    print(f"estimated_cost_usd={tool.estimate_cost(inputs):.2f}")
    result = tool.execute(inputs)
    print(f"success={result.success}")
    print(f"cost_usd={result.cost_usd:.2f}")
    print(f"duration_seconds={result.duration_seconds:.2f}")
    if not result.success:
        print(f"error={result.error}")
        return 1
    print(f"output={OUTPUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
