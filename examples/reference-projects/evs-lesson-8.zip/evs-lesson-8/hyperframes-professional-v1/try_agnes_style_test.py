"""Generate one Agnes comparison clip for the approved EVS 3D style test."""
from __future__ import annotations

import sys
from pathlib import Path

from dotenv import load_dotenv


WORKSPACE = Path(__file__).resolve().parent
PROJECT = WORKSPACE.parents[2]
OUTPUT = WORKSPACE / "assets" / "video" / "generated" / "style-test-fish-3d-agnes.mp4"

sys.path.insert(0, str(PROJECT))
load_dotenv(PROJECT / ".env")

from tools.video.agnes_video import AgnesVideo  # noqa: E402


PROMPT = (
    "One continuous shot, no cuts, no zoom. Premium child-friendly cinematic 3D "
    "educational animation. One friendly orange fish with rounded fins and large "
    "expressive eyes swims smoothly from left to right through clear blue freshwater. "
    "Full body stays visible, accurate fish anatomy, natural fin and tail movement, "
    "soft detailed materials, warm sun rays, simple aquatic plants, uncluttered scene, "
    "generous empty lower area for subtitles, polished feature-animation quality."
)
NEGATIVE = (
    "flat 2D, photoreal documentary, static image, loop, replay, frozen ending, "
    "duplicate fish, extra eyes, extra fins, missing fins, split body, morphing, "
    "flicker, jump cut, camera shake, fast movement, murky water, text, caption, "
    "letters, numbers, logo, watermark, HUD, border"
)


def main() -> int:
    tool = AgnesVideo()
    request = {
        "prompt": PROMPT,
        "negative_prompt": NEGATIVE,
        "operation": "text_to_video",
        "model_id": "agnes-video-2.5-flash",
        "duration": "5",
        "resolution": "720P",
        "aspect_ratio": "16:9",
        "seed": 8103,
        "output_path": str(OUTPUT),
    }
    print(f"provider_status={tool.get_status().value}")
    print(f"estimated_cost_usd={tool.estimate_cost(request):.2f}")
    result = tool.execute(request)
    print(f"success={result.success}")
    print(f"cost_usd={result.cost_usd:.2f}")
    if not result.success:
        print(f"error={result.error}")
        return 1
    print(f"output={OUTPUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
