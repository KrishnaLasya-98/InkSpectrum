# EVS Lesson 8 scene-video audit

Audit date: 2026-09-17  
Scope: every MP4 below `assets/video/scenes` (39 files)  
Review method: technical probe and full decode, start/middle/end contact frames for every file, topic comparison against the lesson timeline, black-frame scan, and freeze scan (1-second threshold).

## Executive result

- All 39 files decode successfully.
- All 39 use the same delivery format: H.264 High, 1344×768, 24 fps, yuv420p, 10.125 seconds, with AAC stereo audio at 32 kHz.
- No black segments were detected.
- `s04-1` contains two long freezes (about 1.25 seconds each, including the ending); `s05-1` contains one freeze of about 1.21 seconds.
- The collection is not a consistent 3D-animation set. It mixes painterly AI animation, flat 2D illustration, photoreal wildlife, game footage, and live-action drawing.
- Content verdict: 9 strong concept clips, 23 conditional/reference clips, and 7 rejects.
- Strict 3D verdict: 0 of 39 can establish a coherent professional 3D visual language without restyling or replacement.

`STRONG` means the concept and motion are useful, although a final 3D-only production still needs a consistent restyle. `CONDITIONAL` means the clip is factually useful but conflicts with the requested 3D style, has weak motion, or only fits one narrow narration beat. `REJECT` means it should not appear in the final lesson.

## File-by-file findings

| File | Observed content | Motion/style | Topic fit | Verdict | Required action |
|---|---|---|---|---|---|
| s01-0 | Orange fish swimming through lily-pad water | Painterly 2.5D; clear travel | Good animal-life opening/water animal | STRONG | Retain as concept reference; replace/restyle to the chosen 3D look |
| s01-1 | Green-yellow bird on a branch | Flat cartoon; very limited movement | Animal example, but not a clear pet-care prompt | CONDITIONAL | Replace with a child-friendly 3D pet-care action |
| s01-2 | White rabbit in a meadow | Painterly; subtle movement | Good general animal/pet example | STRONG | Retain as concept reference; generate stronger 3D action |
| s02-0 | Calf/cow drinking from a trough | Stylized; clear drinking action | Excellent for animals needing water | STRONG | Keep concept and timing; 3D-restyle |
| s02-1 | Sheep under a farm shelter | Photoreal; subtle movement | Good for shelter/animal needs | CONDITIONAL | Replace with matching 3D sheep/shelter footage |
| s02-2 | Goat moving from standing to resting beneath a tree | Stylized; clear state change | Good for animal variety and shelter/rest | STRONG | Keep concept; 3D-restyle |
| s03-0 | Fish moving through a decorative stream | Illustrated 2D/2.5D; continuous motion | Correct for aquatic animals | CONDITIONAL | Replace with coherent 3D underwater footage |
| s03-1 | Lion, elephant, and tiger grouped in a savanna | Illustrated; nearly static | Does not demonstrate land versus water; unnatural grouping | REJECT | Replace with a purposeful 3D land/water comparison |
| s03-2 | Tiger walking across grass | Photoreal; strong movement | Only covers tiger, not lion/elephant/tiger together | CONDITIONAL | Use only as reference; create separate 3D animal shots |
| s04-0 | Duck swimming on a pond | Painterly/photoreal composite; clear travel | Strong bird example | STRONG | Keep concept; restyle consistently |
| s04-1 | Pigeon flapping, then perching | Flat 2D; two ≈1.25 s freezes | Correct pigeon example but technically sluggish | CONDITIONAL | Replace; do not solve by extending/freeze-holding |
| s04-2 | Parrot perched on a branch | Photoreal; subtle head movement | Correct named bird | CONDITIONAL | Replace with expressive 3D parrot action |
| s05-0 | Butterfly flying above flowers | Painterly 2.5D; visible travel | Strong insect/wings example | STRONG | Keep concept; 3D-restyle |
| s05-1 | Housefly and grasshopper on a leaf | Flat 2D; ≈1.21 s freeze | Correct insects, but weak staging/motion | CONDITIONAL | Replace with 3D macro-style insect animation |
| s05-2 | Grasshopper close-up | Photoreal macro; minimal motion | Correct named insect | CONDITIONAL | Replace or reserve as a brief real-world insert |
| s06-0 | Black dog outdoors, standing then lying down | Photoreal; clear behavior | Domestic animal example | CONDITIONAL | Replace with a friendly 3D home setting |
| s06-1 | Two parrots perched together | Photoreal; active interaction | Suitable pet-animal example | CONDITIONAL | Replace/restyle; current manifest mislabels it as rabbit |
| s06-2 | Rabbit grazing in a field | Photoreal; clear feeding | Rabbit example, but does not show human care | CONDITIONAL | Replace with a 3D child caring for a rabbit |
| s07-0 | Tiger walking | Photoreal; strong travel | Correct wild-animal example | CONDITIONAL | Reserve only if hybrid real footage is later approved |
| s07-1 | Lion portrait in grassland | Photoreal; subtle head movement | Correct wild-animal example | CONDITIONAL | Replace with coherent 3D forest behavior |
| s07-2 | Two deer in woodland | Photoreal; moderate movement | Correct wild-animal example; not flesh-eating | CONDITIONAL | Do not use for carnivore narration; use only for general wild animals |
| s08-0 | Fox-like game character entering a cave; visible HUD/map and garbled text | Game capture; intrusive UI | Invalid for animal homes | REJECT | Remove completely; regenerate a clean 3D habitat scene |
| s08-1 | Bird landing/standing on a nest | Photoreal; clear landing | Good bird-home example | CONDITIONAL | Replace with matching 3D nest-building scene |
| s08-2 | Ants moving over an anthill | Macro/AI-realistic; good group motion | Strong animal-home/anthill example | STRONG | Keep concept; 3D-restyle if strict consistency is required |
| s09-0 | Lion walking into a rock cave | Photoreal; strong action | Excellent den concept | CONDITIONAL | Recreate as non-threatening 3D animation |
| s09-1 | Rabbit eating leafy vegetables | Photoreal; clear feeding | Correct rabbit food, not rabbit burrow | CONDITIONAL | Remap only to rabbit-food narration; never use for burrow |
| s09-2 | Lion eating a carcass | Photoreal; graphic prey remains | Factually carnivorous but inappropriate for Class 1 | REJECT | Replace with a gentle, non-graphic 3D food explanation |
| s10-0 | Bird at a nest | Photoreal; moderate action | Correct for birds building nests | CONDITIONAL | Replace with a clearer 3D nest-building action |
| s10-1 | Bird picking/eating a berry | Photoreal; clear feeding | Correct bird-food example, not ants | CONDITIONAL | Correct manifest mapping; restyle/replace |
| s10-2 | Ants moving around a mound/stone | Photoreal macro; clear group motion | Correct ant-group/anthill context, not dog kennel | CONDITIONAL | Correct manifest mapping; restyle/replace |
| s11-0 | Dog walking into a stark chain-link enclosure | Photoreal; clear movement | Visually harsh; not a cow shed | REJECT | Replace with a warm, safe 3D kennel |
| s11-1 | Cow entering a wooden shed | Photoreal; strong purposeful movement | Excellent cow/shed concept | STRONG | Keep concept; 3D-restyle |
| s11-2 | White horse outside stable stalls | Photoreal; subtle movement | Correct horse/stable concept | CONDITIONAL | Replace with clearer 3D stable entry/action |
| s12-0 | Abstract glowing blue paths/icons over a forest | Abstract effects; active camera | Does not communicate the chapter recap | REJECT | Use a structured animated 3D recap montage instead |
| s13-0 | Animal trading cards with unreadable/gibberish labels | Live tabletop/AI text artifacts | Unrelated to clear glossary teaching | REJECT | Use clean glossary UI with short 3D animal actions |
| s14-0 | Dog behind a wire enclosure | Photoreal; mostly static | Unrelated to the assessment; negative tone | REJECT | Use assessment UI; no decorative background clip needed |
| s15-0 | Fish swimming in an aquarium | Photoreal; clear travel | Fits only “Fish live in water,” not all five MCQs | CONDITIONAL | Use only for that question or replace with question-specific 3D clips |
| s16-0 | Hand drawing a cartoon dog | Live-action instructional motion | Exact fit for “Draw any animal” activity | STRONG | Can remain as a purposeful non-3D exception, or recreate as 3D pencil/desk animation |
| s16-1 | Rabbits nuzzling/interacting | Photoreal; gentle movement | Good emotional tone for animal care/Life Skills | CONDITIONAL | Recreate as warm 3D friendship/care ending |

## Incorrect existing asset labels/mappings

The current timeline/asset report has an off-by-one-style mapping problem in several sections. The observed clip content disagrees with stored labels:

- `s05-0` is a butterfly, not a grasshopper.
- `s06-0` is a dog, not parrots.
- `s06-1` is parrots, not a rabbit.
- `s07-0` is a tiger, not a lion.
- `s07-1` is a lion, not deer.
- `s08-0` is game footage of a cave/fox-like character with a HUD, not a clean bird-nest scene.
- `s08-1` is a bird and nest, not an anthill.
- `s09-1` is a rabbit eating vegetables, not a bird building a nest.
- `s10-1` is a bird eating a berry, not ants.
- `s10-2` is ants at a mound, not a dog enclosure.
- `s11-0` is a dog enclosure, not a cow shed.
- `s11-1` is a cow and shed, not a horse stable.

These mappings must be corrected before composition; otherwise narration and visuals will be shifted to the wrong subjects even when the source videos themselves are usable.

## Production recommendation

Do not assemble the final lesson directly from this folder. Use the clips as a motion-and-staging reference library, then build a replacement manifest around one visual specification: child-safe cinematic 3D animation, warm colors, soft materials, expressive but anatomically stable animals, clean backgrounds, no generated text inside video, no embedded UI, and one unambiguous action per narration beat.

The next asset pass should first replace the seven rejected clips and the incorrect mappings. Then replace/restyle the 23 conditional clips section by section. HyperFrames should provide titles, subtitles, assessment UI, and transitions; generated MP4s should provide the moving visual content.
