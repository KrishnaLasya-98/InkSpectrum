# Cinematic 3D Nature Classroom — EVS Class 1

## Audience and teaching rule

The viewer is 5–7 years old. Each shot teaches one concrete idea, remains on
screen long enough to understand, and visibly matches the spoken sentence.
Motion is calm, legible, and purposeful.

## Visual system

- Runtime: HyperFrames HTML/CSS/GSAP.
- Canvas: 1920×1080, 30 fps, 16:9.
- Background: warm ivory `#F7F3E8`.
- Primary ink: deep navy `#17324D`.
- Nature accent: teal `#167C72`.
- Learning accent: amber `#F3B33D`.
- Feedback accent: coral `#E96B5B`.
- Headings: Nunito Sans ExtraBold, locally bundled.
- Body/captions: Atkinson Hyperlegible, locally bundled.
- Child-friendly cinematic 3D video fills 75–100% of concept scenes; UI supports rather than obscures it.
- Cards use 20–28 px corner radii and restrained shadows.
- Maintain at least 80 px edge-safe spacing and a fixed subtitle safe zone.

## Motion

- Scene transitions: 350–600 ms.
- Use clean masks, directional wipes, and gentle scale changes.
- No constant bouncing, spinning, rapid zooming, or decorative motion.
- Keep recognizable animal action visible for at least 2.5 seconds.
- Freeze or hold only when intentional and never on an awkward animal pose.

## Captions

- Maximum two lines and approximately 7 words per displayed phrase.
- Word-synchronized emphasis without moving the caption container.
- Minimum 34 px at 1080p with strong contrast and a local scrim.
- Captions never cover an animal's face or the teaching focus.

## Media policy

- Purpose-built child-friendly cinematic 3D animation is the single primary
  visual language. Every asset must be delivered as moving MP4 or WebM footage;
  still images are not accepted as timeline media.
- Use the same soft-material, rounded-character, warm-lighting style for
  definitions, behavior, habitats, comparisons, vocabulary, and recap scenes.
- Existing 2D, painterly, photoreal, game-capture, and live-action clips are
  reference material only unless an explicit exception is approved. Never mix
  those styles inside one concept sequence.
- Authentic licensed video is a last-resort exception for a behavior that cannot
  be generated accurately. It requires explicit approval before composition.
- AI-generated animation must preserve correct anatomy, number of legs, habitat,
  scale, and direction of motion. It is an illustration, not documentary evidence.
- Reject watermarks, anatomy errors, distressed animals, predation, cages used
  as spectacle, fast attacks, unsafe child–animal contact, and misleading homes.
- Generated footage must not contain writing, labels, logos, watermarks, HUDs,
  choice buttons, or subtitles. HyperFrames owns all readable text and UI.
- No still images, frozen-photo screens, or slideshow treatment. Diagrams and
  labels must be animated natively in HyperFrames or embedded in a moving clip.

## Scene grammar

1. Welcome: short animal motion montage with a restrained title lockup.
2. Observe: one full-bleed behavior clip plus one short teaching label.
3. Compare: two synchronized video windows with a single contrast statement.
4. Explain: animated diagram over or beside authentic footage.
5. Check: large question, three clear choices, audio-timed reveal.
6. Recall: moving thumbnail grid and spoken recap, not a paragraph card.
