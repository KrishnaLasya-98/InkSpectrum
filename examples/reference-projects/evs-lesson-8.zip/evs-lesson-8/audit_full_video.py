"""Audit the obsolete render against the current source-derived schedule."""
from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path
from typing import Any

PROJECT = Path(__file__).resolve().parent
OLD_RENDER = PROJECT / "full-hyperframes" / "renders" / "lesson-8-animal-life-final-v3.mp4"
BASELINE = PROJECT / "one-minute-preview" / "hyperframes" / "renders" / "evs-one-minute-clean-final.mp4"
TIMELINE = PROJECT / "full-hyperframes" / "timeline-data.js"
REPORT = PROJECT / "full-hyperframes" / "artifacts" / "full_video_frame_audio_audit.json"
FRAME_DIR = PROJECT / "full-hyperframes" / "artifacts" / "old-v3-frame-audit"


def probe(path: Path) -> dict[str, Any]:
    result = subprocess.run(["ffprobe", "-v", "error", "-show_format", "-show_streams", "-of", "json", str(path)], capture_output=True, text=True, check=True)
    return json.loads(result.stdout)


def timeline() -> dict[str, Any]:
    text = TIMELINE.read_text(encoding="utf-8").split("=", 1)[1].strip().rstrip(";")
    return json.loads(text)


def silence_intervals(path: Path) -> list[dict[str, float]]:
    result = subprocess.run(["ffmpeg", "-hide_banner", "-i", str(path), "-af", "silencedetect=noise=-42dB:d=0.25", "-f", "null", "NUL"], capture_output=True, text=True, check=False)
    starts: list[float] = []
    intervals: list[dict[str, float]] = []
    for line in result.stderr.splitlines():
        start = re.search(r"silence_start:\s*([0-9.]+)", line)
        end = re.search(r"silence_end:\s*([0-9.]+).*silence_duration:\s*([0-9.]+)", line)
        if start:
            starts.append(float(start.group(1)))
        if end and starts:
            intervals.append({"start": starts.pop(0), "end": float(end.group(1)), "duration": float(end.group(2))})
    return intervals


def extract_frames(duration: float, timestamps: list[float]) -> list[str]:
    FRAME_DIR.mkdir(parents=True, exist_ok=True)
    for second in range(int(duration) + 1):
        target = FRAME_DIR / f"second-{second:04d}.jpg"
        if not target.exists():
            subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-ss", str(second), "-i", str(OLD_RENDER), "-frames:v", "1", "-q:v", "4", str(target)], check=True)
    special: list[str] = []
    for timestamp in sorted(set(round(value, 3) for value in timestamps if value >= 0)):
        target = FRAME_DIR / f"checkpoint-{timestamp:09.3f}.jpg"
        if not target.exists():
            subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-ss", str(timestamp), "-i", str(OLD_RENDER), "-frames:v", "1", "-q:v", "4", str(target)], check=True)
        special.append(str(target.relative_to(PROJECT)))
    return special


def main() -> None:
    old_probe = probe(OLD_RENDER)
    baseline_probe = probe(BASELINE)
    data = timeline()
    old_duration = float(old_probe["format"]["duration"])
    checkpoints: list[float] = []
    entries: list[dict[str, Any]] = []
    for section in data["sections"]:
        checkpoints.extend([section["start"], section["title_start"], section["title_end"], section["audio_start"], section["audio_end"], section["end"]])
        entries.extend([
            {"kind": "section", "id": section["id"], "expected_start": section["start"], "expected_end": section["end"], "expected_state": f"{section['title']} title card then narration/content", "observed_frame_state": "checkpoint extracted from old-v3; obsolete timing", "audio_active_or_silent": "narration with source-derived gaps", "mismatch_category": "obsolete schedule timing"},
            {"kind": "title", "id": section["id"], "expected_start": section["title_start"], "expected_end": section["title_end"], "expected_state": "centered graphics-only title and subtitle", "observed_frame_state": "checkpoint extracted from old-v3", "audio_active_or_silent": "silent title window", "mismatch_category": "old title/content timing is not dynamic"},
        ])
        for phrase in section["caption_phrases"]:
            start, end = phrase["start_ms"] / 1000, phrase["end_ms"] / 1000
            checkpoints.extend([start, end])
            entries.append({"kind": "caption", "id": phrase["id"], "expected_start": start, "expected_end": end, "expected_state": "progressive words, active word highlighted, phrase cleared after end", "observed_frame_state": "checkpoint extracted from old-v3", "audio_active_or_silent": "audio active through phrase; gaps clear", "mismatch_category": "caption schedule requires dynamic render"})
        for beat in section["beats"]:
            checkpoints.extend([beat["start"], beat["end"]])
            entries.append({"kind": "content_card", "id": beat["id"], "expected_start": beat["start"], "expected_end": beat["end"], "expected_state": "matched motion or graphics fallback with source card", "observed_frame_state": "checkpoint extracted from old-v3", "audio_active_or_silent": "narration beat active", "mismatch_category": "asset/card timing requires dynamic render"})
    for item in data["exercises"]:
        checkpoints.extend([item["prompt_start"], item["prediction_start"], item["reveal_start"], item["handoff_end"]])
        entries.append({"kind": "exercise", "id": item["id"], "expected_start": item["prompt_start"], "expected_end": item["handoff_end"], "expected_state": "one question, separate option rows, subtitle band below, 5-second guess, 4-second reveal, hard clear", "observed_frame_state": "attached MCQ diagnosis: inline options collide/wrap, tiny text, stale subtitle; checkpoint extracted", "audio_active_or_silent": "prompt active, prediction silent 5s, reveal/hold 4s", "mismatch_category": "MCQ layout and stale-card timing defect"})
    checkpoints.extend([float(value) for value in range(0, int(old_duration) + 1, 5)])
    special_frames = extract_frames(old_duration, checkpoints)
    report = {
        "old_render_path": str(OLD_RENDER),
        "old_render_probe": old_probe,
        "old_duration_seconds": old_duration,
        "approved_baseline_path": str(BASELINE),
        "approved_baseline_probe": baseline_probe,
        "dynamic_schedule_path": str(TIMELINE),
        "dynamic_duration_seconds": data["duration"],
        "old_vs_dynamic_schedule": {"old_duration_seconds": old_duration, "dynamic_duration_seconds": data["duration"], "duration_delta_seconds": round(old_duration - data["duration"], 3), "old_is_obsolete": True},
        "sampled_timestamps": {"every_1_second": {"start": 0, "end": old_duration, "step": 1}, "every_5_seconds": {"start": 0, "end": old_duration, "step": 5}, "dynamic_checkpoints_seconds": sorted(set(checkpoints)), "special_frame_paths": special_frames, "frame_directory": str(FRAME_DIR)},
        "audio_silence_intervals_old": silence_intervals(OLD_RENDER),
        "expected_observed_entries": entries,
        "subtitle_placement_timing_requirements": {"placement": "separate centered subtitle band below exercise/content card", "progressive": "future words hidden, current word highlighted", "gap_policy": "hide phrase during ASR gaps and punctuation pauses", "source_card_policy": "source card clears independently and never hides subtitle root"},
        "asset_match_mismatch_results": data["coverage_audit"]["asset_report"],
        "attached_mcq_frame_diagnosis": {"header": "III. Choose the correct answer. must remain source-derived", "defects": ["question stem and options are one inline text run", "options wrap/collide and are not separated into rows", "MCQ typography is too small/crowded", "bottom subtitle is stale from a previous question", "question, prediction, answer, and subtitle layers are not distinct"], "required_correction": "one readable stem, three separate option rows, subtitle below, 5-second guess pause, 4-second reveal, hard clear"},
        "frame_extraction_status": {"one_second_frames": True, "special_checkpoints_extracted": True, "semantic_limit": "automated report records extracted checkpoints; attached frame provides the explicit MCQ visual diagnosis"},
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"report": str(REPORT), "old_duration": old_duration, "dynamic_duration": data["duration"], "silence_intervals": len(report["audio_silence_intervals_old"]), "special_frames": len(special_frames)}, indent=2))


if __name__ == "__main__":
    main()
