import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {subtitleWords, endsSentence, spokenAnchor} from './subtitle-text.mjs';

const here = path.dirname(new URL(import.meta.url).pathname.replace(/^\/(.:)/, '$1'));
const project = path.resolve(here, '..');
const read = (name) => JSON.parse(fs.readFileSync(path.join(project, 'artifacts', name), 'utf8'));
const arg=(name)=>{const i=process.argv.indexOf(name);return i<0?undefined:process.argv[i+1];};
const sourceConfigPath=path.join(here,'production-source.json');
const savedSource=fs.existsSync(sourceConfigPath)?JSON.parse(fs.readFileSync(sourceConfigPath,'utf8')):{};
const sourceConfig=arg('--candidate')?{candidate:arg('--candidate'),plan:arg('--plan')}:savedSource;
if(sourceConfig.candidate&&!sourceConfig.plan)throw new Error('Candidate needs an explicit source plan');
const candidate=sourceConfig.candidate?path.resolve(project,sourceConfig.candidate):null;
const readCandidate=(name)=>JSON.parse(fs.readFileSync(path.join(candidate,name),'utf8'));
const script = candidate?JSON.parse(fs.readFileSync(path.resolve(project,sourceConfig.plan),'utf8')):read('narration_script.json');
const manifest = candidate?readCandidate('narration_manifest.json'):read('narration_manifest.json');
const alignment = candidate?readCandidate('word_alignment.json'):read('word_alignment.json');
const resolvedCoverage=candidate?readCandidate('composition-coverage.json'):null;
const candidateQA=candidate?readCandidate('alignment_qa.json'):null;
if(candidate&&readCandidate('sync-plan.json').render_blockers.length)throw new Error('Candidate has unresolved sync blockers');
const teachingCues = JSON.parse(fs.readFileSync(path.join(here, 'teaching-cues.json'), 'utf8'));
const normalize = (value) => String(value).toLowerCase().replace(/[^a-z0-9]/g, '');
function phraseStart(words, phrase, occurrence = 0) {
  const tokens = phrase.match(/[A-Za-z0-9]+(?:'[A-Za-z0-9]+)?/g).map(normalize);
  const hits = words.flatMap((_, index) => tokens.every((token, offset) => normalize(words[index + offset]?.text ?? '') === token) ? [index] : []);
  if (hits[occurrence] === undefined) throw new Error(`Spoken cue not found: ${phrase} (${occurrence})`);
  return words[hits[occurrence]].startMs;
}

const wavDurationSeconds = (filePath) => {
  const buffer = fs.readFileSync(filePath);
  if (buffer.toString('ascii', 0, 4) !== 'RIFF' || buffer.toString('ascii', 8, 12) !== 'WAVE') {
    throw new Error(`Unsupported WAV file: ${filePath}`);
  }
  let offset = 12;
  let byteRate = 0;
  let dataSize = 0;
  while (offset + 8 <= buffer.length) {
    const id = buffer.toString('ascii', offset, offset + 4);
    const size = buffer.readUInt32LE(offset + 4);
    const dataOffset = offset + 8;
    if (id === 'fmt ') byteRate = buffer.readUInt32LE(dataOffset + 8);
    if (id === 'data') { dataSize = size; break; }
    offset = dataOffset + size + (size % 2);
  }
  if (!byteRate || !dataSize) throw new Error(`Could not read WAV duration: ${filePath}`);
  return dataSize / byteRate;
};

const clipFiles = {
  S01: ['s01-beach-arrival-v1.mp4', 's01b-beach-welcome-v1.mp4'],
  S02: ['s02a-beach-objects-v1.mp4', 's02c-cloud-palm-sea-v1.mp4', 's02d-ball-ring-v1.mp4', 's02e-sandcastle-starfish-v1.mp4', 's02b-point-and-name-v1.mp4'],
  S03: ['s03a-family-lovely-day-v1.mp4', 's03c-family-together-v1.mp4', 's03d-family-settles-v1.mp4', 's03b-children-notice-sand-v1.mp4'],
  S04: ['s04-build-start-v1.mp4', 's04b-dig-and-fill-v1.mp4', 's04c-first-tower-v1.mp4'],
  S05: ['s05a-castle-growing-v1.mp4', 's05b-grandparents-room-v1.mp4', 's05c-big-castle-v1.mp4'],
  S06: ['s06a-family-room-v1.mp4', 's06b-playroom-v1.mp4'],
  S07: ['s07a-staircase-v1.mp4', 's07b-basement-hide-and-seek-v1.mp4'],
  S08: ['s08a-parents-call-v1.mp4', 's08-leave-beach-v1.mp4']
};

const teachingItems = {
  S09: [
    ['Shovel', 'a tool for digging earth.'],
    ['Basement', 'rooms or wide space below the ground floor of a building.'],
    ['Staircase', 'a set of stairs in a building.']
  ],
  S10: [
    ['1', 'Varun and Vidya go to a picnic with their family.  ✗'],
    ['2', 'They build a sandcastle on the beach.  ✓'],
    ['3', 'They decorate the sandcastle with a shell.  ✓'],
    ['4', 'Vidya has a shovel and a bucket.  ✓']
  ],
  S11: [
    ['1', 'They build a castle with clay.  False'],
    ['2', 'They went to the beach with their parents.  True'],
    ['3', 'Grandpa and Grandma tells us stories.  True']
  ],
  S12: [
    ['1', 'What do Varun and Vidya do on the beach?  They build a sandcastle.'],
    ['2', 'What do they use to build the sandcastle?  A shovel and a bucket.'],
    ['3', 'Where does the staircase go?  It goes to the basement.']
  ],
  S13: [['Discuss', 'Why do we feel happy when we see a beach?'], ['Your turn', 'Share your own answer.']],
  S14: [['Adithya', 'Hello! I am Adithya. I live in Mumbai.'], ['Smitha', 'Hello, Adithya. I am Smitha. I live in Delhi. I am in Grade I.']],
  S15: [['1', 'Hello, my name is __________.'], ['2', 'I am __________ years old. I live in __________.'], ['3', 'My birthday is on __________.']],
  S16: [['Vowels', 'A   E   I   O   U'], ['Consonants', 'The other twenty-one letters are consonants.']],
  S17: [['Vowels - red', 'U   O   A   I   E'], ['Consonants - blue', 'Z   T   X   B   J   W']],
  S18: [['Friend name', 'Write the name of your friend.'], ['Consonants', 'Circle the consonants.']],
  S19: [['sandcastle', 'sand + castle'], ['staircase', 'stair + case'], ['Joined words', 'Two smaller words join to make one new word.']],
  S20: [['sunflower', 'sun + flower'], ['strawberry', 'straw + berry'], ['sunglasses', 'sun + glasses'], ['rainbow', 'rain + bow']],
  S21: [['baseball', 'base + ball'], ['airplane', 'air + plane'], ['chalkboard', 'chalk + board'], ['snowman', 'snow + man'], ['hairbrush', 'hair + brush'], ['butterfly', 'butter + fly']],
  S22: [['Short a', 'mat · van · rat · dad'], ['Short a', 'nap · at · have · sandcastle']],
  S23: [['All About Me', 'My name · age · birthday'], ['My favourites', 'food · color · pet · movie · sports · subject'], ['My future', 'A fun fact and what I want to be.']],
  S24: [['Listening Ability', 'Listen to your teacher and write the new words in your note book.']],
  S25: [['Family story time', 'Bring a favourite family story or memory to share with the class.']],
  S26: [
    ['I can', 'read and enjoy a text on At the Beach.'],
    ['I can', 'differentiate between vowels and consonants.'],
    ['I can', 'identify the joined words.'],
    ['I can', 'listen carefully and understand the words.'],
    ['I can', 'introduce myself.']
  ]
};

const scriptById = Object.fromEntries(script.sections.map((section) => [section.id, section]));
const alignmentById = Object.fromEntries(alignment.sections.map((section) => [section.section_id, section]));
const sections = [];
let cursor = 0;

for (let index = 0; index < manifest.segments.length; index += 1) {
  const audio = manifest.segments[index];
  const source = scriptById[audio.section_id];
  const aligned = alignmentById[audio.section_id];
  if (!source || !aligned) throw new Error(`Missing source/alignment for ${audio.section_id}`);
  if(candidate && aligned.source_text!==source.narration)throw new Error(`Stale aligned text: ${source.id}`);
  const audioSrc=candidate?`${resolvedCoverage.audio_base}/${source.id}.wav`:`assets/audio/${source.id}.wav`;
  const stagedAudio=path.join(here,audioSrc);
  if(candidate){
    const expected=candidateQA.sections.find(s=>s.section_id===source.id)?.audio_health.audio_sha256;
    if(crypto.createHash('sha256').update(fs.readFileSync(stagedAudio)).digest('hex')!==expected)throw new Error(`Stale staged audio: ${source.id}`);
  }
  const actualAudioDuration = wavDurationSeconds(stagedAudio);
  const startMs = Math.round(cursor * 1000);
  const durationMs = Math.round(actualAudioDuration * 1000);
  const endMs = startMs + durationMs;
  const files = clipFiles[source.id] || [];
  const slotMs = files.length ? durationMs / files.length : 0;
  const coverage = candidate?resolvedCoverage.sections[source.id]:files.map((file, clipIndex) => {
    const clipStart = Math.round(startMs + clipIndex * slotMs - (index || clipIndex ? 160 : 0));
    const clipEnd = Math.round(startMs + (clipIndex + 1) * slotMs + 160);
    return {
      id: `${source.id.toLowerCase()}-clip-${clipIndex + 1}`,
      src: `assets/video/story/${file}`,
      startMs: Math.max(0, clipStart),
      endMs: clipEnd
    };
  });
  if(!Array.isArray(coverage))throw new Error(`Missing measured coverage: ${source.id}`);
  const words = subtitleWords(source.narration, aligned.source_words, startMs);
  const items = teachingItems[source.id] || [];
  const cue = teachingCues[source.id];
  if (items.length && cue.anchors.length !== items.length) throw new Error(`Teaching cue count: ${source.id}`);
  const teaching = items.map(([term, text], itemIndex) => {
    const answer = cue.answers?.[itemIndex];
    const activeMs = phraseStart(words, cue.anchors[itemIndex]);
    const itemEndMs = itemIndex + 1 < items.length ? phraseStart(words, cue.anchors[itemIndex + 1]) : endMs;
    let copy = text.replace(/\s+[✓✗]$/, '').replace(/\s+(True|False)$/, '');
    if (source.id === 'S12') copy = copy.slice(0, copy.indexOf('?') + 1);
    return {id: `${source.id.toLowerCase()}-item-${itemIndex + 1}`, term, text: copy,
      startMs: itemIndex === 0 ? startMs : activeMs,
      activeMs,
      endMs: itemEndMs,
      ...(answer ? {answer: answer.text, answerMs: spokenAnchor(words, answer.anchor, {afterMs: activeMs, beforeMs: itemEndMs})} : {})};
  });
  sections.push({
    id: source.id,
    number: index + 1,
    heading: cue?.heading || source.heading,
    subheading: cue?.subheading || '',
    mode: source.mode,
    startMs,
    endMs,
    audio: audioSrc,
    displayText: source.display_text || [],
    visualCues: source.visual_cues || [],
    coverage,
    teaching,
    teachingLayout: cue?.layout,
    instruction: cue?.instruction,
    words
  });
  cursor += actualAudioDuration;
}

const captions = [];
for (const section of sections) {
  let page = [];
  for (const word of section.words) {
    page.push(word);
    const punctuation = endsSentence(word.text);
    if (punctuation || page.length >= 7) {
      captions.push({ id: `caption-${captions.length + 1}`, startMs: page[0].startMs, endMs: page.at(-1).endMs, words: page });
      page = [];
    }
  }
  if (page.length) captions.push({ id: `caption-${captions.length + 1}`, startMs: page[0].startMs, endMs: page.at(-1).endMs, words: page });
}

const durationMs = Math.round(cursor * 1000);
const data = { durationMs, sections, captions };
fs.writeFileSync(path.join(here, 'production-data.js'), `window.PRODUCTION_DATA = ${JSON.stringify(data)};\n`);

const videoMarkup = sections.flatMap((section, sectionIndex) => section.coverage.map((cue, cueIndex) => {
  const duration = (cue.endMs - cue.startMs) / 1000;
    return `<div id="${cue.id}" class="video-cue"><video id="media-${cue.id}" class="clip media" src="${cue.src}" muted playsinline preload="auto" data-layout-allow-overflow data-start="${cue.startMs / 1000}" data-duration="${duration}" data-track-index="${20 + sectionIndex * 10 + cueIndex}"></video></div>`;
})).join('');
const audioMarkup = sections.map((section, index) => `<audio id="narration-${section.id.toLowerCase()}" class="clip" src="${section.audio}" preload="auto" data-start="${section.startMs / 1000}" data-duration="${(section.endMs - section.startMs) / 1000}" data-track-index="${400 + index}" data-volume="1"></audio>`).join('');
const indexPath = path.join(here, 'index.html');
const html = fs.readFileSync(indexPath, 'utf8');
if (!html.includes('<!-- GENERATED_MEDIA_START -->') || !html.includes('<!-- GENERATED_MEDIA_END -->')) {
  throw new Error('Generated media markers are missing from index.html');
}
const generated = `<!-- GENERATED_MEDIA_START --><div id="video-layer">${videoMarkup}</div><div id="audio-layer">${audioMarkup}</div><!-- GENERATED_MEDIA_END -->`;
const next = html
  .replace(/<!-- GENERATED_MEDIA_START -->[\s\S]*?<!-- GENERATED_MEDIA_END -->/, generated)
  .replace(/data-duration="[\d.]+"/, `data-duration="${durationMs / 1000}"`);
fs.writeFileSync(indexPath, next);

const configPath = path.join(here, 'hyperframes.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
config.duration = durationMs / 1000;
fs.writeFileSync(configPath, `${JSON.stringify(config, null, 2)}\n`);
if(candidate)fs.writeFileSync(sourceConfigPath,`${JSON.stringify(sourceConfig,null,2)}\n`);
console.log(`Built ${sections.length} sections, ${videoMarkup.match(/<video/g)?.length || 0} videos, ${manifest.segments.length} narration tracks and ${captions.length} caption pages. Duration ${(durationMs / 1000).toFixed(3)}s.`);
