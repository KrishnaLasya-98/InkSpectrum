/* Source-faithful teaching layouts. Every state transition consumes measured speech cues. */
window.renderTeaching = function(section, timeline, escapeText) {
  const frame = document.createElement('section');
  const esc = escapeText;
  const id = section.id;
  const layout = section.teachingLayout;
  frame.id = `teaching-${id}`;
  frame.className = 'teaching-section';
  frame.dataset.mode = section.mode;
  const picture = (name, cls = '') => `<img class="source-picture ${cls}" src="assets/exercises/${name}.png" alt="${esc(name.replaceAll('-', ' '))}">`;
  const row = (item, index, body, end = '') => `<div id="${item.id}" class="exercise-row"><span class="row-number">${layout==='smileys'?index+1:String.fromCharCode(97 + index)}.</span><div class="row-text">${body}</div>${end}</div>`;
  const answer = item => `<span id="answer-${item.id}" class="answer-reveal answer-text">${esc(item.answer || '')}</span>`;
  let body = '';
  let instruction = section.instruction || '';
  if (layout === 'glossary') {
    body = section.teaching.map(item => `<div id="${item.id}" class="exercise-row glossary-row"><strong>${esc(item.term)}</strong><div class="row-text">${esc(item.text)}</div></div>`).join('');
  } else if (layout === 'rebus') {
    const content = [
      `Varun and Vidya go to a ${picture('picnic','rebus-picture')} with their family.`,
      `They build a ${picture('sandcastle','rebus-picture')} on the beach.`,
      `They decorate the ${picture('decorating-castle','rebus-picture')} with ${picture('shell','rebus-picture')}.`,
      `Vidya has a ${picture('shovel','rebus-picture')} and a ${picture('bucket','rebus-picture')}.`
    ];
    body = section.teaching.map((item,i) => row(item,i,content[i],`<span class="answer-circle">${answer(item)}</span>`)).join('');
  } else if (layout === 'true-false') {
    body = section.teaching.map((item,i) => row(item,i,esc(item.text),`<div class="true-false-options">${['True','False'].map(value=>`<span class="tf-option">${value}${value===item.answer?`<b id="answer-${item.id}" class="answer-reveal tf-check">✓</b>`:''}</span>`).join('')}</div>`)).join('');
  } else if (layout === 'questions') {
    body = section.teaching.map((item,i)=>`<article id="${item.id}" class="question-card"><p class="question">${String.fromCharCode(97+i)}. ${esc(item.text)}</p><div class="answer-line">${answer(item)}</div><div class="thinking-dots"><i></i><i></i><i></i></div></article>`).join('');
  } else if (layout === 'alphabet') {
    instruction = '';
    body = `<div class="alphabet-grid">${[...'ABCDEFGHIJKLMNOPQRSTUVWXYZ'].map(letter=>`<div id="${id}-letter-${letter}" class="letter-tile">${letter}${'AEIOU'.includes(letter)?`<svg class="letter-circle" viewBox="0 0 120 110"><ellipse id="${id}-circle-${letter}" cx="60" cy="55" rx="55" ry="50" pathLength="360"/></svg>`:''}</div>`).join('')}</div><div class="letter-legend"><span><strong>A E I O U</strong> · 5 vowels</span><span>The other 21 letters are consonants.</span></div>`;
  } else if (layout === 'starfish') {
    instruction = 'Colour the starfish with vowels in red. Colour the consonants in blue.';
    body = `<div class="starfish-grid">${[...'ZUTOXABIJWE'].map(letter=>`<div id="${id}-star-${letter}" class="starfish"><svg viewBox="0 0 200 155"><polygon id="${id}-fill-${letter}" points="100,3 123,53 194,44 145,89 166,149 100,120 34,149 55,89 6,44 77,53"/></svg><span>${letter}</span></div>`).join('')}</div>`;
  } else if (layout === 'friend-name') {
    instruction = 'Write the name of your friend. Circle the Consonants.';
    body = `<div class="friend-line" aria-label="Write your friend's name here"></div>`;
  } else if (layout === 'picture-equations') {
    const pictures = [['sun','flower','sunflower'],['straw','berry-source','strawberry'],['sun','glasses','sunglasses'],['rain','bow','rainbow']];
    const labels = [['sun','flower'],['straw','berry'],['sun','glasses'],['rain','bow']];
    body = section.teaching.map((item,i)=>`<div id="${item.id}" class="equation-stage"><div class="equation-part">${picture(pictures[i][0])}<div class="equation-label">${labels[i][0]}</div></div><span class="equation-symbol">+</span><div class="equation-part">${picture(pictures[i][1])}<div class="equation-label">${labels[i][1]}</div></div><span class="equation-symbol">=</span><div class="equation-part">${picture(pictures[i][2])}<div class="equation-label">${answer(item)}</div></div></div>`).join('');
  } else if (layout === 'equations') {
    body = `<div class="written-equations">${section.teaching.map((item,i)=>row(item,i,`${esc(item.text)}<br>= <span class="written-answer">${answer(item)}</span>`)).join('')}</div>`;
  } else if (layout === 'word-parts') {
    body = section.teaching.slice(0,2).map(item=>`<div id="${item.id}" class="word-parts"><span class="word-result">${esc(item.term)}</span><span>=</span>${item.text.split(' + ').map(t=>`<span class="word-part">${esc(t)}</span>`).join('<span>+</span>')}</div>`).join('') + `<div id="${section.teaching[2].id}" class="word-definition">Words that are made up of two smaller words are called Joined words.</div>`;
  } else if (layout === 'pronunciation') {
    instruction = 'Read the words aloud.';
    body = `<div class="pronunciation-grid">${section.displayText.map(word=>`<div id="${id}-word-${word}" class="pronunciation-word">${word.replaceAll('a','<span class="vowel">a</span>')}</div>`).join('')}</div><p class="pronunciation-note">These words have the short /a/ sound.</p>`;
  } else if (layout === 'smileys') {
    body = `<div class="smiley-table">${section.teaching.map((item,i)=>row(item,i,esc(section.displayText[i]),picture('smileys','smiley-options'))).join('')}</div>`;
  } else if (layout === 'worksheet') {
    instruction = 'Write about yourself to complete the letter.';
    body = `<div class="worksheet-layout">${picture('all-about-me')}<div class="worksheet-fields">${['Name','Age','Birthday','Food','Color','Pet','Movie','Sports','Subject','Fun Facts About me','When I grow up I want to be'].map(word=>`<div class="worksheet-field">${word}<br>________________</div>`).join('')}</div></div>`;
  } else if (layout === 'dialogue') {
    instruction = 'What do you say when you meet someone? How do you introduce yourself?';
    body = `<div class="speaking-bubbles">${section.teaching.map(item=>`<div id="${item.id}" class="speaking-bubble"><strong>${esc(item.term)}</strong>${esc(item.text)}</div>`).join('')}</div>`;
  } else if (layout === 'blanks') {
    body = `<div class="fill-lines">${section.teaching.map(item=>`<div id="${item.id}" class="fill-line">${esc(item.text)}</div>`).join('')}</div>`;
  } else {
    body = `<div class="large-instruction">${section.displayText.map(esc).join('<br>')}</div>${layout==='listening'?'<div class="notebook-lines"></div>':''}`;
  }
  frame.innerHTML = `<div class="teaching-card"><h2 class="teaching-heading">${esc(section.heading)}</h2>${section.subheading?`<h3 class="teaching-subheading">${esc(section.subheading)}</h3>`:''}${instruction?`<p class="exercise-instruction">${esc(instruction)}</p>`:''}<div class="exercise-body">${body}</div></div>`;
  document.getElementById('teaching-ui').appendChild(frame);
  const start=section.startMs/1000, end=section.endMs/1000;
  // Keep the background continuous, but never crossfade two different blocks of text.
  timeline.set(frame,{visibility:'visible',opacity:1},start)
    .set(frame,{visibility:'hidden',opacity:0},end);
  const staged = ['questions','picture-equations'].includes(layout);
  section.teaching.forEach(item=>{
    const el=frame.querySelector(`#${item.id}`);
    if(el){
      if(staged) timeline.set(el,{visibility:'visible',opacity:1},item.startMs/1000).set(el,{visibility:'hidden',opacity:0},item.endMs/1000);
      else timeline.to(el,{backgroundColor:'#e1f4e9',duration:.2},item.activeMs/1000).to(el,{backgroundColor:'#fff',duration:.2},Math.max(item.activeMs/1000,item.endMs/1000-.2));
    }
    const answerEl=frame.querySelector(`#answer-${item.id}`);
    if(answerEl)timeline.fromTo(answerEl,{autoAlpha:0,y:8},{autoAlpha:1,y:0,duration:.22},item.answerMs/1000);
  });
  const normal = value=>value.toLowerCase().replace(/[^a-z]/g,'');
  if(layout==='alphabet'){
    // The spoken list follows "five letters", so sentence-initial "a" cannot trigger a circle.
    const from = section.teaching[0].activeMs;
    for(const letter of 'AEIOU'){
      const word=section.words.find(w=>w.startMs>=from&&normal(w.text)===letter.toLowerCase());
      if(word)timeline.to(`#${id}-circle-${letter}`,{strokeDashoffset:0,duration:.4},word.startMs/1000);
    }
  }
  if(layout==='starfish'){
    for(const letter of 'ZUTOXABIJWE'){
      const words=section.words.filter(w=>normal(w.text)===letter.toLowerCase());
      if(words[0]) timeline.to(`#${id}-star-${letter}`,{scale:1.12,duration:.15},words[0].startMs/1000).to(`#${id}-star-${letter}`,{scale:1,duration:.2},words[0].endMs/1000+.15);
      const at='AEIOU'.includes(letter)?words.at(-1)?.startMs:section.teaching[1].activeMs;
      if(at!==undefined)timeline.to(`#${id}-fill-${letter}`,{fill:'AEIOU'.includes(letter)?'#ffb8b9':'#a9d8ff',stroke:'AEIOU'.includes(letter)?'#b92e39':'#256899',duration:.35},at/1000);
    }
  }
  if(layout==='pronunciation') for(const word of section.words){
    const name=normal(word.text),el=frame.querySelector(`#${id}-word-${name}`);
    if(el)timeline.to(el,{backgroundColor:'#ffe5a5',scale:1.045,duration:.12},word.startMs/1000).to(el,{backgroundColor:'#eaf5f0',scale:1,duration:.16},Math.max(word.endMs/1000,word.startMs/1000+.2));
  }
};
