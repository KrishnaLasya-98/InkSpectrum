# At the Beach - HyperFrames visual system

- Full-bleed, child-friendly 3D story footage for the opening, warm-up and story.
- Small cream section tab at top left; one compact cream learning box at top right only when source text benefits from being visible.
- Stable cream subtitle lane at the bottom, driven by measured word timestamps. The spoken word is highlighted in coral.
- Glossary, assessment, grammar and activity sections use calm textbook-like cards over a softly animated beach-paper background.
- English source wording comes from the supplied chapter. EVS media and EVS text are never imported.
- Generated clip audio is muted. The clean Indian-English narration is authoritative.
