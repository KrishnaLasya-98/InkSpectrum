// Display approved-script punctuation, never punctuation guessed by speech recognition.
export function subtitleWords(narration, alignedWords, startMs = 0) {
  const tokens = [...narration.matchAll(/([“‘"(]*)([A-Za-z0-9]+(?:['’][A-Za-z0-9]+)*)([.,:;!?…'’”")\-–—]*)/g)];
  if (tokens.length !== alignedWords.length) throw new Error('Narration/alignment word count differs');
  const normalize = value => value.toLowerCase().replace(/[^a-z0-9]/g, '');
  return tokens.map((token, i) => {
    const word = alignedWords[i];
    if (normalize(token[2]) !== normalize(word.word)) throw new Error(`Narration/alignment word differs at ${i}: ${token[2]}`);
    return {text: token[1] + token[2] + token[3],
      startMs: startMs + Math.round(word.start * 1000),
      endMs: startMs + Math.round(word.end * 1000)};
  });
}

export function endsSentence(text) {
  return /[.!?][’”"')]*$/.test(text);
}

export function spokenAnchor(words, phrase, {afterMs = -Infinity, beforeMs = Infinity, occurrence = 0} = {}) {
  const normalize = value => value.toLowerCase().replace(/[^a-z0-9]/g, '');
  const needle = (phrase.match(/[A-Za-z0-9]+(?:['’][A-Za-z0-9]+)*/g) || []).map(normalize);
  if (!needle.length) throw new Error('Empty spoken cue');
  const hits = words.filter((word, i) => word.startMs >= afterMs && word.startMs < beforeMs &&
    needle.every((token, offset) => normalize(words[i + offset]?.text || '') === token));
  if (!hits[occurrence]) throw new Error(`Spoken cue not found in its interval: ${phrase}`);
  return hits[occurrence].startMs;
}
