import assert from 'node:assert/strict';
import fs from 'node:fs';
import test from 'node:test';

const source = fs.readFileSync(new URL('./teaching-ui.js', import.meta.url), 'utf8');

test('keeps the complete Speaking Ability prompt from the textbook', () => {
  assert.match(
    source,
    /What do you say when you meet someone\? How do you introduce yourself\?/
  );
});

test('keeps source capitalization for the friend-name activity', () => {
  assert.match(source, /Write the name of your friend\. Circle the Consonants\./);
  assert.doesNotMatch(source, /Write the name of your friend\. Circle the consonants\./);
});
