import test from 'node:test';
import assert from 'node:assert/strict';
import {subtitleWords, endsSentence, spokenAnchor} from './subtitle-text.mjs';

test('keeps comma, colon, question mark and full stop from script', () => {
  const text = 'Hello, Vidya! Lesson one: At the Beach. What do you see?';
  const words = text.match(/[A-Za-z]+/g).map((word,i) => ({word,start:i,end:i+.8}));
  assert.equal(subtitleWords(text,words).map(w=>w.text).join(' '),text);
});
test('keeps quoted questions and apostrophes', () => {
  const text = '“What’s your name?”';
  const result = subtitleWords(text,[{word:"What's",start:0,end:1},{word:'your',start:1,end:2},{word:'name',start:2,end:3}]);
  assert.equal(result.map(w=>w.text).join(' '),text);
  assert.ok(endsSentence(result.at(-1).text));
});
test('does not silently attach timing from different words', () => {
  assert.throws(()=>subtitleWords('Why?', [{word:'How',start:0,end:1}]));
});
test('correct answer is found only after its question, not in instructions', () => {
  const words = [{text:'correct',startMs:1000},{text:'Correct.',startMs:9000},{text:'Correct.',startMs:14000}];
  assert.equal(spokenAnchor(words,'correct',{afterMs:5000,beforeMs:12000}),9000);
  assert.equal(spokenAnchor(words,'correct',{afterMs:12000,beforeMs:18000}),14000);
  assert.throws(()=>spokenAnchor(words,'correct',{afterMs:16000}));
});
