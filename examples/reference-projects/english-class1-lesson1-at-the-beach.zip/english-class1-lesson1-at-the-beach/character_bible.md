# At the Beach - Character Bible

## Identity lock

The master visual reference is `assets/images/character-references/varun-vidya-master-v1.png`. Every generated story frame and image-to-video request must use this file as the identity reference.

### Varun

- Indian boy; warm brown skin; short wavy dark-brown hair.
- Teal short-sleeve T-shirt with no logo, coral shorts, blue sandals.
- Friendly rounded 3D design, expressive brown eyes, curious and confident manner.
- Never change his hairstyle, clothing colors, footwear, age impression, or proportions.

### Vidya

- Indian girl; warm brown skin; dark-brown hair in two tidy braids with yellow bands.
- Sunny-yellow short-sleeve top, sea-blue knee-length shorts, coral sandals.
- Friendly rounded 3D design, expressive brown eyes, observant and enthusiastic manner.
- Never change her hairstyle, clothing colors, footwear, age impression, or proportions.

## Secondary characters

- Mummy and Daddy appear only when the source places the children at the beach with their parents or calls them to leave.
- Grandpa and Grandma are mentioned but not physically shown in the story; their room exists only in the children's imagined sandcastle.
- Adithya and Smitha belong only to the Speaking Ability demonstration and use a separate stable teaching vignette.

## Environment and prop lock

- One sunny Indian beach environment with turquoise water, pale sand, scattered shells, palm trees, and soft late-morning light.
- The ocean remains on the same screen side across adjacent story shots unless the camera clearly crosses with a transition.
- The same yellow bucket and small blue shovel recur whenever the children build.
- The sandcastle develops continuously from a small base to a large imaginative castle; it does not reset between clips.
- Generated motion contains no text, logos, watermarks, subtitles, speech bubbles, or audible dialogue.

## Motion rules

- Use a reference image or the immediately preceding approved frame for every image-to-video story shot.
- One story clip is used once. Generate a continuation clip when more motion is needed.
- Prefer gentle dolly, pan, hand action, sand movement, sea breeze, and natural eye lines.
- Reject identity drift, clothing changes, malformed hands, duplicated characters, jump cuts, loops, and camera teleportation.
