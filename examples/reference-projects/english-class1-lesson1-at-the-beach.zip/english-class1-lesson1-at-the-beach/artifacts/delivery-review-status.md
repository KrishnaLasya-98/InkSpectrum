# Narration delivery review — 2026-09-22

## Latest decision

### Current candidate: v6; render a review copy now, polish tomorrow

Latest user instruction: "create me redered video now we will fix rest tommorow". Stop further creative revisions, assemble the latest synchronized version, and render a clearly labelled review MP4. This is not final educational/encoded visual QA approval.

- User approved the warm v5 opening and separately confirmed **Adithya** sounds correct. The name decision is bound to the exact phrase SHA-256 in `narration-listening-decisions.json`; it does not approve future regenerations.
- v6 contains 26 sections / 130 phrases / **484.06 seconds**. Same locked Indian-English Qwen voice and unchanged approved introduction. Six declared delivery edits clarify two teacher instructions and remove redundant `Makes` from four picture-word answers. See `narration_revision_v6.json`.
- Automated narration/synchronization checks now have **zero unresolved blockers**. Independent cached ASR repaired invalid short word timings only where matching measured word spans fit between neighbours. Primary transcripts, spelling/homophone normalization and timing provenance remain in the QA report. This is not a claim of listening to the full chapter.
- Four new Wan 2.2 image-to-video continuations were generated from near-end frames of this chapter's own clips: arrival, beach discovery, hide-and-seek, departure. Inspected all four 3-fps contact sheets; accepted for preview. No cross-chapter assets, replay or loops.
- `stage_synced_media.py` builds **spoken-concept coverage**, replacing equal-duration clip slots. Two clips use bounded 0.85x retiming. Filter look-ahead is padded then trimmed to actual source duration so interpolation does not truncate the required interval.
- New production source selection is persisted in `hyperframes-final/production-source.json` only after successful staging/build. Older preview files are backed up under `artifacts/preview-before-v6/`.
- Review render command: `scripts/render_review_v6.ps1`. Uses one worker, low-memory mode, standard 1080p quality, a D-drive temporary directory, and a 700-second streaming duration threshold. Records a log and JSON status. Output: `hyperframes-final/renders/english-class1-at-the-beach-review-v6.mp4`.
- Remaining for tomorrow: full rendered-frame/PDF comparison, exercise/UI and transition polish, and encoded audio-sync QA. `qa_encoded_video.py` is prepared to decode every frame and measure audio offset in each of the 26 sections; its results must not be called a full semantic frame review.

### Current candidate: v5 warm opening and source headings

User requested a more interactive opening, natural transitions (especially Glossary), original PDF headings, fewer superfluous terms, and synchronized narration/text. See `pdf-narration-ui-review-v5.md` and the explicit revision manifest.

- v5 is generated: 26 sections, 130 phrases, **482.66 seconds**. Reused 118 identical approved-voice requests within this chapter and generated 12 changed passages.
- New intro (`assets/audio/narration-indian-qwen-v5/intro-review.mp3`) lasts 11.37 seconds. Unprompted recognition matched all three phrases, including Class one, Lesson one and both children's names; no clipped PCM samples. This is text/PCM QA, not independent listening approval.
- New glossary review: `assets/audio/narration-indian-qwen-v5/glossary-review.mp3`.
- Grade - I was visually verified on printed PDF page 20; it is read as Grade one. Grammar and Vocabulary heading hierarchies restored; assessment numbering follows the PDF; duplicate instructions removed.
- Latest HyperFrames draft check: zero lint/runtime/layout/motion issues at six positions, 69/69 contrast checks passed. Inspected Grammar, Vocabulary and Self Assessment snapshots.
- All v5 word QA completed; diagnostic sync plan still reports 22 blockers (phrase recognition/timing review). Story coverage has five intervals needing approximately 8.54 seconds of additional motion under the 0.85x policy. Those are not five confirmed new-clip requests.
- Do not use v4/Tara timings. Do not claim v5 is already in the browser: the current preview remains the old-audio 305-second draft with corrected UI. No final MP4 has been rendered or compared end to end against the PDF.

### Opening title and punctuation correction

- User asked why subject/class/lesson intro disappeared. The previous compact title faded at the first "Today" cue; the browser was also playing beyond that cue. Restored a clearer three-level title: **English · Class 1 / Lesson 1 / At the Beach**, visible from zero through the entire measured S01 introduction. No duplicate S01 corner tab or extra story tagline. The animated family background remains.
- Four 1080p snapshots (0, 1, 4.5, 7 seconds) passed HyperFrames checks: zero lint/runtime/layout/motion errors, 27/27 contrast checks. Inspected opening and 7-second images; title stays clear of faces.
- Browser review revealed a stale-preview reload warning and a panned canvas that cropped the top. Opened a fresh preview tab and used Reset zoom to fit; confirmed the full subject/class/title at time zero.
- Added `hyperframes-final/subtitle-text.mjs`: preserve script commas, full stops, colons, question/exclamation marks, apostrophes and quotes. Word-count and lexical mismatches fail instead of silently attaching another word's timing. Four Node regression tests passed.
- Fixed answer matching to search only inside its question's spoken interval, preventing the instructional word "correct" from revealing ticks early. Applied to the current builder and new-audio diagnostic sync planner. Production data rebuilt successfully for all 26 sections.
- Re-running Qwen word QA without VAD for short prepared phrases; the first-word omission on "Look at the picture" was an ASR gate artifact, not missing provider audio. The new Qwen audio is still isolated until remaining pronunciation/timing and media-coverage blockers are resolved. Current preview remains a 305.053-second old-audio draft, **not the final render**.

### Completed narration, video still pending

- Approved-voice candidate finished: **26 sections / 133 phrases / 484.60 seconds (8:05)**. Full audio: `assets/audio/narration-indian-qwen-v4/chapter-review.mp3`.
- Unprompted word/timing QA ran across all sections: **24 phrases flagged**, not 24 confirmed speech defects. A no-VAD comparison confirmed the earlier "Look at" onset warning was a recognizer issue; raw and prepared audio both recognized the complete phrase. The new aligner uses no VAD for these short phrases and versions that choice in its ASR cache.
- Speech-cue coverage: **23 existing story clips; 5 intervals need about 6.00 seconds additional motion** under the 0.85x minimum-speed policy. This is not five required new clips; plan exact supplemental coverage after correcting timings.
- `sync-plan.json` generated for all 26 sections. It blocks promotion for unresolved phrase flags, invalid word spans, and three S10 answer-before-question cases. S10 "Correct" matching must be bounded to the relevant question/answer interval rather than counting the instructional word "correct".
- Production preview still uses old audio. **Final video not rendered or approved.** Next: investigate flagged pronunciations/timings, fix answer anchors, resolve motion gaps, stage approved synchronization, preview, render, and inspect encoded output.

Continuity sample approved: **"Yes—use this voice for the full chapter"**. Full 26-section Qwen narration is now authorized. Run `scripts/run_indian_narration_candidate.py` to generate the isolated candidate and then unprompted word/timing QA. Preserve any pronunciation flags; approval of the voice is not approval of every generated word. No final-video claim until synchronization and encoded QA are complete.

User approved the original Indian-English Qwen voice sample with "ok good". Its exact provider audio is now hash-locked as the reference for `qwen-tts` via `/api/v6/voice/text_to_audio`. Do not redesign the voice for every phrase or fall back to Tara/Sophia. New code: `scripts/build_indian_narration.py`; isolated candidate: `assets/audio/narration-indian-qwen-v4`. First generate and review the short reference-conditioned continuity sample, then the full chapter. Reference-sample approval does not establish that every new synthesis has correct pronunciation or the same voice quality.

The old HyperFrames production audio has not been replaced. Recalculate word/visual timing from the approved new WAVs; do not use Tara's duration or old manifests.

- Reference-conditioned sample completed: `assets/audio/narration-indian-qwen-v4/continuity-sample/sample.mp3`, 18.39 seconds including deliberate pauses, 48 kHz mono MP3. All five lines use the same hash-locked reference.
- Unprompted `small.en` recognition matched four of five phrases, including Varun and Vidya. One phrase was recognized as "a shovel in a bucket" instead of "a shovel and a bucket". This remains a listening/pronunciation flag, not an automatic content approval. Zero clipped samples in all five phrase WAVs.
- Requested user continuity listening check. Full-chapter generation remains gated on this check; never write an approval automatically from ASR.
- Prepared v4 delivery plan: 26 sections / 133 phrases, preserving the approved pacing structure. Nine offline regression tests passed across existing delivery and new voice-reference safety tests.

**Tara rejected for production: user says the accent needs changing.** Do not promote the 620.77-second candidate or use its timing as the final timeline. Keep the pacing approach and UI improvements. Test an Indian-English voice in a short sample first; no further full-chapter regeneration before accent approval. The completed draft remains available for reference only; word QA may finish locally without further generation charges.

- Tara QA completed: all 26 sections checked, no clipped PCM samples, 28 phrases flagged for text/timing investigation. Not production-ready.
- Created a 13.18-second original-voice sample using ModelsLab `qwen-voice-design`, requesting a warm Indian-English primary-school teacher accent. This is a requested accent, not a verified result. Sample: `assets/audio/delivery-review-indian-qwen-v1/indian-english-sample.mp3`.
- Verified endpoint documentation: `https://modelslab.com/models/modelslab/qwen-voice-design/llms.txt`; POST `/api/v6/voice/voice_design` with `prompt`, `voice_description`, `language: english`, and `model_id: qwen-voice-design`.
- The replacement is an original designed voice, not a clone of a real person. Use short-sample accent approval before selecting its full-chapter synthesis route.
- Latest intro/exercise UI check passed at eight timeline positions with 53/53 contrast checks. Intro title no longer covers the child's face. The preview still uses old production narration, not either candidate voice.

- User feedback on Sophia sample v2: pacing is better; voice still sounds robotic.
- Keep deliberate phrase pauses and thinking time. Do not promote Sophia v2 to production.
- Generated a separate 25.25-second ModelsLab Tara sample with emotion enabled, speed 0.8, and explicit pauses. Accent is not independently verified.
- Sample: `assets/audio/delivery-review-tara/narration-sample-v2.mp3`.
- Unprompted small.en transcription matched four of five phrases after sandcastle compound normalization. The exercise question differed at Varun and the article before beach; pronunciation requires listening review. No claim of full audio QA pass.
- Production narration remains unchanged. Full regeneration and final encode are pending voice selection, pronunciation correction, realignment, and preview QA.
- Exercise UI uses extracted textbook pictures and speech-anchored teaching cues. Browser spot checks covered starfish letters at 180 seconds and picture equations at 212 seconds. These are not full-timeline approval.
- HyperFrames check initially identified crossfading text overlaps. Teaching text transitions were changed to exact boundary switches over the continuous background. The subsequent check passed: no layout issues across nine samples; 75/75 text contrast checks passed.

## Full chapter candidate started

- User requested continuation after receiving the Tara sample; continue as a candidate, not a claim of listening approval or Indian accent.
- `scripts/build_paced_narration.py` prepares 26 sections and 133 phrases in `assets/audio/narration-tara-v3`, preserving original production files.
- Exact phrase text is checked against the narration script, with four declared delivery edits: replace adult answer commentary, pronounce Grade I as Grade one, simplify the listening instruction, and address the child directly for Life Skills. Textbook display text remains unchanged.
- Exercise questions have 2.5-second thinking pauses; joined-word questions have 2 seconds before answers. Phrase timing uses measured PCM samples, not estimated word count.
- Four offline regression tests pass. Cache provenance mismatches block generation instead of reusing a different voice or prompt.
- `scripts/review_pending_delivery.py` waits for the completed candidate, runs unprompted word recognition and timing checks, then checks story coverage. It never promotes audio or starts a render.
- Opening story QA flagged five phrases for review: a number transcription, a possible pronoun difference, sandcastle recognition, omitted Wow, and Mummy/Mommy recognition. Do not call these all confirmed speech defects; listen before correcting.
- Candidate story coverage currently reports seven slots needing approximately 15.17 seconds of additional motion at a minimum 0.85x speed. These are slots, not a finalized count of new videos. Check again after any speech corrections.
- The old alignment manifest had stale durations. `audit_story_coverage.py` now probes actual audio files. Current old audio is covered with modest retiming; this is not proof of coverage for the new longer candidate.
- Story transitions now keep the outgoing shot opaque under the incoming dissolve; the first video and title are visible immediately at time zero. A new HyperFrames check is running for this last change.

## Current resume commands (project directory)

```powershell
& C:\Users\user\Miniconda3\python.exe scripts\build_indian_narration.py sample
& C:\Users\user\Miniconda3\python.exe scripts\qa_indian_voice_sample.py
& C:\Users\user\Miniconda3\python.exe scripts\build_indian_narration.py plan
```

After explicit continuity approval and resolution of the flagged phrase, record `decision: approved` with the actual user feedback in `assets/audio/narration-indian-qwen-v4/continuity-sample/review.json`, then run the new script's `generate` and `align` modes. Do not promote unreviewed audio or interpret the paused full-chapter gate as a provider failure.

## Historical Tara commands — rejected candidate, do not regenerate or promote

```powershell
& C:\Users\user\Miniconda3\python.exe scripts\build_paced_narration.py generate
& C:\Users\user\Miniconda3\python.exe scripts\build_paced_narration.py align
& C:\Users\user\Miniconda3\python.exe scripts\audit_story_coverage.py --candidate
```

Check `assets/audio/narration-tara-v3/pipeline-status.json` before resuming so no duplicate workers are launched. After QA, use `listening-review.html` for per-phrase playback. Full candidate `chapter-review.mp3` is generated only after all sections are assembled. Final video remains pending correction, coverage, word alignment, and preview/encoded QA.
