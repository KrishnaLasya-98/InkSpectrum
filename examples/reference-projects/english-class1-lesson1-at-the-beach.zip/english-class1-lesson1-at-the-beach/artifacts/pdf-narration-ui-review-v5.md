# Source / narration / UI comparison - revised delivery

Source: nine-page English Class 1 PDF, printed pages 17-25. Read all extracted page text and visually checked printed pages 20, 22 and 25 for grade notation, heading hierarchy and assessment numbering.

## Changes

- Intro is a short teacher invitation, not a heading readout: "Hello, children! Welcome to Class one English. Are you ready for Lesson one, At the Beach? Let's join Varun and Vidya!"
- Keep subject, grade, lesson number and lesson title visible throughout S01. Do not add a second title label or an unrelated slogan.
- Printed page 19: keep **Glossary** and all three definitions. Transition: "Now, let's explore the glossary: three words from our story."
- Printed pages 19-20: keep **Comprehending Ability**, **C. Think and Answer.**, and **D. Let's Discuss**. Narrate instructions conversationally instead of speaking isolated A/B/C/D labels.
- Printed page 20 shows **Grade - I** (the text extractor ambiguously reports 1). Read it as **Grade one**, never as the letter "eye". Retain the original grade designation on the teaching screen.
- Printed page 21: restore parent heading **Grammar** above **Vowels and Consonants**.
- Printed page 22: restore **Vocabulary** above **Word forming Ability: Joined Words**. Retain the complete picture-equation instruction, including "The picture will help you."
- Printed page 25: Self Assessment uses numbers **1-5**. Question C on page 20 uses letters **a-c**. Both display sequences now follow the source.
- Remove repeated friend-name UI instructions; retain the source instruction and writing line.
- Remove three teacher-only phrases repeating the listening task, adding generic memories commentary, and repeating the smiley-choice instruction. No source section or assessment item is removed.
- Narration uses singular "English alphabet" as a declared grammar correction to the PDF's "English alphabets". This is recorded in `narration_revision_v5.json` rather than silently changing the source.

## Timing / versioning

- `narration_revision_v5.json` records each changed/removed phrase and cue change.
- The v5 candidate has 26 sections and 130 phrases. Twelve requests changed; 118 exact same-chapter, same-voice requests were reused. No other chapter media or fallback voice is introduced.
- Changed audio cannot inherit old ASR timestamps. Word QA cache requires audio hash and recognition configuration matches.
- Answer-reveal anchors are bounded to their own question interval, avoiding matches to "correct" in instructions.
- Subtitle punctuation comes from narration text, not ASR punctuation; contractions, questions, commas, colons, full stops and quotation marks are preserved.

## Not yet complete

This is a source / script / draft comparison, NOT a claim that the final encoded MP4 has been reviewed. The live 305-second preview still has the previous audio. New narration, word timings, clip coverage and UI must be staged together after outstanding pronunciation and timing review. Final encoded PDF-to-video comparison remains mandatory.
