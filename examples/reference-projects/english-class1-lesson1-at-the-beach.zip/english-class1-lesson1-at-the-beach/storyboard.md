# English Class 1 - At the Beach Storyboard

## Production contract

- Runtime: HyperFrames, 1920x1080, 30 fps.
- Visual style: polished child-friendly 3D animated story plus source-faithful teaching screens.
- Narration begins on full-frame animated beach footage; there is no empty title canvas.
- No `We Learn` or `Highlights` card is shown because the PDF does not contain those sections.
- Generated clip audio is muted. ModelsLab narration is the timing authority.
- Word-highlight subtitles, visual cues, cards, and narration consume the same measured word-timestamp map.
- The Varun/Vidya identity reference is fixed before motion generation.

## Planned chapter flow

| ID | Section | Target | Visual treatment |
|---|---|---:|---|
| S01 | Opening | 8 s | Wide 3D beach arrival with Varun, Vidya, and parents; compact title only. |
| S02 | Warm Up | 30 s | Animated beach exploration; reveal only the nine exact source labels when named. |
| S03 | Read and Enjoy setup | 14 s | Family walking near the sea; Varun and Vidya notice the sand. |
| S04 | Build invitation | 12 s | Varun proposes the sandcastle; Vidya shows the blue shovel and yellow bucket. |
| S05 | Build together | 16 s | Children build the same castle base; close action continuity. |
| S06 | Grandparents' room | 15 s | Castle grows; imaginative room cutaway without physically showing grandparents. |
| S07 | Big castle | 18 s | Castle expands consistently; Mummy/Daddy room and playroom indicated visually, without embedded labels. |
| S08 | Staircase and basement | 21 s | Imaginative castle cutaway; staircase descends to a playful basement and hide-and-seek idea. |
| S09 | Time to leave | 10 s | Parents call from a safe distance; children wave and leave the intact castle. |
| S10 | Glossary | 28 s | Stable three-card reading sequence: shovel, basement, staircase; word highlights remain active. |
| S11 | Comprehending A | 32 s | Source-faithful rebus questions, one sentence at a time, with image chips and answer reveal. |
| S12 | True or false | 24 s | One exact statement per card; production answer appears only after thinking time. |
| S13 | Think and Answer | 34 s | Three exact questions, with short source-grounded answer reveals. |
| S14 | Let's Discuss | 16 s | Exact open question over gentle beach motion; no official answer is invented. |
| S15 | Speaking Ability | 40 s | Adithya/Smitha 3D classroom vignette and exact self-introduction frame. |
| S16 | Vowels and consonants | 42 s | Stable alphabet teaching panel; vowels A E I O U are circled when spoken. |
| S17 | Starfish activity | 28 s | Exact starfish arrangement; vowels animate red and consonants blue. |
| S18 | Friend-name activity | 12 s | Exact prompt and blank line; no sample name replaces the learner's answer. |
| S19 | Joined words concept | 25 s | Sand + castle and stair + case combine with simple object motion. |
| S20 | Picture joined words | 36 s | Sunflower, strawberry, sunglasses, rainbow; one equation at a time. |
| S21 | Written joined words | 32 s | Six exact joins, paced in pairs with clean answer reveals. |
| S22 | Pronunciation | 32 s | Eight short-a words appear one at a time with clear audio and mouth-friendly pacing. |
| S23 | Creative Ability | 30 s | Source-faithful All About Me worksheet; show fields without filling personal data. |
| S24 | Listening Ability | 16 s | Exact instruction; teacher supplies words because the PDF provides none. |
| S25 | Life Skills | 18 s | Family story-time vignette with the complete exact statement. |
| S26 | Self Assessment | 34 s | Five exact lines, one at a time, with three source smiley choices. |

Estimated duration before measured narration: approximately 8 minutes 30 seconds.

## UI rules

- Small cream source-section badge at top left.
- Compact cream learning panel only where the current source content needs it.
- Stable cream subtitle lane at the bottom; maximum seven words and two lines.
- Only the current spoken idea is visible; no duplicate summary paragraph.
- Exercises preserve every blank, picture cue, option, and response control.
- Reading screens receive subtle panel motion but never unnecessary full-screen transitions.

## Final QA gates

1. Audit every source item against the coverage manifest.
2. Reject reused or visibly looped story footage.
3. Confirm Varun/Vidya identity and sandcastle continuity across S01-S09.
4. Confirm each named object appears during its spoken interval.
5. Confirm measured word highlighting, audio onset, and audio tail on every section.
6. Run HyperFrames lint and inspect snapshots across the entire timeline and every transition.
7. Inspect contact sheets from the encoded MP4 and run ffprobe, black-frame, freeze, and audio checks.
