# English Class 1 - Lesson 1 Source Audit

## Authority

- Source PDF: `RPS - ENGLISH - CLASS 1 - INDIVIDUAL - A (2026) PRINTFILE (2)-pages-2.pdf`
- Printed pages: 17-25; PDF pages: 1-9.
- Chapter title: `At the Beach`.
- The PDF has no `We Learn` block and no `Highlights of the Lesson` block. Neither may be invented for this chapter.
- Picture-dependent content was verified from rendered PDF pages because the extracted Markdown omits rebus images and worksheet labels.

## Required source order

1. Warm Up
2. Read and Enjoy
3. Glossary
4. Comprehending Ability A-D
5. Speaking Ability
6. Grammar - Vowels and Consonants
7. Vocabulary - Word forming Ability: Joined Words
8. Pronunciation
9. Creative Ability
10. Listening Ability
11. Life Skills
12. Self Assessment

## Critical recovered visual content

- Warm Up labels: Cloud, Palm Tree, Sea, Ball, Girl, Swimming Ring, Sand, Sandcastle, Starfish.
- Comprehending A picture words: picnic, sandcastle, sandcastle and shell, shovel and bucket. The picnic sentence is not correct for this story; the other three are correct.
- Starfish letters: `Z U T O / X A B / I J W E`; vowels red and consonants blue.
- Joined-word pictures: sun + flower, straw + berry, sun + glasses, rain + bow.
- All About Me fields: photo, Name, Age, Birthday, Food, Color, Pet, Movie, Sports, Subject, Fun Facts About me, and future ambition.
- Every Self Assessment row has happy, sad, and neutral smiley choices.

## Source caveats

- The story does not label speakers. Dialogue assignment is a production interpretation and must not be presented as textbook metadata.
- Preserve exact textbook wording on displayed cards, including source grammar or punctuation oddities.
- Teacher narration may read corrected punctuation naturally, but must not silently replace source card text.
- The PDF provides no Listening Ability word list. Do not invent one as textbook content; prompt the teacher to provide words.
- The PDF provides no official answer key. Any reveals are marked as source-grounded production answers.
- The joined-word picture intended as `straw + berry = strawberry` visually resembles straws and cherries; use an unambiguous berry visual in the video.
