"""Measure sample transcription, speech pacing and audio health; never equate ASR with listening approval."""
import json
import argparse
import subprocess
from pathlib import Path
from faster_whisper import WhisperModel
from align_narration import word_error_rate

project = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--folder', default='delivery-review-v2')
args = parser.parse_args()
folder = project / "assets/audio" / args.folder
manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
model = WhisperModel("small.en", device="cpu", compute_type="int8")
results = []
for phrase in manifest["phrases"]:
    segments, _ = model.transcribe(phrase["file"], language="en", beam_size=5,
                                  word_timestamps=True, vad_filter=True,
                                  condition_on_previous_text=False)
    segments = list(segments)
    transcript = " ".join(s.text.strip() for s in segments)
    words = [{"word": w.word.strip(), "start": round(w.start, 3), "end": round(w.end, 3)}
             for s in segments for w in s.words or []]
    raw_wer = word_error_rate(phrase["text"], transcript)
    # "sand castle" and "sandcastle" are the same audible compound; retain raw WER too.
    wer = word_error_rate(phrase["text"], transcript.replace("sand castle", "sandcastle"))
    duration = phrase["samples"] / 48000
    results.append({"id": phrase["id"], "text": phrase["text"], "transcript": transcript,
                    "wer": round(wer, 4), "raw_wer": round(raw_wer, 4), "words": words,
                    "phrase_wpm": round(len(phrase['text'].split())*60/duration, 1)})
    print(f"{phrase['id']}: WER={wer:.3f}; {transcript}", flush=True)
probe = subprocess.run(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json",
                        str(folder / "narration-sample-v2.wav")], capture_output=True, text=True, check=True)
report = {"asr_model": "small.en", "asr_initial_prompt": None, "phrases": results,
          "technical": json.loads(probe.stdout), "listening_review": "pending",
          "recognition_pass": all(r["wer"] <= .08 for r in results),
          "note": "ASR verifies recognized words; it does not verify accent, warmth, or naturalness."}
(folder / "qa.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
