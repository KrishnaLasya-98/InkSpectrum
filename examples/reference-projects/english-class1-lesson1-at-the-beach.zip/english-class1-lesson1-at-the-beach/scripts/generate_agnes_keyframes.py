"""Generate continuity keyframes through Agnes Image 2.5 Flash."""
from __future__ import annotations

import argparse
import base64
import json
import mimetypes
import os
import time
from pathlib import Path

import requests
from dotenv import load_dotenv


PROJECT = Path(__file__).resolve().parents[1]
OPENMONTAGE = PROJECT.parents[1]
PLAN_PATH = PROJECT / "artifacts" / "story_keyframe_plan.json"
load_dotenv(OPENMONTAGE / ".env")


def data_uri(path: Path) -> str:
    mime = mimetypes.guess_type(path.name)[0] or "image/png"
    return f"data:{mime};base64,{base64.b64encode(path.read_bytes()).decode('ascii')}"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--shot", action="append", help="Shot ID; repeat to select several")
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    api_key = os.environ.get("AGNES_API_KEY") or os.environ.get("AGNES_API_TOKEN")
    if not api_key:
        raise SystemExit("Agnes API key is not configured")
    plan = json.loads(PLAN_PATH.read_text(encoding="utf-8"))
    requested = set(args.shot or [])
    shots = [shot for shot in plan["shots"] if not requested or shot["id"] in requested]
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    failures = 0
    for shot in shots:
        output = PROJECT / shot["output"]
        if output.exists() and output.stat().st_size > 0 and not args.force:
            print(f"SKIP {shot['id']}: {output}", flush=True)
            continue
        references = [data_uri(PROJECT / value) for value in shot["references"]]
        prompt = f"{plan['style']} {shot['prompt']} Avoid: {plan['negative_prompt']}"
        payload = {
            "model": plan["provider"],
            "prompt": prompt,
            "size": "1K",
            "ratio": "16:9",
            "extra_body": {"image": references, "response_format": "url"},
        }
        response = None
        for attempt in range(6):
            response = requests.post(
                "https://apihub.agnes-ai.com/v1/images/generations",
                headers=headers,
                json=payload,
                timeout=180,
            )
            if response.status_code not in {429, 502, 503, 504}:
                break
            time.sleep(min(45, 5 * (2**attempt)))
        assert response is not None
        if response.status_code >= 400:
            failures += 1
            print(f"FAIL {shot['id']}: HTTP {response.status_code}", flush=True)
            continue
        data = response.json()
        item = (data.get("data") or [{}])[0]
        url = item.get("url") or data.get("url")
        encoded = item.get("b64_json") or data.get("b64_json")
        output.parent.mkdir(parents=True, exist_ok=True)
        if url:
            download = requests.get(url, timeout=180)
            download.raise_for_status()
            output.write_bytes(download.content)
            shot["provider_url"] = url
        elif encoded:
            output.write_bytes(base64.b64decode(encoded))
        else:
            failures += 1
            print(f"FAIL {shot['id']}: no image output", flush=True)
            continue
        shot["status"] = "generated-needs-visual-qa"
        PLAN_PATH.write_text(json.dumps(plan, indent=2), encoding="utf-8")
        print(f"OK {shot['id']}: {output}", flush=True)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
