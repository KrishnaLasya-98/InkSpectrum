import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import build_revised_delivery as revision


class RevisionTests(unittest.TestCase):
    def plan(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch.object(revision,'OUT',Path(tmp)/'audio'),patch.object(revision,'PLAN',Path(tmp)/'plan.json'):
                return revision.make_plan()

    def test_every_original_section_survives(self):
        plan=self.plan()
        self.assertEqual([s['id'] for s in plan['sections']],[f'S{i:02d}' for i in range(1,27)])
        self.assertEqual(sum(len(s['phrases']) for s in plan['sections']),130)

    def test_unlisted_source_phrases_stay_unchanged(self):
        edits=json.loads(revision.REVISION.read_text(encoding='utf-8'))
        base=json.loads((revision.PROJECT/'artifacts'/edits['base_plan']).read_text(encoding='utf-8'))
        original={p['id']:p['text'] for s in base['sections'] for p in s['phrases']}
        for s in self.plan()['sections']:
            for p in s['phrases']:
                self.assertEqual(p['text'],edits['replace_phrases'].get(p['id'],original[p['id']]))

    def test_intro_and_grade_are_spoken_naturally(self):
        sections={s['id']:s for s in self.plan()['sections']}
        self.assertIn('Hello, children!',sections['S01']['narration'])
        self.assertIn('Class one English',sections['S01']['narration'])
        self.assertIn('Grade one.',sections['S14']['narration'])
        self.assertNotIn('Grade I.',sections['S14']['narration'])

    def test_no_duplicate_teacher_commentary(self):
        text=' '.join(s['narration'] for s in self.plan()['sections'])
        for unwanted in ['The textbook does not give','The intended answer','Encourage kids to','Choose a happy, sad, or neutral smiley']:
            self.assertNotIn(unwanted,text)


if __name__=='__main__':unittest.main()
