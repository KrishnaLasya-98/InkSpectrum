import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import build_indian_narration as voice


class VoiceSafetyTests(unittest.TestCase):
    def test_rejects_reference_without_listening_approval(self):
        with tempfile.TemporaryDirectory() as tmp:
            ref=Path(tmp)
            (ref/'review-status.json').write_text(json.dumps({'status':'pending'}))
            with patch.object(voice,'REFERENCE',ref), patch.object(voice,'_poll_for_audio') as poll:
                with self.assertRaises(ValueError): voice.locked_voice('test-key')
                poll.assert_not_called()

    def test_mismatched_cache_does_not_submit(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp)
            (folder/'p.receipt.json').write_text(json.dumps({'request':{'prompt':'old'}}))
            with patch.object(voice.requests,'post') as post:
                with self.assertRaises(ValueError):
                    voice.generate_phrase({'id':'p','text':'New words.'},'test-key',{'model_id':'qwen-tts'},folder)
                post.assert_not_called()

    def test_unknown_submission_is_not_resubmitted(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp)
            (folder/'p.receipt.json').write_text(json.dumps({'request':{'prompt':'Hello.','model_id':'qwen-tts'},'status':'submission-uncertain'}))
            with patch.object(voice.requests,'post') as post:
                with self.assertRaises(RuntimeError):
                    voice.generate_phrase({'id':'p','text':'Hello.'},'test-key',{'model_id':'qwen-tts'},folder)
                post.assert_not_called()

    def test_rejects_overlong_prompt_before_submission(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(voice.requests,'post') as post:
            with self.assertRaises(ValueError):
                voice.generate_phrase({'id':'p','text':'x'*1001},'test-key',{'model_id':'qwen-tts'},Path(tmp))
            post.assert_not_called()


if __name__ == '__main__': unittest.main()
