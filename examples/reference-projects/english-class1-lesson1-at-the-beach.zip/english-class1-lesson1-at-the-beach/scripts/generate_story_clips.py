"""Generate or resume source-aligned story clips for English Class 1 Lesson 1."""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from dotenv import load_dotenv


PROJECT = Path(__file__).resolve().parents[1]
OPENMONTAGE = PROJECT.parents[1]
sys.path.insert(0, str(OPENMONTAGE))

load_dotenv(OPENMONTAGE / ".env")

from tools.video.modelslab_video import ModelsLabVideo  # noqa: E402
from tools.video.agnes_video import AgnesVideo  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scene", action="append", help="Scene ID; repeat for several scenes")
    parser.add_argument(
        "--provider",
        choices=("agnes", "modelslab"),
        default="agnes",
    )
    parser.add_argument(
        "--model",
        choices=(
            "agnes-video-v2.0",
            "agnes-video-2.5",
            "agnes-video-2.5-flash",
            "h3-minimax-r2v",
            "wan-2.2-i2v",
        ),
    )
    parser.add_argument("--force", action="store_true")
    parser.add_argument(
        "--submit-only",
        action="store_true",
        help="Submit provider jobs and record request IDs without waiting for completion",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    os.environ.setdefault("OPENMONTAGE_ALLOW_NETWORK", "1")
    plan_path = PROJECT / "artifacts" / "media_plan.json"
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    requested = set(args.scene or [])
    scenes = [s for s in plan["scenes"] if not requested or s["id"] in requested]
    missing = requested - {s["id"] for s in scenes}
    if missing:
        raise SystemExit(f"Unknown scene IDs: {', '.join(sorted(missing))}")

    identity_reference = PROJECT / plan["identity_reference"]
    model = args.model or (
        "agnes-video-2.5" if args.provider == "agnes" else "h3-minimax-r2v"
    )
    if args.provider == "agnes" and not model.startswith("agnes-"):
        raise SystemExit("Agnes provider requires an agnes-video model")
    if args.provider == "modelslab" and model.startswith("agnes-"):
        raise SystemExit("ModelsLab provider requires a ModelsLab model")
    generator = AgnesVideo() if args.provider == "agnes" else ModelsLabVideo()
    failures = 0
    jobs_path = PROJECT / "artifacts" / "provider_jobs.json"
    if jobs_path.exists():
        jobs_payload = json.loads(jobs_path.read_text(encoding="utf-8"))
    else:
        jobs_payload = {"version": "1.0", "jobs": []}

    for scene in scenes:
        keyframe = PROJECT / scene["keyframe"]
        output = PROJECT / scene["output"]
        output.parent.mkdir(parents=True, exist_ok=True)
        if output.exists() and output.stat().st_size > 0 and not args.force:
            print(f"SKIP {scene['id']}: {output}")
            continue

        common = {
            "prompt": scene["prompt"],
            "negative_prompt": plan["negative_prompt"],
            "model_id": model,
            "duration": str(scene["duration"]),
            "output_path": str(output),
        }
        if args.submit_only and args.provider == "modelslab":
            common["submit_only"] = True
        if args.provider == "agnes":
            common.update(
                {
                    "operation": "image_to_video",
                    "image_path": str(keyframe),
                    "resolution": "1080P" if model == "agnes-video-2.5" else "720P",
                    "aspect_ratio": "16:9",
                }
            )
        elif model == "h3-minimax-r2v":
            common.update(
                {
                    "operation": "reference_to_video",
                    "resolution": "768P",
                    "reference_image_paths": [str(keyframe), str(identity_reference)],
                }
            )
        else:
            common.update(
                {
                    "operation": "image_to_video",
                    "image_path": str(keyframe),
                    "fps": 18,
                    "num_frames": 90,
                }
            )

        result = generator.execute(common)
        if result.success:
            data = result.data or {}
            if data.get("request_id"):
                jobs_payload["jobs"] = [
                    job
                    for job in jobs_payload["jobs"]
                    if not (
                        job.get("scene_id") == scene["id"]
                        and job.get("provider") == args.provider
                        and job.get("model_id") == model
                    )
                ]
                jobs_payload["jobs"].append(
                    {
                        "scene_id": scene["id"],
                        "provider": args.provider,
                        "model_id": model,
                        "request_id": data["request_id"],
                        "poll_endpoint": data.get("poll_endpoint", "video"),
                        "status": data.get("status", "processing"),
                        "output": str(output.relative_to(PROJECT)).replace("\\", "/"),
                    }
                )
                jobs_path.write_text(json.dumps(jobs_payload, indent=2), encoding="utf-8")
                print(f"SUBMITTED {scene['id']}: {data['request_id']}")
            else:
                print(f"OK {scene['id']}: {output}")
        else:
            failures += 1
            print(f"FAIL {scene['id']}: {result.error}")

    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
