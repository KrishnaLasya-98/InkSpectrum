"""Check completed phrases while provider generation continues; shares the final ASR cache."""
import hashlib
import argparse
import json
from pathlib import Path
from faster_whisper import WhisperModel
from align_narration import word_error_rate
from build_paced_narration import OUT,PLAN,read_pcm,write_json

parser=argparse.ArgumentParser()
parser.add_argument('--audio-candidate',type=Path,default=OUT)
parser.add_argument('--plan',type=Path,default=PLAN)
args=parser.parse_args()
OUT=args.audio_candidate; PLAN=args.plan
plan=json.loads(PLAN.read_text(encoding='utf-8'))
model=WhisperModel('small.en',device='cpu',compute_type='int8')
for section in plan['sections'][:8]:
    for phrase in section['phrases']:
        file=OUT/'phrases'/(phrase['id']+'.wav')
        if not file.exists():continue
        signal=read_pcm(file)
        digest=hashlib.sha256(file.read_bytes()).hexdigest()
        cache=OUT/'phrases'/(phrase['id']+'.asr.json')
        asr_config={'model':'small.en','language':'en','vad_filter':False,'initial_prompt':None,'beam_size':5}
        previous=json.loads(cache.read_text()) if cache.exists() else {}
        if previous.get('audio_sha256')==digest and previous.get('asr_config')==asr_config:continue
        segments,_=model.transcribe(str(file),language='en',word_timestamps=True,vad_filter=False,condition_on_previous_text=False,beam_size=5)
        segments=list(segments)
        words=[{'word':w.word.strip(),'start':round(w.start,3),'end':round(w.end,3),'probability':round(w.probability,4)} for s in segments for w in s.words or []]
        transcript=' '.join(s.text.strip() for s in segments)
        write_json(cache,{'audio_sha256':digest,'asr_config':asr_config,'transcript':transcript,'words':words})
        wer=word_error_rate(phrase['text'],transcript.replace('sand castle','sandcastle'))
        print(f"{phrase['id']} WER={wer:.2f}: {transcript}",flush=True)
