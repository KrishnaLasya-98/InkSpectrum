"""Generate clean chapter narration with a verified ModelsLab built-in voice."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[1]
OPENMONTAGE = PROJECT.parents[1]
sys.path.insert(0, str(OPENMONTAGE))

from tools.voice.voice_synthesis_pipeline import VoiceSynthesisPipeline  # noqa: E402


BLOCK_TYPES = {
    "story": "concept",
    "explanation": "concept",
    "glossary": "glossary",
    "assessment": "qa_item",
    "activity": "activity",
    "life_skills": "concept",
}


def main() -> int:
    os.environ.setdefault("OPENMONTAGE_ALLOW_NETWORK", "1")
    script = json.loads(
        (PROJECT / "artifacts" / "narration_script.json").read_text(encoding="utf-8")
    )
    segments = [
        {
            "section_id": section["id"],
            "text": section["narration"],
            "source_block_type": BLOCK_TYPES.get(section["mode"], "concept"),
        }
        for section in script["sections"]
    ]
    result = VoiceSynthesisPipeline().execute(
        {
            "narration_segments": segments,
            "output_dir": str(PROJECT / "assets" / "audio" / "narration-clean"),
            "language": "indian english",
            "voice_id": "sophia",
            "model_id": "text-to-speech",
            "speed": 0.88,
            "enable_stt_qa": False,
            "seed": 1081,
        }
    )
    if not result.success:
        print(f"FAIL: {result.error}")
        return 1
    manifest_path = PROJECT / "artifacts" / "narration_manifest.json"
    manifest_path.write_text(
        json.dumps(result.data["narration_manifest"], indent=2),
        encoding="utf-8",
    )
    qa_path = PROJECT / "artifacts" / "narration_qa.json"
    qa_path.write_text(json.dumps(result.data["qa_report"], indent=2), encoding="utf-8")
    print(f"OK: {manifest_path}")
    print(f"QA: {qa_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
