"""Offline regression checks for narration planning and cache safety."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import build_paced_narration as delivery
import create_delivery_sample as synthesis

class DeliveryTests(unittest.TestCase):
    def test_listening_approval_is_bound_to_exact_audio_and_text(self):
        decision={'phrase_id':'S14-03','expected':'Hello!','audio_sha256':'abc','decision':'approved-pronunciation'}
        self.assertIsNotNone(delivery.listening_approval([decision],'S14-03','Hello!','abc'))
        self.assertIsNone(delivery.listening_approval([decision],'S14-03','Hello!','changed'))
        self.assertIsNone(delivery.listening_approval([decision],'S14-03','Different!','abc'))

    def test_equivalence_does_not_hide_wrong_content(self):
        self.assertEqual(delivery.spoken_equivalence('Sand Castle 26'), 'sandcastle twenty six')
        self.assertNotEqual(delivery.spoken_equivalence('Varun'),delivery.spoken_equivalence('Veron'))
        self.assertNotEqual(delivery.spoken_equivalence('they'),delivery.spoken_equivalence('I'))
        self.assertNotEqual(delivery.spoken_equivalence('Makes'),delivery.spoken_equivalence('Make'))
        self.assertEqual(delivery.spoken_equivalence('Colour your favourite picture. Practise in your note book.'),
                         delivery.spoken_equivalence('Color your favorite picture. Practice in your notebook.'))
        self.assertEqual(delivery.spoken_equivalence('Matt Knapp'), 'mat nap')

    def test_zero_duration_word_uses_measured_alternate_inside_neighbours(self):
        source=[{'word':'a','start':0,'end':.2},{'word':'van','start':.8,'end':.8},{'word':'rat','start':1.1,'end':1.4}]
        alternate=[{'word':'van','start':.5,'end':.75,'probability':.8}]
        words,changes=delivery.repair_short_word_timings(source,alternate,2)
        self.assertEqual((words[1]['start'],words[1]['end']),(.5,.75))
        self.assertEqual(len(changes),1)
        self.assertEqual(source[1]['start'],.8)

    def test_timing_fallback_never_crosses_neighbours_or_changes_wrong_word(self):
        source=[{'word':'a','start':0,'end':.4},{'word':'van','start':.8,'end':.8}]
        for alternate in [[{'word':'van','start':.2,'end':.7,'probability':.9}],
                          [{'word':'man','start':.5,'end':.7,'probability':.9}]]:
            words,changes=delivery.repair_short_word_timings(source,alternate,1)
            self.assertEqual(words,source)
            self.assertEqual(changes,[])

    def test_all_sections_preserve_script_except_declared_edits(self):
        plan=delivery.make_plan()
        self.assertEqual(len(plan['sections']),26)
        self.assertEqual(plan,delivery.make_plan())
        self.assertTrue(all(s['phrases'] for s in plan['sections']))
        ids=[p['id'] for s in plan['sections'] for p in s['phrases']]
        self.assertEqual(len(ids),len(set(ids)))

    def test_questions_have_thinking_time(self):
        plan=delivery.make_plan()
        section=next(s for s in plan['sections'] if s['id']=='S12')
        questions=[p for p in section['phrases'] if p['text'].endswith('?')]
        self.assertEqual(len(questions),3)
        self.assertTrue(all(p['pause_after']>=2.5 for p in questions))

    def test_word_equations_pause_before_answer(self):
        plan=delivery.make_plan()
        for sid,count in [('S20',4),('S21',6)]:
            section=next(s for s in plan['sections'] if s['id']==sid)
            answers=[i for i,p in enumerate(section['phrases']) if p['text'].startswith('Makes ')]
            self.assertEqual(len(answers),count)
            for i in answers:
                self.assertGreaterEqual(section['phrases'][i-1]['pause_after'],2)

    def test_cache_settings_mismatch_never_calls_provider(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)
            (path/'test.provider-audio').write_bytes(b'cached')
            (path/'test.receipt.json').write_text(json.dumps({'request':{'voice_id':'different'}}))
            with patch.object(synthesis,'OUT',path),patch.object(synthesis.requests,'post') as post:
                with self.assertRaisesRegex(RuntimeError,'Cached request differs'):
                    synthesis.generate({'id':'test','text':'Hello there.','pause_after':1},'unused')
                post.assert_not_called()

if __name__=='__main__': unittest.main()
