"""Recover accepted ModelsLab jobs that outlive a local polling session."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from dotenv import load_dotenv


PROJECT = Path(__file__).resolve().parents[1]
OPENMONTAGE = PROJECT.parents[1]
sys.path.insert(0, str(OPENMONTAGE))
load_dotenv(OPENMONTAGE / ".env")

from tools.video._modelslab_shared import (  # noqa: E402
    download_modelslab_output,
    poll_modelslab,
)


def main() -> int:
    os.environ.setdefault("OPENMONTAGE_ALLOW_NETWORK", "1")
    api_key = os.environ.get("MODELSLAB_API_KEY", "")
    if not api_key:
        raise SystemExit("MODELSLAB_API_KEY is not configured")
    jobs_path = PROJECT / "artifacts" / "provider_jobs.json"
    payload = json.loads(jobs_path.read_text(encoding="utf-8"))
    failed = 0
    for job in payload["jobs"]:
        if job["status"] == "complete":
            continue
        try:
            result = poll_modelslab(
                job["request_id"],
                api_key,
                endpoint="video",
                timeout=1800,
                interval=10,
            )
            output = PROJECT / job["output"]
            download_modelslab_output(result, output)
            job["status"] = "complete"
            print(f"OK {job['scene_id']}: {output}")
        except Exception as exc:  # noqa: BLE001
            failed += 1
            job["status"] = "still-processing-or-failed"
            job["last_error"] = str(exc)
            print(f"WAIT {job['scene_id']}: {exc}")
    jobs_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
