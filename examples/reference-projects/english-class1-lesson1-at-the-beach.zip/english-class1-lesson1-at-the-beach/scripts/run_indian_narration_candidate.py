"""Run the approved-voice candidate and local QA; never promote or render."""
from datetime import datetime, timezone
from pathlib import Path
import subprocess
import sys
from build_paced_narration import write_json

PROJECT = Path(__file__).resolve().parents[1]
OUT = PROJECT/'assets/audio/narration-indian-qwen-v4'


def status(stage, **extra):
    write_json(OUT/'pipeline-status.json',{'stage':stage,'updated_at':datetime.now(timezone.utc).isoformat(),
        'production_audio_replaced':False,**extra})


if __name__ == '__main__':
    try:
        status('generating-approved-voice',sections_expected=26,phrases_expected=133)
        subprocess.run([sys.executable,str(PROJECT/'scripts/build_indian_narration.py'),'generate'],check=True,cwd=PROJECT)
        status('running-unprompted-word-qa')
        subprocess.run([sys.executable,str(PROJECT/'scripts/build_indian_narration.py'),'align'],check=True,cwd=PROJECT)
        status('checking-spoken-cue-motion-coverage')
        subprocess.run([sys.executable,str(PROJECT/'scripts/audit_story_coverage.py'),'--audio-candidate',str(OUT)],check=True,cwd=PROJECT)
        status('generation-and-automated-qa-complete-listening-review-required')
    except subprocess.CalledProcessError as exc:
        status('stopped-review-required',exit_code=exc.returncode)
        raise SystemExit(exc.returncode)
