"""Apply audited narration revisions, reusing only exact same-chapter voice requests.

Preserves v4 and the live preview. Changed text cannot inherit old timestamps.
"""
import argparse
import copy
import hashlib
import json
import shutil
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import build_paced_narration as paced
import build_indian_narration as qwen

PROJECT=Path(__file__).resolve().parents[1]
REVISION=PROJECT/'artifacts/narration_revision_v5.json'
OUT=PROJECT/'assets/audio/narration-indian-qwen-v5'
PLAN=PROJECT/'artifacts/narration_delivery_v5.json'
BASE=PROJECT/'assets/audio/narration-indian-qwen-v4'


def make_plan():
    edits=json.loads(REVISION.read_text(encoding='utf-8'))
    original=json.loads((PROJECT/'artifacts'/edits['base_plan']).read_text(encoding='utf-8'))
    plan=copy.deepcopy(original)
    plan.update(version=5,status='candidate-not-production',revision_sha256=hashlib.sha256(REVISION.read_bytes()).hexdigest())
    known={p['id'] for s in plan['sections'] for p in s['phrases']}
    if (set(edits['replace_phrases'])|set(edits['remove_teacher_only_phrases']))-known:
        raise ValueError('Revision references an unknown phrase')
    for section in plan['sections']:
        revised=[]
        for phrase in section['phrases']:
            if phrase['id'] in edits['remove_teacher_only_phrases']:continue
            if phrase['id'] in edits['replace_phrases']:
                phrase['previous_text']=phrase['text']
                phrase['text']=edits['replace_phrases'][phrase['id']]
            phrase['pause_after']=edits['pause_overrides'].get(phrase['id'],phrase['pause_after'])
            revised.append(phrase)
        section['phrases']=revised
        section['narration']=' '.join(p['text'] for p in revised)
        section.update(edits['source_heading_overrides'].get(section['id'],{}))
    OUT.mkdir(parents=True,exist_ok=True)
    if PLAN.exists() and json.loads(PLAN.read_text(encoding='utf-8'))!=plan:
        raise ValueError('Existing revision differs; use a new candidate version')
    paced.write_json(PLAN,plan)
    original_cues=json.loads((PROJECT/'hyperframes-final/story-cues.json').read_text(encoding='utf-8'))
    original_cues['sections'].update(edits['story_cue_overrides'])
    paced.write_json(OUT/'story-cues.json',original_cues)
    return plan


def reuse_exact(plan):
    reused=0
    directory=OUT/'phrases'; directory.mkdir(exist_ok=True)
    for s in plan['sections']:
        for p in s['phrases']:
            receipt_path=BASE/'phrases'/(p['id']+'.receipt.json')
            if not receipt_path.exists():continue
            receipt=json.loads(receipt_path.read_text(encoding='utf-8'))
            if receipt['request']!={**plan['voice'],'prompt':p['text']}:continue
            # Immutable receipts and audio are copied; no prior chapter or other voice is used.
            for suffix in ['provider-audio','receipt.json','asr.json']:
                source=BASE/'phrases'/(p['id']+'.'+suffix)
                dest=directory/source.name
                if source.exists() and not dest.exists():shutil.copyfile(source,dest)
            reused+=1
    return reused


def main():
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['plan','generate','align'])
    args=parser.parse_args();plan=make_plan()
    paced.OUT=OUT; paced.PLAN=PLAN
    if args.mode=='generate':
        review=json.loads((BASE/'continuity-sample/review.json').read_text(encoding='utf-8'))
        if review.get('decision')!='approved':raise ValueError('Voice continuity approval missing')
        key=qwen._api_key()
        if qwen.locked_voice(key)!=plan['voice']:raise ValueError('Voice reference drift')
        reused=reuse_exact(plan)
        tasks=[p for s in plan['sections'] for p in s['phrases']]
        print(f'{len(tasks)} phrases; {reused} exact cached requests; {len(tasks)-reused} revised requests',flush=True)
        with ThreadPoolExecutor(max_workers=2) as pool:
            results={p['id']:p for p in pool.map(lambda p:qwen.generate_phrase(p,key,plan['voice'],OUT/'phrases'),tasks)}
        paced.assemble(plan,plan['sections'],results)
    elif args.mode=='align':paced.align(plan)
    else:print(f"Revised plan: {len(plan['sections'])} sections",flush=True)


if __name__=='__main__':main()
