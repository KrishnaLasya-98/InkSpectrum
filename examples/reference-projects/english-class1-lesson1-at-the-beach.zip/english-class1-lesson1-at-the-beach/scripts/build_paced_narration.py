"""Isolated, resumable narration candidate: source text -> phrasing -> audio -> unprompted QA.

Never modifies production audio, source script, or current HyperFrames timing.
"""
from __future__ import annotations
import argparse
import hashlib
import html
import json
import re
import subprocess
import wave
from difflib import SequenceMatcher
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
import create_delivery_sample as synthesis

PROJECT = Path(__file__).resolve().parents[1]
OUT = PROJECT / 'assets/audio/narration-tara-v3'
PLAN = PROJECT / 'artifacts/narration_delivery_v3.json'

# Only teacher delivery changes. The displayed textbook wording stays untouched.
EDITS = {
    'S11': [('The intended answer is true.', 'True.')],
    'S14': [('Grade I.', 'Grade one.')],
    'S24': [('The textbook does not give a word list here, so listen for the words your teacher chooses.',
             'Listen carefully to the words your teacher chooses.')],
    'S25': [('Encourage kids to bring a favourite family story or memory to share with the class.',
             'Bring a favourite family story or memory to share with your class.')],
}

def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')

def phrases_for(section):
    sid, text = section['id'], section['narration']
    if sid == 'S22':
        return [('Read the words aloud.', 1.0), ('Mat, van, rat, dad, nap, at, have, sandcastle.', 1.5),
                ('These are all words having the short a sound.', 1.0),
                ('Say them once more with me: mat, van, rat, dad, nap, at, have, sandcastle.', 2.5)]
    sentences = re.split(r'(?<=[.!?])\s+', text)
    # Never generate a heading letter or interjection as an isolated request.
    grouped = []
    carry = ''
    for sentence in sentences:
        carry = (carry + ' ' + sentence).strip()
        if len(carry.split()) < 3 and not carry.endswith('?'):
            continue
        grouped.append(carry)
        carry = ''
    if carry:
        if grouped: grouped[-1] += ' ' + carry
        else: grouped.append(carry)
    # Split answers away from questions without splitting a natural narrative phrase.
    if sid == 'S10':
        grouped = ['A. Tick the correct sentences.', 'Varun and Vidya go to a picnic with their family. Is that correct?',
                   'No. They go to the beach.', 'They build a sandcastle on the beach.', 'Correct.',
                   'They decorate the sandcastle with a shell.', 'Correct.', 'Vidya has a shovel and a bucket.', 'Correct.']
    if sid == 'S11':
        grouped = ['B. Tick whether the following statements are true or false.',
                   'They build a castle with clay.', 'False.', 'They went to the beach with their parents.',
                   'True.', 'Grandpa and Grandma tells us stories.', 'True.']
    result = []
    for i, phrase in enumerate(grouped):
        pause = .65 if section['mode'] == 'story' else .9
        if phrase.endswith('?'): pause = 2.5 if section['mode'] != 'story' else 1.0
        if sid in {'S10','S11'} and i % 2 == 1: pause = 2.5
        if sid == 'S15' and 'blank' in phrase: pause = 2.5
        if sid in {'S18','S23','S26'}: pause = 1.4
        if sid in {'S20','S21'} and ' makes ' in phrase:
            question, answer = phrase.split(' makes ', 1)
            result.extend([(question + '.', 2.0), ('Makes ' + answer, 1.1)])
            continue
        result.append((phrase, pause))
    if result: result[-1] = (result[-1][0], max(result[-1][1], 1.0))
    return result

def make_plan(voice=None, version=3, accent='not independently verified'):
    original = json.loads((PROJECT / 'artifacts/narration_script.json').read_text(encoding='utf-8'))
    sections = []
    for source in original['sections']:
        section = dict(source)
        for before, after in EDITS.get(section['id'], []):
            if before not in section['narration']: raise ValueError('Source edit anchor missing')
            section['narration'] = section['narration'].replace(before, after)
        phrases = phrases_for(section)
        expected = re.findall(r'\w+', section['narration'].lower())
        actual = re.findall(r'\w+', ' '.join(p[0] for p in phrases).lower())
        if expected != actual: raise ValueError(f"Phrase content changed: {section['id']}")
        section['phrases'] = [{'id': f"{section['id']}-{i+1:02d}", 'text': text, 'pause_after': pause}
                              for i, (text, pause) in enumerate(phrases)]
        # Punctuation follows the actual phrase delivery, not stale source timing.
        section['narration'] = ' '.join(p['text'] for p in section['phrases'])
        section['delivery_edits'] = [list(edit) for edit in EDITS.get(section['id'], [])]
        sections.append(section)
    plan = {'version': version, 'status': 'candidate-not-production', 'voice': voice or {'voice_id':'Tara','language':'en','speed':.8,'emotion':True},
            'accent': accent, 'source_script_sha256':hashlib.sha256((PROJECT/'artifacts/narration_script.json').read_bytes()).hexdigest(),
            'leading_seconds':.25, 'sections':sections}
    OUT.mkdir(parents=True, exist_ok=True)
    if PLAN.exists() and json.loads(PLAN.read_text(encoding='utf-8')) != plan:
        raise ValueError('Existing candidate plan differs; create a versioned candidate instead of overwriting')
    write_json(PLAN, plan)
    print(f"Plan: {len(sections)} sections, {sum(len(s['phrases']) for s in sections)} phrases", flush=True)
    return plan

def read_pcm(path):
    with wave.open(str(path), 'rb') as f:
        if f.getparams()[:3] != (1,2,48000): raise ValueError('Unexpected PCM format')
        return np.frombuffer(f.readframes(f.getnframes()), dtype='<i2').copy()

def spoken_equivalence(text):
    # Orthographic variants only: do not normalize names, pronouns, or wrong content words.
    text=re.sub(r'\bsand castle\b','sandcastle',text.lower())
    text=re.sub(r'\bnote book\b','notebook',text)
    # Matt/mat and Knapp/nap are exact English homophones, unlike Varun/Lauren.
    spelling={'colour':'color','favourite':'favorite','practise':'practice','matt':'mat','knapp':'nap'}
    text=re.sub(r'\b(?:colour|favourite|practise|matt|knapp)\b',lambda m:spelling[m.group()],text)
    numbers={'1':'one','3':'three','5':'five','21':'twenty one','26':'twenty six'}
    return re.sub(r'\b(?:26|21|1|3|5)\b',lambda m:numbers[m.group()],text)


def repair_short_word_timings(mapped, alternate, duration):
    """Use independently measured matching words, never invented equal spacing.

    Only repair sub-80-ms words inside their existing neighbours. Inserted or
    differently recognized words cannot supply a timing. Full ASR discrepancies
    remain in text QA; this function does not approve the alternate transcript.
    """
    def norm(word):return re.sub(r'[^a-z0-9]','',spoken_equivalence(word))
    matcher=SequenceMatcher(a=[norm(w['word']) for w in mapped],
        b=[norm(w['word']) for w in alternate],autojunk=False)
    matches={a+k:b+k for a,b,n in matcher.get_matching_blocks() for k in range(n)}
    revised=[dict(w) for w in mapped];repairs=[]
    for index,word in enumerate(revised):
        if word['end']-word['start']>=.08 or index not in matches:continue
        replacement=alternate[matches[index]]
        lo=revised[index-1]['end'] if index else 0
        hi=revised[index+1]['start'] if index+1<len(revised) else duration
        start,end=replacement['start'],replacement['end']
        if not 0<=lo<=start<end<=min(hi,duration) or end-start<.08:continue
        repairs.append({'word':word['word'],'before':[word['start'],word['end']],
            'after':[start,end],'basis':'independent base.en ASR exact/homophone word match'})
        word.update(start=start,end=end,timing_origin='base.en measured fallback',probability=replacement['probability'])
    return revised,repairs


def listening_approval(decisions,phrase_id,text,audio_sha256):
    return next((d for d in decisions if d.get('phrase_id')==phrase_id and d.get('expected')==text
        and d.get('audio_sha256')==audio_sha256 and d.get('decision')=='approved-pronunciation'),None)

def generate(plan, selected):
    synthesis.OUT = OUT / 'phrases'
    synthesis.OUT.mkdir(parents=True, exist_ok=True)
    synthesis.VOICE_SETTINGS = plan['voice']
    key = synthesis._api_key()
    sections = [s for s in plan['sections'] if not selected or s['id'] in selected]
    tasks = [p for s in sections for p in s['phrases']]
    with ThreadPoolExecutor(max_workers=2) as pool:
        generated = {p['id']: p for p in pool.map(lambda p: synthesis.generate(p,key), tasks)}
    assemble(plan,sections,generated)

def assemble(plan,sections,generated=None):
    if generated is None:
        generated={}
        for s in sections:
            for p in s['phrases']:
                file=OUT/'phrases'/(p['id']+'.wav')
                receipt=json.loads((OUT/'phrases'/(p['id']+'.receipt.json')).read_text(encoding='utf-8'))
                expected={'model_id':'text-to-speech','prompt':p['text'],**plan['voice']}
                if receipt['request']!=expected: raise ValueError('Audio cache provenance mismatch')
                generated[p['id']]={**p,'file':str(file),'samples':len(read_pcm(file)),'settings':expected}
    manifests = []
    for s in sections:
        parts = [np.zeros(round(plan['leading_seconds']*48000),dtype='<i2')]
        cursor = len(parts[0])
        receipts = []
        for p in s['phrases']:
            result = generated[p['id']]
            signal = read_pcm(result['file'])
            receipts.append({**result, 'offset_seconds':cursor/48000})
            gap = np.zeros(round(p['pause_after']*48000),dtype='<i2')
            parts.extend([signal,gap]); cursor += len(signal)+len(gap)
        raw = OUT / (s['id']+'.unmastered.wav')
        with wave.open(str(raw),'wb') as f:
            f.setparams((1,2,48000,0,'NONE','not compressed')); f.writeframes(np.concatenate(parts).tobytes())
        dest = OUT / (s['id']+'.wav')
        subprocess.run(['ffmpeg','-y','-v','error','-i',str(raw),'-af','loudnorm=I=-16:TP=-1.5:LRA=7',
                        '-ar','48000','-ac','1','-c:a','pcm_s16le',str(dest)],check=True)
        manifests.append({'section_id':s['id'],'text':s['narration'],'audio_path':str(dest),
                          'duration_seconds':len(read_pcm(dest))/48000,'phrases':receipts})
        write_json(OUT/(s['id']+'.manifest.json'),manifests[-1])
    all_manifests = [OUT/(s['id']+'.manifest.json') for s in plan['sections']]
    if all(p.exists() for p in all_manifests):
        manifests = [json.loads(p.read_text(encoding='utf-8')) for p in all_manifests]
        write_json(OUT/'narration_manifest.json',{'status':'candidate','segments':manifests})
        # Audio review artifact only; not a final rendered video.
        with wave.open(str(OUT/'chapter-review.wav'),'wb') as f:
            f.setparams((1,2,48000,0,'NONE','not compressed'))
            for s in manifests: f.writeframes(read_pcm(s['audio_path']).tobytes())
        subprocess.run(['ffmpeg','-y','-v','error','-i',str(OUT/'chapter-review.wav'),'-b:a','192k',str(OUT/'chapter-review.mp3')],check=True)
        print(f"Full candidate: {sum(s['duration_seconds'] for s in manifests):.2f}s",flush=True)

def align(plan):
    from faster_whisper import WhisperModel
    from align_narration import align_source_words, word_error_rate
    model = WhisperModel('small.en',device='cpu',compute_type='int8')
    decision_path=PROJECT/'artifacts/narration-listening-decisions.json'
    decisions=json.loads(decision_path.read_text(encoding='utf-8'))['decisions'] if decision_path.exists() else []
    results=[]; audits=[]
    for s in plan['sections']:
        section_path=OUT/(s['id']+'.manifest.json')
        if not section_path.exists(): continue
        manifest=json.loads(section_path.read_text(encoding='utf-8'))
        pcm=read_pcm(manifest['audio_path'])
        audio_health={'sample_rate':48000,'channels':1,'duration_seconds':round(len(pcm)/48000,4),
                      'peak_dbfs':round(float(20*np.log10(max(1,int(np.abs(pcm.astype(np.int32)).max()))/32768)),2),
                      'clipped_samples':int((np.abs(pcm.astype(np.int32))>=32767).sum()),
                      'audio_sha256':hashlib.sha256(Path(manifest['audio_path']).read_bytes()).hexdigest()}
        source_words=[]; measured_all=[]; transcripts=[]; phrase_qa=[]
        for p in manifest['phrases']:
            cache=OUT/'phrases'/(p['id']+'.asr.json')
            digest=hashlib.sha256(Path(p['file']).read_bytes()).hexdigest()
            result=json.loads(cache.read_text(encoding='utf-8')) if cache.exists() else {}
            asr_config={'model':'small.en','language':'en','vad_filter':False,'initial_prompt':None,'beam_size':5}
            if result.get('audio_sha256') != digest or result.get('asr_config') != asr_config:
                # Short, already-trimmed phrases can lose soft initial words under VAD.
                segments,_=model.transcribe(p['file'],language='en',word_timestamps=True,vad_filter=False,condition_on_previous_text=False,beam_size=5)
                segments=list(segments)
                words=[{'word':w.word.strip(),'start':round(w.start,3),'end':round(w.end,3),'probability':round(w.probability,4)} for seg in segments for w in seg.words or []]
                result={'audio_sha256':digest,'asr_config':asr_config,'transcript':' '.join(seg.text.strip() for seg in segments),'words':words}
                write_json(cache,result)
            measured=result['words']; transcript=result['transcript']
            primary_transcript=transcript;recognizer='small.en'
            alternate_path=OUT/'phrases'/(p['id']+'.base-asr.json')
            alternate=json.loads(alternate_path.read_text(encoding='utf-8')) if alternate_path.exists() else {}
            if alternate.get('audio_sha256')!=digest or alternate.get('asr_config',{}).get('initial_prompt') is not None:
                alternate={}
            if alternate and word_error_rate(spoken_equivalence(p['text']),spoken_equivalence(transcript))>0:
                if word_error_rate(spoken_equivalence(p['text']),spoken_equivalence(alternate['transcript']))==0:
                    measured=alternate['words'];transcript=alternate['transcript'];recognizer='base.en'
            # Keep every lexical discrepancy visible; a low overall WER can hide a wrong pronoun.
            raw_wer=word_error_rate(p['text'],transcript)
            wer=word_error_rate(spoken_equivalence(p['text']),spoken_equivalence(transcript))
            mapped=align_source_words(p['text'],measured)
            offset=p['offset_seconds']; duration=p['samples']/48000
            mapped,timing_repairs=repair_short_word_timings(mapped,alternate.get('words',[]),duration)
            issues=[]
            for w in mapped:
                if w['end']<=w['start'] or w['start']<0 or w['end']>duration+.02:
                    issues.append(w['word'])
                w['start']=round(w['start']+offset,3); w['end']=round(w['end']+offset,3)
            source_words.extend(mapped)
            measured_all.extend([{**w,'start':round(w['start']+offset,3),'end':round(w['end']+offset,3)} for w in measured])
            transcripts.append(transcript)
            approval=listening_approval(decisions,p['id'],p['text'],digest)
            phrase_qa.append({'id':p['id'],'expected':p['text'],'transcript':transcript,'primary_transcript':primary_transcript,
                              'selected_recognizer':recognizer,'timing_repairs':timing_repairs,
                              'wer':round(wer,4),'raw_wer':round(raw_wer,4),'timing_issues':issues,
                              'listening_approval':approval,
                              'status':'review' if issues or (wer>0 and not approval) else ('user-approved-pronunciation' if approval else 'recognized')})
        results.append({'section_id':s['id'],'audio_path':manifest['audio_path'],'duration_seconds':manifest['duration_seconds'],
                        'source_text':s['narration'],'source_words':source_words,'transcribed_words':measured_all,'transcript':' '.join(transcripts)})
        audits.append({'section_id':s['id'],'audio_health':audio_health,'phrases':phrase_qa,'review_count':sum(p['status']=='review' for p in phrase_qa)})
        write_json(OUT/'word_alignment.json',{'timestamp_basis':'phrase-local ASR plus measured PCM offsets','sections':results})
        write_json(OUT/'alignment_qa.json',{'listening_review':'not completed','initial_prompt':None,'sections':audits})
        print(f"{s['id']}: {audits[-1]['review_count']} phrases need review",flush=True)
    write_review(plan, audits)

def write_review(plan, audits):
    """Local human-listening report. Recognized words are not a quality approval."""
    by_id={s['section_id']:s for s in audits}
    cards=[]
    for section in plan['sections']:
        audit=by_id.get(section['id'])
        if not audit: continue
        phrase_cards=[]
        for p in audit['phrases']:
            phrase_cards.append(f"<details class='{p['status']}'><summary>{html.escape(p['id'])} — {html.escape(p['status'])}</summary>"
                f"<p><b>Script:</b> {html.escape(p['expected'])}</p><p><b>Recognized:</b> {html.escape(p['transcript'])}</p>"
                f"<p>Word error rate: {p['wer']:.1%}; timing flags: {html.escape(', '.join(p['timing_issues'])) or 'none'}</p>"
                f"<audio controls preload='none' src='phrases/{p['id']}.wav'></audio></details>")
        cards.append(f"<section><h2>{section['id']} · {html.escape(section['heading'])}</h2>"
                     f"<audio controls preload='none' src='{section['id']}.wav'></audio>"
                     f"<p>{html.escape(section['narration'])}</p>{''.join(phrase_cards)}</section>")
    document="""<!doctype html><meta charset='utf-8'><title>English narration candidate review</title>
<style>body{max-width:1000px;margin:40px auto;padding:0 24px;font:18px/1.6 system-ui;color:#17384b;background:#f5f8f6}section{background:white;border-radius:18px;padding:28px;margin:24px 0}audio{width:100%}details{padding:12px;margin:8px 0;border:1px solid #b9d7c9;border-radius:10px}.review{border-color:#bc5c35;background:#fff4e9}summary{cursor:pointer}h1,h2{line-height:1.25}.notice{padding:18px;background:#ffeabb;border-radius:12px}</style>
<h1>At the Beach — narration candidate</h1><p class='notice'>Candidate, not final production audio. Voice warmth, accent and names require listening. Automated recognition cannot approve pronunciation or naturalness. Orange items need investigation.</p>
"""+("<h2>Full chapter audio</h2><audio controls preload='metadata' src='chapter-review.mp3'></audio>" if (OUT/'chapter-review.mp3').exists() else '<p>Full chapter audio is still generating.</p>')+''.join(cards)
    (OUT/'listening-review.html').write_text(document,encoding='utf-8')

if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('mode',choices=['plan','generate','assemble','align']); parser.add_argument('--sections',nargs='*')
    args=parser.parse_args(); plan=make_plan()
    if args.mode=='generate':
        review_path=OUT/'voice-review.json'
        if review_path.exists() and json.loads(review_path.read_text(encoding='utf-8')).get('decision')=='rejected-for-production':
            raise SystemExit('Voice rejected by user. Generate and approve a short replacement sample first.')
        generate(plan,args.sections)
    if args.mode=='assemble': assemble(plan,[s for s in plan['sections'] if not args.sections or s['id'] in args.sections])
    if args.mode=='align': align(plan)
