"""Compare untrimmed provider audio with prepared PCM without VAD or script hints."""
import argparse
import json
from pathlib import Path
from faster_whisper import WhisperModel
from build_paced_narration import write_json

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--audio-candidate',type=Path,required=True)
    parser.add_argument('--phrases',nargs='+',required=True)
    args=parser.parse_args()
    model=WhisperModel('small.en',device='cpu',compute_type='int8')
    results=[]
    for pid in args.phrases:
        row={'id':pid,'vad_filter':False,'initial_prompt':None}
        for label,suffix in [('provider','provider-audio'),('prepared','wav')]:
            file=args.audio_candidate/'phrases'/f'{pid}.{suffix}'
            segments,_=model.transcribe(str(file),language='en',word_timestamps=True,
                vad_filter=False,condition_on_previous_text=False,beam_size=5)
            segments=list(segments)
            row[label]={'transcript':' '.join(s.text.strip() for s in segments),
                'words':[{'word':w.word.strip(),'start':w.start,'end':w.end} for s in segments for w in s.words or []]}
        results.append(row)
        print(f"{pid}: provider={row['provider']['transcript']} | prepared={row['prepared']['transcript']}",flush=True)
    write_json(args.audio_candidate/'onset-diagnostics.json',{'status':'diagnostic-not-approval','phrases':results})
