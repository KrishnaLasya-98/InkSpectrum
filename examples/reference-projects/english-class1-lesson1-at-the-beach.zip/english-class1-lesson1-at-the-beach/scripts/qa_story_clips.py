"""Run technical and sampled-frame QA on every planned story clip."""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw


PROJECT = Path(__file__).resolve().parents[1]
PLAN_PATH = PROJECT / "artifacts" / "media_plan.json"
OUT = PROJECT / "artifacts" / "qa" / "story-clips"
FRAMES = OUT / "frames"
SAMPLE_TIMES = (0.35, 1.35, 2.35, 3.35, 4.35)


def command(*parts: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        list(parts), check=True, capture_output=True, text=True, encoding="utf-8"
    )


def probe(path: Path) -> dict:
    result = command(
        "ffprobe",
        "-v",
        "error",
        "-show_entries",
        "format=duration,size",
        "-show_entries",
        "stream=index,codec_type,codec_name,width,height,r_frame_rate,pix_fmt,sample_rate,channels",
        "-of",
        "json",
        str(path),
    )
    return json.loads(result.stdout)


def all_frame_metrics(path: Path) -> dict:
    width, height = 192, 108
    proc = subprocess.Popen(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-i",
            str(path),
            "-an",
            "-vf",
            f"scale={width}:{height}",
            "-pix_fmt",
            "gray",
            "-f",
            "rawvideo",
            "-",
        ],
        stdout=subprocess.PIPE,
    )
    assert proc.stdout is not None
    frame_size = width * height
    previous = None
    changes: list[float] = []
    dark: list[float] = []
    while True:
        raw = proc.stdout.read(frame_size)
        if len(raw) != frame_size:
            break
        frame = np.frombuffer(raw, dtype=np.uint8).reshape(height, width)
        dark.append(float((frame < 16).mean()))
        if previous is not None:
            changes.append(
                float(
                    np.abs(frame.astype(np.int16) - previous.astype(np.int16)).mean()
                )
            )
        previous = frame
    proc.wait()
    array = np.array(changes or [0.0])
    dark_array = np.array(dark or [1.0])
    return {
        "frames_read": len(dark),
        "temporal_change_mean": round(float(array.mean()), 5),
        "temporal_change_p05": round(float(np.percentile(array, 5)), 5),
        "near_static_frame_pairs": int((array < 0.08).sum()),
        "max_dark_fraction": round(float(dark_array.max()), 5),
        "nearly_black_frames": int((dark_array > 0.98).sum()),
    }


def sample_frames(scene_id: str, path: Path) -> list[Path]:
    outputs: list[Path] = []
    for index, second in enumerate(SAMPLE_TIMES):
        output = FRAMES / f"{scene_id}-{index + 1}.jpg"
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-hide_banner",
                "-loglevel",
                "error",
                "-ss",
                str(second),
                "-i",
                str(path),
                "-frames:v",
                "1",
                "-vf",
                "scale=320:180",
                "-q:v",
                "2",
                str(output),
            ],
            check=True,
        )
        outputs.append(output)
    return outputs


def contact_sheets(rows: list[tuple[str, list[Path]]]) -> list[str]:
    outputs: list[str] = []
    for page, start in enumerate(range(0, len(rows), 5), start=1):
        batch = rows[start : start + 5]
        sheet = Image.new("RGB", (5 * 320, len(batch) * 205), (244, 241, 232))
        draw = ImageDraw.Draw(sheet)
        for row, (scene_id, paths) in enumerate(batch):
            for column, path in enumerate(paths):
                image = Image.open(path).convert("RGB")
                sheet.paste(image, (column * 320, row * 205))
            draw.text((8, row * 205 + 184), scene_id, fill=(15, 42, 55))
        output = OUT / f"contact-sheet-{page}.jpg"
        sheet.save(output, quality=92)
        outputs.append(str(output.relative_to(PROJECT)).replace("\\", "/"))
    return outputs


def main() -> int:
    plan = json.loads(PLAN_PATH.read_text(encoding="utf-8"))
    OUT.mkdir(parents=True, exist_ok=True)
    FRAMES.mkdir(parents=True, exist_ok=True)
    clips: list[dict] = []
    rows: list[tuple[str, list[Path]]] = []
    for scene in plan["scenes"]:
        path = PROJECT / scene["output"]
        if not path.is_file() or path.stat().st_size == 0:
            clips.append(
                {"id": scene["id"], "path": scene["output"], "status": "missing"}
            )
            continue
        technical = probe(path)
        metrics = all_frame_metrics(path)
        streams = technical.get("streams", [])
        video = next((item for item in streams if item.get("codec_type") == "video"), {})
        audio = next((item for item in streams if item.get("codec_type") == "audio"), None)
        duration = float(technical.get("format", {}).get("duration", 0.0))
        status = "pass"
        issues: list[str] = []
        if duration < 4.5:
            status = "review"
            issues.append("short_duration")
        if metrics["nearly_black_frames"]:
            status = "review"
            issues.append("black_frames")
        if metrics["near_static_frame_pairs"] > max(4, metrics["frames_read"] // 5):
            status = "review"
            issues.append("possible_freeze_or_low_motion")
        samples = sample_frames(scene["id"], path)
        rows.append((scene["id"], samples))
        clips.append(
            {
                "id": scene["id"],
                "path": scene["output"],
                "status": status,
                "issues": issues,
                "duration_seconds": round(duration, 4),
                "width": video.get("width"),
                "height": video.get("height"),
                "fps": video.get("r_frame_rate"),
                "codec": video.get("codec_name"),
                "native_audio_present": audio is not None,
                **metrics,
            }
        )
    sheets = contact_sheets(rows)
    report = {
        "version": "1.0",
        "planned": len(plan["scenes"]),
        "present": sum(item.get("status") != "missing" for item in clips),
        "technical_pass": sum(item.get("status") == "pass" for item in clips),
        "needs_review": sum(item.get("status") == "review" for item in clips),
        "native_audio_policy": "discard generated clip audio during composition",
        "contact_sheets": sheets,
        "clips": clips,
    }
    (OUT / "technical_qa.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )
    print(json.dumps({key: report[key] for key in ("planned", "present", "technical_pass", "needs_review", "contact_sheets")}, indent=2))
    return 0 if report["present"] == report["planned"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
