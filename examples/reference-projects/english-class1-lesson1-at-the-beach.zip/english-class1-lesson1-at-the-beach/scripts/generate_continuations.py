"""Resume-safe, bounded four-shot continuation batch using the existing adapter.

Receipts never contain API keys or unfiltered provider errors. A submission with
an uncertain outcome is blocked, not automatically repeated.
"""
import hashlib
import json
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from dotenv import load_dotenv
from build_paced_narration import write_json

PROJECT=Path(__file__).resolve().parents[1]
REPO=PROJECT.parents[1]
sys.path.insert(0,str(REPO))
from tools.video.modelslab_video import ModelsLabVideo
from tools.video._modelslab_shared import poll_modelslab, download_modelslab_output


def run_scene(scene,plan):
    receipt_path=PROJECT/'artifacts/continuation-jobs-v5'/(scene['id']+'.json')
    receipt_path.parent.mkdir(parents=True,exist_ok=True)
    seed=PROJECT/scene['keyframe']
    output=PROJECT/'assets/video/continuations-v5'/scene['output_name']
    normalized=PROJECT/'assets/video/normalized'/scene['output_name']
    request={'operation':'image_to_video','image_path':str(seed),'model_id':plan['model'],
        'prompt':scene['prompt'],'negative_prompt':plan['negative_prompt'],
        'fps':18,'num_frames':90,'duration':'5','submit_only':True,'output_path':str(output)}
    digest=hashlib.sha256(seed.read_bytes()).hexdigest()
    receipt=json.loads(receipt_path.read_text(encoding='utf-8')) if receipt_path.exists() else None
    if receipt and (receipt['request']!=request or receipt['seed_sha256']!=digest):
        raise ValueError(f"{scene['id']}: request/reference drift")
    generator=ModelsLabVideo()
    if not receipt:
        receipt={'request':request,'seed_sha256':digest,'status':'submitting'}
        write_json(receipt_path,receipt)
        result=generator.execute(request)
        if not result.success or not (result.data or {}).get('request_id'):
            receipt['status']='submission-uncertain';write_json(receipt_path,receipt)
            raise RuntimeError(f"{scene['id']}: no acknowledged job; not resubmitting")
        receipt.update(request_id=result.data['request_id'],status='processing',poll_endpoint=result.data['poll_endpoint'])
        write_json(receipt_path,receipt)
        print(f"{scene['id']}: submitted job {receipt['request_id']}",flush=True)
    if receipt['status'] in {'submitting','submission-uncertain'}:
        raise RuntimeError(f"{scene['id']}: uncertain submission requires investigation")
    if not output.exists():
        try:
            data=poll_modelslab(receipt['request_id'],generator._get_api_key(),endpoint=receipt['poll_endpoint'],timeout=900)
            download_modelslab_output(data,output)
        except Exception:
            print(f"{scene['id']}: output not retrieved; saved job retained for resume",flush=True)
            return False
        receipt.update(status='downloaded',output_sha256=hashlib.sha256(output.read_bytes()).hexdigest())
        write_json(receipt_path,receipt)
    if not normalized.exists():
        command=['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(output),'-an','-vf',
            'crop=trunc(ih*16/9/2)*2:ih,minterpolate=fps=30:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1,scale=1920:1080:flags=lanczos,format=yuv420p',
            '-c:v','libx264','-preset','medium','-crf','17','-movflags','+faststart',str(normalized)]
        subprocess.run(command,check=True)
    probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(normalized)],text=True))
    if len(probe['streams'])!=1 or probe['streams'][0]['codec_type']!='video':raise ValueError('Unexpected generated audio stream')
    receipt.update(status='normalized-awaiting-visual-qa',normalized=str(normalized),
        normalized_sha256=hashlib.sha256(normalized.read_bytes()).hexdigest(),duration_seconds=float(probe['format']['duration']))
    write_json(receipt_path,receipt)
    print(f"{scene['id']}: normalized {receipt['duration_seconds']:.3f}s; visual QA pending",flush=True)
    return True


def main():
    load_dotenv(REPO/'.env');os.environ.setdefault('OPENMONTAGE_ALLOW_NETWORK','1')
    plan=json.loads((PROJECT/'artifacts/continuation-media-v5.json').read_text(encoding='utf-8'))
    with ThreadPoolExecutor(max_workers=2) as pool:
        results=list(pool.map(lambda s:run_scene(s,plan),plan['scenes']))
    return 0 if all(results) else 1


if __name__=='__main__':raise SystemExit(main())
