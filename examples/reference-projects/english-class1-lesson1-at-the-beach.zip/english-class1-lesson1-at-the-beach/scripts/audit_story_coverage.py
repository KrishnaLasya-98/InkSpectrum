"""Fail-closed media capacity plan from spoken cues; never loops or extends frozen frames."""
import argparse
import json
import re
import subprocess
from pathlib import Path

PROJECT=Path(__file__).resolve().parents[1]
def tokens(value): return re.findall(r'[a-z0-9]+',value.lower().replace("'",'').replace('’',''))
def cue_start(words,phrase):
    needle=tokens(phrase)
    for i in range(len(words)):
        if [(tokens(w['word']) or [''])[0] for w in words[i:i+len(needle)]]==needle:
            return words[i]['start']
    raise ValueError(f'Missing speech cue: {phrase}')

def main():
    parser=argparse.ArgumentParser()
    group=parser.add_mutually_exclusive_group()
    group.add_argument('--candidate',action='store_true',help='Historical Tara candidate only')
    group.add_argument('--audio-candidate',type=Path,help='Candidate folder containing measured word_alignment.json')
    args=parser.parse_args()
    candidate=bool(args.candidate or args.audio_candidate)
    root=args.audio_candidate.resolve() if args.audio_candidate else (PROJECT/'assets/audio/narration-tara-v3' if args.candidate else PROJECT/'artifacts')
    aligned=json.loads((root/'word_alignment.json').read_text(encoding='utf-8'))
    sections={s['section_id']:s for s in aligned['sections']}
    cue_path=(root/'story-cues.json') if (root/'story-cues.json').exists() else PROJECT/'hyperframes-final/story-cues.json'
    cue_data=json.loads(cue_path.read_text(encoding='utf-8'))['sections']
    output=[]
    for sid,cues in cue_data.items():
        if sid not in sections: continue
        section=sections[sid]
        starts=[0 if i==0 else cue_start(section['source_words'],c['anchor']) for i,c in enumerate(cues)]
        if starts!=sorted(starts): raise ValueError(f'Out of order cues: {sid}')
        audio_path=Path(section['audio_path']) if candidate else PROJECT/'hyperframes-final/assets/audio'/f'{sid}.wav'
        audio_duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(audio_path)],text=True))
        ends=starts[1:]+[audio_duration]
        for i,c in enumerate(cues):
            file=PROJECT/'assets/video/normalized'/c['file']
            duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(file)],text=True))
            required=ends[i]-starts[i]+(.16 if i==0 else .32)
            output.append({'section':sid,'file':c['file'],'anchor':c.get('anchor','section start'),
                           'start':round(starts[i],3),'end':round(ends[i],3),'slot_with_transition_seconds':round(required,3),
                           'source_seconds':duration,'minimum_speed_if_full_clip':round(duration/required,3),
                           'extra_motion_needed_at_085x':round(max(0,required-duration/.85),3),
                           'status':'needs_supplement' if required>duration/.85 else 'covered'})
    report={'candidate':candidate,'alignment_source':str(root/'word_alignment.json'),
            'status':'planning-not-visual-approval','minimum_allowed_speed':.85,
            'missing_sections':sorted(set(cue_data)-set(sections)),'clips':output}
    target=(root/'story_coverage.json') if args.audio_candidate else PROJECT/'artifacts'/('story_coverage_tara_v3.json' if args.candidate else 'story_coverage_current.json')
    target.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({'clips':len(output),'need_supplement':sum(c['status']=='needs_supplement' for c in output),
                      'additional_seconds':round(sum(c['extra_motion_needed_at_085x'] for c in output),2)}))
if __name__=='__main__':main()
