"""Wait for a complete candidate, then run local QA. No provider calls or promotion."""
import json
import subprocess
import sys
import time
from pathlib import Path

PROJECT=Path(__file__).resolve().parents[1]
OUT=PROJECT/'assets/audio/narration-tara-v3'
status_path=OUT/'pipeline-status.json'
deadline=time.monotonic()+3600
def status(stage,**details):
    status_path.write_text(json.dumps({'stage':stage,'production_audio_replaced':False,**details},indent=2),encoding='utf-8')
    print(stage,flush=True)

status('waiting-for-narration-generation')
while not (OUT/'narration_manifest.json').exists():
    if time.monotonic()>deadline:
        status('generation-incomplete-timeout'); raise SystemExit(1)
    time.sleep(10)
try:
    status('transcribing-and-checking-word-timings')
    subprocess.run([sys.executable,str(PROJECT/'scripts/build_paced_narration.py'),'align'],check=True)
    status('checking-story-media-capacity')
    subprocess.run([sys.executable,str(PROJECT/'scripts/audit_story_coverage.py'),'--candidate'],check=True)
    qa=json.loads((OUT/'alignment_qa.json').read_text(encoding='utf-8'))
    coverage=json.loads((PROJECT/'artifacts/story_coverage_tara_v3.json').read_text(encoding='utf-8'))
    reviews=sum(s['review_count'] for s in qa['sections'])
    supplemental=sum(c['status']=='needs_supplement' for c in coverage['clips'])
    rejected=(OUT/'voice-review.json').exists() and json.loads((OUT/'voice-review.json').read_text(encoding='utf-8')).get('decision')=='rejected-for-production'
    status('voice-rejected-qa-complete' if rejected else 'candidate-ready-for-review',phrases_flagged=reviews,slots_needing_more_motion=supplemental,
           listening_review='accent rejected by user' if rejected else 'pending',final_encode='not-started')
except Exception as exc:
    status('qa-stopped',error_type=type(exc).__name__); raise
