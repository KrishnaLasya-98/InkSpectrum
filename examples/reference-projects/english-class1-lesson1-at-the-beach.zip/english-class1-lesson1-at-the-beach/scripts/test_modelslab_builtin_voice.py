"""Generate a clean built-in ModelsLab voice sample before replacing narration."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[1]
OPENMONTAGE = PROJECT.parents[1]
sys.path.insert(0, str(OPENMONTAGE))

from tools.voice.voice_synthesis_pipeline import VoiceSynthesisPipeline  # noqa: E402


def main() -> int:
    os.environ.setdefault("OPENMONTAGE_ALLOW_NETWORK", "1")
    script = json.loads(
        (PROJECT / "artifacts" / "narration_script.json").read_text(encoding="utf-8")
    )
    section = next(item for item in script["sections"] if item["id"] == "S04")
    result = VoiceSynthesisPipeline().execute(
        {
            "narration_segments": [
                {
                    "section_id": "S04-sophia-test",
                    "text": section["narration"],
                    "source_block_type": "concept",
                }
            ],
            "output_dir": str(PROJECT / "assets" / "audio" / "provider-tests"),
            "language": "indian english",
            "voice_id": "sophia",
            "model_id": "text-to-speech",
            "speed": 0.88,
            "enable_stt_qa": False,
        }
    )
    if not result.success:
        print(f"FAIL: {result.error}")
        return 1
    print(json.dumps(result.data["narration_manifest"]["segments"][0], indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
