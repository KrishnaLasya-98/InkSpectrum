"""Stage a speech-anchored preview; never encode or claim final visual approval."""
import argparse
import hashlib
import json
import shutil
import subprocess
from pathlib import Path
from build_paced_narration import write_json

PROJECT=Path(__file__).resolve().parents[1]


def fit_interval(start,end,source_duration,continuation_duration=None,min_speed=.85):
    required=end-start
    if required<=0:raise ValueError('Invalid visual interval')
    if required<=source_duration:
        return [{'kind':'source','start':start,'end':end,'speed':1}]
    if continuation_duration is not None:
        continuation_start=start+source_duration-.16
        if end-continuation_start>continuation_duration:
            raise ValueError('Continuation still leaves a motion gap')
        return [{'kind':'source','start':start,'end':start+source_duration,'speed':1},
                {'kind':'continuation','start':continuation_start,'end':end,'speed':1}]
    if required<=source_duration/min_speed:
        return [{'kind':'source','start':start,'end':end,'speed':min_speed}]
    raise ValueError('Insufficient motion; never loop or freeze')


def duration(file):
    return float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(file)],text=True))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--candidate',type=Path,required=True)
    args=parser.parse_args();candidate=args.candidate.resolve()
    sync=json.loads((candidate/'sync-plan.json').read_text(encoding='utf-8'))
    if sync['render_blockers']:raise ValueError('Unresolved audio/timing blockers: '+str(sync['render_blockers']))
    supplements=json.loads((PROJECT/'artifacts/continuation-media-v5.json').read_text(encoding='utf-8'))
    continuations={s['source_clip']:s['output_name'] for s in supplements['scenes']}
    # Selected after inspecting all four 3-fps contact sheets; not final encoded QA.
    review=json.loads((PROJECT/'artifacts/continuation-visual-review-v5.json').read_text(encoding='utf-8'))
    if set(review['accepted_scene_ids'])!={s['id'] for s in supplements['scenes']}:
        raise ValueError('Continuation visual review incomplete')
    base=PROJECT/'hyperframes-final';audio_folder=base/'assets/audio'/candidate.name
    video_folder=base/'assets/video/story-v6'
    audio_folder.mkdir(parents=True,exist_ok=True);video_folder.mkdir(parents=True,exist_ok=True)
    sections={};used=set();manifest=[]
    for section in sync['sections']:
        source_audio=Path(section['audio_path']);staged_audio=audio_folder/source_audio.name
        shutil.copyfile(source_audio,staged_audio)
        sections[section['id']]=[]
        cues=section['story_cues']
        for i,cue in enumerate(cues):
            file=cue['file'];original=PROJECT/'assets/video/normalized'/file
            if file in used:raise ValueError('Unapproved repeated clip: '+file)
            used.add(file)
            start=cue['global_start_seconds']
            end=cues[i+1]['global_start_seconds'] if i+1<len(cues) else section['end_seconds']
            # Shorter 200-ms dissolve only at the tight playroom boundaries.
            left_handle=.10 if file in {'s06b-playroom-v1.mp4','s07a-staircase-v1.mp4'} else .16
            right_handle=.10 if section['id']=='S06' else .16
            start=max(0,start-left_handle);end=end+right_handle
            extra=PROJECT/'assets/video/normalized'/continuations[file] if file in continuations else None
            slots=fit_interval(start,end,duration(original),duration(extra) if extra else None)
            for slot in slots:
                source=extra if slot['kind']=='continuation' else original
                filename=source.name if slot['speed']==1 else source.stem+'-paced-v6b.mp4'
                dest=video_folder/filename
                source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
                receipt_path=video_folder/(filename+'.json')
                expected={'source_sha256':source_hash,'speed':slot['speed']}
                old=json.loads(receipt_path.read_text(encoding='utf-8')) if receipt_path.exists() else None
                if dest.exists() and old!=expected:raise ValueError('Staged media provenance mismatch')
                if not dest.exists():
                    if slot['speed']==1:shutil.copyfile(source,dest)
                    else:
                        # Minterpolate needs look-ahead frames. Pad its input only, then
                        # trim the output to the real retimed source length; do not
                        # extend the story with a frozen tail.
                        target_duration=duration(source)/slot['speed']
                        subprocess.run(['ffmpeg','-y','-v','error','-i',str(source),'-an','-vf',
                            f"setpts=(PTS-STARTPTS)/{slot['speed']},tpad=stop_mode=clone:stop_duration=0.15,minterpolate=fps=30:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1,trim=duration={target_duration},format=yuv420p",
                            '-c:v','libx264','-preset','fast','-crf','17','-movflags','+faststart',str(dest)],check=True)
                    write_json(receipt_path,expected)
                staged_duration=duration(dest)
                if staged_duration+1/30<slot['end']-slot['start']:raise ValueError('Staged clip is too short')
                sections[section['id']].append({'id':f"{section['id'].lower()}-clip-{len(sections[section['id']])+1}",
                    'src':str(dest.relative_to(base)).replace('\\','/'),'startMs':round(slot['start']*1000),
                    'endMs':round(slot['end']*1000),'fadeMs':160 if slot['kind']=='continuation' else min(240,round((left_handle+right_handle)*1000)),
                    'source':str(source),'source_sha256':source_hash,'playback_speed':slot['speed'],'staged_duration_seconds':staged_duration})
                manifest.append({'section_id':section['id'],'file':str(dest),'duration_seconds':staged_duration,'speed':slot['speed']})
        print(f"Staged {section['id']}: {len(sections[section['id']])} clips",flush=True)
    flattened=[c for clips in sections.values() for c in clips]
    for index,clip in enumerate(flattened):
        overlap=flattened[index-1]['endMs']-clip['startMs'] if index else 0
        if index and overlap<0:raise ValueError('Uncovered visual gap')
        clip['fadeMs']=min(240,overlap) if index else 0
    report={'status':'preview-staged-not-rendered','audio_candidate':str(candidate),
        'audio_base':str(audio_folder.relative_to(base)).replace('\\','/'),'sections':sections,'media':manifest}
    write_json(candidate/'composition-coverage.json',report)


if __name__=='__main__':main()
