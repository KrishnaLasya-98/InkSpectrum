"""Extract labeled section-boundary and named-cue frames from an encoded video."""

from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


def extract_frame(video: Path, timestamp: float, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [
            "ffmpeg",
            "-v",
            "error",
            "-ss",
            f"{timestamp:.6f}",
            "-i",
            str(video),
            "-frames:v",
            "1",
            "-q:v",
            "2",
            "-y",
            str(output),
        ],
        check=True,
    )


def make_sheet(items: list[dict], output: Path, columns: int = 4) -> None:
    thumb_width, thumb_height, label_height = 480, 270, 38
    rows = (len(items) + columns - 1) // columns
    sheet = Image.new("RGB", (columns * thumb_width, rows * (thumb_height + label_height)), "white")
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 19)
    for index, item in enumerate(items):
        image = Image.open(item["path"]).convert("RGB")
        image.thumbnail((thumb_width, thumb_height), Image.Resampling.LANCZOS)
        x = (index % columns) * thumb_width
        y = (index // columns) * (thumb_height + label_height)
        sheet.paste(image, (x, y))
        draw.text((x + 8, y + thumb_height + 7), item["label"], fill="black", font=font)
    output.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output, quality=92, subsampling=0)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--video", type=Path, required=True)
    parser.add_argument("--sync-plan", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    plan = json.loads(args.sync_plan.read_text(encoding="utf-8"))
    args.out.mkdir(parents=True, exist_ok=True)

    boundary_items = []
    for index, section in enumerate(plan["sections"], start=1):
        timestamp = min(section["end_seconds"] - 0.05, section["start_seconds"] + 0.25)
        path = args.out / "section-boundaries" / f"{index:02d}-{section['id']}.jpg"
        extract_frame(args.video, timestamp, path)
        boundary_items.append(
            {
                "path": path,
                "label": f"{section['id']} {section['heading']} @ {timestamp:.2f}s",
            }
        )

    cue_items = []
    cue_index = 0
    for section in plan["sections"]:
        for cue in section.get("story_cues", []):
            cue_index += 1
            timestamp = min(section["end_seconds"] - 0.05, cue["global_start_seconds"] + 0.30)
            path = args.out / "named-cues" / f"{cue_index:02d}-{section['id']}.jpg"
            extract_frame(args.video, timestamp, path)
            anchor = cue.get("anchor", "section start")
            cue_items.append(
                {
                    "path": path,
                    "label": f"{section['id']} {anchor[:34]} @ {timestamp:.2f}s",
                }
            )

    make_sheet(boundary_items, args.out / "section-boundaries.jpg")
    make_sheet(cue_items, args.out / "named-cues.jpg")
    manifest = {
        "video": str(args.video.resolve()),
        "section_boundaries": len(boundary_items),
        "named_story_cues": len(cue_items),
        "capture_offset_seconds": 0.30,
        "status": "generated-for-human-review",
    }
    (args.out / "visual-qa-manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(manifest))


if __name__ == "__main__":
    main()
