"""Six delivery edits only; preserve all other approved-voice material byte for byte."""
import argparse
import copy
import hashlib
import json
import shutil
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import build_paced_narration as paced
import build_indian_narration as qwen

PROJECT=Path(__file__).resolve().parents[1]
REVISION=PROJECT/'artifacts/narration_revision_v6.json'
OUT=PROJECT/'assets/audio/narration-indian-qwen-v6'
PLAN=PROJECT/'artifacts/narration_delivery_v6.json'


def make_plan():
    revision=json.loads(REVISION.read_text(encoding='utf-8'))
    plan=copy.deepcopy(json.loads((PROJECT/'artifacts'/revision['base_plan']).read_text(encoding='utf-8')))
    plan.update(version=6,revision_sha256=hashlib.sha256(REVISION.read_bytes()).hexdigest())
    seen=set()
    for section in plan['sections']:
        for p in section['phrases']:
            if p['id'] in revision['replacements']:
                p['previous_text']=p['text'];p['text']=revision['replacements'][p['id']];seen.add(p['id'])
        section['narration']=' '.join(p['text'] for p in section['phrases'])
    if seen!=set(revision['replacements']):raise ValueError('Unknown phrase revision')
    if PLAN.exists() and json.loads(PLAN.read_text(encoding='utf-8'))!=plan:raise ValueError('Plan drift: create a new version')
    OUT.mkdir(parents=True,exist_ok=True);paced.write_json(PLAN,plan)
    return plan,revision


def main():
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['generate','align'])
    args=parser.parse_args();plan,revision=make_plan();paced.OUT=OUT;paced.PLAN=PLAN
    if args.mode=='align':paced.align(plan);return
    base=PROJECT/'assets/audio'/revision['base_candidate'];directory=OUT/'phrases';directory.mkdir(exist_ok=True)
    for name in ['story-cues.json','intro-review.json']:
        if not (OUT/name).exists():shutil.copyfile(base/name,OUT/name)
    for section in plan['sections']:
        for p in section['phrases']:
            if p['id'] in revision['replacements']:continue
            receipt=json.loads((base/'phrases'/(p['id']+'.receipt.json')).read_text(encoding='utf-8'))
            if receipt['request']!={**plan['voice'],'prompt':p['text']}:raise ValueError('Exact audio provenance differs')
            for suffix in ['provider-audio','wav','receipt.json','asr.json','base-asr.json']:
                origin=base/'phrases'/(p['id']+'.'+suffix);target=directory/origin.name
                if origin.exists() and not target.exists():shutil.copyfile(origin,target)
    key=qwen._api_key()
    if qwen.locked_voice(key)!=plan['voice']:raise ValueError('Voice lock drift')
    tasks=[p for s in plan['sections'] for p in s['phrases'] if p['id'] in revision['replacements']]
    with ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(lambda p:qwen.generate_phrase(p,key,plan['voice'],directory),tasks))
    paced.assemble(plan,plan['sections'])


if __name__=='__main__':main()
