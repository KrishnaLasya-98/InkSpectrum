"""One bounded, versioned repair pass; preserve the approved intro and v5 audio.

No script or voice changes. Eight fresh requests plus one exact, approved sample
replacement. Pending provider requests are resumed, never blindly resubmitted.
"""
import argparse
import hashlib
import json
import shutil
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import build_paced_narration as paced
import build_indian_narration as qwen

PROJECT=Path(__file__).resolve().parents[1]
BASE=PROJECT/'assets/audio/narration-indian-qwen-v5'
OUT=PROJECT/'assets/audio/narration-indian-qwen-v5-repair1'
PLAN=PROJECT/'artifacts/narration_delivery_v5.json'
REGENERATE={'S10-01','S12-01','S14-03','S14-05','S20-04','S20-06','S20-08','S21-12'}
APPROVED_REUSE={'S04-03':'story-3'}


def prepare(plan):
    directory=OUT/'phrases';directory.mkdir(parents=True,exist_ok=True)
    record={'source_plan_sha256':hashlib.sha256(PLAN.read_bytes()).hexdigest(),
        'base_candidate':str(BASE),'regenerate':sorted(REGENERATE),'approved_sample_reuse':APPROVED_REUSE,
        'reason':'Repeated independent ASR discrepancies; replacement candidates still require QA',
        'voice_and_script_changed':False,'production_audio_replaced':False}
    repair=OUT/'repair-plan.json'
    if repair.exists() and json.loads(repair.read_text(encoding='utf-8'))!=record:
        raise ValueError('Repair plan changed; create a new version')
    paced.write_json(repair,record)
    for name in ['story-cues.json','intro-review.json']:
        if (BASE/name).exists() and not (OUT/name).exists():shutil.copyfile(BASE/name,OUT/name)
    sample=qwen.OUT/'continuity-sample'
    if json.loads((sample/'review.json').read_text(encoding='utf-8')).get('decision')!='approved':
        raise ValueError('Voice continuity approval missing')
    for s in plan['sections']:
        for p in s['phrases']:
            if p['id'] in REGENERATE:continue
            origin=sample if p['id'] in APPROVED_REUSE else BASE/'phrases'
            origin_id=APPROVED_REUSE.get(p['id'],p['id'])
            receipt=json.loads((origin/(origin_id+'.receipt.json')).read_text(encoding='utf-8'))
            if receipt['request']!={**plan['voice'],'prompt':p['text']}:
                raise ValueError('Exact source/voice provenance mismatch')
            for suffix in ['provider-audio','wav','asr.json','base-asr.json']:
                source=origin/(origin_id+'.'+suffix);dest=directory/(p['id']+'.'+suffix)
                if source.exists() and not dest.exists():shutil.copyfile(source,dest)
            target=directory/(p['id']+'.receipt.json')
            if not target.exists():
                paced.write_json(target,{**receipt,'reused_from':str(origin/(origin_id+'.provider-audio')),
                    'source_sha256':qwen.digest(origin/(origin_id+'.provider-audio'))})


def main():
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['generate','align'])
    args=parser.parse_args();plan=json.loads(PLAN.read_text(encoding='utf-8'))
    paced.OUT=OUT;paced.PLAN=PLAN
    if args.mode=='align':paced.align(plan);return
    prepare(plan)
    key=qwen._api_key()
    if qwen.locked_voice(key)!=plan['voice']:raise ValueError('Approved voice changed')
    tasks=[p for s in plan['sections'] for p in s['phrases'] if p['id'] in REGENERATE]
    print(f'Repair pass: {len(tasks)} provider requests; remaining phrases use exact cached approved-voice audio',flush=True)
    with ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(lambda p:qwen.generate_phrase(p,key,plan['voice'],OUT/'phrases'),tasks))
    paced.assemble(plan,plan['sections'])


if __name__=='__main__':main()
