import unittest
from prepare_candidate_sync import anchor_time
from audit_story_coverage import cue_start


class SyncTests(unittest.TestCase):
    def test_punctuation_and_case(self):
        words=[{'word':'Hello,','start':1},{'word':'Vidya!','start':2}]
        self.assertEqual(anchor_time(words,'hello vidya'),1)

    def test_repeated_answers_require_correct_occurrence(self):
        words=[{'word':'True','start':1},{'word':'or','start':2},{'word':'false','start':3},
               {'word':'True.','start':9},{'word':'True.','start':15}]
        self.assertEqual(anchor_time(words,'true',1),9)
        self.assertEqual(anchor_time(words,'true',2),15)

    def test_missing_anchor_fails_instead_of_even_spacing(self):
        with self.assertRaises(ValueError): anchor_time([{'word':'hello','start':0}],'unspoken')

    def test_empty_anchor_fails(self):
        with self.assertRaises(ValueError): anchor_time([], '')

    def test_contracted_story_cue(self):
        words=[{'word':"Let's",'start':2},{'word':'join','start':2.4},{'word':'Varun','start':2.7}]
        self.assertEqual(cue_start(words,"Let's join"),2)

    def test_answer_is_bounded_to_its_question(self):
        words=[{'word':'correct','start':1},{'word':'Correct.','start':9},{'word':'Correct.','start':15}]
        self.assertEqual(anchor_time(words,'Correct',after=5,before=12),9)
        self.assertEqual(anchor_time(words,'Correct',after=12,before=20),15)
        with self.assertRaises(ValueError): anchor_time(words,'Correct',after=16,before=20)


if __name__=='__main__':unittest.main()
