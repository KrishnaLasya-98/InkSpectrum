"""Reference-locked Qwen narration. No fallback voice and no production promotion.

ModelsLab contract: https://modelslab.com/models/modelslab/qwen-tts/llms.txt
Only the original, user-approved synthetic voice is used as a reference.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import subprocess
import shutil
import wave
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
import requests
import build_paced_narration as paced
from create_delivery_sample import PHRASES, _api_key, _download, _poll_for_audio

PROJECT = Path(__file__).resolve().parents[1]
REFERENCE = PROJECT / 'assets/audio/delivery-review-indian-qwen-v1'
OUT = PROJECT / 'assets/audio/narration-indian-qwen-v4'
PLAN = PROJECT / 'artifacts/narration_delivery_v4.json'
ENDPOINT = 'https://modelslab.com/api/v6/voice/text_to_audio'


def reuse_exact_approved_sample(tasks, voice):
    """Avoid a paid duplicate when this chapter's approved test already spoke the exact line."""
    sample_dir=OUT/'continuity-sample'
    manifest_path=sample_dir/'manifest.json'
    if not manifest_path.exists(): return
    manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
    directory=OUT/'phrases'; directory.mkdir(parents=True,exist_ok=True)
    for phrase in tasks:
        settings={**voice,'prompt':phrase['text']}
        raw=directory/(phrase['id']+'.provider-audio')
        if raw.exists(): continue
        for sample_phrase in manifest['phrases']:
            if sample_phrase['settings'] != settings: continue
            source=sample_dir/(sample_phrase['id']+'.provider-audio')
            source_receipt=json.loads((sample_dir/(sample_phrase['id']+'.receipt.json')).read_text(encoding='utf-8'))
            receipt_path=directory/(phrase['id']+'.receipt.json')
            previous=json.loads(receipt_path.read_text(encoding='utf-8')) if receipt_path.exists() else None
            if previous and previous.get('status') not in {'error','failed'}:
                continue # Do not overwrite pending or uncertain provider work.
            if previous and previous.get('request')!=settings:
                raise ValueError('Existing phrase receipt differs')
            shutil.copyfile(source,raw)
            paced.write_json(receipt_path,{'request':settings,'status':'reused-exact-approved-sample',
                'source':str(source),'source_sha256':digest(source),'source_request_id':source_receipt.get('id'),
                'previous_attempt':previous})
            print(f"Reused exact approved line: {phrase['id']}",flush=True)
            break


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def locked_voice(key):
    approval = json.loads((REFERENCE/'review-status.json').read_text(encoding='utf-8'))
    if approval.get('status') != 'user-approved-voice-sample':
        raise ValueError('Reference voice needs user approval')
    expected = {'reference_sha256':digest(REFERENCE/'sample.provider-audio'),
                'approved_wav_sha256':digest(REFERENCE/'indian-english-sample.wav')}
    lock_path = OUT/'voice-lock.json'
    if lock_path.exists():
        lock = json.loads(lock_path.read_text(encoding='utf-8'))
        if any(lock[k] != v for k,v in expected.items()):
            raise ValueError('Approved reference changed; use a new version')
    else:
        receipt = json.loads((REFERENCE/'request.json').read_text(encoding='utf-8'))
        url = _poll_for_audio(str(receipt['request_id']), key)
        if not url:
            raise RuntimeError('Cannot recover original designed voice URL; do not redesign the voice')
        check = OUT/'reference.provider-audio'
        _download(url, check)
        if digest(check) != expected['reference_sha256']:
            raise ValueError('Provider reference differs from approved sample')
        lock = {**expected,'init_audio':url,'origin_request_id':receipt['request_id'],
                'identity':'original synthetic voice approved by user',
                'documentation':'https://modelslab.com/models/modelslab/qwen-tts/llms.txt'}
        paced.write_json(lock_path,lock)
    return {'model_id':'qwen-tts','init_audio':lock['init_audio'],'language':'english'}


def generate_phrase(phrase, key, voice, directory):
    directory.mkdir(parents=True, exist_ok=True)
    raw = directory/(phrase['id']+'.provider-audio')
    receipt_path = directory/(phrase['id']+'.receipt.json')
    settings = {**voice,'prompt':phrase['text']}
    if len(phrase['text']) > 1000:
        raise ValueError('Prompt exceeds documented model limit')
    receipt = json.loads(receipt_path.read_text(encoding='utf-8')) if receipt_path.exists() else None
    if receipt and receipt.get('request') != settings:
        raise ValueError('Cached request mismatch; use new candidate version')
    if raw.exists() and not receipt:
        raise ValueError('Cached audio lacks provenance')
    if not raw.exists():
        # Resume an acknowledged job rather than submit it a second time.
        if not receipt:
            try:
                response = requests.post(ENDPOINT,json={'key':key,**settings},timeout=120)
                data = response.json()
            except requests.RequestException:
                paced.write_json(receipt_path,{'request':settings,'status':'submission-uncertain'})
                raise RuntimeError('Submission outcome unknown; inspect before retrying') from None
            receipt = {'request':settings,'id':data.get('id'),'status':data.get('status'),
                       'http_status':response.status_code}
            if data.get('status') == 'success':
                links = data.get('output') or data.get('url')
                receipt['output_url'] = links[0] if isinstance(links,list) and links else links
            paced.write_json(receipt_path,receipt)
        if receipt['status'] == 'success':
            url = receipt.get('output_url')
        elif receipt['status'] == 'processing' and receipt.get('id'):
            url = _poll_for_audio(str(receipt['id']),key)
        else:
            raise RuntimeError(f"{phrase['id']}: provider status {receipt['status']}; no automatic resubmission")
        if not url:
            raise RuntimeError(f"{phrase['id']}: output pending/unavailable; rerun resumes the same job")
        _download(url,raw)
    pcm = directory/(phrase['id']+'.wav')
    subprocess.run(['ffmpeg','-y','-v','error','-i',str(raw),'-ar','48000','-ac','1','-c:a','pcm_s16le',str(pcm)],check=True)
    signal = paced.read_pcm(pcm)
    active = np.flatnonzero(np.abs(signal.astype(np.int32)) > 140)
    if not len(active):
        raise ValueError('Silent provider output')
    # Preserve onset/offset consonants; deliberate pauses are appended at assembly.
    signal = signal[max(0,int(active[0])-5760):min(len(signal),int(active[-1])+5761)]
    with wave.open(str(pcm),'wb') as f:
        f.setparams((1,2,48000,0,'NONE','not compressed')); f.writeframes(signal.tobytes())
    print(f"Generated {phrase['id']}: {len(signal)/48000:.2f}s",flush=True)
    return {**phrase,'file':str(pcm),'samples':len(signal),'settings':settings}


def sample(key,voice):
    directory = OUT/'continuity-sample'
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(lambda p:generate_phrase(p,key,voice,directory),PHRASES))
    parts = [np.zeros(12000,dtype='<i2')]
    for p in results:
        parts.extend([paced.read_pcm(p['file']),np.zeros(round(p['pause_after']*48000),dtype='<i2')])
    joined = directory/'sample-unmastered.wav'
    with wave.open(str(joined),'wb') as f:
        f.setparams((1,2,48000,0,'NONE','not compressed')); f.writeframes(np.concatenate(parts).tobytes())
    final = directory/'sample.wav'
    subprocess.run(['ffmpeg','-y','-v','error','-i',str(joined),'-af','loudnorm=I=-16:TP=-1.5:LRA=7','-ar','48000','-ac','1',str(final)],check=True)
    subprocess.run(['ffmpeg','-y','-v','error','-i',str(final),'-b:a','192k',str(directory/'sample.mp3')],check=True)
    paced.write_json(directory/'manifest.json',{'status':'continuity-review-required','voice':voice,'phrases':results,
        'duration_seconds':len(paced.read_pcm(final))/48000,'production_audio_replaced':False})
    print(f'Continuity sample: {directory / "sample.mp3"}',flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode',choices=['sample','plan','generate','align'])
    parser.add_argument('--sections',nargs='*')
    args = parser.parse_args()
    OUT.mkdir(parents=True,exist_ok=True)
    key = _api_key()
    voice = locked_voice(key)
    if args.mode == 'sample':
        sample(key,voice); return
    paced.OUT = OUT; paced.PLAN = PLAN
    plan = paced.make_plan(voice=voice,version=4,accent='Indian English; reference sample approved by user')
    if args.mode == 'generate':
        review = OUT/'continuity-sample/review.json'
        if not review.exists() or json.loads(review.read_text(encoding='utf-8')).get('decision') != 'approved':
            raise ValueError('Review reference-conditioned sample before full-chapter generation')
        sections = [s for s in plan['sections'] if not args.sections or s['id'] in args.sections]
        tasks = [p for s in sections for p in s['phrases']]
        reuse_exact_approved_sample(tasks,voice)
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = {p['id']:p for p in pool.map(lambda p:generate_phrase(p,key,voice,OUT/'phrases'),tasks)}
        paced.assemble(plan,sections,results)
    elif args.mode == 'align':
        paced.align(plan)


if __name__ == '__main__':
    main()
