"""Transcribe final narration locally and create measured word timestamps."""
from __future__ import annotations

import json
import re
from difflib import SequenceMatcher
from pathlib import Path

from faster_whisper import WhisperModel


PROJECT = Path(__file__).resolve().parents[1]
MANIFEST_PATH = PROJECT / "artifacts" / "narration_manifest.json"
ALIGNMENT_PATH = PROJECT / "artifacts" / "word_alignment.json"
QA_PATH = PROJECT / "artifacts" / "narration_alignment_qa.json"


def normalized_words(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", text.lower().replace("'", ""))


def source_tokens(text: str) -> list[str]:
    return re.findall(r"[A-Za-z0-9]+(?:'[A-Za-z0-9]+)?", text)


def align_source_words(source: str, measured_words: list[dict]) -> list[dict]:
    """Map measured ASR timings onto the exact approved source words."""
    source_list = source_tokens(source)
    source_norm = [normalized_words(word)[0] for word in source_list]
    measured_norm = [
        (normalized_words(item["word"]) or [""])[0] for item in measured_words
    ]
    aligned: list[dict | None] = [None] * len(source_list)
    matcher = SequenceMatcher(a=source_norm, b=measured_norm, autojunk=False)
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            for source_index, measured_index in zip(range(i1, i2), range(j1, j2)):
                measured = measured_words[measured_index]
                aligned[source_index] = {
                    "word": source_list[source_index],
                    "start": measured["start"],
                    "end": measured["end"],
                    "probability": measured["probability"],
                }
        elif tag in {"replace", "delete"} and i2 > i1:
            if j2 > j1:
                span_start = measured_words[j1]["start"]
                span_end = measured_words[j2 - 1]["end"]
                probability = round(
                    sum(item["probability"] for item in measured_words[j1:j2])
                    / (j2 - j1),
                    4,
                )
            else:
                previous_end = (
                    aligned[i1 - 1]["end"] if i1 and aligned[i1 - 1] else 0.0
                )
                next_start = (
                    measured_words[j1]["start"]
                    if j1 < len(measured_words)
                    else previous_end + 0.25 * (i2 - i1)
                )
                span_start, span_end, probability = previous_end, next_start, 0.5
            step = max(0.04, (span_end - span_start) / (i2 - i1))
            for offset, source_index in enumerate(range(i1, i2)):
                aligned[source_index] = {
                    "word": source_list[source_index],
                    "start": round(span_start + offset * step, 3),
                    "end": round(
                        span_end
                        if source_index == i2 - 1
                        else span_start + (offset + 1) * step,
                        3,
                    ),
                    "probability": probability,
                }
    # Fill any unmatched source token from neighbouring measured timing.
    for index, item in enumerate(aligned):
        if item is not None:
            continue
        previous_end = aligned[index - 1]["end"] if index and aligned[index - 1] else 0.0
        next_start = next(
            (
                candidate["start"]
                for candidate in aligned[index + 1 :]
                if candidate is not None
            ),
            previous_end + 0.25,
        )
        aligned[index] = {
            "word": source_list[index],
            "start": round(previous_end, 3),
            "end": round(max(previous_end + 0.04, next_start), 3),
            "probability": 0.5,
        }
    return [item for item in aligned if item is not None]


def word_error_rate(reference: str, hypothesis: str) -> float:
    expected = normalized_words(reference)
    actual = normalized_words(hypothesis)
    if not expected:
        return 0.0 if not actual else 1.0
    previous = list(range(len(actual) + 1))
    for row, expected_word in enumerate(expected, start=1):
        current = [row]
        for column, actual_word in enumerate(actual, start=1):
            current.append(
                min(
                    current[-1] + 1,
                    previous[column] + 1,
                    previous[column - 1] + (expected_word != actual_word),
                )
            )
        previous = current
    return previous[-1] / len(expected)


def main() -> int:
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    model = WhisperModel("small.en", device="cpu", compute_type="int8")
    aligned_sections: list[dict] = []
    qa_sections: list[dict] = []
    for item in manifest["segments"]:
        audio_path = Path(item["audio_path"])
        segments, info = model.transcribe(
            str(audio_path),
            language="en",
            beam_size=5,
            word_timestamps=True,
            vad_filter=True,
            condition_on_previous_text=False,
            initial_prompt=item["text"],
        )
        words: list[dict] = []
        transcript_parts: list[str] = []
        for segment in segments:
            transcript_parts.append(segment.text.strip())
            for word in segment.words or []:
                clean = word.word.strip()
                if clean:
                    words.append(
                        {
                            "word": clean,
                            "start": round(float(word.start), 3),
                            "end": round(float(word.end), 3),
                            "probability": round(float(word.probability), 4),
                        }
                    )
        transcript = " ".join(part for part in transcript_parts if part).strip()
        wer = round(word_error_rate(item["text"], transcript), 4)
        mean_probability = round(
            sum(word["probability"] for word in words) / max(1, len(words)), 4
        )
        aligned_sections.append(
            {
                "section_id": item["section_id"],
                "audio_path": str(audio_path),
                "duration_seconds": item["duration_seconds"],
                "source_text": item["text"],
                "transcript": transcript,
                "source_words": align_source_words(item["text"], words),
                "transcribed_words": words,
            }
        )
        qa_sections.append(
            {
                "section_id": item["section_id"],
                "wer": wer,
                "mean_word_probability": mean_probability,
                "word_count": len(words),
                "status": "pass" if wer <= 0.12 and mean_probability >= 0.72 else "review",
            }
        )
        print(
            f"{item['section_id']}: WER={wer:.3f} confidence={mean_probability:.3f}",
            flush=True,
        )
    alignment = {
        "version": "1.0",
        "model": "faster-whisper-small.en",
        "timestamp_basis": "measured from final narration audio",
        "sections": aligned_sections,
    }
    qa = {
        "version": "1.0",
        "model": "faster-whisper-small.en",
        "total": len(qa_sections),
        "passed": sum(item["status"] == "pass" for item in qa_sections),
        "review": sum(item["status"] == "review" for item in qa_sections),
        "sections": qa_sections,
    }
    ALIGNMENT_PATH.write_text(json.dumps(alignment, indent=2), encoding="utf-8")
    QA_PATH.write_text(json.dumps(qa, indent=2), encoding="utf-8")
    print(json.dumps({"total": qa["total"], "passed": qa["passed"], "review": qa["review"]}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
