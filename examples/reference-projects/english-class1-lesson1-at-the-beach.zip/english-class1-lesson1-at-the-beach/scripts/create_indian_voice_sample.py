"""One original voice-design sample; no cloning or full-chapter generation."""
import json
import subprocess
import sys
from pathlib import Path
import requests

PROJECT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PROJECT.parents[1]))
from tools.voice.voice_synthesis_pipeline import _api_key,_download,_poll_for_audio

OUT=PROJECT/'assets/audio/delivery-review-indian-qwen-v1'
OUT.mkdir(parents=True,exist_ok=True)
request={
    'model_id':'qwen-voice-design',
    'prompt':'Hey, let us build a sandcastle!\n\nSure! I have a shovel and a bucket too.\n\nVarun and Vidya build a castle together.\n\nWhat do Varun and Vidya do on the beach?\n\nThey build a sandcastle.',
    'voice_description':'An adult Indian female primary-school teacher speaking clear, natural Indian English with an educated neutral Indian accent. Not an American or British accent. Warm, friendly, smiling and gently expressive storytelling for six-year-old children. Natural variations in pitch and emphasis, not a flat robotic reading and not exaggerated sing-song. Calm, unhurried delivery around 100 to 110 words per minute. Distinct sentence pauses and gentle natural breaths. A longer thinking pause after the question before the answer. Pronounce the Indian names Varun and Vidya clearly and naturally. Clean dry speech only, no music or sound effects.',
    'language':'english'
}
receipt=OUT/'request.json'
raw=OUT/'sample.provider-audio'
if receipt.exists() and json.loads(receipt.read_text(encoding='utf-8'))['request']!=request:
    raise RuntimeError('Different request cached; create a new sample version')
if not raw.exists():
    key=_api_key()
    response=requests.post('https://modelslab.com/api/v6/voice/voice_design',json={'key':key,**request},timeout=120)
    response.raise_for_status()
    data=response.json()
    receipt.write_text(json.dumps({'request':request,'provider_status':data.get('status'),'request_id':data.get('id'),
                                  'documentation':'https://modelslab.com/models/modelslab/qwen-voice-design/llms.txt'},indent=2),encoding='utf-8')
    if data.get('status') not in {'success','processing'}:
        # Error messages can echo request credentials; never log the raw response.
        raise RuntimeError(f"Voice design failed: status={data.get('status')}; HTTP={response.status_code}")
    if data.get('status')=='processing' and data.get('id'):
        url=_poll_for_audio(str(data['id']),key)
    else:
        links=data.get('output') or data.get('future_links') or []
        url=links[0] if isinstance(links,list) and links else links
    if not url: raise RuntimeError('No audio URL returned')
    _download(url,raw)
wav=OUT/'indian-english-sample.wav'
mp3=OUT/'indian-english-sample.mp3'
subprocess.run(['ffmpeg','-y','-v','error','-i',str(raw),'-af','loudnorm=I=-16:TP=-1.5:LRA=7','-ar','48000','-ac','1','-c:a','pcm_s16le',str(wav)],check=True)
subprocess.run(['ffmpeg','-y','-v','error','-i',str(wav),'-b:a','192k',str(mp3)],check=True)
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','json',str(mp3)],text=True))
(OUT/'review-status.json').write_text(json.dumps({'status':'awaiting-listening-review','requested_accent':'Indian English',
    'accent_verified':False,'identity':'original designed voice, not a real-person clone','duration_seconds':float(probe['format']['duration']),
    'production_audio_replaced':False,'sample':str(mp3)},indent=2),encoding='utf-8')
print(f"Sample ready: {mp3}; {probe['format']['duration']} seconds",flush=True)
