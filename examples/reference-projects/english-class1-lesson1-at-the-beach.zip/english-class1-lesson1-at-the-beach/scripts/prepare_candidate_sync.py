"""Build a diagnostic speech-anchored timeline; never change the live composition.

Source words are preserved, but approximate ASR mappings are NOT an approval.
Every unresolved text/timing flag stays in the render blockers.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path
from build_paced_narration import read_pcm, write_json

PROJECT=Path(__file__).resolve().parents[1]


def norm(value):
    return re.sub(r'[^a-z0-9]','',value.lower())


def anchor_time(words,phrase,occurrence=0,after=0,before=float('inf')):
    needle=[norm(t) for t in re.findall(r"[A-Za-z0-9]+(?:'[A-Za-z0-9]+)?",phrase)]
    if not needle:
        raise ValueError('Empty spoken anchor')
    hits=[i for i in range(len(words)) if after<=words[i]['start']<before and [norm(w['word']) for w in words[i:i+len(needle)]]==needle]
    if occurrence<0 or occurrence>=len(hits):
        raise ValueError(f'Missing spoken anchor {phrase!r}, occurrence {occurrence}')
    return words[hits[occurrence]]['start']


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--audio-candidate',type=Path,required=True)
    parser.add_argument('--plan',type=Path,required=True)
    args=parser.parse_args()
    folder=args.audio_candidate.resolve()
    plan=json.loads(args.plan.read_text(encoding='utf-8'))
    alignment=json.loads((folder/'word_alignment.json').read_text(encoding='utf-8'))
    manifest=json.loads((folder/'narration_manifest.json').read_text(encoding='utf-8'))
    qa=json.loads((folder/'alignment_qa.json').read_text(encoding='utf-8'))
    aligned={s['section_id']:s for s in alignment['sections']}
    audio={s['section_id']:s for s in manifest['segments']}
    audits={s['section_id']:s for s in qa['sections']}
    teaching=json.loads((PROJECT/'hyperframes-final/teaching-cues.json').read_text(encoding='utf-8'))
    story_path=(folder/'story-cues.json') if (folder/'story-cues.json').exists() else PROJECT/'hyperframes-final/story-cues.json'
    story=json.loads(story_path.read_text(encoding='utf-8'))['sections']
    results=[]; blockers=[]; cursor=0
    for section in plan['sections']:
        sid=section['id']
        if sid not in aligned or sid not in audio or sid not in audits:
            blockers.append(f'{sid}: audio/alignment/QA missing'); continue
        track=audio[sid]; alignment_section=aligned[sid]; audit=audits[sid]
        if alignment_section['source_text'] != section['narration']:
            blockers.append(f'{sid}: alignment script mismatch')
        file=Path(track['audio_path'])
        duration=len(read_pcm(file))/48000
        if abs(duration-track['duration_seconds'])>.002:
            blockers.append(f'{sid}: stale manifest duration')
        if hashlib.sha256(file.read_bytes()).hexdigest()!=audit['audio_health']['audio_sha256']:
            blockers.append(f'{sid}: QA audio hash mismatch')
        if audit['review_count']:
            blockers.append(f"{sid}: {audit['review_count']} unresolved phrase QA flags")
        words=alignment_section['source_words']
        previous_end=0
        for word in words:
            if not 0<=word['start']<word['end']<=duration+.002 or word['start']<previous_end-.002:
                blockers.append(f"{sid}: invalid/overlapping word timing {word['word']}")
            previous_end=word['end']
        entry={'id':sid,'heading':section['heading'],'mode':section['mode'],
            'start_seconds':round(cursor,6),'end_seconds':round(cursor+duration,6),
            'audio_path':str(file),'duration_seconds':duration,'story_cues':[],'teaching_cues':[]}
        for i,cue in enumerate(story.get(sid,[])):
            try:
                start=0 if i==0 else anchor_time(words,cue['anchor'],cue.get('occurrence',0))
                entry['story_cues'].append({**cue,'local_start_seconds':start,'global_start_seconds':round(cursor+start,6)})
            except ValueError as exc:
                blockers.append(f'{sid}: {exc}')
        for i,anchor in enumerate(teaching.get(sid,{}).get('anchors',[])):
            try:
                start=anchor_time(words,anchor)
                cue={'anchor':anchor,'local_start_seconds':start,'global_start_seconds':round(cursor+start,6)}
                answers=teaching[sid].get('answers',[])
                if i<len(answers):
                    answer=answers[i]
                    anchors=teaching[sid]['anchors']
                    end=anchor_time(words,anchors[i+1]) if i+1<len(anchors) else duration
                    at=anchor_time(words,answer['anchor'],after=start,before=end)
                    if at<start: blockers.append(f'{sid}: answer precedes its question')
                    cue.update(answer=answer['text'],answer_local_seconds=at,answer_global_seconds=round(cursor+at,6))
                entry['teaching_cues'].append(cue)
            except ValueError as exc:
                blockers.append(f'{sid}: {exc}')
        results.append(entry); cursor+=duration
    write_json(folder/'sync-plan.json',{'status':'diagnostic-not-promoted',
        'duration_seconds':round(cursor,6),'sections':results,'render_blockers':blockers,
        'production_audio_replaced':False,'visual_content_review':'pending','media_coverage_review':'see story_coverage.json'})
    print(f'Speech-anchored sync plan: {len(results)} sections, {cursor:.2f}s, {len(blockers)} blockers',flush=True)


if __name__=='__main__':main()
