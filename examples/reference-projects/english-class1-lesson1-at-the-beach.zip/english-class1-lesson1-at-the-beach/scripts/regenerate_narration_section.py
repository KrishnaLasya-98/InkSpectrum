"""Regenerate selected clean narration sections and merge the manifest."""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[1]
OPENMONTAGE = PROJECT.parents[1]
sys.path.insert(0, str(OPENMONTAGE))

from tools.voice.voice_synthesis_pipeline import VoiceSynthesisPipeline  # noqa: E402


BLOCK_TYPES = {
    "story": "concept",
    "explanation": "concept",
    "glossary": "glossary",
    "assessment": "qa_item",
    "activity": "activity",
    "life_skills": "concept",
}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("section", nargs="+", help="Section IDs such as S20")
    parser.add_argument(
        "--sentences-per-chunk",
        type=int,
        default=0,
        help="Split long text into short TTS requests, then concatenate",
    )
    args = parser.parse_args()
    os.environ.setdefault("OPENMONTAGE_ALLOW_NETWORK", "1")
    script = json.loads(
        (PROJECT / "artifacts" / "narration_script.json").read_text(encoding="utf-8")
    )
    manifest_path = PROJECT / "artifacts" / "narration_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    sections = {item["id"]: item for item in script["sections"]}
    for section_id in args.section:
        section = sections.get(section_id)
        if not section:
            raise SystemExit(f"Unknown section: {section_id}")
        text = section["narration"]
        if args.sentences_per_chunk:
            sentences = re.split(r"(?<=[.!?])\s+", text.strip())
            chunk_size = max(1, args.sentences_per_chunk)
            chunks = [
                " ".join(sentences[index : index + chunk_size])
                for index in range(0, len(sentences), chunk_size)
            ]
        else:
            chunks = [text]
        result = VoiceSynthesisPipeline().execute(
            {
                "narration_segments": [
                    {
                        "section_id": (
                            section_id
                            if len(chunks) == 1
                            else f"{section_id}-part{index + 1}"
                        ),
                        "text": chunk,
                        "source_block_type": BLOCK_TYPES.get(
                            section["mode"], "concept"
                        ),
                    }
                    for index, chunk in enumerate(chunks)
                ],
                "output_dir": str(PROJECT / "assets" / "audio" / "narration-clean"),
                "language": "indian english",
                "voice_id": "sophia",
                "model_id": "text-to-speech",
                "speed": 0.88,
                "enable_stt_qa": False,
            }
        )
        if not result.success:
            print(f"FAIL {section_id}: {result.error}")
            return 1
        generated = result.data["narration_manifest"]["segments"]
        if len(generated) == 1:
            replacement = generated[0]
        else:
            final_path = PROJECT / "assets" / "audio" / "narration-clean" / f"{section_id}.wav"
            temporary = final_path.with_suffix(".combined.wav")
            command = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error"]
            for item in generated:
                command.extend(["-i", item["audio_path"]])
            inputs = "".join(f"[{index}:a]" for index in range(len(generated)))
            command.extend(
                [
                    "-filter_complex",
                    f"{inputs}concat=n={len(generated)}:v=0:a=1[a]",
                    "-map",
                    "[a]",
                    "-ar",
                    "48000",
                    "-ac",
                    "1",
                    str(temporary),
                ]
            )
            subprocess.run(command, check=True)
            temporary.replace(final_path)
            duration_result = subprocess.run(
                [
                    "ffprobe",
                    "-v",
                    "error",
                    "-show_entries",
                    "format=duration",
                    "-of",
                    "default=noprint_wrappers=1:nokey=1",
                    str(final_path),
                ],
                check=True,
                capture_output=True,
                text=True,
            )
            replacement = {
                **generated[0],
                "section_id": section_id,
                "text": text,
                "audio_path": str(final_path),
                "duration_seconds": round(float(duration_result.stdout.strip()), 2),
                "chunk_count": len(generated),
            }
        manifest["segments"] = [
            replacement if item["section_id"] == section_id else item
            for item in manifest["segments"]
        ]
        print(f"OK {section_id}: {replacement['audio_path']}")
    manifest["total_duration_seconds"] = round(
        sum(float(item["duration_seconds"]) for item in manifest["segments"]), 2
    )
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
