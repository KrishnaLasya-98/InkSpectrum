"""Extract approved textbook exercise artwork with the existing PDF audit engine (PyMuPDF)."""
import hashlib
import json
from pathlib import Path
import pymupdf

PROJECT = Path(__file__).resolve().parents[1]
config = json.loads((PROJECT / "chapter_config.json").read_text(encoding="utf-8"))
source = Path(config["source_pdf"])
out = PROJECT / "assets/images/textbook-exercises"
out.mkdir(parents=True, exist_ok=True)
doc = pymupdf.open(source)
# Rectangles are in native PDF points, grounded in the audited page renders.
# Render only source artwork; do not retouch the book's images or merge its labels into our captions.
crops = {
    "picnic": (3, [249, 545, 295, 577]),
    "sandcastle": (3, [181, 573, 230, 605]),
    "decorating-castle": (3, [222, 604, 265, 635]),
    "shell": (3, [313, 604, 352, 635]),
    "shovel": (3, [164, 632, 203, 667]),
    "bucket": (3, [240, 636, 265, 663]),
    "alphabet": (5, [54, 354, 576, 716]),
    "starfish-letters": (6, [70, 80, 580, 340]),
    "sun": (6, [92, 630, 203, 718]),
    "flower": (6, [265, 629, 365, 707]),
    "sunflower": (6, [450, 623, 561, 707]),
    "straw": (7, [90, 62, 183, 142]),
    "berry-source": (7, [254, 65, 340, 142]),
    "strawberry": (7, [449, 59, 539, 145]),
    "glasses": (7, [250, 186, 343, 266]),
    "sunglasses": (7, [438, 173, 550, 274]),
    "rain": (7, [86, 300, 192, 378]),
    "bow": (7, [241, 300, 352, 382]),
    "rainbow": (7, [438, 300, 550, 382]),
    "all-about-me": (8, [54, 237, 576, 732]),
    "smileys": (9, [348, 434, 459, 468]),
}
entries = []
for name, (page_number, coordinates) in crops.items():
    path = out / f"{name}.png"
    doc[page_number - 1].get_pixmap(matrix=pymupdf.Matrix(4, 4), clip=pymupdf.Rect(coordinates), alpha=False).save(path)
    entries.append({"id": name, "file": str(path.relative_to(PROJECT)).replace('\\', '/'),
                    "pdf_page": page_number, "printed_page": page_number + 16, "rect_points": coordinates,
                    "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
(out / "manifest.json").write_text(json.dumps({"source_pdf": str(source),
    "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "engine": "PyMuPDF, same as tmp/pdfs/english-class1/audit_pdf.py", "assets": entries,
    "caveats": ["The source berry picture depicts cherries; label this as the textbook's berry cue, not a strawberry illustration.",
                "Alphabet source contains printed red circles. Animated circle draws will use separate authored letter tiles."]}, indent=2), encoding="utf-8")
print(f"Extracted {len(entries)} textbook exercise assets into {out}")
