"""Smoke-test Agnes Image 2.5 Flash with the chapter identity reference."""
from __future__ import annotations

import base64
import mimetypes
import os
import time
from pathlib import Path

import requests
from dotenv import load_dotenv


PROJECT = Path(__file__).resolve().parents[1]
OPENMONTAGE = PROJECT.parents[1]
load_dotenv(OPENMONTAGE / ".env")


def main() -> int:
    api_key = (
        os.environ.get("AGNES_API_KEY")
        or os.environ.get("AGNES_API_TOKEN")
        or os.environ.get("APIHUB_AGNES_API_KEY")
    )
    if not api_key:
        raise SystemExit("Agnes API key is not configured")

    source = PROJECT / "assets" / "images" / "character-references" / "varun-vidya-master-v1.png"
    mime = mimetypes.guess_type(source.name)[0] or "image/png"
    data_uri = f"data:{mime};base64,{base64.b64encode(source.read_bytes()).decode('ascii')}"
    payload = {
        "model": "agnes-image-2.5-flash",
        "prompt": (
            "Use the two recurring sibling identities from the reference. Create one polished "
            "16:9 premium 3D animated beach story keyframe with Varun and Vidya discovering "
            "a starfish near a small sandcastle. Preserve their exact faces, hair, clothing, "
            "colors, footwear, and proportions. No text, logos, watermark, or extra children."
        ),
        "size": "1K",
        "ratio": "16:9",
        "extra_body": {
            "image": [data_uri],
            "response_format": "url",
        },
    }
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    response = None
    for attempt in range(5):
        response = requests.post(
            "https://apihub.agnes-ai.com/v1/images/generations",
            headers=headers,
            json=payload,
            timeout=120,
        )
        if response.status_code not in {429, 502, 503, 504}:
            break
        time.sleep(min(30, 5 * (2**attempt)))
    assert response is not None
    if response.status_code >= 400:
        print(f"FAIL HTTP {response.status_code}")
        return 1
    data = response.json()
    item = (data.get("data") or [{}])[0]
    url = item.get("url") or data.get("url")
    b64 = item.get("b64_json") or data.get("b64_json")
    output = PROJECT / "assets" / "images" / "provider-tests" / "agnes-image-25-flash.png"
    output.parent.mkdir(parents=True, exist_ok=True)
    if url:
        image_response = requests.get(url, timeout=120)
        image_response.raise_for_status()
        output.write_bytes(image_response.content)
    elif b64:
        output.write_bytes(base64.b64decode(b64))
    else:
        print("FAIL: response contained no image output")
        return 1
    print(f"OK: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
