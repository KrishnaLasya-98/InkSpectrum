"""Generate a reviewable, phrase-paced ModelsLab sample without replacing production audio."""
from __future__ import annotations

import json
import argparse
import re
import subprocess
import sys
import wave
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np
import requests

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT.parents[1]))
from tools.voice.voice_synthesis_pipeline import _api_key, _download, _poll_for_audio

OUT = PROJECT / "assets/audio/delivery-review-v2"
VOICE_SETTINGS = {"voice_id": "sophia", "language": "american english", "speed": 0.65}
PHRASES = [
    {"id": "story-1", "text": "Hey, let us build a sandcastle!", "pause_after": 0.85},
    {"id": "story-2b", "text": "Sure. I have a shovel and a bucket too.", "pause_after": 0.85},
    {"id": "story-3", "text": "Varun and Vidya build a castle together.", "pause_after": 1.2},
    {"id": "exercise-question", "text": "What do Varun and Vidya do on the beach?", "pause_after": 2.5},
    {"id": "exercise-answer", "text": "They build a sandcastle.", "pause_after": 1.0},
]


def generate(phrase: dict, key: str) -> dict:
    raw = OUT / (phrase["id"] + ".provider-audio")
    receipt = OUT / (phrase["id"] + ".receipt.json")
    settings = {"model_id": "text-to-speech", "prompt": phrase["text"], **VOICE_SETTINGS}
    if raw.exists():
        if not receipt.exists() or json.loads(receipt.read_text(encoding='utf-8')).get('request') != settings:
            raise RuntimeError(f"Cached request differs for {phrase['id']}; use a new review folder")
    if not raw.exists():
        response = requests.post("https://modelslab.com/api/v6/voice/text_to_speech",
                                 json={"key": key, **settings}, timeout=90)
        response.raise_for_status()
        data = response.json()
        status = data.get("status")
        receipt.write_text(json.dumps({"request": settings, "id": data.get("id"),
                                      "status": status}, indent=2), encoding="utf-8")
        links = data.get("output") or data.get("future_links") or []
        if status == "processing" and not links:
            url = _poll_for_audio(str(data["id"]), key)
        elif status in {"success", "processing"}:
            url = links[0] if isinstance(links, list) and links else links
        else:
            raise RuntimeError(f"Generation failed for {phrase['id']}; HTTP {response.status_code}; status {status}")
        if not url:
            raise RuntimeError(f"No audio output for {phrase['id']}")
        _download(url, raw)
    pcm = OUT / (phrase["id"] + ".wav")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(raw), "-ar", "48000",
                    "-ac", "1", "-c:a", "pcm_s16le", str(pcm)], check=True)
    with wave.open(str(pcm), "rb") as src:
        signal = np.frombuffer(src.readframes(src.getnframes()), dtype="<i2").copy()
    # Trim only exterior silence. Keep 120 ms handles to protect initial/final consonants.
    energy = np.abs(signal.astype(np.int32))
    active = np.flatnonzero(energy > 140)
    if not len(active):
        raise RuntimeError(f"Silent provider output: {phrase['id']}")
    lo, hi = max(0, int(active[0]) - 5760), min(len(signal), int(active[-1]) + 5761)
    signal = signal[lo:hi]
    with wave.open(str(pcm), "wb") as dest:
        dest.setparams((1, 2, 48000, 0, "NONE", "not compressed"))
        dest.writeframes(signal.tobytes())
    print(f"Generated {phrase['id']}: {len(signal)/48000:.2f}s", flush=True)
    return {**phrase, "file": str(pcm), "samples": len(signal), "settings": settings}


def main() -> None:
    global OUT, VOICE_SETTINGS
    parser = argparse.ArgumentParser()
    parser.add_argument('--voice', default='sophia')
    parser.add_argument('--language', default='american english')
    parser.add_argument('--speed', type=float, default=.65)
    parser.add_argument('--emotion', action='store_true')
    parser.add_argument('--folder', default='delivery-review-v2')
    args = parser.parse_args()
    if not re.fullmatch(r'[a-zA-Z0-9_-]+', args.folder):
        raise ValueError('Review folder must be a plain directory name')
    OUT = PROJECT / 'assets/audio' / args.folder
    VOICE_SETTINGS = {"voice_id":args.voice,"language":args.language,"speed":args.speed,"emotion":args.emotion}
    OUT.mkdir(parents=True, exist_ok=True)
    key = _api_key()
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(lambda phrase: generate(phrase, key), PHRASES))
    signal_parts = [np.zeros(12000, dtype="<i2")]
    cursor = 0.25
    for result in results:
        with wave.open(result["file"], "rb") as src:
            signal = np.frombuffer(src.readframes(src.getnframes()), dtype="<i2")
        result["start"] = round(cursor, 4)
        cursor += len(signal) / 48000
        result["end"] = round(cursor, 4)
        gap = int(result["pause_after"] * 48000)
        signal_parts.extend([signal, np.zeros(gap, dtype="<i2")])
        cursor += gap / 48000
    assembled = OUT / "narration-sample-unmastered.wav"
    with wave.open(str(assembled), "wb") as dest:
        dest.setparams((1, 2, 48000, 0, "NONE", "not compressed"))
        dest.writeframes(np.concatenate(signal_parts).tobytes())
    final = OUT / "narration-sample-v2.wav"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(assembled), "-af",
                    "loudnorm=I=-16:TP=-1.5:LRA=7", "-ar", "48000", "-ac", "1", str(final)], check=True)
    mp3 = OUT / "narration-sample-v2.mp3"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(final), "-c:a", "libmp3lame",
                    "-b:a", "192k", str(mp3)], check=True)
    report = {"status": "awaiting-listening-review", "voice": args.voice, "language_request": args.language,
              "accent": "American English" if args.voice == 'sophia' else "not independently verified",
              "duration_seconds": round(cursor, 3), "phrases": results,
              "pace_wpm_with_pauses": round(sum(len(re.findall(r'\b\w+\b', p['text'])) for p in PHRASES)*60/cursor, 1),
              "files": [str(final), str(mp3)], "source_sections": ["S04", "S12"],
              "edits": "Punctuation only; textbook words unchanged. Explicit phrase and question pauses.",
              "documentation": "https://docs.modelslab.com/voice-cloning/text-to-speech"}
    (OUT / "manifest.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"Sample: {mp3}\nDuration: {cursor:.2f}s; overall pace: {report['pace_wpm_with_pauses']} wpm", flush=True)


if __name__ == "__main__":
    main()
