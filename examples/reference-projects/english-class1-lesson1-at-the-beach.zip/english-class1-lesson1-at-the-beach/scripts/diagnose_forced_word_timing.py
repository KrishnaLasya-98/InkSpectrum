"""Acoustic alignment of supplied words, independent from pronunciation QA.

Calls the installed faster-whisper/CTranslate2 alignment implementation. This is
NOT transcription evidence: supplied words can align even if spoken incorrectly.
Unusable word durations remain visible rather than being linearly invented.
"""
import argparse
import hashlib
import json
from pathlib import Path
from faster_whisper import WhisperModel
from faster_whisper.audio import decode_audio, pad_or_trim
from faster_whisper.tokenizer import Tokenizer
from faster_whisper.transcribe import merge_punctuations
from build_paced_narration import write_json


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--audio-candidate',type=Path,required=True)
    parser.add_argument('--plan',type=Path,required=True)
    parser.add_argument('--phrases',nargs='+',required=True)
    args=parser.parse_args()
    plan=json.loads(args.plan.read_text(encoding='utf-8'))
    phrases={p['id']:p for s in plan['sections'] for p in s['phrases']}
    model=WhisperModel('small.en',device='cpu',compute_type='int8')
    tokenizer=Tokenizer(model.hf_tokenizer,multilingual=False,task='transcribe',language='en')
    for pid in args.phrases:
        file=args.audio_candidate/'phrases'/(pid+'.wav')
        audio=decode_audio(str(file),sampling_rate=16000)
        if len(audio)>29*16000:raise ValueError('Phrase exceeds this diagnostic aligner window')
        features=model.feature_extractor(audio)
        encoded=model.encode(pad_or_trim(features))
        tokens=tokenizer.encode(' '+phrases[pid]['text'])
        aligned=model.find_alignment(tokenizer,[tokens],encoded,min(features.shape[-1],3000))[0]
        merge_punctuations(aligned,'"\'“¿([{-','"\'.。,，!！?？:：”)]}、')
        words=[{'word':w['word'].strip(),'start':round(float(w['start']),3),
            'end':round(float(w['end']),3),'probability':round(float(w['probability']),4)} for w in aligned if w['word'].strip()]
        result={'status':'diagnostic-not-pronunciation-approval','algorithm':'faster-whisper-small.en supplied-text cross-attention DTW',
            'audio_sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'source_text':phrases[pid]['text'],'words':words}
        write_json(args.audio_candidate/'phrases'/(pid+'.forced-alignment.json'),result)
        print(pid+': '+str(words),flush=True)


if __name__=='__main__':main()
