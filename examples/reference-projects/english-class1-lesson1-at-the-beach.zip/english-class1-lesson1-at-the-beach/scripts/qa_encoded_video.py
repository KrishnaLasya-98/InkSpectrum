"""Decode every final frame, inspect metadata, and measure narration offset per section.

This technical gate does not claim semantic frame-by-frame or human listening QA.
Rendered-frame contact sheets and PDF/UI comparison remain separate review steps.
"""
import argparse
import json
import re
import subprocess
from pathlib import Path
import numpy as np
from scipy.signal import correlate
from build_paced_narration import write_json


def decode_audio(file):
    result=subprocess.run(['ffmpeg','-v','error','-i',str(file),'-vn','-ar','16000','-ac','1',
        '-f','f32le','pipe:1'],check=True,stdout=subprocess.PIPE)
    return np.frombuffer(result.stdout,dtype='<f4').copy()


def check_sync(reference,encoded,sections):
    checks=[]
    for section in sections:
        start=int((section['start_seconds']+.25)*16000)
        size=min(40000,int((section['duration_seconds']-.5)*16000))
        if size<=0:raise ValueError('No speech span to compare')
        target=reference[start:start+size]
        lower=max(0,start-4000);upper=min(len(encoded),start+size+4000)
        search=encoded[lower:upper]
        energy=float(np.dot(target,target))
        if len(search)<size or energy<.0001:
            checks.append({'section_id':section['id'],'status':'failed','reason':'Missing or silent decoded audio'});continue
        values=correlate(search,target,mode='valid',method='fft')
        peak=int(np.argmax(values));matched=search[peak:peak+size]
        score=float(values[peak]/np.sqrt(energy*max(1e-15,float(np.dot(matched,matched)))))
        offset=(lower+peak-start)/16000
        checks.append({'section_id':section['id'],'offset_seconds':round(offset,5),
            'correlation':round(score,5),'status':'passed' if abs(offset)<=.05 and score>=.9 else 'failed'})
    return checks


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--video',type=Path,required=True)
    parser.add_argument('--candidate',type=Path,required=True);parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    timeline=json.loads((args.candidate/'sync-plan.json').read_text(encoding='utf-8'))
    probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_format','-show_streams','-of','json',str(args.video)],text=True))
    write_json(args.out/'ffprobe.json',probe)
    video=next(s for s in probe['streams'] if s['codec_type']=='video')
    audio=next(s for s in probe['streams'] if s['codec_type']=='audio')
    checks={'h264':video['codec_name']=='h264','1080p':(video['width'],video['height'])==(1920,1080),
        '30fps':video['avg_frame_rate']=='30/1','aac':audio['codec_name']=='aac',
        '48khz':audio['sample_rate']=='48000','duration':abs(float(probe['format']['duration'])-timeline['duration_seconds'])<.10}
    process=subprocess.run(['ffmpeg','-hide_banner','-i',str(args.video),'-an','-vf',
        'blackdetect=d=0.10:pix_th=0.03,freezedetect=n=-50dB:d=0.65','-f','null','-'],
        stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    (args.out/'frame-decode.log').write_text(process.stderr,encoding='utf-8')
    blacks=[{'start':float(s),'end':float(e)} for s,e in re.findall(r'black_start:([\d.]+) black_end:([\d.]+)',process.stderr)]
    freezes=[];pending=None
    for line in process.stderr.splitlines():
        match=re.search(r'freeze_start: ([\d.]+)',line)
        if match:pending=float(match[1])
        match=re.search(r'freeze_end: ([\d.]+)',line)
        if match and pending is not None:freezes.append({'start':pending,'end':float(match[1])});pending=None
    if pending is not None:freezes.append({'start':pending,'end':float(probe['format']['duration'])})
    story=[s for s in timeline['sections'] if s['story_cues']]
    story_freezes=[f for f in freezes if any(min(f['end'],s['end_seconds'])-max(f['start'],s['start_seconds'])>.65 for s in story)]
    checks.update(all_frames_decoded=process.returncode==0,no_black_intervals=not blacks,no_story_freezes=not story_freezes)
    reference=decode_audio(args.candidate/'chapter-review.wav');encoded=decode_audio(args.video)
    sync=check_sync(reference,encoded,timeline['sections'])
    checks['audio_sync']=all(s['status']=='passed' for s in sync)
    report={'status':'technical-pass-visual-review-pending' if all(checks.values()) else 'failed',
        'video':str(args.video.resolve()),'checks':checks,'decoded_video_frames':int(video.get('nb_read_frames',0)),
        'duration_seconds':float(probe['format']['duration']),'audio_channels':audio['channels'],
        'black_intervals':blacks,'story_freezes':story_freezes,'all_freeze_intervals':freezes,'audio_sync':sync,
        'semantic_frame_review':'not established by this automated test','human_listening_review':'not established by this automated test'}
    write_json(args.out/'encoded-qa.json',report)
    print(json.dumps({'status':report['status'],'checks':checks,'frames':report['decoded_video_frames']}),flush=True)
    return 0 if all(checks.values()) else 1


if __name__=='__main__':raise SystemExit(main())
