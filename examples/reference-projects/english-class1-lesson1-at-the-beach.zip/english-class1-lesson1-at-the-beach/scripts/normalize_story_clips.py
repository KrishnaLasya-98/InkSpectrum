"""Normalize approved story clips for smooth HyperFrames composition."""
from __future__ import annotations

import json
import subprocess
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[1]
PLAN_PATH = PROJECT / "artifacts" / "media_plan.json"
OUTPUT_DIR = PROJECT / "assets" / "video" / "normalized"


def main() -> int:
    plan = json.loads(PLAN_PATH.read_text(encoding="utf-8"))
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    failed = 0
    for scene in plan["scenes"]:
        source = PROJECT / scene["output"]
        output = OUTPUT_DIR / source.name
        if not source.is_file():
            failed += 1
            print(f"MISSING {scene['id']}: {source}", flush=True)
            continue
        command = [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-i",
            str(source),
            "-an",
            "-vf",
            (
                "crop=trunc(ih*16/9/2)*2:ih,"
                "minterpolate=fps=30:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1,"
                "scale=1920:1080:flags=lanczos,format=yuv420p"
            ),
            "-c:v",
            "libx264",
            "-preset",
            "medium",
            "-crf",
            "17",
            "-movflags",
            "+faststart",
            str(output),
        ]
        result = subprocess.run(command, check=False)
        if result.returncode:
            failed += 1
            print(f"FAIL {scene['id']}", flush=True)
            continue
        scene["normalized_output"] = str(output.relative_to(PROJECT)).replace("\\", "/")
        print(f"OK {scene['id']}: {output}", flush=True)
    PLAN_PATH.write_text(json.dumps(plan, indent=2), encoding="utf-8")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
