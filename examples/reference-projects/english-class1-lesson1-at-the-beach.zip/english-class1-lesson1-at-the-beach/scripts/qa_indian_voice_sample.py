"""Unprompted recognition and PCM health for the reference-conditioned sample."""
import hashlib
import json
from pathlib import Path
import numpy as np
from faster_whisper import WhisperModel
from align_narration import word_error_rate
from build_paced_narration import read_pcm, spoken_equivalence, write_json

DIRECTORY = Path(__file__).resolve().parents[1]/'assets/audio/narration-indian-qwen-v4/continuity-sample'

if __name__ == '__main__':
    manifest = json.loads((DIRECTORY/'manifest.json').read_text(encoding='utf-8'))
    model = WhisperModel('small.en',device='cpu',compute_type='int8')
    rows = []
    for phrase in manifest['phrases']:
        segments,_ = model.transcribe(phrase['file'],language='en',word_timestamps=True,
                                     vad_filter=True,condition_on_previous_text=False,beam_size=5)
        segments = list(segments)
        transcript = ' '.join(s.text.strip() for s in segments)
        words = [{'word':w.word.strip(),'start':w.start,'end':w.end} for s in segments for w in s.words or []]
        signal = read_pcm(phrase['file']).astype(np.int32)
        wer = word_error_rate(spoken_equivalence(phrase['text']),spoken_equivalence(transcript))
        row = {'id':phrase['id'],'expected':phrase['text'],'transcript':transcript,'words':words,
               'wer':wer,'status':'text-review' if wer else 'recognized-not-listening-approved',
               'duration_seconds':len(signal)/48000,'clipped_samples':int((np.abs(signal)>=32767).sum()),
               'audio_sha256':hashlib.sha256(Path(phrase['file']).read_bytes()).hexdigest()}
        rows.append(row)
        print(f"{phrase['id']}: WER={wer:.2f}; {transcript}",flush=True)
    write_json(DIRECTORY/'qa.json',{'initial_prompt':None,'voice_continuity':'requires-listening',
        'phrases':rows,'flags':sum(bool(r['wer']) for r in rows),'production_audio_replaced':False})
