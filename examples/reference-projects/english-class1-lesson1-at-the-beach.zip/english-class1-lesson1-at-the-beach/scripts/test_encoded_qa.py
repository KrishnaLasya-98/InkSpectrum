import unittest
import numpy as np
from qa_encoded_video import check_sync

class SyncTests(unittest.TestCase):
    def test_recovers_small_known_encoded_offset(self):
        audio=np.random.default_rng(3).normal(0,.05,80000).astype(np.float32)
        encoded=np.concatenate([np.zeros(320,dtype=np.float32),audio])
        result=check_sync(audio,encoded,[{'id':'S01','start_seconds':0,'duration_seconds':5}])[0]
        self.assertEqual(result['status'],'passed');self.assertAlmostEqual(result['offset_seconds'],.02)
    def test_detects_wrong_audio_and_excess_delay(self):
        audio=np.random.default_rng(3).normal(0,.05,80000).astype(np.float32)
        wrong=np.random.default_rng(4).normal(0,.05,80000).astype(np.float32)
        delayed=np.concatenate([np.zeros(1600,dtype=np.float32),audio])
        for encoded in [wrong,delayed]:
            self.assertEqual(check_sync(audio,encoded,[{'id':'S01','start_seconds':0,'duration_seconds':5}])[0]['status'],'failed')

if __name__=='__main__':unittest.main()
