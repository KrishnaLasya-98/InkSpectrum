"""Independent unprompted ASR diagnostics, never a pronunciation approval.

Uses the second cached model only on flagged phrases. Keeps the first recognizer
and the actual WAV unchanged, and binds diagnostics to the WAV hash.
"""
import argparse
import hashlib
import json
from pathlib import Path
from faster_whisper import WhisperModel
from build_paced_narration import spoken_equivalence, write_json
from align_narration import word_error_rate


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--audio-candidate',type=Path,required=True)
    args=parser.parse_args()
    folder=args.audio_candidate
    qa=json.loads((folder/'alignment_qa.json').read_text(encoding='utf-8'))
    config={'model':'base.en','language':'en','vad_filter':False,'initial_prompt':None,'beam_size':5}
    model=WhisperModel('base.en',device='cpu',compute_type='int8')
    reports=[]
    for section in qa['sections']:
        for phrase in section['phrases']:
            if phrase['status']!='review':continue
            file=folder/'phrases'/(phrase['id']+'.wav')
            digest=hashlib.sha256(file.read_bytes()).hexdigest()
            cache=folder/'phrases'/(phrase['id']+'.base-asr.json')
            result=json.loads(cache.read_text(encoding='utf-8')) if cache.exists() else {}
            if result.get('audio_sha256')!=digest or result.get('asr_config')!=config:
                segments,_=model.transcribe(str(file),language='en',word_timestamps=True,
                    vad_filter=False,condition_on_previous_text=False,beam_size=5)
                segments=list(segments)
                result={'audio_sha256':digest,'asr_config':config,
                    'transcript':' '.join(s.text.strip() for s in segments),
                    'words':[{'word':w.word.strip(),'start':round(w.start,3),'end':round(w.end,3),
                        'probability':round(w.probability,4)} for s in segments for w in s.words or []]}
                write_json(cache,result)
            row={'id':phrase['id'],'expected':phrase['expected'],'first_transcript':phrase['transcript'],
                'second_transcript':result['transcript'],
                'second_wer':word_error_rate(spoken_equivalence(phrase['expected']),spoken_equivalence(result['transcript'])),
                'zero_duration_words':[w['word'] for w in result['words'] if w['end']<=w['start']]}
            reports.append(row)
            write_json(folder/'second-opinion.json',{'status':'diagnostic-not-approval','phrases':reports})
            print(f"{row['id']}: {row['second_transcript']} | WER {row['second_wer']:.3f} | timing {row['zero_duration_words']}",flush=True)


if __name__=='__main__':main()
