import unittest
from stage_synced_media import fit_interval

class CoverageTests(unittest.TestCase):
    def test_short_cue_trims_without_speeding_up(self):
        self.assertEqual(fit_interval(10,13,5),[{'kind':'source','start':10,'end':13,'speed':1}])
    def test_continuation_overlaps_without_replay(self):
        result=fit_interval(0,9,5,5)
        self.assertEqual(result[1]['start'],4.84)
        self.assertEqual(result[1]['end'],9)
        self.assertTrue(all(c['speed']==1 for c in result))
    def test_missing_motion_blocks(self):
        with self.assertRaisesRegex(ValueError,'Insufficient motion'):fit_interval(0,9,5)
        with self.assertRaisesRegex(ValueError,'still leaves'):fit_interval(0,11,5,5)
    def test_minor_retime_is_bounded(self):
        self.assertEqual(fit_interval(0,5.8,5)[0]['speed'],.85)

if __name__=='__main__':unittest.main()
