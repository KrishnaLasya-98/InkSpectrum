"""Bounded, every-section browser snapshots. These are QA, never video assets."""
import json
import os
from pathlib import Path
import subprocess
from PIL import Image, ImageDraw
from lib.production_runtime import atomic_json

PROJECT=Path(__file__).resolve().parent
ROOT=PROJECT/'artifacts/revision-v4'
CLI=PROJECT.parents[1]/'.runtime/hyperframes/node_modules/hyperframes/bin/hyperframes.mjs'

def main():
    plan=json.loads((ROOT/'composition-plan-media.json').read_text(encoding='utf-8'))
    times=[]
    for section in plan['sections']:
        start,end=section['start_seconds'],section['end_seconds']
        body=section['heading_holds'][-1]['end_seconds'] if section['heading_holds'] else start
        times.extend([start+1, min(end-.1,body+1),(body+end)/2])
    times=sorted(set(round(t,3) for t in times+[0,plan['duration']-.1]))
    output=ROOT/'section-snapshots'
    output.mkdir(exist_ok=True)
    environment=os.environ.copy()
    environment.update(TEMP=str(ROOT/'check-temp'),TMP=str(ROOT/'check-temp'))
    result=subprocess.run(['node',str(CLI),'snapshot',str(PROJECT/'hyperframes-v4-production'),
        '--output',str(output),'--at',','.join(map(str,times)),
        '--timeout','15000','--no-end','--describe','false'],capture_output=True,
        text=True,encoding='utf-8',errors='replace',env=environment,timeout=600)
    (ROOT/'section-snapshots.log').write_text(result.stdout+'\n'+result.stderr,encoding='utf-8')
    files=sorted(output.glob('frame-*.png'))
    for offset in range(0,len(files),12):
        page=files[offset:offset+12]
        sheet=Image.new('RGB',(1440,4*294),'#17242b')
        draw=ImageDraw.Draw(sheet)
        for i,path in enumerate(page):
            with Image.open(path) as frame:
                thumb=frame.convert('RGB');thumb.thumbnail((480,270))
                x,y=(i%3)*480,(i//3)*294
                sheet.paste(thumb,(x,y+24))
                draw.text((x+6,y+4),path.stem,fill='white')
        sheet.save(output/f'sheet-{offset//12+1:02}.jpg',quality=90)
    atomic_json(ROOT/'section-snapshot-report.json',{'exit_code':result.returncode,
        'requested':len(times),'captured':len(files),'times':times,'visually_reviewed':False})
    print(json.dumps({'exit_code':result.returncode,'captured':len(files)}))
    raise SystemExit(result.returncode)

if __name__=='__main__':
    main()
