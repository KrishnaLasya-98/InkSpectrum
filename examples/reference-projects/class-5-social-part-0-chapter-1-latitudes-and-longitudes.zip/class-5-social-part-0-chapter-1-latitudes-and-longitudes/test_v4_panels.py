import json
import unittest
from prepare_v4_panels import paginate, table_rows, anchors, exact_span, assign_panel_windows, ROOT, PROJECT


class PanelTests(unittest.TestCase):
    def test_exact_roundtrip_with_punctuation_and_degrees(self):
        text = ('The value is 23.5\u00b0 N. Preserve commas, apostrophes and pauses!  ' * 12).strip()
        pages = paginate(text)
        self.assertEqual(''.join(p['text'] for p in pages), text)
        self.assertTrue(all(len(p['text'].split()) <= 35 for p in pages))

    def test_table_preserves_all_cells_not_separator(self):
        self.assertEqual(table_rows('| Word | Meaning |\n| --- | --- |\n| Equator | 0\u00b0 latitude |'),
                         [['Word', 'Meaning'], ['Equator', '0\u00b0 latitude']])

    def test_repeated_phrase_is_not_assigned_guessed_time(self):
        words = [{'word': w, 'start_ms': i*100} for i,w in enumerate('The Earth is round The Earth is round'.split())]
        self.assertEqual(anchors('The Earth is round', words)['status'], 'manual_timing_review')

    def test_all_required_source_blocks_mapped_without_completion_claim(self):
        report = json.loads((ROOT/'source-panel-plan.json').read_text())
        self.assertEqual(report['required_blocks'], report['mapped_blocks'])
        self.assertEqual(report['mapped_blocks'], 71)
        self.assertFalse(report['render_ready'])
        self.assertTrue(all('hide_during_heading_holds' not in b for b in report['blocks'] if b['layout']=='title'))

    def test_figure_manifest_resolves(self):
        report = json.loads((ROOT/'source-panel-plan.json').read_text())
        figures = [b for b in report['blocks'] if b['layout']=='source_figure_contain']
        self.assertEqual(len(figures), 7)
        self.assertTrue(all((PROJECT/b['figure_selection']).is_file() for b in figures))
        self.assertTrue(all((PROJECT/b['asset']).is_file() for b in figures))
        self.assertTrue(all(b['display_start_ms'] < b['display_end_ms'] for b in figures))
        continent = next(b for b in figures if b['role']=='continent_map')
        self.assertTrue(continent['asset'].endswith('/continent_map.png'))

    def test_exact_match_preserves_measured_end(self):
        words = [{'word': w, 'start_ms': i*200, 'end_ms': i*200+150}
                 for i,w in enumerate('Title. Equator (0° latitude): It divides Earth.'.split())]
        span = exact_span('Equator (0° latitude): It divides Earth.', words)
        self.assertEqual((span['start_ms'], span['end_ms']), (200, 1350))
        self.assertEqual(exact_span('Equator (0° latitude): Wrong ending.', words)['status'], 'manual_timing_review')

    def test_numeric_values_do_not_collapse(self):
        words = [{'word':'235','start_ms':100,'end_ms':500}]
        self.assertEqual(exact_span('23.5', words)['status'], 'manual_timing_review')

    def test_all_source_page_and_table_spans_matched(self):
        report = json.loads((ROOT/'source-panel-plan.json').read_text())
        self.assertEqual(report['timing_issues'], [])
        for block in report['blocks']:
            spans = [p['timing'] for p in block['pages']] if block['layout']=='compact_corner_panel' else block.get('row_timing', [])
            for span in spans:
                self.assertEqual(span['status'], 'whole_source_matched')
                self.assertLessEqual(span['end_ms'], span['display_end_ms'])

    def test_body_window_cannot_cross_heading_hold(self):
        blocks = [{'section_id':'s1','source_block_id':'b1','layout':'compact_corner_panel',
                   'pages':[{'timing':{'status':'whole_source_matched','start_ms':100,'end_ms':200}}]}]
        times = {'s1':{'end_seconds':3,'heading_holds':[{'start_seconds':1,'end_seconds':2}]}}
        self.assertEqual(assign_panel_windows(blocks,times)[0]['issue'], 'body intersects heading hold')


if __name__ == '__main__':
    unittest.main()
