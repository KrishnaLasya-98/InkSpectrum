"""Offline recovery guards: no generation submissions and no secret output."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch, MagicMock

spec = importlib.util.spec_from_file_location('recovery', Path(__file__).with_name('recover_v4_once.py'))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.output = Path(self.directory.name) / 'clip.mp4'
        self.sidecar = self.output.with_suffix('.mp4.modelslab-job.json')
        self.state = {'provider': 'modelslab', 'request_id': '12345',
                      'model_id': 'wan-2.2-i2v', 'operation': 'image_to_video',
                      'poll_endpoint': 'video', 'status': 'timed_out'}
        self.save()

    def save(self):
        self.sidecar.write_text(json.dumps(self.state), encoding='utf-8')

    def test_existing_output_never_calls_provider(self):
        self.output.write_bytes(b'existing')
        with patch.object(module.requests, 'Session') as session:
            self.assertEqual(module.check(self.sidecar)['status'], 'already_downloaded')
            session.assert_not_called()

    def test_invalid_request_id_never_calls_provider(self):
        self.state['request_id'] = '../wrong'
        self.save()
        with patch.object(module.requests, 'Session') as session:
            self.assertEqual(module.check(self.sidecar)['status'], 'invalid_sidecar')
            session.assert_not_called()

    def test_processing_checks_once_does_not_resubmit_or_change_sidecar(self):
        before = self.sidecar.read_bytes()
        with patch.dict(module.os.environ, {'MODELSLAB_API_KEY': 'mock-secret'}), \
             patch.object(module.requests, 'Session') as session, \
             patch.object(module, 'ModelsLabVideo') as adapter:
            post = session.return_value.__enter__.return_value.post
            post.return_value.status_code = 200
            post.return_value.json.return_value = {'status': 'processing'}
            result = module.check(self.sidecar)
            self.assertEqual(result['status'], 'processing')
            self.assertNotIn('mock-secret', json.dumps(result))
            post.assert_called_once_with('https://modelslab.com/api/v6/video/fetch/12345',
                json={'key': 'mock-secret'}, timeout=(10, 30))
            adapter.assert_not_called()
        self.assertEqual(self.sidecar.read_bytes(), before)

    def test_success_uses_resume_id_and_saved_endpoint(self):
        with patch.dict(module.os.environ, {'MODELSLAB_API_KEY': 'mock-secret'}), \
             patch.object(module.requests, 'Session') as session, \
             patch.object(module, 'ModelsLabVideo') as adapter:
            response = session.return_value.__enter__.return_value.post.return_value
            response.status_code = 200
            response.json.return_value = {'status': 'success', 'output': ['https://example.invalid/clip.mp4']}
            adapter.return_value.execute.return_value = MagicMock(success=True)
            result = module.check(self.sidecar)
            self.assertEqual(result['status'], 'recovery_error')
            args = adapter.return_value.execute.call_args.args[0]
            self.assertEqual(args['resume_request_id'], '12345')
            self.assertEqual(args['poll_endpoint'], 'video')
            self.assertNotIn('prompt', args)

    def test_http_error_keeps_job_recoverable(self):
        before = self.sidecar.read_bytes()
        with patch.dict(module.os.environ, {'MODELSLAB_API_KEY': 'mock-secret'}), \
             patch.object(module.requests, 'Session') as session:
            session.return_value.__enter__.return_value.post.side_effect = module.requests.Timeout('mock-secret')
            result = module.check(self.sidecar)
            self.assertEqual(result['status'], 'check_error')
            self.assertNotIn('mock-secret', json.dumps(result))
        self.assertEqual(self.sidecar.read_bytes(), before)


if __name__ == '__main__':
    unittest.main()
