"""Materialize explicit gentle retimes; no loop, implicit freeze or API calls."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
from lib.production_runtime import atomic_json
from prepare_v4_composition import PROJECT, ROOT, read, probe


def required_retime(info, target):
    duration=float(info['duration'])
    if duration >= target:
        return None
    numerator,denominator=map(float,info['r_frame_rate'].split('/'))
    last_pts=duration-denominator/numerator
    factor=(target+1/30)/last_pts
    if factor > 1/.88:
        raise ValueError('Clip needs more than a gentle retime; generate new motion')
    return factor


def main():
    plan=deepcopy(read(ROOT/'composition-plan.json'))
    destination=PROJECT/'assets/video/revision-v4-retimed'
    destination.mkdir(exist_ok=True)
    if shutil.disk_usage(destination).free < 2*1024**3:
        raise SystemExit('Insufficient retime disk')
    changes=[]
    for section in plan['sections']:
        for i,shot in enumerate(section['visuals']):
            # A short incoming dissolve has pre-roll. Geometry was authored to
            # exact speech, so it must NEVER be speed-adjusted or pre-rolled.
            precise=bool(shot.get('teaching_hold_allowed'))
            lead=0 if precise or shot['start']==0 else min(.18,shot['start'])
            shot.update(render_start=shot['start']-lead, dissolve_seconds=lead)
            if shot['kind'] != 'video':
                continue
            source=PROJECT/shot['asset']
            info=probe(source)
            target=shot['end']-shot['render_start']
            if precise:
                # <= one output frame of explicit completed-geometry hold only.
                if target-float(info['duration']) > 1/30+.002:
                    raise ValueError('Precision animation unexpectedly short')
                continue
            factor=required_retime(info,target)
            if factor is None:
                continue
            digest=hashlib.sha256((shot['source_sha256']+f'|{target:.6f}|{factor:.9f}').encode()).hexdigest()[:12]
            output=destination/f'{source.stem}-{digest}.mp4'
            if not output.exists():
                temporary=output.with_suffix('.partial.mp4')
                if temporary.exists():
                    raise ValueError('Partial output exists; inspect before retry')
                command=['ffmpeg','-hide_banner','-loglevel','error','-n','-i',str(source),
                    '-vf',f'setpts={factor:.9f}*PTS,fps=30','-t',f'{target+.034:.6f}',
                    '-an','-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p',
                    '-movflags','+faststart',str(temporary)]
                subprocess.run(command,capture_output=True,check=True,timeout=120)
                verified=probe(temporary)
                if float(verified['duration']) < target:
                    raise ValueError('Derived clip still short; preserve partial for inspection')
                temporary.replace(output)
            verified=probe(output)
            if float(verified['duration']) < target:
                raise ValueError('Existing derived output too short')
            changes.append({'source':shot['asset'],'derived':output.relative_to(PROJECT).as_posix(),
                            'source_sha256':shot['source_sha256'],'setpts_factor':factor,
                            'speed':1/factor,'target_seconds':target,'probe':verified})
            shot.update(original_asset=shot['asset'],asset=output.relative_to(PROJECT).as_posix(),
                        source_duration=float(verified['duration']),needs_retime=False,
                        source_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),retime_factor=factor)
    plan.update(stage='media_timing_prepared',warnings=[],render_ready=False)
    atomic_json(ROOT/'retimed-media-report.json',{'changes':changes,'no_loops':True,'chapter_complete':False})
    atomic_json(ROOT/'composition-plan-media.json',plan)
    print(json.dumps({'retimed_clips':len(changes),'render_ready':False}))


if __name__=='__main__':
    main()
