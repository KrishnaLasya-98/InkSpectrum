# Remaining ocean animation reference artwork

Generated 2026-10-01 with built-in GPT image generation, not CLI.
These are starting references for Wan 2.2 animated clips, not still-image backgrounds.

## southern-ocean-3d-v4

Saved: assets/images/gpt-keyframes/southern-ocean-3d-v4.png

Use case: stylized-concept. Asset type: wide 16:9 reference frame for a 3D animated Class 5 geography lesson. A visibly stylized children's CGI movie scene of the Southern Ocean near Antarctica: rounded rolling blue-grey waves with broad sculpted white foam, small distant tabular iceberg on the far left, layered low clouds suggesting wind. Light and welcoming, not frightening storm. Clearly simplified three-dimensional cartoon material treatment, smooth sculpted surfaces and rounded forms, NOT a photograph, NOT live action, NOT flat painted art. Ocean fills lower two thirds. Keep upper right uncluttered for later textbook text. No people, animals, ships, generated labels, maps, arrows, text, logos, or watermark. The scene illustrates cold waters and wind, not a geographic reconstruction.

## arctic-ocean-3d-v4

Saved: assets/images/gpt-keyframes/arctic-ocean-3d-v4.png

Use case: stylized-concept. Asset type: wide 16:9 reference frame for a child-friendly 3D animated geography lesson. Low elevated view over Arctic sea ice: broad flat rounded white ice floes separated by calm blue ocean channels stretching to the horizon, no mountains and no land at the North Pole. Soft pale-blue daylight and rounded clouds. Polished visibly CARTOON 3D animated-film rendering, sculpted simplified ice blocks with smooth bevels and soft shadows, not photography and not flat art. The open water between floes will move in the animation. Keep top-right sky free for an overlay. No penguins, polar bears, people, flags, buildings, ships, maps, symbols, letters, watermark or UI.

## ocean-marine-life-3d-v4

Saved: assets/images/gpt-keyframes/ocean-marine-life-3d-v4.png

Use case: stylized-concept. Asset type: wide 16:9 starting frame for a child-friendly 3D animated educational video about oceans supporting marine life. One friendly anatomically plausible green sea turtle, four flippers, one head, one shell, swims above a gently undulating sea-grass meadow on the left; three small distinct fish nearby, sunlit blue underwater space on the right. Polished stylized 3D cartoon-film rendering with round clean forms, soft expressive eyes, smooth materials and clear depth, not a photograph and not flat 2D art. A different environment from a coral reef: sea grass and sandy floor only, no reef. Composition leaves upper right clear for a later textbook panel. No text, labels, logos, humans, plastic, bubbles covering faces or watermark.


Visual review: Southern Ocean has sculpted foam and a distant ice shelf; Arctic has flat sea ice with no invented polar land/mountains; marine-life frame has one stylized turtle with four visible flippers and three fish. All are illustrative CGI, no map labels. Final clip anatomy, style and motion need review.
