# Fresh GPT reference artwork - revision v4

Generated on 2026-10-01 using the built-in image-generation tool, not a CLI/API fallback. All six images were visually inspected and copied into the project. These are starting frames for ModelsLab Wan 2.2 image-to-video, not still images to fill chapter duration.

## Prompt set

Common specification: stylized-concept; a landscape 16:9 keyframe for a Class 5 children's 3D geography film; premium sculpted 3D animated-film forms, matte materials, warm cinematic light; uncluttered upper-right space for later teaching UI; full bleed; no lettering, labels, logos, watermarks, fantasy additions or flat illustration. Location-specific requirements:

| Local asset under assets/images/gpt-keyframes | Location and requested visual |
| --- | --- |
| grand-canyon-3d-v4.png | Layered red/orange cliffs, mesas, a small Colorado River far below; oblique aerial view, strong near/far depth. |
| niagara-falls-3d-v4.png | Broad recognizable Horseshoe Falls from a low green plateau into a turquoise river; curved waterfall, flowing white water and soft mist; not a tall mountain waterfall. |
| amazon-rainforest-3d-v4.png | Expansive dense tropical canopy, broad winding blue-brown river, humid morning air and rounded layered foliage; no mountains. |
| andes-3d-v4.png | Long South American mountain chain extending into the distance, snowcapped peaks and dry high-altitude valleys; blue/violet distant ridges, muted ochre foreground. |
| eiffel-3d-v4.png | Recognizable four-legged iron Eiffel Tower, arches and latticework, Champ de Mars lawns and Paris rooftops; rigid architecture. |
| colosseum-3d-v4.png | Recognizable oval Roman amphitheatre, repeated tiers of arches and partially surviving outer wall, warm travertine; no gladiators or invented structures. |

The exact motion prompts and image paths sent to ModelsLab are preserved in motion-batch-03.json and motion-batch-04.json. Each shot has its own source-narration cue. Each clip still needs motion, geometry, semantic and timeline QA after recovery; accepted generation requests are not finished media.
