# Ocean animation reference artwork

Generated 2026-10-01 with the built-in GPT image-generation tool (not CLI).
These are reference inputs for Wan 2.2 motion, not still substitutes.
Illustrative ocean scenery; geographic location is supplied by the source map, not inferred from the generated image.

## pacific-ocean-3d-v4

Saved: assets/images/gpt-keyframes/pacific-ocean-3d-v4.png

Use case: stylized-concept. Asset type: 16:9 starting frame for Wan 2.2 3D educational animation, Class 5 oceans lesson. A wide sweeping open Pacific Ocean vista: deep cobalt water with layered gently rolling swells, broad horizon, a few rounded white clouds. Polished stylized 3D animated-film look with sculpted smooth waves, clearly not a live-action photograph. Camera near water level, sunlit inviting atmosphere; ample uncluttered sky at upper right for later textbook panel. No boats, animals, people, islands, text, labels, symbols, watermark, or UI. This is an illustrative ocean view, not a map or depth diagram. Full-bleed landscape, tasteful saturated blue and teal, physical depth.

## atlantic-shipping-3d-v4

Saved: assets/images/gpt-keyframes/atlantic-shipping-3d-v4.png

Use case: stylized-concept. Asset type: 16:9 starting frame for Wan 2.2 educational 3D animation. A single friendly stylized modern container cargo ship crossing the open Atlantic Ocean in clear daylight, shown full vessel from elevated three-quarter side view on the left half, bow toward right, visible foam wake behind. Neatly stacked colored rectangular containers, structurally coherent red hull and cream bridge, deep blue rolling water. Polished child-friendly 3D animated-film materials, rounded edges, not photorealistic or flat illustration. Open sky and distant horizon in upper right reserved for later teaching panel. No writing on ship or containers, no flags, logos, watermarks, text, maps, extra ships or people. Wide cinematic landscape.

## indian-ocean-3d-v4

Saved: assets/images/gpt-keyframes/indian-ocean-3d-v4.png

Use case: stylized-concept. Asset type: 16:9 starting frame for a child-friendly 3D animated geography video, later animated with Wan 2.2. An illustrative warm tropical Indian Ocean seascape: luminous turquoise water in foreground transitioning to deep azure towards horizon, gentle sculpted swells and sunlit clouds, very distant low tropical island at far left, wide expansive water. Polished stylized 3D animated-film environment with rounded cloud forms, layered water surfaces and warm sunlight, not live action and not flat 2D illustration. Upper-right sky uncluttered for later textbook panel. No people, boats, animals, text, labels, map outlines, logos, UI or watermark. Full-bleed wide landscape.


Review: all three rendered without labels, UI or obvious geometry errors. Pacific and Indian ocean water has naturalistic detail despite the CGI treatment; animation style and perceived motion require review after generation. The cargo ship is coherent and plainly CGI. No geographic reconstruction claim.
