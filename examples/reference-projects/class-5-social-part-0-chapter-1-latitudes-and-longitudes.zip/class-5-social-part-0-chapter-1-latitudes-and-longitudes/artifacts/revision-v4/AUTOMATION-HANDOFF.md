# Chapter 1 automatic continuation

## Final verified export — 2026-10-01

The scoped 22-section video (opening through Word Bank, including Start-Up Activity; no assessment or exercise material after Word Bank) is complete at `renders/class5-social-chapter1-latitudes-longitudes-v4.mp4`. HyperFrames one-worker low-memory render exited successfully: 635.1 seconds, 1920x1080 at 30 fps, H.264/AAC, 146,412,751 bytes. The finalizer reconciled all canonical educational checkpoints in stage order; all 12 report `completed`.

Revision-v4 evidence: `render-report.json`, `final-review.json`, `encoded-qa/report.json`, `encoded-comparison/encoded-comparison-report.json`, six visually reviewed encoded contact sheets, and `composition-coverage.json` mapping all 71 scoped source blocks. Encoded QA found zero black events, zero freeze conflicts during generated motion, and 22/22 passing audio-envelope alignments with no measured section offsets. The encoded comparison passed its technical, source-topic, reference-integrity, and caption timing/punctuation gates. Subjective voice naturalness/pronunciation remains for the user to judge on playback; automated alignment is not listener approval.

No further generation or render should run for this chapter unless the user requests a revision. Disable the scheduled follow-up and do not begin Chapter 2 until the user approves Chapter 1.

User authorized automatic end-to-end completion and notification on 2026-10-01.
The Codex thread heartbeat `finish-class-5-social-chapter-1` is ACTIVE every ten minutes.
This is local scheduled agent continuation, not a deployed cloud service. It requires the computer and app to remain available.

## Locked scope and deliverable

- Class 5 Social Studies, Chapter 1: Latitudes and Longitudes.
- Use this directory's educational_plan.json, chapter_document.json, coverage_contract.json and narration_manifest.json. Scope is all 22 consecutive sections s01-title through s22-wordbank, inclusive, including s03-startup. Do not use the narrower v3 scope or the old 46-section full chapter.
- The opening contains the lesson title, subject and class; Word Bank is the final section, not part of the opening.
- Narration duration is 635.084 seconds. The plan's older estimated 696 seconds is not authoritative for timing. Use measured narration and aligned words.
- Fresh 3D animated motion, GPT reference images animated with ModelsLab wan-2.2-i2v when helpful. Source diagrams with accurate authored labels; stable textbook boxes, Recall, comparison table and Word Bank while read. No Ken Burns substitution, looping or unrelated background clips.
- English Class 1 final-v7 is the canonical UI reference, with the EVS synced video also approved as presentation guidance. No reuse of their media.
- Preserve all 71 in-scope required source blocks. Do not silently remove Start-Up Activity, facts, table cells or source figures.
- Narrator currently Kokoro af_heart at 0.85 speed; four-second heading holds and topic pauses. All source text, punctuation, pronunciation and word highlighting still need QA.
- Deliver one verified MP4 and its path. Do not begin another chapter until the user approves this one. Disable the heartbeat when finished.

## Latest verified update: 2026-10-01, after 14:45 IST

Render started after 15:07 IST under unified exec session 34696, HyperFrames renderJobId 538e1436-0e6c-46d3-9fe7-efac3bdb000b. Command uses one worker, low-memory mode, HF_CAPTURE_PARALLEL_STREAM=true, D-drive TEMP/cache. Output target: PROJECT/renders/class5-social-chapter1-latitudes-longitudes-v4.mp4. Actual CLI compiled 29 video and 22 audio; screenshot/low-memory profile confirmed. All 29 video inputs entered extraction. Do not start a concurrent render; poll session 34696 or inspect process/output. Preflight: no competing render, no lock, C ~12.35 GB and D ~203.53 GB free, HyperFrames info duration635.084s and element counts correct. Check exit code before claiming file valid. Output is still rendering, not QA-approved.

Follow-up: all 68 section snapshots reviewed; brief blank heading-boundary and intro-card absence at frame zero fixed. Single-paragraph reading cards enlarged. User explicitly requested professional diagram labels; compose_v4.py now adds narration-cued callouts for parallels, Equator, all five named latitude lines, North/South Poles, Prime Meridian and Date Line. Seven label/transition snapshots reviewed (label-snapshots); small line-anchor refinements followed and need regenerated snapshots. Latest build has 298 timed nodes. Ten composition tests pass. No final render yet.

Ten word-boundary flags now have documented 10ms waveform + short/wide ASR evidence in word-boundary-repairs.json. prepare_v4_timing.py applies these AFTER silent-prefix/overlap cleanup with exact old-boundary guards. Updated alignment has 1,139 preserved words and zero structural timing flags; this is acoustic evidence, not human listening approval. Source panels/composition/media plans rebuilt successfully in dependency order; one transient truncated ffprobe JSON caused a guarded stop, the single local retry succeeded. Checkpoints still need proper reconciliation; no final completion claims.

No final v4 MP4 yet. All provider jobs are recovered: 27 downloaded, five rejected, 22 candidate clips, zero pending. Batch 10 clean replacements 188289817/188289821 passed all-81-thumbnail review; batch 09 remains rejected. No new submissions needed. Six production precision globe animations plus corrected Start-Up Activity are complete at 1080p30; no local component render is active.

The new hyperframes-v4-production draft now contains all 22 sections, 71 source blocks, seven figures, 173 caption phrases, 29 video elements and 22 audio elements. composition-coverage.json remains draft, not final QA approval. Three short clips are gently retimed (not looped) by prepare_v4_render_media.py. Ten composition tests pass. HyperFrames check exited 0: runtime/layout zero errors or warnings, 55/55 contrast checks pass. Structural lint warnings remain (monolithic timed nodes/density, duplicate figure heuristic); they are not encoded QA. Five full-size compiled snapshots reviewed; no clipping seen. All-section and boundary review still needed.

compose_v4.py is being corrected for visual layer order and a 0.25-second incoming heading-background dissolve over the preceding quiet tail; rebuild and recheck before render. The exact measured heading holds and speech times are not changed. Current draft source figure p0006-b0007 (coordinate example) deliberately accompanies s07 exact-position explanation rather than s16 date-line narration; coverage records relocation.

Ten uncertain ASR word flags were rerun and remain explicitly unapproved; unsafe crop-edge/silence-overlap suggestions were NOT applied. Read word-flag-audio-review.json. Next: complete timing/transition preview QA, reconcile superseded manifests in stage order, then one-worker low-memory render after disk/process checks and encoded QA. No dependency installs. Static HTTP server on 127.0.0.1:8766 is a project-file preview only (Python PID 21348 at last check), not a render. Last disk C 11.55 GB, D 189.56 GB.

## Previous verified update: 2026-10-01, approximately 14:05 IST

No final v4 chapter MP4 exists. Batches 08 and 09 recovered: 25 downloaded provider clips, five rejected (including both batch-09 clips for fabricated lettering), 20 candidates. Batch-08 opening globe has all-81-thumbnail review, but final-size placement remains. Provider rejected 122-frame request as over its 120 limit; shared Wan adapter clamp corrected to 120 with 14 passing targeted tests. A 114-frame accepted request still returned 81 frames/5.0625 seconds, so duration must be measured, not assumed. Preserved diagnostic: motion-batch-08-validation-error.json. Inventory helper corrected to ignore diagnostic/status JSON instead of mistaking it for a submission manifest.

Batch 10 is a clean replacement for the two rejected batch-09 outputs, using the same fresh GPT reference artwork but physical-action-only prompts. Recover any batch-10 durable IDs before submitting again. See motion-batch-10.json and its status sidecar. GPT reference prompts/provenance: gpt-reference-artwork-batch08.md and gpt-reference-artwork-batch09.md. Three reference PNGs are in assets/images/gpt-keyframes. Originals and rejected clips are preserved.

Six exact sphere/coordinate teaching components now exist as 480p15 previews: GridLines, LatitudeCircles, ImportantParallels, MeridianLines, GreenwichTime, DateLine. All one-second preview thumbnails inspected; geometry unit tests pass (10). Sources precision_globes_v4.py and precision_globe_geometry.py. Production sequential runner render_v4_globes.py is CURRENTLY RUNNING under session 47023; inspect per-scene precision-*-production.json and process/lock before starting any local render. Shared lock artifacts/revision-v4/startup-render.lock prevents concurrent renders. Remaining overlay work: exact degree/name labels, GMT 15-degree/one-hour relationship, IDL gain/loss day labels, source figures and synchronized panels/captions. No final composition approval yet. See precision-globes-review.json.

Last disk check C 11.57 GB, D 189.63 GB. No dependency installs. Existing shared composer is not safe to blindly reuse: single-video-per-section assumption and fake green continent blobs/red-tab decoration conflict with current scope/reference. New v4 composition must support multiple timed shots and source diagrams, English/EVS typography/panels, measured words and title-only heading holds. Ten audio flags remain unresolved. Reconcile superseded manifests in stage order only after evidence, then preview, one-worker low-memory render and encoded QA.

## Previous verified update: 2026-10-01, approximately 13:39 IST

**No final v4 chapter MP4 yet.** All batches through 07 are recovered: 22 downloaded provider clips, 3 rejected, 19 candidates, zero pending provider jobs. Do not submit duplicates. Batch 06 IDs 188286906/188286916/188286920 and batch 07 IDs 188287378/188287385/188287394 all delivered. Batch 07 comprises Southern Ocean, Arctic Ocean and marine life; GPT inputs and full prompt provenance are in gpt-reference-artwork-batch07.md. All six latest clips passed technical checks and all 81 thumbnail frames per clip were reviewed, but placement/full-size approval remains pending.

Source-panel timing now matches complete contiguous source spans, rather than prefixes; all 71 source blocks, all table cells and seven selected figures resolve with zero timing issues. Exact source text is preserved in <=35-word body pages. Ambiguous matches fail closed, overlaps and heading-hold intersections are checked. Decimal token normalization preserves 23.5 versus 235. Seventeen panel/timing tests passed; 26 combined with recovery/deadline tests passed. source-panel-plan.json remains render_ready=false until layout and listening QA.

Ocean cues now alternate exact source maps for geographic phrases and unique short motion clips for waves, shipping, ice and marine life. Their measured motion intervals fit the recovered clips, avoiding loops. Three land/reef cues slightly exceed five seconds and need explicit gentle retiming, not looping. See visual-cue-plan.json. Intro and other precision teaching visuals remain unfinished.

Start-Up Activity production correction completed at 08:07 UTC, runner session 64071 exited 0; no active component render left by that runner. Selected candidate: assets/video/precision-v4-production-linefix/videos/precision_v4/1080p30/StartUpActivity.mp4, H.264 1920x1080 30 fps, 706 frames, 23.533333 seconds versus 23.548-second narration (14.7ms short; explicit stable teaching end-hold is acceptable). Twenty-four one-second samples plus a full-size 12-second frame reviewed: continuous front-facing great-circle arcs, one ball, marker appears after construction. Full frame/timeline QA still pending. Earlier precision-v4-production output is rejected/superseded because Cairo depth sorting produced dashed/doubled rings. Preserve it but never select it. A fixed teaching camera and analytic visible semicircles remove that artifact. Source: precision_v4.py. Bounded isolated runner: render_v4_startup.py; lock automatically released. Do not run concurrent local renders.

Ten audio/word flags remain unresolved. audit_v4_word_flags.py ran cached small.en on local crops; word-flag-audio-review.json records independent candidates, NOT repairs. Several candidates touch crop edges, overlap known heading silence, or have low confidence, so none were applied. The script has since gained explicit unsafe-candidate annotations; rerun before relying on those annotations. No pronunciation/listening approval claimed. Missing scipy was avoided using existing faster_whisper decoding; no packages installed.

Next: precision teaching visuals and intro, full-size asset selection, flagged word onset/offset checks, complete HyperFrames composition with source panels and measured highlights. Then reconcile checkpoints in order, preview and one-worker render/encoded QA. The audio/timing/source plan is not a finished video. Check current disk/processes before launching any render.

## Previous verified update: 2026-10-01, approximately 13:10 IST

**Chapter remains unfinished; there is no approved v4 final MP4.** This update supersedes the old six-job provider-wait restriction below: all six original requests were recovered successfully without resubmission. The three batch-05 jobs also recovered at 07:34 UTC: Antarctic ice 188286184, researchers 188286199, Great Barrier Reef 188286201. Inventory now has 16 downloaded outputs: 3 rejected and 13 candidates, none composition-approved. All nine newly recovered clips pass technical motion checks (5.062 seconds, silent video, no detected black/frozen interval). All 81 thumbnail frames per clip were inspected and recorded in motion-qa-progress.json. This is not full-size playback or placed-timeline approval. Researcher hands/instrument and perceived ice motion deserve final-size scrutiny.

Fresh batch-06 GPT reference artwork has been generated with the built-in image tool, saved in assets/images/gpt-keyframes, and submitted to the approved Wan 2.2 I2V adapter. Prompt set: gpt-reference-artwork-batch06.md; generation requests: motion-batch-06.json. These are reference images for motion, not still-image substitutes. All three accepted jobs are pending recovery; resume these IDs first:

| Shot | Durable request |
| --- | --- |
| pacific-ocean-i2v-06 | 188286906 |
| atlantic-shipping-i2v-06 | 188286916 |
| indian-ocean-i2v-06 | 188286920 |

The submit-only process exited 0. No Python/FFmpeg process or local render remained at the final check. No duplicate jobs submitted. Use recover_v4_once.py on the next heartbeat, not another long polling cycle. Remaining generative assets include Southern Ocean, Arctic Ocean and a distinct marine-life shot. Pacific/Indian reference water has naturalistic detail despite CGI rendering; review style and genuine motion before placement. Source maps, not generated backgrounds, supply geographic accuracy and labels.

Fixed the shared adapter's polling-deadline error in tools/video/_modelslab_shared.py: a transport error exhausting the deadline now raises TimeoutError rather than accessing an unassigned or stale response. Four new mocked regression tests cover first/late deadline failures, recovery and bounded attempts. All 22 targeted ModelsLab tests passed (exit 0). This local bug did not prove that earlier provider processing delays were client-caused.

New prepare_v4_panels.py builds source-panel-plan.json: 71/71 required source blocks across all 22 sections, exact source slices (at most 35 words per body page), intact table cells and figure references. Fixed its figure manifest pointer to artifacts/revision-v4/source-figure-manifest.json; a regression test verifies all seven references resolve. This is a DRAFT, render_ready=false: prefix timing diagnostics still require end timings, overlaps and layout review. Do not treat it as complete composition. Title panels stay visible during heading holds while body panels are suppressed. Rebuilt visual-cue-plan with the recovered Antarctic and reef assets. All 18 local timing/panel/recovery tests passed; the combined panel + ModelsLab run also passed 27 tests.

Next: recover batch 06, generate remaining ocean footage, finish precision teaching animations and panel timing, then complete audio listening checks and HyperFrames composition. The earlier ten word-timing/listening flags remain. Stable source maps/diagrams/Recall/Word Bank are permitted only as deliberate teaching screens; do not stretch the short provider clips across the chapter. Full final render and encoded textbook comparison remain pending.

Disk check: C **6.20 GB**, D **189.65 GB** free. Recheck and ensure adequate TEMP/streaming space before a production render; never start a multi-worker screenshot capture. No dependencies installed and no checkpoints falsely marked complete.

## Previous verified update: 2026-10-01, approximately 12:42 IST

Bounded recovery sweep at 07:04 UTC checked all six outstanding job IDs once (HTTP 200 each): all remain **processing**, no output URLs, no new submissions. See recovery-sweep-latest.json. This is not evidence of terminal failure. New project helper recover_v4_once.py checks saved jobs once with at most three concurrent fetches and only invokes explicit-ID recovery when output is ready. Five offline guard tests pass, including no duplicate submissions, no secret output, preserving sidecars after transport errors, and no false recovered status for missing output. The eight subtitle timing tests also still pass (13 total, exit 0). Use this bounded sweep on future heartbeats rather than another 900-second polling cycle for every job.

Corrected Start-Up Activity **moving preview now exists**, rendered successfully with the isolated Manim environment and a 900-second process limit. File: assets/video/precision-v4-preview-corrected/videos/precision_v4/480p15/StartUpActivity.mp4. ffprobe confirms 854x480, 15 fps, H.264, 354 frames, 23.600 seconds, silent. Reviewed 24 one-second samples: the sphere remains visible, line construction appears and marker follows. It is preview-only, not production approved; thin lines/mesh seams, full-resolution legibility, subtitle/panel placement and exact boundary frames remain. See startup-preview-review.json and startup-sheet.jpg. The old floor-occluded preview remains rejected. Render session exited 0; no local render was left running.

Everest I2V and Sahara I2V now also have all-81-frame thumbnail contact-sheet review (motion-qa-progress.json). Stable illustrative 3D geometry and smooth progression observed, no obvious cuts or textual artifacts. This does not certify geographical reconstruction or final placed-timeline QA.

Last free-space check: C 9.51 GB, D 189.67 GB. Recheck before a production render. No dependencies installed, no final MP4 or checkpoint completion claimed.

## Previous verified update: approximately 12:27 IST

**Chapter is NOT rendered or ready. Stop new paid submissions until the six accepted I2V jobs below are recovered or conclusively failed.** They each exhausted a bounded 900-second polling window without delivering output. This is a provider-wait blocker, not permission to resubmit. All six polling processes have exited; no known active local render remains. Keep the heartbeat active, but avoid repeated submission or unchanged notifications.

| Shot | Durable request | Current local state |
| --- | --- | --- |
| grand-canyon-i2v-03 | 188282817 | timed_out, resumable; no MP4 |
| niagara-falls-i2v-03 | 188282827 | timed_out, resumable; no MP4 |
| amazon-rainforest-i2v-03 | 188282837 | timed_out, resumable; no MP4 |
| andes-i2v-04 | 188283427 | timed_out, resumable; no MP4 |
| eiffel-i2v-04 | 188283442 | timed_out, resumable; no MP4 |
| colosseum-i2v-04 | 188283452 | timed_out, resumable; no MP4 |

Prompts and local GPT starting-frame paths are in motion-batch-03.json and motion-batch-04.json. Images were generated with the built-in GPT image tool and copied to assets/images/gpt-keyframes/. They are reference inputs for animation, NOT slideshow substitutes. Submission helper now supports explicit image_to_video and project-local reference paths. It skips outputs/sidecars to prevent duplicate submissions.

`media-inventory.json` is the current acquired-media evidence: **7 downloaded provider clips = 3 rejected + 4 candidates**, and **6 pending recovery**. `refresh_v4_media_inventory.py` updates inventory and batch status without provider calls. Do not equate acquisition_complete with quality approval.

New wildlife QA: africa-wildlife-02 and australia-wildlife-02 pass technical motion checks. All 81 frames of each were reviewed in thumbnail contact sheets; identities and cartoon style remain consistent. Both still require final-size/timeline QA. The Australian clip does not hop; this is acceptable for narration naming the animals, which does not claim hopping.

### Subtitle timing repair and cue plan

Run `prepare_v4_timing.py` from the repo with PYTHONPATH set to the repo to reproducibly produce:
- alignment-clean/narration_aligned.json, word_captions.json, formatted_subtitles.srt, qa.json
- visual-cue-plan.json: all 22 measured sections, 28 precise continent/ocean visual cues, four-second heading holds, missing-asset and duration flags. It is NOT render-ready.

Original alignment and narration were preserved. Clean copy retains **all 1,139 words**, fixes `to:.` and `halves:.`, and resolves three 20/40/60ms overlaps at their midpoint. The audio waveform confirms all 21 post-heading pauses are four seconds and below 0.001 peak amplitude. First body-word timestamps were incorrectly extended backwards into this silence in 18 sections; only those silent prefixes were trimmed. The worst was s16-idl, where "The" began 4.241 seconds too early. No wholesale section offset was applied. Three long/short boundary uncertainties and several very short words still require listening review; refer to qa.json. This is structural QA, NOT pronunciation approval.

Eight tests in test_v4_timing.py pass, including source token preservation, monotonic word timings, ambiguous cue rejection, subtitle splitting over pauses, and 22 four-second title holds. The test output exit code was 0.

### Source illustrations

Seven required source figures are now inside assets/source-figures/revision-v4, with source-figure-manifest.json and source-figure-review.json. `extract_v4_figures.py` matches existing OpenDataLoader embedded images by page/bounding-box IoU; six selected images are original embedded assets, one is a Poppler page crop. Use ONLY the manifest-selected paths:
- For continent_map use **continent_map.png**, NOT continent_map-source.png: embedded extraction has three white rectangles at lower right.
- Do not use the broad `*-v2.png` padded crops; some include adjacent body text.
- Preserve original labels, transparency, and SailingIssues.com credit. The source typo "North Pool" remains in the coordinate illustration; do not narrate this as new wording.
- Final composition must contain full figures without cropping and verify encoded label readability.

### Precision Start-Up Activity prototype (NOT approved media)

Existing isolated environment C:/Users/user/Miniconda3/envs/openmontage-maths-manim has Manim 0.19.0; no dependencies were installed. precision_v4.py authors one true 3D sphere with three orthogonal great circles, timed from spoken cues. This is a precision teaching visualization, not a substitute for missing Wan story footage.

The first 480p15 preview at assets/video/precision-v4-preview/videos/precision_v4/480p15/StartUpActivity.mp4 is **REJECTED**: an unshaded floor occluded the sphere. Code was corrected with 3D shading for the floor/shadow, and a new final-frame snapshot verifies the sphere is visible at assets/video/precision-v4-framecheck-v2/images/precision_v4/StartUpActivity_ManimCE_v0.19.0.png. Fine mesh seams still need visual polish. The corrected moving clip has NOT been rerendered; there is NO production 1080p version. Never select the rejected preview by filename existence.

## Earlier progress and checkpoint context

Latest continuation update: rebuilt scene_plan.json and media_research_plan.json in this v4 directory using measured narration. Both checkpoints now completed; assets is in_progress. asset_manifest.planned.json is a plan, NOT acquired assets. The old prerequisite error remains relevant for assets/voice until validated; do not redo scene planning unnecessarily.

Two more source-cued T2V cartoon wildlife jobs have been submitted in motion-batch-02.json: africa-wildlife-02 request 188281720 and australia-wildlife-02 request 188281722. Check local outputs and sidecars and resume these IDs before new submissions. These are candidates requiring visual/anatomy QA, not automatically approved. The submission helper submit_v4_batch.py preserves existing job sidecars and does not resubmit them.

The first five recovered clips are listed below; the two wildlife clips described above bring the downloaded count to seven. Provider recovery worked without duplicate submissions for these earlier jobs.

| File | Provider request | Review |
| --- | --- | --- |
| startup-ball-01.mp4 | 188280278 | Reject: more than one ball appears despite single-ball prompt; not suitable for the intended explanation. |
| asia-everest-01.mp4 | 188280281 | Reject style: photorealistic rather than requested animated-film look. |
| africa-sahara-01.mp4 | 188280293 | Reject style: photorealistic, with unwanted bright drifting particles. |
| asia-everest-i2v-02.mp4 | 188280736 | GPT-reference animation recovered; technical motion QA passed, five sampled frames preserve stylized mountains. Full clip/semantic/timing QA remains. |
| africa-sahara-i2v-02.mp4 | 188280947 | GPT-reference animation recovered; contact sheet extracted. Run technical and semantic checks before acceptance. |

The generated clips are around five seconds, 832x464 (I2V) or 832x480 (T2V), 16 fps. Do not call them native 1080p or full chapter coverage. Do not stretch these few clips across ten minutes.

GPT keyframes are copied into assets/images/gpt-keyframes/everest-3d-v4.png and sahara-3d-v4.png. Their I2V prompts are in this directory. Generated with the built-in image tool; use the images as video references, not slideshow substitutes.

The local `modelslab_recovery_smoke` sessions for these two I2V clips finished successfully (exit 0). No known active generation session remains at handoff. Always inspect job sidecars and active processes before starting work.

## Timing and checkpoint issue

Alignment generated 1,139 word entries successfully using faster_whisper, saved under alignment/:
- narration_aligned.json
- word_captions.json
- formatted_subtitles.srt
- qa_card_props.json (empty because this scope has no assessment cards)

The attempt to finish text_audio_alignment was rejected with PREREQUISITE VIOLATION: scene_plan, media_research, assets and voice_synthesis are invalidated/missing for the v4 scope. Preserve the alignment outputs; do not rerun costly alignment merely to update tracking. Rebuild/revalidate the upstream artifacts in manifest order; never falsify completed checkpoints to bypass the gate. Root artifacts/scene_plan.json is stale (section-0001 IDs); it is NOT the current scene plan.

Alignment still needs source-token and monotonic-time verification, pronunciation listening checks and pause checks. Known narration-derived punctuation defects include `to:.` in objectives and `halves:.` in hemispheres. Repair display punctuation without losing source words or changing timing; check whether audio needs regeneration before doing so. Original audio lives in assets/audio/narration-v2; v4 references only the approved 22 files. Do not assume recorded `wer: 0` means pronunciation was verified.

## Next work, in order

1. Recover the six durable jobs above before new submissions; do not repeat the prior paid jobs. Inspect any returned clips fully and record QA. Preserve rejected candidates, exclude from composition.
2. Build the v4 scene/shot plan using measured narration, sentence/word cues, PDF figures and source boxes. Multiple unique shots are needed for continents and oceans; each named landmark or animal must match its spoken cue. Maps, coordinates and degree labels need exact authored overlays, not generated lettering.
3. Reconcile scene/media/asset/voice checkpoints with evidence. Assets remain incomplete until real required media exists and passes checks. Do not run full ingestion again or allow old config to overwrite the scoped plan.
4. Generate remaining relevant fresh assets in bounded small batches under the configured Wan models. Respect rate limits (the user reports 35 videos/hour, 18/30 minutes, 15 concurrent); no unlimited retry storm. Use the existing adapter and durable sidecars.
5. Validate narration and word alignment, then build approved HyperFrames composition. Text panels must paginate/read clearly, no overflowing paragraphs or stray decorative lines; subtitles must have professional punctuation and word highlight. Heading pauses show title only over relevant motion.
6. Preview timeline and boundary frames; run HyperFrames lint/info and ensure static registration of all timed media.
7. Render to a new versioned output using one worker, low-memory streaming after checking free temp disk. Do not overwrite the rejected old MP4. Check ffprobe, encoded frames, subtitles, source coverage, audio onset/offset, motion and visual/audio semantic synchronization end to end before calling it final.

## Existing interfaces

Run Python from D:/InkSpectrum/OpenMontage. Current Python has faster_whisper and kokoro_onnx; WhisperX is absent. Use registry/tool adapters and EducationalRunTracker. No dependency installs without recording requirements and installation guide first.

Recovery only:
`python -m tools.analysis.modelslab_recovery_smoke --output <existing-output.mp4> --resume-job <existing-output.mp4.modelslab-job.json>`

I2V submission/recovery helper (only after checking no prior job for target):
`python -m tools.analysis.modelslab_recovery_smoke --model-id wan-2.2-i2v --operation image_to_video --duration 5 --resolution 480 --fps 16 --num-frames 82 --reference-image <project-keyframe.png> --prompt-file <prompt.txt> --output <unique-output.mp4>`

Credentials are already in ignored environment configuration. Never print them. Existing repository edits are user-owned; do not reset or commit unrelated changes.
