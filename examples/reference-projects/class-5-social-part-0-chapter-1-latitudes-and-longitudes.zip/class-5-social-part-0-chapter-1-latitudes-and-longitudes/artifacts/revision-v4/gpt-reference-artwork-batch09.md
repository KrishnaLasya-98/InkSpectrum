# Fresh continuity artwork

Built-in GPT image tool used on 2026-10-01. Both references were inspected: single globe, coherent broad continents, no labels, matching classroom materials. Right/left placement reserves the approved title/teaching-panel slots. These are video inputs, not still slideshow media. Source PDF figures remain factual authority.

- Opening detail: assets/images/gpt-keyframes/opening-detail-3d-v4.png. Original retained: C:/Users/user/.codex/generated_images/01a0a9f5-8189-72c3-8d39-262c2d7edcb4/exec-3bdadb9d-097d-4ec9-8c5b-844e10821e3b.png.
- Globe explanation: assets/images/gpt-keyframes/globe-teaching-3d-v4.png. Original retained: C:/Users/user/.codex/generated_images/01a0a9f5-8189-72c3-8d39-262c2d7edcb4/exec-bf429ae2-0963-4487-bd85-edc07a3e867f.png.

## Opening detail prompt

Use case: stylized-concept. Input image: reference for classroom design, globe materials and lighting only. Create a new camera shot of the same single blue globe on the same dark teal stand and honey wooden desk in this warm child-friendly 3D animated classroom. Move the camera slightly closer and lower, with the globe still on the right third, complete sphere and stand in frame, left half softly detailed and uncluttered for a title overlay. Preserve coherent recognizable Africa/Europe continental silhouettes, thin spherical coordinate lines, bright warm morning light and tactile CGI surfaces. It must clearly look like polished 3D animation, not live-action. No text, numbers, country borders, letters, logos or watermark. No people or additional globe. Wide 16:9 frame. This is the input to a second moving opening shot, not a still slide.

## Globe explanation prompt

Use case: stylized-concept. Input image is a continuity reference for the same classroom, globe and lighting. Create a different wide 16:9 composition for the lesson's explanation of a globe, NOT its title. The single blue globe and its dark teal stand now sit fully within the LEFT half on the same honey wooden classroom desk, with recognizable Africa, Europe and Asia facing us. Preserve the same child-friendly polished 3D animated-film CGI style and coherent real-world continent silhouettes. The RIGHT half is an uncluttered softly lit warm cream classroom wall reserved for a teaching text panel. A large sunlit window behind the globe gives depth, foliage outside, tactile soft materials. Keep the complete spherical globe and its base within frame. No country boundaries, no printed labels, no letters, numbers, words, logos or watermark. No people and no second globe. Do not mirror the continents: use correct geographic orientation. This will be animated as moving footage.
