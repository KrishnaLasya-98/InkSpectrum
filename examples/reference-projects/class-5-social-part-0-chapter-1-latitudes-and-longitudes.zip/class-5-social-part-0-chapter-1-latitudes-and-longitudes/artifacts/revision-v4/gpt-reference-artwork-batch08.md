# Opening artwork provenance

- Generated 2026-10-01 with the built-in GPT image tool, not CLI fallback.
- Original retained at C:/Users/user/.codex/generated_images/01a0a9f5-8189-72c3-8d39-262c2d7edcb4/exec-9e629f56-d5c6-4f19-b31f-37770411576c.png.
- Project copy: assets/images/gpt-keyframes/opening-globe-3d-v4.png.
- Inspected: single CGI globe, right-side framing, title-safe left side, no visible text. Illustrative globe only; exact source diagrams remain the teaching authority.
- Animate with approved Wan 2.2, 114 requested frames at 16 fps. The first 122-frame request was explicitly rejected as above the API maximum of 120; no job ID was returned and no recovery sidecar exists. Corrected the adapter limit, preserved this evidence, and made one corrected submission. Actual duration must be probed; never assume provider duration, loop or freeze it to fill the title.

## Exact image prompt

Use case: stylized-concept. Asset type: starting frame for an animated Class 5 Social Studies chapter opening about Latitudes and Longitudes. Wide 16:9 composition, polished child-friendly 3D animated-film aesthetic, clearly CGI rounded forms and soft tactile materials, not a photograph. A single beautiful blue classroom globe on a sturdy dark teal stand sits on a honey-colored school desk at the right third. The globe displays recognizable simplified Earth continents without country borders or any labels, Africa and Europe facing the viewer; correct broad continental silhouettes, no invented extra land. Gentle thin curved latitude and longitude grid lines follow the spherical surface. Sunlit classroom, soft green foliage outside the window, gentle depth of field, rich warm natural light. Keep the left half softly detailed and low contrast to reserve room for a large title panel added later. Full globe and stand remain inside safe margins. No people, no words, no letters, no numerals, no watermark, no logos, no border, no subtitles. This is an input for true moving video, not a finished still slide.
