# Batch 05 reference artwork

Generated 2026-10-01 with the built-in GPT image tool, not CLI. All three inspected: subject/style/composition suitable as animation references; not approved as standalone still backgrounds.

## antarctic-ice-3d-v4

Saved: `assets/images/gpt-keyframes/antarctic-ice-3d-v4.png`

Prompt: Use case: stylized-concept. Asset: 16:9 reference frame to animate for Class 5 geography. Create a polished child-friendly 3D animated-film landscape of Antarctica, a vast snow-covered continent with rounded blue-white ice cliffs and glaciated mountains, cold blue sea in foreground with a few small ice pieces. Clearly computer-animated matte materials, simplified sculpted forms, soft global illumination, cheerful clear polar daylight. Wide cinematic view with uncluttered upper-right sky for a later teaching panel. No text, labels, map outlines, logos, watermark, buildings, people, animals, polar bears or vegetation. Not photorealistic and not a flat illustration.

## antarctic-researchers-3d-v4

Saved: `assets/images/gpt-keyframes/antarctic-researchers-3d-v4.png`

Prompt: Use case: illustration-story. Asset: 16:9 starting frame for child-friendly 3D educational animation about scientists working in Antarctica. Two adult scientists with friendly expressive cartoon faces, one in orange insulated parka and one in teal parka, gloves and snow boots, standing on snowy ground beside a small unbranded research station. One holds a plain clipboard; the other observes a simple weather instrument. Modest small equipment, no writing or markings. Icy blue mountains behind, clear polar daylight. Polished stylized 3D animated-film render, rounded sculpted forms and matte textures, not photorealism. Place people lower-left/center, upper-right sky uncluttered for later textbook panel. No flags, borders, letters, labels, logos, watermark, animals, extra limbs or bare skin except faces.

## great-barrier-reef-3d-v4

Saved: `assets/images/gpt-keyframes/great-barrier-reef-3d-v4.png`

Prompt: Use case: stylized-concept. Asset: 16:9 keyframe for a Class 5 animated geography video mentioning Australia's Great Barrier Reef. Polished child-friendly underwater 3D animated-film scene: a healthy coral garden of rounded branching and plate corals, a few small reef fish with plausible fins and anatomy, turquoise clear water and soft sunlight shafts. Wide view with strong sense of depth and room for fish to swim; coral fills lower-left and lower center, upper-right mostly clean blue water for later overlay. Matte sculpted animated materials and soft global illumination, vibrant but natural coral colors. No text, people, labels, maps, country outlines, logos or watermark, no anthropomorphic smiling coral, no photorealism, no flat drawing.

Animation requests and motion prompts: motion-batch-05.json. Returned footage must pass semantic and technical QA.
