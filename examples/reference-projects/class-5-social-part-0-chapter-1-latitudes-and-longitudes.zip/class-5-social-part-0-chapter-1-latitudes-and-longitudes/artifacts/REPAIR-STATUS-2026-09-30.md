# Chapter 1 repair status

The existing native-animation MP4 is not the approved final delivery. Do not
mark it accepted or start Chapter 2 from its layout.

## Verified this session

- ModelsLab `h3-minimax-ref-to-video-fast`: live five-second reference-video
  submission rejected for exhausted third-party access; no request ID created.
  Provider website labels this model open source, so account entitlement needs
  clarification from ModelsLab before assuming a new subscription is necessary.
- ModelsLab `wan2.2`: new text-to-video job 188227903 completed and recovered
  with the same request ID. Sample: `assets/video/recovery-smoke/globe-wan22.mp4`.
  ffprobe: H.264, 832x480, 16 fps, 5.0625 seconds, no audio. This is a provider
  smoke test, not final semantic, motion, or 1080p-quality acceptance.
- Six previously completed chapter clips recovered without new submissions into
  `assets/video/recovered/`: sections 0013, 0029, 0062, 0063, 0100, 0112.
- Recovery guards distinguish evaluator-pending from rejected footage, preserve
  attempt files, stop account-limit retries, remove automatic model swaps and
  protect existing media against destructive dry-run placeholders.
- Focused tests: 12 passed. Broader tests identified the pre-existing independent
  template-package hash mismatch. Do not replace its expected hash with the
  current file hash merely to bypass the guard.
- Narration splitter preserves decimal values and complete sentences. Longer
  sentence timing still requires a reviewed multi-shot media plan before render.

## Still required before final rendering

1. Rebuild and verify source-aligned chapter plan, every exercise and its answer.
2. Restore approved English/EVS presentation components and independently pin
   the reviewed package; current package has not passed reference review.
3. Resolve evaluator runtime and inspect recovered/new clips for relevance,
   geography accuracy, motion and minimum usable source quality.
4. Generate sufficient unique motion under the approved provider path; never
   stretch a five-second clip to cover a long narration sentence.
5. Regenerate changed narration, align actual word timings, verify title/topic
   pauses and produce a representative composed preview.
6. Render Chapter 1 and pass source, audio, layout and encoded-video QA.
7. Obtain Chapter 1 acceptance before sequential remaining-chapter production.

No full chapter generation/render job is currently running after the smoke test.
