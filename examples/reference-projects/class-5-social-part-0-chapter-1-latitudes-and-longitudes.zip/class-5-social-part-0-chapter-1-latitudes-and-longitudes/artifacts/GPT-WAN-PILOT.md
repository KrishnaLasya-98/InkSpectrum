# GPT image to Wan video pilot

User approved this route on 2026-09-30: create images with GPT and animate them
using Wan image-to-video. This is a single-scene test, not final chapter QA.

- Source: Chapter 1, Globe subsection: a globe is a small model of Earth.
- Image: built-in GPT image-generation tool, no explicit model ID exposed.
- Image asset: `assets/images/gpt-keyframes/globe-classroom-v1.png`.
- Image prompt: polished child-friendly 3D classroom globe, navy stand, honey
  wooden desk, warm window light; recognizable Africa/Europe/Asia; clear right
  panel and bottom caption space; no text, labels, people or UI.
- Video model: ModelsLab `wan-2.2-i2v`, `image_to_video`, 480 resolution,
  18 fps requested, 90 frames requested. Exact measured output may differ.
- Motion prompt: `artifacts/gpt-wan-i2v-pilot-prompt.txt`.
- Video: `assets/video/gpt-wan-i2v/globe-classroom-v1.mp4` when downloaded.
- Final output must contain actual motion, not Ken Burns image animation.
- Exact geography diagrams and all text remain separate deterministic overlays.
- Previous H3 Fast route is account-blocked. Wan text-to-video succeeded;
  image-to-video remains subject to this independent live test.

## Submission

ModelsLab accepted image-to-video job `188228324`; its durable sidecar is next
to the intended MP4. Do not resubmit this shot merely because it is slow.
The current CLI polls this job for up to 900 seconds and records timeout as
recoverable. A processing status is not a visual QA pass.

Two offline regression tests passed for image/reference input routing. This
ensures that image-to-video sends `image_url`, rather than accidentally sending
the reference-to-video-only field and omitting the required starting image.

## Result

- Job 188228324 completed and downloaded after 835.43 seconds; no duplicate
  generation was submitted. Image-to-video provider access is confirmed.
- ffprobe: 5.0625 seconds, 832x464, 16 fps, H.264, 81 decoded frames, no audio.
- Complete-clip FFmpeg black/freeze scan found no events at the configured
  thresholds (black 0.20 seconds; freeze 1.5 seconds with noise 0.003).
- Five one-second visual samples show genuine globe rotation and preserve the
  broad classroom/globe appearance. Not merely a still-image pan or zoom.
- Visual issues: some framing drift and a small new camera-like object at the
  right desk edge. These violate strict reference preservation and require
  refinement before final production acceptance. Geography labels/diagrams
  must still come from validated deterministic overlays, not this texture.
- Output is not native 1080p/30fps. A larger export does not restore lost detail.
- The six-tile contact sheet has one black unused padding tile; that tile is
  not an encoded black video frame.
- Status: provider pilot successful, final visual acceptance pending. This is
  not a final chapter video and is not authorization to bypass chapter QA.
