# Chapter 1 visual source review - 2026-09-30

Status: source pages reviewed; production repair required. NOT final-render approval.

Source: `textbook-collections/class-5-social/source-chapters/chapter-01-latitude-and-longitudes.pdf`.
All ten rendered pages (`tmp/pdfs/social-ch1/page-01.png` through `page-10.png`)
were visually inspected in this session and compared with `artifacts/extracted_content.md`.
Printed pages are 7-16. The previous Markdown is a normalized transcription,
not a verbatim source or a complete inventory of visual elements.

## Required sequence and visual coverage

| PDF page | Printed page | Mandatory teaching content | Visual/layout requirements |
| --- | --- | --- | --- |
| 1 | 7 | Lesson 1: Latitudes and Longitudes; Learning Objectives lead-in and all five objectives; Start-Up Activity complete text; Globe complete paragraph | Chapter title; yellow objectives box; blue activity box; globe illustration |
| 2 | 8 | Continents complete paragraph: seven continents and every named place/feature/animal | Preserve all seven continent labels and positions on the source map; one relevant visual per spoken subject |
| 3 | 9 | Oceans complete paragraph: five oceans, location/features, surface coverage and uses | Ocean map, both Pacific labels, Arctic arrow, Southern Ocean boundary, all five ocean names |
| 4 | 10 | Lines on the Globe; Latitudes or Parallels; Do You Know?; all five Important Parallels; all three Characteristics of Latitudes | Preserve blue callout; exact degree values; latitude globe labels including poles, Equator, north/south and degree ticks |
| 5 | 11 | Longitudes or Meridians; Eastern and Western Hemisphere; both hemisphere descriptions | Both globe diagrams; meridian/parallel labels, degree ticks, Prime Meridian, Equator, antimeridian, east/west arrows |
| 6 | 12 | Greenwich Mean Time (GMT); Let's Learn More!; International Date Line (IDL) | Yellow fact box; complete cutaway coordinate diagram, including New Orleans example, Earth's centre/radius, angles, Equator and Prime Meridian; retain figure attribution |
| 7 | 13 | Do You Know?; four Characteristics of Longitudes; transition into comparison; full four-row comparison; Recall; all five Let's Remember lines | Yellow fact box; three-column/four-row comparison with original row relationships; visibly distinct Recall and Let's Remember sections |
| 8 | 14 | Word Bank: all five word/meaning pairs; Assessment Activity; I: five very short questions; II: three short questions; III: two long questions | Original headings and numbering; questions before answers; preserve degree symbols; readable glossary pairs |
| 9 | 15 | IV: five blanks; V: five true/false statements; VI: five matching pairs; Activity heading, Find Your City on the Map! and three instructions | Keep blanks empty during question phase; true/false answer slots; original a-e matching options and their order; timed answer connectors/reveals |
| 10 | 16 | Project heading, Create Your Own Globe! and all three instructions; HOTs: both questions; Life Skills complete paragraph and discussion instruction | Purple project box; blue HOTs response area; Life Skills box; end after this content, not at the assessment table |

## Confirmed extraction differences requiring repair

1. Page 7 transition sentence is missing from the Markdown:
   `Let’s see the difference between Latitudes and Longitudes`.
2. Page 5 original heading is `Eastern and Western Hemisphere`; the Markdown
   silently pluralizes it. Preserve the original displayed heading.
3. Page 9 separates `Activity` from `Find Your City on the Map!`; page 10 likewise
   separates `Project` from `Create Your Own Globe!`. Preserve both hierarchy levels.
4. The original final activity instruction is `Compare with three other cities.`;
   the Markdown changes it to `Compare them with three other cities.`
5. Figure labels and numeric ticks are absent from the Markdown coverage list.
   The large page 6 New Orleans coordinate example is not represented at all.
6. Original matching choices are lettered a-e, and response slots are explicit;
   the Markdown table loses those identifiers and slots.
7. Source punctuation, capitalization and some wording are normalized, including
   duplicated punctuation in questions, `Colosseum`/`Coliseum`-style spelling
   variation (source spells `Coloseum`), and the final Australia sentence. Use
   separate raw-source and polished-delivery fields; do not label a normalized
   passage an exact transcription.

## Ambiguities and source errors - no silent changes

- RESOLVED BY USER: filename and current project say Grade 5, but every inspected
  footer says `Rockland Social book - 4th class`. The user confirmed that this is
  an editor's mistake and the book belongs to Class 5. Opening title and metadata
  must use Social Studies, Class 5, Lesson 1: Latitudes and Longitudes. Do not copy
  the erroneous footer into instructional overlays or narration.
- Page 3 contains duplicated `the` and a missing space after `oceans.`; page 5
  contains `They are altogether Western 360 longitudes.` and stray letter `t`
  glyphs near the hemisphere diagram. Preserve raw evidence but review delivery
  corrections explicitly; do not narrate obvious layout debris as lesson facts.
- Page 6 claims every degree of longitude is approximately 111 km apart without
  the equatorial qualification. The source sentence must remain traceable;
  a separately identified factual clarification needs verification before use.
- The source describes the International Date Line as at 180 degrees; the final
  visualization must not imply that its real-world path has no deviations.
- The source's counts of 181 latitudes and 360 longitudes describe the familiar
  whole-degree convention, not a finite count of every possible coordinate.
- Page 6 figure label `North Pool` appears to be a source typo for North Pole.
  Preserve source evidence and log a corrected display rather than silently
  treating it as a new geography term.

## Presentation and timing acceptance contract

- Keep approved English-reference HyperFrames appearance: full-frame relevant
  moving scenes, corner source-text panels and a stable subtitle lane.
- Do not summarize away source lines. Break dense passages into ordered readable
  cards; never squeeze an entire page into a tiny corner box.
- All educational text, labels and numerical values are composed as editable
  layers, not trusted to AI-generated video typography or geography.
- Preserve source tables, callout grouping, questions, diagrams and captions.
  Use source diagram assets or verified precision animation for coordinates.
- Record added narration, answers, factual clarifications and editorial fixes
  separately from original textbook wording.
- Speak headings, then hold the title alone for four seconds; use the approved
  0.85 narration delivery rate and planned topic/answer-thinking pauses.
- Derive visual cues, sentence cards and punctuated word-highlight subtitles from
  measured speech timing. Never stretch a five-second asset across a long
  passage, loop it, or substitute a still-image pan for generated motion.
- Track each source element to a scene and final timestamp; mapping is not proof
  until the encoded image/audio evidence has been reviewed.

## Remaining before a final MP4

Repair source and exercise contracts; apply confirmed Class 5 title metadata; compile complete
reviewed script and answer reveals; generate and align corrected narration;
acquire enough topic-specific moving clips; rebuild the approved UI; validate
template integrity; preview and encode; compare the encoded result with all ten
PDF pages. Current pilot media and previous native-only render are not final.
