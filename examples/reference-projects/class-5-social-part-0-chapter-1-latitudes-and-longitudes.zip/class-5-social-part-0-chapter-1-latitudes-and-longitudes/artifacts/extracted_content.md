<!-- page: 1 -->
# Lesson 1: Latitudes and Longitudes

## Learning Objectives

By the end of this chapter, learners will be able to:

- Identify and describe the globe as a model of the Earth.
- Name and locate the seven continents and five oceans.
- Understand the concept of lines on the globe.
- Explain the meaning and characteristics of latitudes and longitudes.
- Differentiate between latitudes and longitudes.

## Start-Up Activity

Look at a ball. Imagine it is the Earth. If we draw lines around it, can we divide it into equal parts? The Earth is round, just like a ball, and we use imaginary lines to locate places on it. Let's explore more about these lines!

## Globe

A globe is a small model of the Earth. It shows the shape, size, and location of continents, oceans, and countries. Unlike maps, which are flat, the globe gives a true representation of the Earth. It helps us understand how the Earth looks from space.

<!-- page: 2 -->
## Continents

The Earth has seven continents, each with its own unique features. Asia, the largest continent, is home to the world's highest mountain, Mount Everest, and many different cultures and countries like China and India. Africa is famous for its vast deserts like the Sahara, the world's largest hot desert, and its wildlife, including elephants and lions. North America includes countries like the United States, Canada, and Mexico, with famous places such as the Grand Canyon and Niagara Falls. South America is known for the Amazon Rainforest, the largest rainforest in the world, and the Andes Mountains, the longest mountain range. Antarctica, the coldest continent, is covered in ice and snow, with no countries but many scientists working there. Europe is home to ancient history and iconic landmarks like the Eiffel Tower in France and the Colosseum in Italy. Australia, the smallest continent, is famous for its unique animals like kangaroos and koalas, and its Great Barrier Reef, the largest coral reef in the world. It is the only continent that is also an island.

<!-- page: 3 -->
## Oceans

The Earth has five major oceans, each covering large areas of the planet. The Pacific Ocean is the largest and deepest ocean, stretching from Asia to the Americas. The Atlantic Ocean lies between the Americas and Europe, and it is known for its busy shipping routes. The Indian Ocean is located between Africa, Asia, and Australia, and it is the warmest of all the oceans. The Southern Ocean surrounds Antarctica and is known for its cold waters and strong winds. The Arctic Ocean is the smallest and shallowest ocean, located around the North Pole, and it is covered with ice for much of the year. These five oceans make up more than 70% of the Earth's surface, and they are important for travel, trade, and marine life.

<!-- page: 4 -->
## Lines on the Globe

To locate places on Earth, we use imaginary lines drawn on the globe. These lines are called latitudes and longitudes. They help us determine the exact position of any place on Earth.

## Latitudes or Parallels

Latitudes are horizontal imaginary lines that run from east to west across the globe. The distance between the latitudes is equal. The length of the parallels, or latitudes, keeps decreasing as we move away from the Equator towards the poles. They never cross one another. They are measured in degrees. There are altogether 181 latitudes.

## Do You Know?

Latitudes are imaginary lines that run horizontally across the Earth, while longitudes run vertically, helping us locate places.

## Important Parallels of Latitude

- Equator (0° latitude): It divides the Earth into the Northern and Southern Hemispheres.
- Tropic of Cancer (23.5° N): It marks the northernmost point of the tropics.
- Tropic of Capricorn (23.5° S): It marks the southernmost point of the tropics.
- Arctic Circle (66.5° N): The region near the North Pole.
- Antarctic Circle (66.5° S): The region near the South Pole.

## Characteristics of Latitudes

- They are parallel to each other.
- The Equator is the longest latitude.
- They help to determine the climate of a place.

<!-- page: 5 -->
## Longitudes or Meridians

Longitudes are vertical imaginary lines that run from the North Pole to the South Pole. They are measured in degrees east or west of the Prime Meridian. The zero-degree meridian is also called the Prime Meridian. It divides the Earth into the Eastern Hemisphere and Western Hemisphere. There are altogether 360 longitudes. The meridian 180 degrees east and the meridian 180 degrees west are known as the International Date Line.

## Eastern and Western Hemispheres

The Prime Meridian (0° longitude) divides the Earth into two equal halves:

- Eastern Hemisphere: The region east of the Prime Meridian, including Asia, Australia, and most of Africa and Europe.
- Western Hemisphere: The region west of the Prime Meridian, including North and South America and a small part of western Africa.

<!-- page: 6 -->
## Greenwich Mean Time (GMT)

Greenwich Mean Time (GMT) is the time at the Prime Meridian (0° longitude), passing through Greenwich, England. It serves as the reference time for different time zones across the world. Each 15° of longitude represents a one-hour difference from GMT.

## Let's Learn More!

Earth is divided into 360 degrees of longitude, with each degree being approximately 111 kilometers apart.

## International Date Line (IDL)

The International Date Line (IDL) is an imaginary line at 180° longitude, opposite the Prime Meridian. It marks the place where the date changes by one day when crossing it. Traveling westward across the IDL moves the calendar forward by one day, while traveling eastward moves it back by one day.

<!-- page: 7 -->
## Do You Know?

The Tropics of Cancer and Capricorn mark the farthest points where the Sun can be directly overhead at noon.

## Characteristics of Longitudes

- All longitudes meet at the poles.
- The Prime Meridian (0°) passes through Greenwich, England.
- They help determine time zones and the division of the Earth into hemispheres.
- The International Date Line (180°) helps adjust global time and date differences.

## Difference between Latitudes and Longitudes

| Feature | Latitudes | Longitudes |
| --- | --- | --- |
| Direction | East to west | North to south |
| Shape | Parallel lines | Meet at the poles |
| Measurement | Degrees north or south | Degrees east or west |
| Importance | Climate | Time zones |

## Recall

Latitudes and longitudes help us locate places on Earth. While latitudes affect climate, longitudes determine time zones. Together, they make navigation and mapping possible.

## Let's Remember

- The globe is a model of the Earth.
- The seven continents and five oceans cover the Earth.
- Latitudes run east-west, while longitudes run north-south.
- The Equator and Prime Meridian are the most important lines.
- Latitude affects climate, and longitude affects time zones.

<!-- page: 8 -->
## Word Bank

| Word | Meaning |
| --- | --- |
| Globe | A model of the Earth. |
| Latitude | Imaginary lines running east to west. |
| Longitude | Imaginary lines running north to south. |
| Equator | The 0° latitude dividing the Earth into two halves. |
| Prime Meridian | The 0° longitude passing through Greenwich. |

## Assessment Activity

### I. Answer the following very short questions

1. How many continents are there?
2. Name the largest ocean.
3. What is the 0° latitude called?
4. What is the 0° longitude called?
5. Which continent is the smallest?

### II. Answer the following short questions

1. Define latitude.
2. Name two important parallels of latitude.
3. Why is the Prime Meridian important?

### III. Answer the following long questions

1. Differentiate between latitudes and longitudes.
2. Describe the five major oceans of the world.

<!-- page: 9 -->
### IV. Fill in the blanks

1. The Equator is at ______° latitude.
2. The Prime Meridian passes through ______.
3. The Earth has ______ continents.
4. The largest continent is ______.
5. The ocean near the North Pole is the ______ Ocean.

### V. Write true or false

1. Longitudes run from east to west.
2. The Arctic Ocean is the largest ocean.
3. The Equator is a latitude.
4. The Prime Meridian divides the Earth into two halves.
5. Antarctica is a desert.

### VI. Match the following

| Column A | Column B |
| --- | --- |
| Asia | Largest ocean |
| Pacific Ocean | Smallest continent |
| Prime Meridian | 0° longitude |
| Equator | 0° latitude |
| Australia | Largest continent |

## Activity: Find Your City on the Map!

Use an atlas to locate your city's latitude and longitude. Write down the coordinates. Compare them with three other cities.

<!-- page: 10 -->
## Project: Create Your Own Globe!

Use a ball to mark important latitudes and longitudes. Label the continents and oceans. Present your globe to the class.

## HOTS

1. Why is it important to know the coordinates of a place?
2. How would the world change if there were no lines of latitude and longitude?

## Life Skills

When traveling to unknown places, you need to rely on teamwork to read maps and coordinate directions. In teams, everyone can focus on different aspects, like reading coordinates or identifying landmarks, ensuring everyone gets to the destination safely. Discuss in the class.
