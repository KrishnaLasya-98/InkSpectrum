# H3 start/end model check - 2026-09-30

User authorized `h3-minimax-start-end-frame` as an additional continuity option.
No change to the approved GPT-image + Wan video path was made.

## Documentation

- https://modelslab.com/models/modelslab/h3-minimax-start-end-frame/llms.txt
- https://modelslab.com/models/modelslab/h3-minimax-start-end-frame
- https://modelslab.com/minimax-api

The model-specific contract documents v6 `/video/img2video`, `init_image` as an
array, duration 5-15 seconds, and 768P. It does not explain start/end array ordering
or provide an end-frame parameter. Its samples omit the required image input.
Do not infer verified two-frame continuity from the model name.

## Actual account test

Tool: existing `tools.analysis.modelslab_recovery_smoke` and `ModelsLabVideo`.
Input: chapter-scoped GPT globe image and the previously saved globe-motion prompt.
One five-second image-to-video submission, numeric resolution 768 (existing
adapter's live-compatible form). Listed price: $0.05/s; about $0.25 before plan
allowance. This was an access/image-conditioning test, not a two-endpoint test.

Result: rejected before a request ID or clip existed. Provider response:

> You have exhausted your third party access for this month, please fund your wallet to continue using this model

Evidence: `assets/video/h3-continuity-pilot/globe-classroom-v1.mp4.recovery-report.json`.
No retry loop and no new key were attempted. The public self-hosted/plan description
conflicts with this account response; ModelsLab support must clarify entitlement.
No claim of zero charges is made, because billing was not independently queried.

## Adapter safeguard

The adapter previously silently dropped `end_image_url` for this model (and Wan's
scalar image input also discarded a second image). It now refuses unverified
end-frame constraints before upload/submission. Start-image-only generation and
explicit recovery of an existing job remain available. This is a fail-closed
guard, not newly implemented end-frame support. Focused adapter/continuity/CLI
tests completed with exit code 0: 18 passed. This is not an end-to-end video pass.

## Continuity policy

Generate only shots needed by the reviewed narration; keep recurring scene
identity, framing, lighting and direction consistent. Where a verified I2V model
allows it, a reviewed terminal frame may seed the next chronological shot.
Validate boundary frames and motion before composition; do not force every topic
change into a morph. Accurate geography overlays remain in HyperFrames, not in
unreliable generated map labels.
