"""Reviewed, silent 3D teaching geometry; HyperFrames supplies text and audio.

Only the Start-Up Activity is implemented here. One sphere, three mutually
orthogonal great circles: eight equal spherical octants. No fabricated maps.
Animation events derive from the aligned words, not the estimated scene plan.
"""
import json
import math
from pathlib import Path
import numpy as np
from manim import (
    ThreeDScene, Sphere, Rectangle, Circle, ParametricFunction, VGroup,
    Create, LaggedStart, DEGREES, OUT, UP, DOWN, linear, smooth,
)

PROJECT = Path(__file__).resolve().parent


class StartUpActivity(ThreeDScene):
    def construct(self):
        voice = json.loads((PROJECT / 'artifacts/revision-v4/narration_manifest.json').read_text())
        segment = next(s for s in voice['segments'] if s['section_id'] == 's03-startup')
        aligned = json.loads((PROJECT / 'artifacts/revision-v4/alignment-clean/narration_aligned.json').read_text())
        words = next(s for s in aligned['segments'] if s['section_id'] == 's03-startup')['words']

        def cue(word):
            entry = next(w for w in words if w['word'].lower().strip('.,!?') == word)
            return entry['start_ms'] / 1000 - segment['start_seconds']

        def until(target):
            duration = target - self.time
            if duration > 0:
                self.wait(duration)

        self.camera.background_color = '#DCEEF1'
        self.set_camera_orientation(phi=68*DEGREES, theta=-72*DEGREES,
                                    frame_center=np.array([1.4, 0, 0]), zoom=0.91)
        self.camera.light_source.move_to(np.array([-5, -6, 8]))
        floor = Rectangle(width=32, height=32, fill_color='#C7DFD4', fill_opacity=1, stroke_width=0)
        floor.shift(OUT * -2.27)
        floor.set_shade_in_3d(True)
        shadow = VGroup(*[
            Circle(radius=2.2 - i*.07, fill_color='#6E8D88',
                   fill_opacity=.014, stroke_width=0).shift(OUT*(-2.255+i*.0001))
            for i in range(12)
        ])
        shadow.set_shade_in_3d(True)
        ball = Sphere(radius=2.2, resolution=(28, 48))
        ball.set_fill('#238FC7', opacity=1).set_stroke('#238FC7', width=.5)
        ball.set_shade_in_3d(True)
        self.add(floor, shadow, ball)
        # Fixed teaching view avoids painter-order seams between a sphere's
        # tessellated faces and line segments. Motion comes from the ball and
        # the timed line construction, not a drifting diagram camera.
        until(cue('look'))
        # A gentle lift/settle attracts attention to the one existing ball.
        self.play(ball.animate.shift(OUT*.15), run_time=.38, rate_func=smooth)
        self.play(ball.animate.shift(OUT*-.15), run_time=.38, rate_func=smooth)
        until(cue('draw'))

        def great_circle(axis):
            def point(angle):
                c, s = 2.212*math.cos(angle), 2.212*math.sin(angle)
                return np.array([c, s, 0]) if axis == 0 else (
                    np.array([c, 0, s]) if axis == 1 else np.array([0, c, s]))
            # Analytically clip the hidden hemisphere. Cairo's depth sorting
            # interleaved short arcs with sphere faces and produced false
            # dashed/doubled lines; visible arcs are now drawn over the ball.
            phi, theta = 68*DEGREES, -72*DEGREES
            eye = np.array([math.sin(phi)*math.cos(theta),
                            math.sin(phi)*math.sin(theta), math.cos(phi)])
            a, b = (eye[0],eye[1]) if axis==0 else (
                (eye[0],eye[2]) if axis==1 else (eye[1],eye[2]))
            middle = math.atan2(b,a)
            # One continuous front semicircle avoids tiny seams at arc joins.
            return VGroup(ParametricFunction(point,
                t_range=[middle-math.pi/2,middle+math.pi/2,.01],
                color='#FFF9ED',stroke_width=5))

        rings = [great_circle(axis) for axis in range(3)]
        self.play(LaggedStart(*[Create(ring) for ring in rings], lag_ratio=.25),
                  run_time=2.4, rate_func=linear)
        until(cue('locate'))
        # A point at the intersection gives a concrete place to locate;
        # it is not assigned a fictional country or coordinate label.
        marker = Sphere(radius=.08, resolution=(8, 12)).set_color('#A83C2D')
        marker.set_shade_in_3d(False)
        marker.move_to(np.array([0, -2.24, 0]))
        self.add(marker)
        until(segment['duration_seconds'])
