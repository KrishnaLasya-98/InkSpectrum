"""Bounded HyperFrames verification with durable output, no render or API calls."""
import json
import os
import subprocess
from pathlib import Path
from lib.production_runtime import atomic_json

PROJECT=Path(__file__).resolve().parent
ROOT=PROJECT/'artifacts/revision-v4'
CLI=PROJECT.parents[1]/'.runtime/hyperframes/node_modules/hyperframes/bin/hyperframes.mjs'


def main():
    environment=os.environ.copy()
    temp=ROOT/'check-temp'
    temp.mkdir(exist_ok=True)
    environment.update(TEMP=str(temp),TMP=str(temp))
    command=['node',str(CLI),'check',str(PROJECT/'hyperframes-v4-production'),
             '--json','--snapshots','--timeout','15000','--max-issues','60',
             '--at','1.5,5,14,47,68,98,129,209,234,255,310,357,395,426,478,547,628']
    try:
        result=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',
                              errors='replace',timeout=300,env=environment)
    except subprocess.TimeoutExpired:
        atomic_json(ROOT/'hyperframes-check-summary.json',{'state':'timed_out','chapter_complete':False})
        raise
    (ROOT/'hyperframes-check.stdout.log').write_text(result.stdout,encoding='utf-8')
    (ROOT/'hyperframes-check.stderr.log').write_text(result.stderr,encoding='utf-8')
    try:
        report=json.loads(result.stdout)
    except ValueError:
        report={'parse_error':True}
    atomic_json(ROOT/'hyperframes-check.json',report)
    summary={'exit_code':result.returncode,'chapter_complete':False,'report_keys':list(report),
             'result':{k:v for k,v in report.items() if isinstance(v,(str,int,bool,float))}}
    atomic_json(ROOT/'hyperframes-check-summary.json',summary)
    print(json.dumps(summary))
    raise SystemExit(result.returncode)


if __name__=='__main__':
    main()
