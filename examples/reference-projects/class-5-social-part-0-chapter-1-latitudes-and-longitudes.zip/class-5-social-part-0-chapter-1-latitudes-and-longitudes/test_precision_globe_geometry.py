import math
import pytest
from precision_globe_geometry import point, latitude_points, longitude_points, visible_runs


@pytest.mark.parametrize('latitude',[-90,-66.5,-23.5,0,23.5,66.5,90])
def test_points_stay_on_sphere(latitude):
    for longitude in [-180,-90,0,90,180]:
        xyz=point(latitude,longitude)
        assert math.sqrt(sum(x*x for x in xyz))==pytest.approx(2.22)


def test_parallels_constant_height_and_shrinking_radius():
    radii=[]
    for latitude in [0,23.5,66.5]:
        points=latitude_points(latitude)
        assert max(p[2] for p in points)-min(p[2] for p in points)<1e-10
        radii.append(math.hypot(points[0][0],points[0][1]))
    assert radii[0]>radii[1]>radii[2]


def test_meridians_share_poles():
    for longitude in [-60,0,60]:
        points=longitude_points(longitude)
        assert points[0]==pytest.approx((0,0,2.22))
        assert points[-1]==pytest.approx((0,0,-2.22))


def test_visibility_does_not_draw_hidden_hemisphere():
    eye=(0,-math.sin(math.radians(78)),math.cos(math.radians(78)))
    for lat in [-66.5,0,66.5]:
        for run in visible_runs(latitude_points(lat)):
            assert len(run)>1
            assert all(sum(a*b for a,b in zip(p,eye))>=-1e-9 for p in run)
