"""Bounded sequential rendering of reviewed precision components only."""
import argparse
import hashlib
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from lib.production_runtime import atomic_json, run_logged

PROJECT=Path(__file__).resolve().parent
ROOT=PROJECT/'artifacts/revision-v4'
SCENES=['GridLines','LatitudeCircles','ImportantParallels','MeridianLines','GreenwichTime','DateLine']


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--mode',choices=['frames','preview','production'],required=True)
    parser.add_argument('--scene',choices=SCENES,action='append')
    args=parser.parse_args()
    if shutil.disk_usage(PROJECT).free<10*1024**3:
        raise SystemExit('Insufficient output/temp disk')
    interpreter=Path('C:/Users/user/Miniconda3/envs/openmontage-maths-manim/python.exe')
    if not interpreter.is_file():
        raise SystemExit('Isolated Manim environment missing')
    # Shared with the Start-Up Activity runner; never delete an unfamiliar lock.
    lock=ROOT/'startup-render.lock'
    descriptor=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    os.close(descriptor)
    source=PROJECT/'precision_globes_v4.py'
    media=PROJECT/'assets/video'/f'precision-globes-v4-{args.mode}'
    temporary=ROOT/'render-temp'
    temporary.mkdir(exist_ok=True)
    environment=os.environ.copy()
    environment.update(TEMP=str(temporary),TMP=str(temporary),
                       PYTHONPATH=str(PROJECT)+os.pathsep+str(PROJECT.parents[1]))
    try:
        for scene in args.scene or SCENES:
            status=ROOT/f'precision-{scene}-{args.mode}.json'
            quality='480p15' if args.mode=='preview' else '1080p30'
            output=(media/'images/precision_globes_v4'/f'{scene}_ManimCE_v0.19.0.png'
                    if args.mode=='frames' else media/'videos/precision_globes_v4'/quality/f'{scene}.mp4')
            if output.exists():
                print(f'Preserving existing {scene} {args.mode}; inspect before rerender')
                continue
            state={'state':'running','scene':scene,'mode':args.mode,'chapter_complete':False,
                   'output':str(output),'started_at':datetime.now(timezone.utc).isoformat(),
                   'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
                   'geometry_sha256':hashlib.sha256((PROJECT/'precision_globe_geometry.py').read_bytes()).hexdigest(),
                   'quality_approved':False,'runner_pid':os.getpid()}
            command=[str(interpreter),'-m','manim','--renderer','cairo','--disable_caching',
                     '--media_dir',str(media)]
            command+=['-ql'] if args.mode=='preview' else ['-r','1920,1080','--fps','30']
            if args.mode=='frames':
                command+=['-s']
            command += [str(source),scene]
            def heartbeat(pid):
                state.update(render_pid=pid,heartbeat_at=datetime.now(timezone.utc).isoformat())
                atomic_json(status,state)
            result=run_logged(command,cwd=PROJECT,env=environment,timeout=1800,
                              log_dir=ROOT/f'precision-{scene}-{args.mode}-logs',heartbeat=heartbeat)
            state.update(exit_code=result.returncode,finished_at=datetime.now(timezone.utc).isoformat(),
                         state='rendered_needs_qa' if result.returncode==0 and output.exists() else 'failed')
            atomic_json(status,state)
            print(json.dumps(state),flush=True)
            if state['state']=='failed':
                raise SystemExit(result.returncode or 1)
    finally:
        lock.unlink(missing_ok=True)


if __name__=='__main__':
    main()
