import json
from pathlib import Path
import unittest
from prepare_v4_timing import caption_srt, phrase_index, lex

ROOT = Path(__file__).resolve().parent / 'artifacts/revision-v4'


class TimingTests(unittest.TestCase):
    def test_unique_phrase(self):
        words = [{'word': x} for x in 'The Grand Canyon and Niagara Falls.'.split()]
        self.assertEqual(phrase_index(words, 'Niagara Falls'), 4)

    def test_ambiguous_phrase_is_rejected(self):
        with self.assertRaises(ValueError):
            phrase_index([{'word': 'The'}, {'word': 'The'}], 'The')

    def test_missing_phrase_is_rejected(self):
        with self.assertRaises(ValueError):
            phrase_index([{'word': 'Ocean'}], 'Sahara')

    def test_long_pause_splits_subtitle(self):
        text = caption_srt([{'words': [
            {'word': 'Heading', 'start_ms': 0, 'end_ms': 800},
            {'word': 'Body.', 'start_ms': 5000, 'end_ms': 5500}]}])
        self.assertIn('00:00:00,000 --> 00:00:00,800', text)
        self.assertIn('00:00:05,000 --> 00:00:05,500', text)

    def test_all_source_words_retained(self):
        old = json.loads((ROOT/'alignment/narration_aligned.json').read_text())
        new = json.loads((ROOT/'alignment-clean/narration_aligned.json').read_text())
        self.assertEqual(len(new['segments']), 22)
        self.assertEqual(sum(len(s['words']) for s in new['segments']), 1139)
        for a, b in zip(old['segments'], new['segments']):
            self.assertEqual([lex(w['word']) for w in a['words']], [lex(w['word']) for w in b['words']])

    def test_clean_words_are_monotonic(self):
        data = json.loads((ROOT/'alignment-clean/narration_aligned.json').read_text())
        for s in data['segments']:
            for a, b in zip(s['words'], s['words'][1:]):
                self.assertLessEqual(a['end_ms'], b['start_ms'])

    def test_four_second_holds(self):
        data = json.loads((ROOT/'visual-cue-plan.json').read_text())
        for s in data['sections']:
            self.assertEqual(len(s['heading_holds']), 1)
            hold = s['heading_holds'][0]
            self.assertAlmostEqual(hold['end_seconds']-hold['start_seconds'], 4, places=3)

    def test_no_completion_claim(self):
        data = json.loads((ROOT/'alignment-clean/qa.json').read_text())
        self.assertFalse(data['chapter_complete'])
        self.assertEqual(data['listening_qa'], 'pending')


if __name__ == '__main__':
    unittest.main()
