"""Submit one approved project shot batch without replacing existing jobs."""
import argparse
import json
from pathlib import Path
from lib.production_runtime import atomic_json
from tools.video.modelslab_video import ModelsLabVideo


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('batch', type=Path)
    args = parser.parse_args()
    project = Path(__file__).resolve().parent
    batch = json.loads(args.batch.read_text(encoding='utf-8'))
    status_path = args.batch.with_name(args.batch.stem + '-status.json')
    previous = json.loads(status_path.read_text()) if status_path.exists() else {'shots': []}
    reports = {row['shot_id']: row for row in previous['shots']}
    tool = ModelsLabVideo()
    for shot in batch['shots']:
        output = project / 'assets/video/revision-v4' / (shot['shot_id'] + '.mp4')
        sidecar = Path(str(output) + '.modelslab-job.json')
        if output.exists() or sidecar.exists():
            print('Skip existing file/job: ' + shot['shot_id'], flush=True)
            continue
        operation = batch.get('operation', 'text_to_video')
        frames = batch.get('num_frames', 82 if operation == 'image_to_video' else 81)
        if not isinstance(frames, int) or isinstance(frames, bool) or frames not in (
                (82, 114) if operation == 'image_to_video' else (81,)):
            raise SystemExit('Unreviewed frame count; allowed I2V: 82 or 114, T2V: 81')
        request = {
            'prompt': shot['prompt'],
            'negative_prompt': 'photorealism, live action, text, watermark, malformed anatomy, extra limbs, frozen frame',
            'model_id': batch['model_id'], 'operation': operation,
            'duration': frames / 16, 'fps': 16, 'num_frames': frames,
            'resolution': '480',
            'generate_audio': False, 'educational_mode': True,
            'submit_only': True, 'output_path': str(output),
        }
        if operation == 'image_to_video':
            reference = (project / shot['reference_image']).resolve()
            if not reference.is_file() or not reference.is_relative_to(project):
                raise SystemExit('Missing or out-of-project image reference: ' + shot['shot_id'])
            request['image_path'] = str(reference)
        result = tool.execute(request)
        entry = {'shot_id': shot['shot_id'], 'success': result.success,
                 'request_id': result.data.get('request_id'), 'error': result.error,
                 'output_path': str(output)}
        reports[shot['shot_id']] = entry
        atomic_json(status_path, {'shots': list(reports.values()), 'complete': False})
        print(json.dumps(entry), flush=True)
        if not result.success:
            raise SystemExit(2)


if __name__ == '__main__':
    main()
