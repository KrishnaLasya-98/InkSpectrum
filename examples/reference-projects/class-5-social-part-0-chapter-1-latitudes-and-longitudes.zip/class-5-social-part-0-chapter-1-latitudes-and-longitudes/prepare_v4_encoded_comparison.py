"""Package actual scoped v4 evidence for the repository's encoded comparison gate."""
import json
from pathlib import Path
from lib.production_runtime import atomic_json

PROJECT=Path(__file__).resolve().parent
ROOT=PROJECT/'artifacts/revision-v4'

def load(name):return json.loads((ROOT/name).read_text(encoding='utf-8'))

def main():
    plan=load('composition-plan-media.json')
    coverage=load('composition-coverage.json')
    chapter=load('chapter_document.json')
    expected=[s['section_id'] for s in load('educational_plan.json')['sections']]
    actual=[s['section_id'] for s in plan['sections']]
    if actual!=expected or len(actual)!=22 or len({p['block'] for p in coverage['placements']})!=71:
        raise ValueError('Scoped source coverage is not 22 sections/71 blocks')
    if actual[0]!='s01-title' or actual[-1]!='s22-wordbank' or 's03-startup' not in actual:
        raise ValueError('Unapproved chapter scope')
    source={'version':'1.0','textbook_pages':len(chapter['pages']),
            'required_topics':[s['title'] for s in plan['sections']],
            'required_source_block_ids':sorted({p['block'] for p in coverage['placements']})}
    sections=[]
    captions=[]
    for s in plan['sections']:
        sections.append({'id':s['section_id'],'heading':s['title'],
                         'display':[b['source_text'] for b in s['blocks']]})
        words=[w for c in s['captions'] for w in c['words']]
        if not words:raise ValueError('Missing subtitle words: '+s['section_id'])
        if s['section_id']=='s01-title':continue
        body=[w for w in words if w['start_ms']/1000>=
              (s['heading_holds'][-1]['end_seconds'] if s['heading_holds'] else 0)]
        if not body:raise ValueError('Missing body subtitle: '+s['section_id'])
        captions.append({'id':s['section_id']+'-body','start':body[0]['start_ms']/1000,
                         'end':body[-1]['end_ms']/1000,
                         'words':[{'word':w['word'],'start':w['start_ms']/1000,
                                   'end':w['end_ms']/1000} for w in body]})
    out=ROOT/'encoded-comparison'
    out.mkdir(exist_ok=True)
    atomic_json(out/'source-audit-v4.json',source)
    atomic_json(out/'production-data-v4.json',{'sections':sections,'captions':captions,
        'scope_sections':actual,'source_blocks':71,'word_level_subtitles':True})
    print(json.dumps({'sections':len(sections),'body_captions':len(captions),
                      'source_blocks':len(source['required_source_block_ids'])}))

if __name__=='__main__':main()
