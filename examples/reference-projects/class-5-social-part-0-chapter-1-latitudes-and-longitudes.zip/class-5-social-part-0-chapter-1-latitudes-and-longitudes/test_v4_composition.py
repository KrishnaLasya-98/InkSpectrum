import pytest
from prepare_v4_composition import validate_intervals, caption_groups
from prepare_v4_render_media import required_retime


def test_exact_section_coverage():
    validate_intervals([{'start':0,'end':2},{'start':2,'end':4}],0,4)


@pytest.mark.parametrize('rows',[
    [{'start':0,'end':2},{'start':2.2,'end':4}],
    [{'start':0,'end':2},{'start':1.8,'end':4}],
    [{'start':0,'end':3}],
    [{'start':0,'end':0},{'start':0,'end':4}],
])
def test_visual_gaps_and_overlap_fail(rows):
    with pytest.raises(ValueError):
        validate_intervals(rows,0,4)


def test_punctuation_and_words_preserved():
    words=[{'word':w,'start_ms':i*500,'end_ms':i*500+450}
           for i,w in enumerate(['Hello,','Earth.','Where','are','we?'])]
    pages=caption_groups({'words':words},[])
    assert [w['word'] for p in pages for w in p['words']]==[w['word'] for w in words]
    assert pages[0]['text']=='Hello, Earth.'


def test_caption_cannot_spill_into_title_hold():
    words=[{'word':'Globe.','start_ms':0,'end_ms':1100}]
    pages=caption_groups({'words':words},[{'start_seconds':1,'end_seconds':5}])
    assert pages[0]['end']==1


def test_caption_within_hold_is_error():
    with pytest.raises(ValueError):
        caption_groups({'words':[{'word':'Incorrect','start_ms':2000,'end_ms':2200}]},
                       [{'start_seconds':1,'end_seconds':5}])


def test_retime_measures_last_source_frame():
    info={'duration':'5.0625','r_frame_rate':'16/1'}
    factor=required_retime(info,5.52)
    assert 1 < factor < 1/.88
    assert (5.0625-1/16)*factor > 5.52


def test_retime_never_stretches_far_or_loops():
    with pytest.raises(ValueError):
        required_retime({'duration':'5.0625','r_frame_rate':'16/1'},8)
    assert required_retime({'duration':'5.0625','r_frame_rate':'16/1'},4) is None
