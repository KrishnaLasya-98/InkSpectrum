"""Recheck suspicious caption timings against short audio crops, without script prompts.

This produces evidence only; it never rewrites words or grants listening approval.
Uses the already cached small.en model with two CPU threads and no downloads.
"""
import json
import argparse
import io
import re
from pathlib import Path
import soundfile as sf
from faster_whisper import WhisperModel
from faster_whisper.audio import decode_audio
from lib.production_runtime import atomic_json

PROJECT = Path(__file__).resolve().parent
ROOT = PROJECT/'artifacts/revision-v4'


def lexical(text):
    return re.sub(r'[^\w]', '', text.casefold())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--context',type=float,default=1.4)
    parser.add_argument('--output',default='word-flag-audio-review.json')
    args=parser.parse_args()
    if not 1 <= args.context <= 5 or Path(args.output).name != args.output:
        raise ValueError('Bounded context and plain output filename required')
    read = lambda name: json.loads((ROOT/name).read_text(encoding='utf-8'))
    flags = read('alignment-clean/qa.json')['timing_review_required']
    voices = {s['section_id']:s for s in read('narration_manifest.json')['segments']}
    aligned = {s['section_id']:s for s in read('alignment-clean/narration_aligned.json')['segments']}
    model = WhisperModel('small.en',device='cpu',compute_type='int8',cpu_threads=2,
                         num_workers=1,local_files_only=True)
    rows = []
    for i, flag in enumerate(flags):
        sid = flag['section']
        voice = voices[sid]
        original = flag.get('word') or aligned[sid]['words'][len(voice['spoken_heading'].split())]
        center = original['start_ms']/1000 - voice['start_seconds']
        audio, rate = sf.read(voice['audio_path'],dtype='float32')
        start, end = max(0,center-args.context), min(len(audio)/rate,center+args.context+1)
        sample = audio[round(start*rate):round(end*rate)]
        if sample.ndim == 2:
            sample = sample.mean(axis=1)
        buffer = io.BytesIO()
        sf.write(buffer,sample,rate,format='WAV')
        buffer.seek(0)
        sample = decode_audio(buffer,sampling_rate=16000)
        parts, _ = model.transcribe(sample,language='en',beam_size=5,vad_filter=False,
                                    word_timestamps=True,condition_on_previous_text=False)
        origin_ms = round((voice['start_seconds']+start)*1000)
        heard = [{'word':w.word.strip(),'start_ms':round(w.start*1000)+origin_ms,
                  'end_ms':round(w.end*1000)+origin_ms,'probability':w.probability}
                 for part in parts for w in (part.words or [])]
        matches = [w for w in heard if lexical(w['word'])==lexical(original['word'])]
        row = {'section_id':sid,'flag':flag,'original':original,'crop_local_seconds':[start,end],
               'heard_words':heard,'status':'review_required','script_prompt_used':False}
        matches.sort(key=lambda w:abs(w['start_ms']-original['start_ms']))
        if matches:
            row['candidate_boundary']=matches[0]
            row['boundary_delta_ms']=[matches[0]['start_ms']-original['start_ms'],
                                       matches[0]['end_ms']-original['end_ms']]
            concerns = []
            if matches[0]['start_ms'] <= origin_ms+30:
                concerns.append('candidate starts at crop edge; onset is not established')
            if matches[0]['probability'] < .7:
                concerns.append('low recognizer probability')
            body_ms = round((voice['start_seconds']+voice['body_start_seconds'])*1000)
            pause_ms = round((voice['start_seconds']+voice['heading_duration_seconds'])*1000)
            if matches[0]['start_ms'] < body_ms and matches[0]['end_ms'] > pause_ms:
                concerns.append('candidate overlaps verified heading silence')
            row['candidate_concerns'] = concerns
            row['candidate_is_safe_to_apply_automatically'] = False
        rows.append(row)
        atomic_json(ROOT/args.output,{'method':'cropped small.en ASR, not forced alignment',
                    'complete':False,'rows':rows,'automatically_applied':False})
        print(json.dumps({'index':i,'section':sid,'word':original['word'],
                          'candidate':row.get('candidate_boundary'),'delta':row.get('boundary_delta_ms')}),flush=True)
    atomic_json(ROOT/args.output,{'method':'cropped small.en ASR, not forced alignment',
                'complete':True,'rows':rows,'automatically_applied':False,
                'note':'ASR agreement is not a guarantee of pronunciation or exact timing.'})


if __name__=='__main__':
    main()
