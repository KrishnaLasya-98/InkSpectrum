"""Build a source-linked assembly draft; never marks the chapter approved.

All timing derives from measured narration. The manifest is separate from HTML
so missing media, rejected shots and text coverage fail before browser rendering.
"""
import hashlib
import json
from pathlib import Path
import subprocess
from lib.production_runtime import atomic_json
from prepare_v4_timing import phrase_index

PROJECT = Path(__file__).resolve().parent
ROOT = PROJECT / 'artifacts/revision-v4'
VIDEO = 'assets/video/revision-v4/'
FIGURE = 'assets/source-figures/revision-v4/'
PRECISION = 'assets/video/precision-globes-v4-production/videos/precision_globes_v4/1080p30/'
PRECISION_SCENES = {
    's03-startup': 'assets/video/precision-v4-production-linefix/videos/precision_v4/1080p30/StartUpActivity.mp4',
    's07-grid': PRECISION + 'GridLines.mp4',
    's08-latitudes': PRECISION + 'LatitudeCircles.mp4',
    's10-parallels': PRECISION + 'ImportantParallels.mp4',
    's12-longitudes': PRECISION + 'MeridianLines.mp4',
    's14-gmt': PRECISION + 'GreenwichTime.mp4',
    's16-idl': PRECISION + 'DateLine.mp4',
}
STABLE = {'s02-objectives', 's09-didyouknow', 's15-learn-more',
          's17-tropics', 's18-longitude-features', 's19-comparison',
          's20-recall', 's21-remember', 's22-wordbank'}
FIGURES = {'s11-latitude-features': 'latitude_diagram-source.png',
           's13-hemispheres': 'hemisphere_diagram-source.png'}


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def probe(path):
    result = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0',
        '-show_entries', 'stream=duration,width,height,r_frame_rate,nb_frames',
        '-of', 'json', str(path)], capture_output=True, text=True, check=True, timeout=20)
    return json.loads(result.stdout)['streams'][0]


def validate_intervals(rows, start, end, tolerance=.002):
    """A nominal teaching interval must cover the whole section once."""
    cursor = start
    for row in rows:
        if abs(row['start'] - cursor) > tolerance:
            raise ValueError(f'Gap/overlap at {cursor}: {row}')
        if row['end'] <= row['start']:
            raise ValueError('Non-positive visual duration')
        cursor = row['end']
    if abs(cursor-end) > tolerance:
        raise ValueError(f'Visual coverage ends at {cursor}, expected {end}')


def section_visuals(section, words):
    sid, start, end = section['section_id'], section['start_seconds'], section['end_seconds']
    body_start = section['heading_holds'][-1]['end_seconds'] if section['heading_holds'] else start
    def item(a, b, asset=None, kind='video', **extra):
        return {'start': a, 'end': b, 'kind': kind, 'asset': asset, **extra}
    if sid == 's01-title':
        return [item(start, 3.8, VIDEO+'opening-globe-i2v-08.mp4'),
                item(3.8, end, VIDEO+'opening-detail-clean-i2v-10.mp4')]
    if sid in PRECISION_SCENES:
        return [item(start, end, PRECISION_SCENES[sid], teaching_hold_allowed=True)]
    if section['visual_cues']:
        first = section['visual_cues'][0]
        rows = [item(start, first['start_seconds'], first['asset'], 'source_figure')]
        for cue in section['visual_cues']:
            rows.append(item(cue['start_seconds'], cue['end_seconds'], cue['asset'],
                             'video' if cue['continuous_motion_required'] else 'source_figure',
                             spoken_cue=cue['cue'], subject=cue['subject']))
        return rows
    if sid == 's04-globe':
        # The model turns for its definition; the original labelled illustration
        # remains visible during map/shape comparisons. This is deliberate diagram
        # teaching, not a frozen generative clip or a Ken Burns replacement.
        shot_end = min(body_start+4.7, end)
        return [item(start, body_start, kind='heading'),
                item(body_start, shot_end, VIDEO+'globe-teaching-clean-i2v-10.mp4'),
                item(shot_end, end, FIGURE+'globe_figure-source.png', 'source_figure')]
    if sid in FIGURES:
        return [item(start, end, FIGURE+FIGURES[sid], 'source_figure')]
    if sid in STABLE:
        return [item(start, end, kind='stable_source_reading')]
    raise ValueError('No visual strategy for '+sid)


def caption_groups(segment, heading_holds):
    """Complete punctuation-preserving phrases, bounded to 70 characters."""
    result, group = [], []
    for word in segment['words']:
        if group and (word['start_ms']-group[-1]['end_ms'] > 700
                      or len(' '.join(w['word'] for w in group+[word])) > 70
                      or group[-1]['word'].endswith(('.', '?', '!'))):
            result.append(group)
            group = []
        group.append(word)
    if group:
        result.append(group)
    pages=[]
    for group in result:
        start, end = group[0]['start_ms']/1000, group[-1]['end_ms']/1000
        for hold in heading_holds:
            if start < hold['start_seconds'] < end:
                end = hold['start_seconds']
            if start >= hold['start_seconds'] and start < hold['end_seconds']:
                raise ValueError('Spoken caption begins within heading silence')
        if end <= start:
            raise ValueError('Empty caption interval')
        pages.append({'start':start, 'end':end, 'words':group,
                      'text':' '.join(w['word'] for w in group)})
    return pages


def main():
    cues=read(ROOT/'visual-cue-plan.json')
    panels=read(ROOT/'source-panel-plan.json')
    aligned=read(ROOT/'alignment-clean/narration_aligned.json')['segments']
    narration=read(ROOT/'narration_manifest.json')['segments']
    figures=read(ROOT/'source-figure-manifest.json')['figures']
    rejected={r['file'] for r in read(ROOT/'motion-qa-progress.json')['rejected_clips']}
    if panels['timing_issues'] or panels['mapped_blocks'] != panels['required_blocks']:
        raise ValueError('Source contract is incomplete')
    by_audio={s['section_id']:s for s in narration}
    by_words={s['section_id']:s for s in aligned}
    media_cache, sections, warnings = {}, [], []
    for section in cues['sections']:
        sid=section['section_id']
        words=by_words[sid]['words']
        visuals=section_visuals(section, words)
        validate_intervals(visuals, section['start_seconds'], section['end_seconds'])
        for i, shot in enumerate(visuals):
            asset=shot.get('asset')
            if not asset:
                continue
            path=(PROJECT/asset).resolve()
            if not path.is_relative_to(PROJECT) or not path.is_file():
                raise ValueError('Missing/out-of-project visual: '+asset)
            if path.name in rejected:
                raise ValueError('Rejected clip selected: '+asset)
            if shot['kind']=='video':
                if asset not in media_cache:
                    media_cache[asset]=probe(path)
                info=media_cache[asset]
                available=float(info['duration'])
                needed=shot['end']-shot['start']
                shot.update(source_duration=available, media_start=0,
                            source_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
                shortage=needed-available
                if shortage > .04:
                    # Only gentle, recorded retiming is eligible. Not executed
                    # by this planner. No loop or implicit browser end freeze.
                    shot['needs_retime']=True
                    shot['suggested_speed']=round(available/(needed+.04), 6)
                    warnings.append({'section':sid,'asset':asset,'issue':'needs_physical_retime',
                                     'seconds_short':round(shortage,6)})
                elif shortage > 0:
                    if not shot.get('teaching_hold_allowed'):
                        warnings.append({'section':sid,'asset':asset,'issue':'short_clip'})
                    shot['end_hold_seconds']=round(shortage,6)
            shot['id']=f'{sid}-visual-{i:02d}'
        blocks=[b for b in panels['blocks'] if b['section_id']==sid]
        audio=Path(by_audio[sid]['audio_path']).resolve()
        if not audio.is_file() or not audio.is_relative_to(PROJECT):
            raise ValueError('Missing/out-of-project narration: '+sid)
        sections.append({**section,'visuals':visuals,'blocks':blocks,
                         'audio':audio.relative_to(PROJECT).as_posix(),
                         'captions':caption_groups(by_words[sid],section['heading_holds'])})
    actual_ids=[b['source_block_id'] for s in sections for b in s['blocks']]
    if len(actual_ids) != len(set(actual_ids)) or len(actual_ids) != panels['required_blocks']:
        raise ValueError('Duplicated or missing source blocks')
    # Required source figures must be displayed even when an animation also
    # explains the topic; record them as additional diagram cues for the builder.
    figure_cues=[]
    for figure in figures:
        owner=next(s for s in sections if figure['block_id'] in s['source_block_ids'])
        figure_cues.append({'section':owner['section_id'], **figure})
    output={'stage':'assembly_draft','render_ready':False,'chapter_complete':False,
            'duration':cues['duration_seconds'],'sections':sections,'required_figures':figure_cues,
            'source_block_count':len(actual_ids),'warnings':warnings,
            'remaining_gates':['retimed media','all seven figure placements','audio flags',
                               'placed UI review','stage reconciliation','encoded output QA']}
    atomic_json(ROOT/'composition-plan.json',output)
    print(json.dumps({'sections':len(sections),'source_blocks':len(actual_ids),
                      'caption_pages':sum(len(s['captions']) for s in sections),
                      'required_figures':len(figure_cues),'warnings':warnings,'render_ready':False}))


if __name__=='__main__':
    main()
