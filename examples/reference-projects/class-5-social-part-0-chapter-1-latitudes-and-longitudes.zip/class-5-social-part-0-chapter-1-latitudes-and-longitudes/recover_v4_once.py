"""One bounded status check per saved job; never submits generation requests."""
import json
import os
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

import requests
from dotenv import load_dotenv
from lib.production_runtime import atomic_json
from tools.video.modelslab_video import ModelsLabVideo

PROJECT = Path(__file__).resolve().parent
REPO = PROJECT.parents[1]


def check(path):
    state = json.loads(path.read_text(encoding='utf-8'))
    output = Path(str(path).removesuffix('.modelslab-job.json'))
    row = {'shot': output.stem, 'request_id': str(state['request_id']),
           'new_submission': False, 'checked_at': datetime.now(timezone.utc).isoformat()}
    if output.is_file() and output.stat().st_size:
        return {**row, 'status': 'already_downloaded'}
    if state.get('status') == 'terminal_failed':
        return {**row, 'status': 'terminal_failed'}
    request_id = row['request_id']
    if not request_id.isdigit() or state.get('provider') != 'modelslab':
        return {**row, 'status': 'invalid_sidecar'}
    endpoint = state.get('poll_endpoint')
    if endpoint not in ('video', 'video-fusion'):
        return {**row, 'status': 'unsupported_endpoint'}
    version = 'v6' if endpoint == 'video' else 'v7'
    try:
        with requests.Session() as session:
            response = session.post(
                f'https://modelslab.com/api/{version}/{endpoint}/fetch/{request_id}',
                json={'key': os.environ['MODELSLAB_API_KEY']}, timeout=(10, 30))
            row['http_status'] = response.status_code
            response.raise_for_status()
            payload = response.json()
        row['status'] = str(payload.get('status', 'unknown'))
        row['output_available'] = bool(payload.get('output') or payload.get('url'))
        if row['status'] == 'success':
            result = ModelsLabVideo().execute({
                'resume_request_id': request_id, 'model_id': state['model_id'],
                'operation': state['operation'], 'poll_endpoint': endpoint,
                'generate_audio': False, 'educational_mode': True,
                'output_path': str(output), 'job_state_path': str(path)})
            row['output_bytes'] = output.stat().st_size if output.is_file() else 0
            row['status'] = 'recovered' if result.success and row['output_bytes'] else 'recovery_error'
        # A response error is not sufficient evidence that the generation itself
        # failed (authentication and service errors also use status=error).
        return row
    except (requests.RequestException, ValueError, KeyError) as exc:
        return {**row, 'status': 'check_error', 'error_type': type(exc).__name__}


def main():
    load_dotenv(REPO / '.env')
    if not os.environ.get('MODELSLAB_API_KEY'):
        raise SystemExit('MODELSLAB_API_KEY is not configured locally')
    paths = sorted((PROJECT / 'assets/video/revision-v4').glob('*.mp4.modelslab-job.json'))
    with ThreadPoolExecutor(max_workers=3) as pool:
        rows = list(pool.map(check, paths))
    report = {'checked_at': datetime.now(timezone.utc).isoformat(),
              'new_submissions': 0, 'jobs': rows, 'chapter_complete': False}
    atomic_json(PROJECT / 'artifacts/revision-v4/recovery-sweep-latest.json', report)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
