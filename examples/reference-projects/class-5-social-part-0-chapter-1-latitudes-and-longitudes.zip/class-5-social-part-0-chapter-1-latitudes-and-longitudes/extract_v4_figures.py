"""Render required source-PDF regions with Poppler, preserving original labels."""
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
import pymupdf
from lib.production_runtime import atomic_json

PROJECT = Path(__file__).resolve().parent


def overlap_ratio(a, b):
    intersection = max(0, min(a[2], b[2])-max(a[0], b[0])) * max(0, min(a[3], b[3])-max(a[1], b[1]))
    union = (a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - intersection
    return intersection / union if union else 0


def main():
    artifact = PROJECT / 'artifacts/revision-v4/chapter_document.json'
    chapter = json.loads(artifact.read_text(encoding='utf-8'))
    source = Path(chapter['source']['path'])
    extracted = PROJECT.parents[1] / 'textbook-collections/class-5-social/extracted/chapter-01/chapter-01-latitude-and-longitudes.json'
    image_nodes = [node for node in json.loads(extracted.read_text(encoding='utf-8'))['kids']
                   if node.get('type') == 'image']
    executable = shutil.which('pdftoppm')
    if not executable:
        raise SystemExit('Poppler missing; no silent substitute or dependency install')
    output = PROJECT / 'assets/source-figures/revision-v4'
    output.mkdir(parents=True, exist_ok=True)
    entries = []
    with pymupdf.open(source) as pdf:
        for block in chapter['blocks']:
            if block['block_type'] != 'figure' or not block.get('required_for_coverage'):
                continue
            page_number = block['page_number']
            rect = pdf[page_number - 1].rect
            width, height = rect.width * 2.5, rect.height * 2.5
            x0, y0, x1, y1 = block['bbox']
            # Prefer the original embedded image already extracted by
            # OpenDataLoader. Full page crops can pick up adjacent body text.
            matches = []
            for node in image_nodes:
                if node['page number'] != page_number:
                    continue
                x, y, right_x, upper_y = node['bounding box']
                bounds = [x/rect.width, 1-upper_y/rect.height, right_x/rect.width, 1-y/rect.height]
                matches.append((overlap_ratio(block['bbox'], bounds), node))
            score, match = max(matches, key=lambda item: item[0]) if matches else (0, None)
            left, top = math.floor(x0 * width), math.floor(y0 * height)
            right, bottom = math.ceil(x1 * width), math.ceil(y1 * height)
            prefix = output / (block['semantic_role'] + '-source')
            destination = prefix.with_suffix('.png')
            # The embedded continent PNG has three white rectangular
            # extraction artifacts at bottom-right; page raster is intact.
            use_embedded = score >= .8 and block['semantic_role'] != 'continent_map'
            if use_embedded:
                original = extracted.parent / match['source']
                if not destination.exists():
                    shutil.copy2(original, destination)
                method = 'OpenDataLoader original embedded image'
            elif block['semantic_role'] == 'continent_map':
                destination = output / 'continent_map.png'
                if not destination.is_file():
                    raise SystemExit('Reviewed intact continent page crop is missing')
                method = 'Poppler source-page region; embedded PNG rejected for extraction artifacts'
            elif not destination.exists():
                subprocess.run([executable, '-f', str(page_number), '-l', str(page_number),
                                '-singlefile', '-r', '180', '-x', str(left), '-y', str(top),
                                '-W', str(right-left), '-H', str(bottom-top), '-png',
                                str(source), str(prefix)], check=True, timeout=60,
                               capture_output=True)
                method = 'Poppler source-page region'
            else:
                method = 'Poppler source-page region'
            entries.append({'block_id': block['block_id'], 'page_number': page_number,
                            'semantic_role': block['semantic_role'], 'normalized_bbox': block['bbox'],
                            'rendered_bbox': [x0, y0, x1, y1],
                            'extraction_method': method, 'image_match_iou': round(score, 5),
                            'original_image': match['source'] if use_embedded else None,
                            'asset': destination.relative_to(PROJECT).as_posix(),
                            'source_labels': block['source_text'],
                            'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
                            'visual_review': 'pending', 'labels_retyped': False})
    atomic_json(PROJECT / 'artifacts/revision-v4/source-figure-manifest.json',
                {'source_pdf': str(source), 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                 'renderer': 'Poppler pdftoppm', 'dpi': 180, 'figures': entries})
    print(json.dumps({'extracted': len(entries), 'directory': str(output), 'review': 'pending'}))


if __name__ == '__main__':
    main()
