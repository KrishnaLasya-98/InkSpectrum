# Class 5 Social Chapter 1 — revision v4

Inherits the approved English Class 1 final-v7 / EVS teaching presentation and the existing hyperframes-educational-v1 1.0.3 palette contract. This is a new chapter composition, not new media from those chapters.

Cream #FFF9ED, ink #123247, teaching accent #A83C2D, active word #B64132, inactive word #526B78. Georgia for verbatim source reading; Nunito/Segoe UI for headings and captions. Generous 58–64px edge safety. Full-frame fresh 3D shots; exact source diagrams use contain, never crop their labels. Compact cream top-right panels. No decorative heading underline, red hanging tab, invented summary, fake geographic silhouette, or filler copy. Source tables and objectives remain stable during reading.

Title includes Social Studies, Class 5, Lesson 1 and Latitudes and Longitudes over fresh chapter artwork/motion. Later heading holds display only the source heading for four measured silent seconds. Teaching content starts after that hold. Body pages preserve contiguous exact source text, never smaller than 28px. Caption lane is consistently bottom-centred, with measured word highlights and punctuation.

0.55s incoming-over-outgoing scene dissolves; no dark dip. Short topical shot changes use a restrained dissolve only if both source durations cover it; never loop, stretch narration, or freeze story footage. Precise silent 3D teaching animations may intentionally hold completed geometry while the explanation continues. No CSS infinite animation or media-controlled playback.

Layout-preview.html is static hero-frame QA only. A rendered layout preview does not imply final audio, timing, media, source or encoded-output approval.
