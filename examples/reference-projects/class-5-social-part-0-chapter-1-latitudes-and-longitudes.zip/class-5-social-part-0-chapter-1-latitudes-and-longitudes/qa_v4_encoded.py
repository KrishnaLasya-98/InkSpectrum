"""Encoded Chapter 1 checks. Run only after the render process exits zero."""
import json
import math
import re
from pathlib import Path
import subprocess
import numpy as np
import soundfile as sf
from PIL import Image,ImageDraw
from lib.production_runtime import atomic_json

PROJECT=Path(__file__).resolve().parent
ROOT=PROJECT/'artifacts/revision-v4'
VIDEO=PROJECT/'renders/class5-social-chapter1-latitudes-longitudes-v4.mp4'
OUT=ROOT/'encoded-qa'

def run(command,timeout):
    done=subprocess.run(command,capture_output=True,timeout=timeout)
    if done.returncode:
        raise RuntimeError(done.stderr.decode(errors='replace')[-1000:])
    return done.stdout.decode(errors='replace')

def envelope(samples,rate):
    hop=round(rate*.1)
    full=len(samples)//hop
    view=samples[:full*hop].reshape(full,hop)
    return np.sqrt(np.mean(view.astype(np.float64)**2,axis=1))

def audio_alignment(probe,plan):
    if not any(x['codec_type']=='audio' for x in probe['streams']):
        return {'status':'fail','issue':'encoded audio absent'}
    encoded=np.frombuffer(subprocess.run(['ffmpeg','-v','error','-i',str(VIDEO),'-vn',
        '-ac','1','-ar','8000','-f','f32le','pipe:1'],capture_output=True,check=True,
        timeout=240).stdout,dtype='<f4')
    encoded_level=envelope(encoded,8000)
    checks=[]
    for section in plan['sections']:
        source,sr=sf.read(PROJECT/section['audio'],dtype='float32')
        if source.ndim>1:source=source.mean(axis=1)
        local=envelope(source,sr)
        start=round(section['start_seconds']*10)
        # AAC encoders can introduce up to a short framing offset. Compare
        # 100ms loudness envelopes across a bounded 500ms lag range.
        matched=[]
        for shift in range(-5,6):
            lo=start+shift
            if lo<0 or lo+len(local)>len(encoded_level):continue
            a,b=local,encoded_level[lo:lo+len(local)]
            if np.std(a)<1e-6 or np.std(b)<1e-6:continue
            matched.append((float(np.corrcoef(a,b)[0,1]),shift/10))
        score,shift=max(matched,default=(0,0))
        checks.append({'section_id':section['section_id'],'envelope_correlation':round(score,3),
                       'best_offset_seconds':shift,'status':'pass' if score>=.7 and abs(shift)<=.2 else 'review'})
    return {'status':'pass' if all(x['status']=='pass' for x in checks) else 'review',
            'checks':checks,'encoded_rms':float(np.sqrt(np.mean(encoded.astype(np.float64)**2)))}

def main():
    if not VIDEO.is_file():raise SystemExit('Render output missing')
    OUT.mkdir(exist_ok=True)
    plan=json.loads((ROOT/'composition-plan-media.json').read_text(encoding='utf-8'))
    raw=json.loads(run(['ffprobe','-v','error','-show_format','-show_streams',
                        '-print_format','json',str(VIDEO)],60))
    video=next(s for s in raw['streams'] if s['codec_type']=='video')
    audio=next((s for s in raw['streams'] if s['codec_type']=='audio'),None)
    duration=float(raw['format']['duration'])
    technical={'duration_seconds':duration,'width':video['width'],'height':video['height'],
        'fps':video['avg_frame_rate'],'video_codec':video['codec_name'],
        'audio_codec':audio['codec_name'] if audio else None,
        'audio_sample_rate':int(audio['sample_rate']) if audio else None,
        'audio_channels':audio['channels'] if audio else None,
        'bytes':VIDEO.stat().st_size}
    technical['pass']=abs(duration-plan['duration'])<.15 and video['width']==1920 and video['height']==1080 and video['codec_name']=='h264' and audio is not None
    times=[]
    for section in plan['sections']:
        begin,end=section['start_seconds'],section['end_seconds']
        hold=section['heading_holds'][-1]['end_seconds'] if section['heading_holds'] else begin
        times.extend([min(end-.1,begin+.5),min(end-.1,hold+1),min(end-.1,(hold+end)/2)])
    times=sorted(set(round(x,3) for x in times+[0,duration-.1]))
    paths=[]
    for i,at in enumerate(times):
        file=OUT/f'frame-{i:03d}-at-{at:.3f}.jpg'
        run(['ffmpeg','-hide_banner','-loglevel','error','-ss',str(at),'-i',str(VIDEO),
             '-frames:v','1','-vf','scale=480:-2','-q:v','3','-y',str(file)],30)
        paths.append(file)
    for page in range(math.ceil(len(paths)/12)):
        batch=paths[page*12:(page+1)*12]
        sheet=Image.new('RGB',(1440,1200),'#142033'); draw=ImageDraw.Draw(sheet)
        for j,file in enumerate(batch):
            with Image.open(file) as f:small=f.convert('RGB')
            x,y=(j%3)*480,(j//3)*300
            sheet.paste(small,(x,y+30));draw.text((x+8,y+6),file.stem,fill='white')
        sheet.save(OUT/f'contact-{page+1:02d}.jpg',quality=90)
    # ffmpeg emits filter findings on stderr.
    scan=subprocess.run(['ffmpeg','-hide_banner','-i',str(VIDEO),'-vf',
        'blackdetect=d=0.10:pix_th=0.05','-an','-f','null','NUL'],
        capture_output=True,text=True,timeout=300)
    if scan.returncode:raise RuntimeError(scan.stderr[-1000:])
    black_events=[line for line in scan.stderr.splitlines() if 'black_start:' in line]
    freeze_scan=subprocess.run(['ffmpeg','-hide_banner','-i',str(VIDEO),'-vf',
        'freezedetect=n=-48dB:d=1.5','-an','-f','null','NUL'],
        capture_output=True,text=True,timeout=300)
    if freeze_scan.returncode:raise RuntimeError(freeze_scan.stderr[-1000:])
    frozen=[]
    active_start=None
    for line in freeze_scan.stderr.splitlines():
        a=re.search(r'freeze_start:\s*([\d.]+)',line)
        b=re.search(r'freeze_end:\s*([\d.]+)',line)
        if a:active_start=float(a.group(1))
        if b and active_start is not None:
            frozen.append({'start':active_start,'end':float(b.group(1))})
            active_start=None
    if active_start is not None:frozen.append({'start':active_start,'end':duration})
    generated=[shot for section in plan['sections'] for shot in section['visuals']
        if shot['kind']=='video' and not shot.get('teaching_hold_allowed')]
    motion_conflicts=[]
    for shot in generated:
        for freeze in frozen:
            overlap=max(0,min(shot['end'],freeze['end'])-max(shot['start'],freeze['start']))
            if overlap>1.0:
                motion_conflicts.append({'asset':shot['asset'],'shot':shot['id'],
                    'overlap_seconds':round(overlap,3),'freeze':freeze})
    report={'stage':'encoded_qa_needs_visual_review','technical':technical,
       'black_events':black_events,'audio_alignment':audio_alignment(raw,plan),
       'freeze_intervals':frozen,'generated_motion_freeze_conflicts':motion_conflicts,
       'contact_sheets':[str(x) for x in sorted(OUT.glob('contact-*.jpg'))],
       'captured_frames':len(paths),'visual_review_passed':False,'chapter_complete':False}
    atomic_json(OUT/'report.json',report)
    print(json.dumps({'technical_pass':technical['pass'],'black_events':len(black_events),
        'freeze_intervals':len(frozen),'generated_motion_freelicts':len(motion_conflicts),
        'audio_alignment':report['audio_alignment']['status'],'frames':len(paths)}))
    if not technical['pass']:raise SystemExit(1)

if __name__=='__main__':main()
