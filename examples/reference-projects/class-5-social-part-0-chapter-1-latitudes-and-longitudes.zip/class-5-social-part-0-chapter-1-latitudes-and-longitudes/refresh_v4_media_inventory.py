"""Inventory real outputs and durable job IDs, without making provider calls."""
import hashlib
import json
import re
from pathlib import Path
from datetime import datetime, timezone
from lib.production_runtime import atomic_json
from tools.analysis.educational_clip_qa import technical_motion_audit

PROJECT = Path(__file__).resolve().parent
ROOT = PROJECT / 'artifacts/revision-v4'


def main():
    read = lambda path: json.loads(path.read_text(encoding='utf-8'))
    qa = read(ROOT / 'motion-qa-progress.json')
    rejected = {item['file']: item['reason'] for item in qa['rejected_clips']}
    rows = []
    for sidecar in sorted((PROJECT / 'assets/video/revision-v4').glob('*.mp4.modelslab-job.json')):
        job = read(sidecar)
        clip = Path(str(sidecar).removesuffix('.modelslab-job.json'))
        entry = {'shot_id': clip.stem, 'request_id': job['request_id'], 'model_id': job['model_id'],
                 'provider_state': job['status'], 'exists': clip.is_file(),
                 'asset': clip.relative_to(PROJECT).as_posix(),
                 'status': 'pending_recovery', 'composition_approved': False}
        if clip.is_file():
            entry.update(bytes=clip.stat().st_size, sha256=hashlib.sha256(clip.read_bytes()).hexdigest(),
                         technical=technical_motion_audit(clip))
            entry['status'] = 'rejected' if clip.name in rejected else 'candidate_needs_placed_qa'
            if clip.name in rejected:
                entry['rejection_reason'] = rejected[clip.name]
        rows.append(entry)
    report = {'updated_at': datetime.now(timezone.utc).isoformat(), 'chapter_complete': False,
              'provider_calls_made': 0, 'clips': rows,
              'summary': {state: sum(row['status'] == state for row in rows)
                          for state in ('rejected', 'candidate_needs_placed_qa', 'pending_recovery')}}
    atomic_json(ROOT / 'media-inventory.json', report)
    for batch_file in sorted(ROOT.glob('motion-batch-*.json')):
        # Diagnostics and status sidecars are not submission manifests.
        if not re.fullmatch(r'motion-batch-\d+', batch_file.stem):
            continue
        batch = read(batch_file)
        wanted = {shot['shot_id'] for shot in batch['shots']}
        subset = [row for row in rows if row['shot_id'] in wanted]
        atomic_json(batch_file.with_name(batch_file.stem + '-status.json'),
                    {'shots': subset, 'acquisition_complete': len(subset) == len(wanted) and all(x['exists'] for x in subset),
                     'quality_approved': False, 'complete': False})
    print(json.dumps(report['summary']))


if __name__ == '__main__':
    main()
