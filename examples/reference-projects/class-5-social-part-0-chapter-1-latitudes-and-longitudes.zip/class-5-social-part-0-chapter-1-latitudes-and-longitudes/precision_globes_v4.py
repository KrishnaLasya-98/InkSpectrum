"""Source-cued 3D teaching components, silent and without invented geography.

These geometric globes supplement complete textbook figures in HyperFrames.
No external images, geographic outlines or guessed map labels are generated.
"""
import json
import re
from pathlib import Path
import numpy as np
from manim import ThreeDScene, Sphere, VMobject, VGroup, Create, FadeIn, LaggedStart, MoveAlongPath, DEGREES, linear
from precision_globe_geometry import point, latitude_points, longitude_points, visible_runs

PROJECT = Path(__file__).resolve().parent
ROOT = PROJECT/'artifacts/revision-v4'
CREAM = '#FFF8E9'
GOLD = '#F9C75B'
CORAL = '#E87857'


def tokens(text):
    return re.sub(r'[^\w]+','',text.casefold())


class TeachingGlobe(ThreeDScene):
    section_id = None

    def setup(self):
        super().setup()
        self.voice = next(s for s in json.loads((ROOT/'narration_manifest.json').read_text())['segments']
                          if s['section_id']==self.section_id)
        self.words = next(s['words'] for s in json.loads((ROOT/'alignment-clean/narration_aligned.json').read_text())['segments']
                          if s['section_id']==self.section_id)
        section = next(s for s in json.loads((ROOT/'visual-cue-plan.json').read_text())['sections']
                       if s['section_id']==self.section_id)
        self.body_start = section['heading_holds'][-1]['end_seconds']
        self.camera.background_color = '#DCEEF1'
        self.set_camera_orientation(phi=78*DEGREES,theta=-90*DEGREES,
                                    frame_center=np.array([1.6,0,0]),zoom=.95)
        self.camera.light_source.move_to(np.array([-5,-6,8]))
        self.globe = Sphere(radius=2.2,resolution=(32,56)).set_fill('#3798B4',opacity=1)
        self.globe.set_stroke('#3798B4',width=.3).set_shade_in_3d(True)
        self.add(self.globe)

    def cue(self, phrase):
        words = [tokens(w['word']) for w in self.words]
        target = [tokens(w) for w in phrase.split()]
        hits = [i for i in range(len(words)-len(target)+1)
                if words[i:i+len(target)]==target
                and self.words[i]['start_ms']/1000 >= self.body_start-.001]
        if len(hits)!=1:
            raise ValueError(f'Ambiguous or missing body cue: {self.section_id} {phrase}: {hits}')
        return self.words[hits[0]]['start_ms']/1000-self.voice['start_seconds']

    def until(self, target):
        if target < self.time-.075:
            raise ValueError(f'Animation passed its cue by {self.time-target:.3f}s')
        if target>self.time:
            self.wait(target-self.time)

    def curve(self, points, color=CREAM, width=4):
        return VGroup(*[VMobject(color=color,stroke_width=width).set_points_as_corners(np.array(run))
                        for run in visible_runs(points)])

    def parallel(self, lat, color=CREAM, width=4):
        return self.curve(latitude_points(lat),color,width)

    def meridian(self, lon, color=CREAM, width=4):
        return self.curve(longitude_points(lon),color,width)

    def finish(self):
        self.until(self.voice['duration_seconds'])


class GridLines(TeachingGlobe):
    section_id = 's07-grid'

    def construct(self):
        self.until(self.cue('imaginary lines'))
        parallels = VGroup(*[self.parallel(lat) for lat in [-60,-30,0,30,60]])
        self.play(LaggedStart(*[Create(curve) for curve in parallels],lag_ratio=.1),run_time=1.0)
        self.until(self.cue('longitudes'))
        meridians = VGroup(*[self.meridian(lon) for lon in [-60,-30,0,30,60]])
        self.play(LaggedStart(*[Create(curve) for curve in meridians],lag_ratio=.1),run_time=1.0)
        self.until(self.cue('exact position'))
        marker = Sphere(radius=.09,resolution=(8,12)).set_color(CORAL)
        marker.set_shade_in_3d(False).move_to(point(30,30,2.25))
        self.play(FadeIn(marker),run_time=.35)
        self.finish()


class LatitudeCircles(TeachingGlobe):
    section_id = 's08-latitudes'

    def construct(self):
        self.until(self.cue('horizontal imaginary lines'))
        lines = {lat:self.parallel(lat) for lat in [-60,-30,0,30,60]}
        self.play(LaggedStart(*[Create(line) for line in lines.values()],lag_ratio=.12),run_time=1.3,rate_func=linear)
        self.until(self.cue('distance between'))
        self.play(*[lines[lat].animate.set_color(GOLD) for lat in [0,30,60]],run_time=.45)
        self.until(self.cue('keeps decreasing'))
        self.play(*[line.animate.set_color(CREAM) for line in lines.values()],run_time=.3)
        for lat in [0,30,60]:
            self.play(lines[lat].animate.set_stroke(GOLD,width=7),run_time=.45)
            self.play(lines[lat].animate.set_stroke(CREAM,width=4),run_time=.25)
        self.finish()


class ImportantParallels(TeachingGlobe):
    section_id = 's10-parallels'

    def construct(self):
        pairs = [('Equator',0),('Tropic of Cancer',23.5),('Tropic of Capricorn',-23.5),
                 ('Arctic Circle',66.5),('Antarctic Circle',-66.5)]
        previous = None
        for phrase,latitude in pairs:
            self.until(self.cue(phrase))
            if previous is not None:
                previous.set_stroke(CREAM,width=3)
            line = self.parallel(latitude,GOLD,6)
            self.play(Create(line),run_time=.65,rate_func=linear)
            previous = line
        self.finish()


class MeridianLines(TeachingGlobe):
    section_id = 's12-longitudes'

    def construct(self):
        self.until(self.cue('vertical imaginary lines'))
        lines = {lon:self.meridian(lon) for lon in [-60,-30,0,30,60]}
        self.play(LaggedStart(*[Create(line) for line in lines.values()],lag_ratio=.12),run_time=1.2)
        self.until(self.cue('North Pole to the South Pole'))
        # North-to-south construction already traces the correct direction;
        # emphasize the same meridian rather than drawing false straight axes.
        self.play(lines[0].animate.set_stroke(GOLD,width=7),run_time=.4)
        self.until(self.cue('degrees east or west'))
        self.play(lines[30].animate.set_stroke(CORAL,width=6),
                  lines[-30].animate.set_stroke(CORAL,width=6),run_time=.6)
        self.until(self.cue('zero-degree meridian'))
        self.play(lines[30].animate.set_stroke(CREAM,width=4),
                  lines[-30].animate.set_stroke(CREAM,width=4),run_time=.4)
        self.finish()


class GreenwichTime(TeachingGlobe):
    section_id = 's14-gmt'

    def construct(self):
        self.until(self.cue('Greenwich Mean Time (GMT) is'))
        prime=self.meridian(0,GOLD,6)
        self.play(Create(prime),run_time=.7)
        self.until(self.cue('different time zones'))
        zones=VGroup(*[self.meridian(lon,CREAM,3) for lon in [-60,-45,-30,-15,15,30,45,60]])
        self.play(LaggedStart(*[Create(line) for line in zones],lag_ratio=.07),run_time=1.1)
        self.until(self.cue('Each 15°'))
        arc=self.curve([point(0,i*.15) for i in range(101)],CORAL,7)
        self.play(Create(arc),run_time=.55)
        self.finish()


class DateLine(TeachingGlobe):
    section_id = 's16-idl'

    def construct(self):
        # This is the opposite view: camera-facing meridian represents 180°.
        # There are no land outlines; exact source cutaway stays separately
        # visible in the composition. It is NOT an invented geographic map.
        self.until(self.cue('imaginary line'))
        dateline=self.meridian(0,GOLD,6)
        self.play(Create(dateline),Create(self.parallel(0,CREAM,3)),run_time=.7)
        marker=Sphere(radius=.10,resolution=(8,12)).set_color(CORAL)
        marker.set_shade_in_3d(False)
        self.until(self.cue('Traveling westward'))
        west=self.curve([point(0,30-i*.5,2.25) for i in range(121)],CORAL,6)
        marker.move_to(point(0,30,2.25))
        self.add(marker)
        self.play(Create(west),MoveAlongPath(marker,west[0]),run_time=1.4,rate_func=linear)
        self.until(self.cue('traveling eastward'))
        east=self.curve([point(0,-30+i*.5,2.25) for i in range(121)],CORAL,6)
        self.play(MoveAlongPath(marker,east[0]),run_time=1.4,rate_func=linear)
        self.finish()
