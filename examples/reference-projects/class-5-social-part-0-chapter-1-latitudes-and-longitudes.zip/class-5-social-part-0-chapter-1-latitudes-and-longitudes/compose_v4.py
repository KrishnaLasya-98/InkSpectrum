"""Compile the scoped, measured assembly plan into HyperFrames HTML.

This is an inspectable draft, not a final-video checkpoint. The chapter-specific
assembly is data-driven; the locked educational CSS is shared across every scene.
"""
from html import escape
import hashlib
import json
from pathlib import Path
import shutil
from lib.production_runtime import atomic_json
from prepare_v4_composition import PROJECT, ROOT, read
from prepare_v4_timing import phrase_index

OUT=PROJECT/'hyperframes-v4-production'
STYLE=PROJECT/'hyperframes-revision-v4'
COMP='class5-social-chapter1-v4'


class Composer:
    def __init__(self, plan):
        self.plan=plan
        self.html=[]
        self.js=[]
        self.counter=0
        self.coverage=[]
        self.media=[]

    def asset(self, relative):
        source=(PROJECT/relative).resolve()
        if not source.is_relative_to(PROJECT) or not source.is_file():
            raise ValueError('Missing/out-of-project asset: '+relative)
        digest=hashlib.sha256(source.read_bytes()).hexdigest()
        name=source.stem+'-'+digest[:10]+source.suffix
        folder=OUT/'media'
        folder.mkdir(exist_ok=True)
        target=folder/name
        if not target.exists():
            shutil.copy2(source,target)
        elif hashlib.sha256(target.read_bytes()).hexdigest()!=digest:
            raise ValueError('Immutable media copy changed: '+name)
        return 'media/'+name

    def node(self, body, start, end, cls='overlay', track=30, z=1000, source=None, entrance=True):
        if end <= start:
            raise ValueError('Empty timed node')
        self.counter+=1
        ident=f'node-{self.counter:04d}'
        attr=f' data-source-block="{escape(source)}"' if source else ''
        self.html.append(f'<div id="{ident}" class="clip {cls}" data-start="{start:.6f}" '
                         f'data-duration="{end-start:.6f}" data-track-index="{track}" '
                         f'style="z-index:{z}"{attr}>{body}</div>')
        if entrance:
            self.js.append(f'tl.from("#{ident}",{{opacity:0,duration:.18,ease:"sine.out",immediateRender:false}},{start:.6f});')
        if source:
            self.coverage.append({'block':source,'element':ident,'start':start,'end':end})
        return ident

    def picture(self, relative, start, end, source=None, z=500):
        content=f'<div class="scene-content"><div class="figure-layout"><figure class="source-figure"><img src="{self.asset(relative)}" alt="Exact textbook figure"></figure></div></div>'
        return self.node(content,start,end,'overlay figure-layer',track=70,z=z,source=source)

    def movie(self, shot, number):
        start,end=shot['render_start'],shot['end']
        ident=f'movie-{number:03d}'
        wrapper=f'{ident}-wrapper'
        # Wrapper is deliberately NOT timed: runtime controls the media once.
        self.html.append(f'<div class="media-wrap" id="{wrapper}" style="z-index:{10+number}">'
             f'<video id="{ident}" class="clip" src="{self.asset(shot["asset"])}" '
             f'data-start="{start:.6f}" data-duration="{end-start:.6f}" '
             f'data-media-start="0" data-track-index="{100+number}" muted playsinline preload="metadata"></video></div>')
        duration=shot.get('dissolve_seconds',0)
        if duration:
            self.js.append(f'tl.from("#{ident}",{{opacity:0,duration:{duration},ease:"power2.inOut",immediateRender:false}},{start:.6f});')
        self.media.append({'id':ident,'asset':shot['asset'],'start':start,'end':end,
                           'available_seconds':shot['source_duration'],
                           'explicit_teaching_end_hold':shot.get('end_hold_seconds',0)})

    def captions(self, section):
        for caption in section['captions']:
            index=self.counter+1
            spans=[]
            for j,word in enumerate(caption['words']):
                wid=f'word-{index:04d}-{j}'
                spans.append(f'<span id="{wid}" class="caption-word">{escape(word["word"])}</span>')
                self.js.append(f'tl.set("#{wid}",{{color:"#FFF9ED",backgroundColor:"#B64132"}},{word["start_ms"]/1000:.6f});')
                self.js.append(f'tl.set("#{wid}",{{color:"#526B78",backgroundColor:"transparent"}},{min(word["end_ms"]/1000,caption["end"]):.6f});')
            self.node('<div class="caption-lane">'+' '.join(spans)+'</div>',
                      caption['start'],caption['end'],'caption-shell',track=90,z=10000,entrance=False)

    def diagram_label(self, text, x, y, anchor_x, anchor_y, start, end):
        # Pixel anchors correspond to the fixed authored 1080p teaching camera.
        # Labels are separate from source panels and never baked into AI video.
        svg=f'<svg class="label-leader" viewBox="0 0 1920 1080"><path d="M {anchor_x} {anchor_y} L {x-18} {y+24} L {x} {y+24}"/><circle cx="{anchor_x}" cy="{anchor_y}" r="5"/></svg>'
        label=f'<span class="diagram-label" style="left:{x}px;top:{y}px">{escape(text)}</span>'
        self.node(svg+label,start,end,track=82,z=800)

    def table(self, block, start, end):
        rows=[]
        ident_base=f'table-{self.counter+1}'
        for i,row in enumerate(block['rows']):
            tag='th' if i==0 else 'td'
            rid=f'{ident_base}-row-{i}'
            cells=''.join(f'<{tag}>{escape(cell)}</{tag}>' for cell in row)
            rows.append(f'<tr id="{rid}">{cells}</tr>')
            timing=block['row_timing'][i]
            self.js.append(f'tl.set("#{rid}",{{backgroundColor:"#F6E2C9"}},{timing["start_ms"]/1000:.6f});')
            self.js.append(f'tl.set("#{rid}",{{backgroundColor:"transparent"}},{timing["display_end_ms"]/1000:.6f});')
        table='<table><thead>'+rows[0]+'</thead><tbody>'+''.join(rows[1:])+'</tbody></table>'
        body=f'<div class="scene-content"><div class="reading-frame"><article class="reading-card">{table}</article></div></div>'
        self.node(body,start,end,source=block['source_block_id'])

    def reading(self, blocks, start, end):
        content=[]
        for block in blocks:
            if block['type'] in ('chapter_title','section_heading','figure','table'):
                continue
            bid=block['source_block_id']
            ident='reading-'+bid
            css='reading bullet-reading' if block['type']=='bullet' else 'reading'
            content.append(f'<p id="{ident}" class="{css}" data-source-block="{bid}">{escape(block["source_text"])}</p>')
            pages=block['pages']
            a=pages[0]['timing']['start_ms']/1000
            b=pages[-1]['timing']['display_end_ms']/1000
            self.js.append(f'tl.set("#{ident}",{{backgroundColor:"#F6E2C9"}},{a:.6f});')
            self.js.append(f'tl.set("#{ident}",{{backgroundColor:"transparent"}},{b:.6f});')
            self.coverage.append({'block':bid,'element':ident,'start':start,'end':end})
        body='<div class="scene-content"><div class="reading-frame"><article class="reading-card reading-list">'+''.join(content)+'</article></div></div>'
        self.node(body,start,end)

    def panels(self, blocks):
        for block in blocks:
            if block['type'] in ('chapter_title','section_heading','figure','table'):
                continue
            for page in block['pages']:
                t=page['timing']
                body='<div class="scene-content"><div class="panel-layout"><article class="learning-panel"><p class="reading">'+escape(page['text'])+'</p></article></div></div>'
                self.node(body,t['display_start_ms']/1000,t['display_end_ms']/1000,
                          track=30,z=1000,source=block['source_block_id'])

    def build(self):
        figure_by_asset={f['asset']:f['block_id'] for f in self.plan['required_figures']}
        movie_number=0
        visual_number=0
        words=read(ROOT/'alignment-clean/narration_aligned.json')['segments']
        words_by={s['section_id']:s['words'] for s in words}
        def cue(sid,phrase):
            seq=words_by[sid]
            return seq[phrase_index(seq,phrase)]['start_ms']/1000
        for sn,section in enumerate(self.plan['sections']):
            sid=section['section_id']
            start,end=section['start_seconds'],section['end_seconds']
            body_start=section['heading_holds'][-1]['end_seconds'] if section['heading_holds'] else start
            # One microsecond tolerance prevents binary-float false overlap at
            # adjacent narration boundaries. It only trims trailing room silence.
            self.html.append(f'<audio id="audio-{sid}" src="{self.asset(section["audio"])}" data-start="{start:.6f}" data-duration="{end-start-.000001:.6f}" data-track-index="1" data-volume="1"></audio>')
            for shot in section['visuals']:
                visual_number+=1
                if shot['kind']=='video':
                    movie_number+=1
                    self.movie(shot,visual_number)
                elif shot['kind']=='source_figure':
                    self.picture(shot['asset'],max(body_start,shot['render_start']),shot['end'],
                                 figure_by_asset.get(shot['asset']),z=10+visual_number) if shot['end']>body_start else None
            title_block=next(b for b in section['blocks'] if b['type'] in ('chapter_title','section_heading'))
            if sid=='s01-title':
                exact='Latitudes and Longitudes'
                title_words=words_by[sid]
                title='<div class="scene-content intro-content"><article class="intro-card"><p class="subject">SOCIAL STUDIES · CLASS 5</p><p class="lesson-number">Lesson 1</p><h1>'
                title+=' '.join(f'<span id="intro-word-{i}">{escape(w)}</span>' for i,w in enumerate(exact.split()))
                title+='</h1></article></div>'
                ident=self.node(title,start,end,source=title_block['source_block_id'],entrance=False)
                self.js.append(f'tl.from("#{ident} .intro-card",{{y:12,duration:.3,ease:"power3.out"}},0);')
                for i,w in enumerate(title_words[2:]):
                    self.js.append(f'tl.set("#intro-word-{i}",{{color:"#B64132"}},{w["start_ms"]/1000:.6f});')
                    self.js.append(f'tl.set("#intro-word-{i}",{{color:"#123247"}},{w["end_ms"]/1000:.6f});')
                self.captions(section)
                continue
            # Source heading alone while announced and through the four-second
            # measured hold. No body text, diagram labels or subtitle duplicates.
            heading='<h1>'+escape(section['title'])+'</h1>'
            # Incoming background dissolves over the preceding topic's quiet
            # tail. The heading itself is revealed only at its spoken cue;
            # the measured four-second hold and narration remain unchanged.
            transition_start=max(0,start-.25)
            ident=self.node(heading,transition_start,body_start,'heading-hold',track=50,z=9000+sn,
                            source=title_block['source_block_id'],entrance=False)
            self.js.append(f'tl.from("#{ident}",{{opacity:0,duration:.25,ease:"sine.inOut",immediateRender:false}},{transition_start:.6f});')
            self.js.append(f'tl.from("#{ident} h1",{{y:12,duration:.35,ease:"power3.out",immediateRender:false}},{transition_start:.6f});')
            label='<div class="scene-content"><h1 class="heading-label">'+escape(section['title'])+'</h1></div>'
            self.node(label,body_start,end,track=40,z=2000,source=title_block['source_block_id'])
            tables=[b for b in section['blocks'] if b['type']=='table']
            stable=section['visuals'][0]['kind']=='stable_source_reading'
            if tables:
                for block in tables:
                    self.table(block,body_start,end)
            elif stable:
                self.reading(section['blocks'],body_start,end)
            else:
                self.panels(section['blocks'])
            # Captions cover the announcement too, then disappear throughout the
            # measured four-second pause. Every spoken word remains represented.
            self.captions(section)
            if sid=='s08-latitudes':
                self.diagram_label('Latitudes / parallels',850,475,775,424,
                    cue(sid,'horizontal imaginary lines')+1.3,end)
                self.diagram_label('Equator · 0°',850,595,775,578,
                    cue(sid,'Equator'),end)
            if sid=='s10-parallels':
                rings=[('Equator','Equator · 0°',595,790,569),
                       ('Tropic of Cancer','Tropic of Cancer · 23.5° N',430,770,450),
                       ('Tropic of Capricorn','Tropic of Capricorn · 23.5° S',695,765,690),
                       ('Arctic Circle','Arctic Circle · 66.5° N',285,630,287),
                       ('Antarctic Circle','Antarctic Circle · 66.5° S',805,635,803)]
                for phrase,label,y,ax,ay in rings:
                    self.diagram_label(label,840,y,ax,ay,cue(sid,phrase)+.65,end)
            if sid=='s12-longitudes':
                stop=cue(sid,'There are altogether')
                self.diagram_label('North Pole',840,250,535,261,
                    cue(sid,'North Pole to the South Pole'),stop)
                self.diagram_label('South Pole',840,790,535,814,
                    cue(sid,'North Pole to the South Pole'),stop)
                self.diagram_label('Prime Meridian · 0°',840,525,535,540,
                    cue(sid,'zero-degree meridian')+.4,stop)
            if sid=='s14-gmt':
                self.diagram_label('Prime Meridian · 0°',840,500,535,540,body_start+.7,end)
            if sid=='s16-idl':
                self.diagram_label('Date Line · 180°',840,500,535,540,
                    cue(sid,'imaginary line')+.7,end)
            if sid=='s12-longitudes':
                self.picture('assets/source-figures/revision-v4/meridian_diagram-source.png',
                             cue(sid,'There are altogether'),end,'p0005-b0007',z=600)
            if sid=='s07-grid':
                # Source places this illustration after IDL, but it illustrates
                # coordinates, not date changes. Place it with the source's exact
                # position explanation; record this deliberate figure relocation.
                self.picture('assets/source-figures/revision-v4/coordinate_example_diagram-source.png',
                             cue(sid,'They help us determine'),end,'p0006-b0007',z=600)
            if sid=='s14-gmt':
                note='<div class="scene-content"><div class="precision-note">15° longitude · one-hour difference</div></div>'
                self.node(note,cue(sid,'Each'),end,track=80,z=700)
            if sid=='s16-idl':
                for phrase,text,finish in [
                    ('Traveling westward','Westward: calendar forward by one day',cue(sid,'while traveling eastward')),
                    ('while traveling eastward','Eastward: calendar back by one day',end)]:
                    note='<div class="scene-content"><div class="precision-note">'+text+'</div></div>'
                    self.node(note,cue(sid,phrase),finish,track=80,z=700)
        required={b['source_block_id'] for s in self.plan['sections'] for b in s['blocks']}
        found={r['block'] for r in self.coverage}
        if required-found:
            raise ValueError('Unplaced source blocks: '+repr(sorted(required-found)))
        # This CSS adds only structural layout helpers to the visually reviewed
        # reference; palette and type settings remain in educational.css.
        structural='''
        .clip.overlay,.clip.caption-shell,.clip.heading-hold{position:absolute;inset:0}
        .panel-layout,.figure-layout{display:grid;grid-template-columns:minmax(0,1fr) 610px;gap:48px;flex:1;min-height:0;align-items:start;padding-top:100px}
        .figure-layout{align-items:center}.figure-layer{background:#DCEEF1}
        .reading-list{display:flex;flex-direction:column;gap:15px}
        .reading-list .reading{font-size:32px;padding:3px 8px;border-radius:8px}
        .reading-list:has(>p:only-child){width:1150px;padding:44px 48px}
        .reading-list:has(>p:only-child) .reading{font-size:42px;line-height:1.5}
        .bullet-reading{padding-left:28px!important;position:relative}
        .bullet-reading:before{content:'•';position:absolute;left:2px;color:#A83C2D}
        .caption-lane{width:1620px}.precision-note{max-width:1050px}
        .label-leader{position:absolute;inset:0;width:1920px;height:1080px;fill:#A83C2D;stroke:#A83C2D;stroke-width:2.5}
        .label-leader path{fill:none}
        .diagram-label{position:absolute;font:800 25px/1.3 Nunito,'Segoe UI',sans-serif;color:#123247;background:#FFF9ED;padding:10px 14px;border-radius:10px;max-width:365px;box-shadow:0 4px 14px #12324715}
        '''
        html='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=1920,height=1080"><title>Class 5 Social — Latitudes and Longitudes</title><link rel="stylesheet" href="educational.css"><script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"></script><style>'+structural+'</style></head><body>'
        html+=f'<main id="root" class="composition" data-composition-id="{COMP}" data-start="0" data-duration="{self.plan["duration"]}" data-width="1920" data-height="1080">'+'\n'.join(self.html)+'</main>'
        html+='<script>window.__timelines=window.__timelines||{};const tl=gsap.timeline({paused:true});\n'+'\n'.join(self.js)+f'window.__timelines["{COMP}"]=tl;</script></body></html>'
        return html


def main():
    if not (OUT/'hyperframes.json').exists():
        raise SystemExit('Scaffold with pinned local HyperFrames init first')
    plan=read(ROOT/'composition-plan-media.json')
    composer=Composer(plan)
    html=composer.build()
    (OUT/'index.html').write_text(html,encoding='utf-8')
    shutil.copy2(STYLE/'educational.css',OUT/'educational.css')
    shutil.copy2(STYLE/'DESIGN.md',OUT/'DESIGN.md')
    config=read(OUT/'hyperframes.json')
    config.update(name='Class 5 Social Chapter 1 revision v4',width=1920,height=1080,
                  fps=30,duration=plan['duration'])
    atomic_json(OUT/'hyperframes.json',config)
    atomic_json(ROOT/'composition-coverage.json',{
        'stage':'draft_html_needs_runtime_qa','render_ready':False,'chapter_complete':False,
        'source_blocks':len({x['block'] for x in composer.coverage}),
        'placements':composer.coverage,'media':composer.media,
        'figure_relocation':{'p0006-b0007':'s07-grid exact-position explanation; source owner s16-idl retained in coverage contract'},
        'html_sha256':hashlib.sha256(html.encode()).hexdigest()})
    print(json.dumps({'html':str(OUT/'index.html'),'source_blocks':71,
                      'timed_nodes':composer.counter,'videos':len(composer.media),'render_ready':False}))


if __name__=='__main__':
    main()
