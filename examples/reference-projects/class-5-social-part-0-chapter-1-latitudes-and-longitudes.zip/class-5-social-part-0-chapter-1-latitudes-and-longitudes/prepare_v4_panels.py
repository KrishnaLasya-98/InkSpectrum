"""Lossless source-panel pagination draft; does not approve a composition."""
import json
import re
from pathlib import Path
from lib.production_runtime import atomic_json

PROJECT = Path(__file__).resolve().parent
ROOT = PROJECT / 'artifacts/revision-v4'


def paginate(text, limit=35):
    """Return exact character slices, preferring sentence boundaries."""
    words = list(re.finditer(r'\S+', text))
    result, first = [], 0
    while first < len(words):
        last = min(first + limit, len(words))
        if last < len(words):
            ends = [i+1 for i in range(first+max(1,limit//3), last)
                    if re.search(r'[.!?]$', words[i].group())]
            if ends:
                last = ends[-1]
        start = 0 if first == 0 else words[first].start()
        end = len(text) if last == len(words) else words[last].start()
        result.append({'char_start': start, 'char_end': end, 'text': text[start:end]})
        first = last
    assert ''.join(x['text'] for x in result) == text
    return result


def lex(text):
    # Numeric values must not collapse: 23.5 and 235 are different facts.
    return ''.join(re.findall(r'(?<=\d)\.(?=\d)|[^\W_]', text.casefold()))


def anchors(text, words):
    """Match only unambiguous spoken prefixes; never invent numeric timing."""
    source = [lex(w['word']) for w in words]
    target = [lex(t) for t in text.split() if lex(t)]
    for size in (6, 5, 4, 3):
        if len(target) < size:
            continue
        hits = [i for i in range(len(source)-size+1) if source[i:i+size] == target[:size]]
        if len(hits) == 1:
            return {'status': 'prefix_matched_end_pending', 'start_ms': words[hits[0]]['start_ms'],
                    'matched_words': size, 'end_ms': None}
    return {'status': 'manual_timing_review', 'start_ms': None, 'end_ms': None}


def table_rows(text):
    rows = [[c.strip() for c in line.strip().strip('|').split('|')]
            for line in text.splitlines() if line.strip()]
    return [row for row in rows if not all(re.fullmatch(r':?-+:?', cell) for cell in row)]


def exact_span(text, words):
    """Match the whole source string; preserve measured word bounds, fail closed."""
    target = [lex(t) for t in text.split() if lex(t)]
    source = [(lex(w['word']), i) for i, w in enumerate(words) if lex(w['word'])]
    hits = [i for i in range(len(source)-len(target)+1)
            if target and [token for token, _ in source[i:i+len(target)]] == target]
    if len(hits) != 1:
        return {'status': 'manual_timing_review', 'start_ms': None, 'end_ms': None,
                'reason': 'whole_source_not_unique', 'match_count': len(hits)}
    first = source[hits[0]][1]
    last = source[hits[0]+len(target)-1][1]
    return {'status': 'whole_source_matched', 'start_ms': words[first]['start_ms'],
            'end_ms': words[last]['end_ms'], 'first_word_index': first,
            'last_word_index': last, 'matched_words': len(target)}


def assign_panel_windows(blocks, timing):
    """Hold a read page until the next read page; never cross a section boundary."""
    problems = []
    for sid, section in timing.items():
        items = []
        for block in (b for b in blocks if b['section_id'] == sid):
            if block['layout'] == 'compact_corner_panel':
                items.extend((block['source_block_id'], page['timing']) for page in block['pages'])
            elif block['layout'] == 'stable_table_with_row_highlight':
                items.extend((block['source_block_id'], span) for span in block['row_timing'])
        if any(span['status'] != 'whole_source_matched' for _, span in items):
            problems.extend({'section_id': sid, 'source_block_id': bid, 'issue': 'unmatched source text'}
                            for bid, span in items if span['status'] != 'whole_source_matched')
            continue
        for i, (bid, span) in enumerate(items):
            end = items[i+1][1]['start_ms'] if i+1 < len(items) else round(section['end_seconds']*1000)
            if end < span['end_ms'] or span['start_ms'] >= end:
                problems.append({'section_id': sid, 'source_block_id': bid, 'issue': 'overlapping source windows'})
                continue
            if any(span['start_ms'] < hold['end_seconds']*1000 and end > hold['start_seconds']*1000
                   for hold in section['heading_holds']):
                problems.append({'section_id': sid, 'source_block_id': bid, 'issue': 'body intersects heading hold'})
                continue
            span['display_start_ms'] = span['start_ms']
            span['display_end_ms'] = end
    return problems


def main():
    read = lambda name: json.loads((ROOT/name).read_text(encoding='utf-8'))
    plan, coverage = read('educational_plan.json'), read('coverage_contract.json')
    alignment = {s['section_id']: s for s in read('alignment-clean/narration_aligned.json')['segments']}
    timing = {s['section_id']: s for s in read('visual-cue-plan.json')['sections']}
    figures = {f['block_id']: f for f in read('source-figure-manifest.json')['figures']}
    required = {e['source_block_id'] for e in coverage['entries'] if e['required']}
    blocks, seen = [], set()
    for section in plan['sections']:
        sid = section['section_id']
        for fragment in section['source_fragments']:
            block_id = fragment['block_id']
            if block_id not in required or block_id in seen:
                raise ValueError('Out-of-scope or duplicate source block: '+block_id)
            seen.add(block_id)
            text = fragment['source_text']
            entry = {'section_id': sid, 'source_block_id': block_id,
                     'source_page': fragment['page_number'], 'source_text': text,
                     'role': fragment['semantic_role'], 'type': fragment['block_type'],
                     'hide_during_heading_holds': timing[sid]['heading_holds']}
            if fragment['block_type'] in ('chapter_title', 'section_heading'):
                entry['layout'] = 'title'
                entry.pop('hide_during_heading_holds')
                entry['visible_during_heading_holds'] = timing[sid]['heading_holds']
                entry['pages'] = [{'text': text, 'char_start': 0, 'char_end': len(text)}]
            elif fragment['block_type'] == 'figure':
                entry['layout'] = 'source_figure_contain'
                entry['figure_selection'] = 'artifacts/revision-v4/source-figure-manifest.json'
                if not (PROJECT / entry['figure_selection']).is_file():
                    raise FileNotFoundError(entry['figure_selection'])
                selected = figures[block_id]
                if not (PROJECT / selected['asset']).is_file():
                    raise FileNotFoundError(selected['asset'])
                entry['asset'] = selected['asset']
                entry['asset_sha256'] = selected['sha256']
                entry['preserve_source_labels'] = True
                entry['display_start_ms'] = round(max(
                    [timing[sid]['start_seconds']] + [h['end_seconds'] for h in timing[sid]['heading_holds']])*1000)
                entry['display_end_ms'] = round(timing[sid]['end_seconds']*1000)
                entry['pages'] = []
            elif fragment['block_type'] == 'table':
                entry['layout'] = 'stable_table_with_row_highlight'
                entry['rows'] = table_rows(text)
                entry['row_timing'] = [exact_span(' '.join(row), alignment[sid]['words']) for row in entry['rows']]
                entry['cell_timing'] = []
                for row, span in zip(entry['rows'], entry['row_timing']):
                    row_words = alignment[sid]['words'][span['first_word_index']:span['last_word_index']+1] if span['status'] == 'whole_source_matched' else []
                    entry['cell_timing'].append([exact_span(cell, row_words) for cell in row])
                entry['pages'] = []
            else:
                entry['layout'] = 'compact_corner_panel'
                entry['pages'] = paginate(text)
                for page in entry['pages']:
                    page['timing'] = exact_span(page['text'], alignment[sid]['words'])
            blocks.append(entry)
    if seen != required:
        raise ValueError('Missing source blocks: '+str(sorted(required-seen)))
    problems = assign_panel_windows(blocks, timing)
    report = {'status': 'source_preserved_layout_and_listening_review_pending',
              'render_ready': False, 'required_blocks': len(required), 'mapped_blocks': len(seen),
              'timing_issues': problems, 'timing_match_method': 'whole-source contiguous token match to measured words',
              'sections': len(plan['sections']), 'blocks': blocks,
              'notes': ['Source slices rejoin exactly; no source summarization.',
                        'Full source matches derive read spans; display windows end at the next read page or section end. Listening and rendered layout QA still required.',
                        'Hide body panels during heading holds; title itself stays visible.',
                        'This artifact does not complete an upstream or rendering checkpoint.']}
    atomic_json(ROOT/'source-panel-plan.json', report)
    print(json.dumps({k:v for k,v in report.items() if k not in ('blocks','notes')}))


if __name__ == '__main__':
    main()
