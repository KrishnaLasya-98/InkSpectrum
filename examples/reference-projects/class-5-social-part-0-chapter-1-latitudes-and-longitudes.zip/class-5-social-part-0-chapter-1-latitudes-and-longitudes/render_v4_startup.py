"""One bounded, locked component render; never approves the final chapter."""
import json
import argparse
import hashlib
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from lib.production_runtime import atomic_json, run_logged

PROJECT = Path(__file__).resolve().parent
ROOT = PROJECT / 'artifacts/revision-v4'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--variant',choices=['precision-v4-production','precision-v4-production-linefix'],
                        default='precision-v4-production')
    args = parser.parse_args()
    media = PROJECT/'assets/video'/args.variant
    output = media/'videos/precision_v4/1080p30/StartUpActivity.mp4'
    python = Path('C:/Users/user/Miniconda3/envs/openmontage-maths-manim/python.exe')
    if not python.is_file():
        raise SystemExit('Existing isolated Manim environment unavailable')
    if output.exists():
        raise SystemExit('Preserving existing output; inspect it before any new render')
    if shutil.disk_usage(PROJECT).free < 10*1024**3:
        raise SystemExit('At least 10 GiB free space required on output/temp drive')
    lock = ROOT/'startup-render.lock'
    descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    os.close(descriptor)
    suffix = '-linefix' if args.variant.endswith('-linefix') else ''
    status_path = ROOT/f'startup-production{suffix}-render.json'
    state = {'state':'running','chapter_complete':False,'render_pid':None,
             'runner_pid':os.getpid(),'started_at':datetime.now(timezone.utc).isoformat(),
             'output':str(output),'timeout_seconds':1800,'quality_approved':False,
             'source_sha256':hashlib.sha256((PROJECT/'precision_v4.py').read_bytes()).hexdigest()}
    try:
        temporary = PROJECT/'artifacts/revision-v4/render-temp'
        temporary.mkdir(exist_ok=True)
        environment = os.environ.copy()
        environment.update(TEMP=str(temporary), TMP=str(temporary))
        command = [str(python),'-m','manim','-r','1920,1080','--fps','30',
                   '--renderer','cairo','--disable_caching','--media_dir',
                   str(media),
                   str(PROJECT/'precision_v4.py'),'StartUpActivity']
        def heartbeat(pid):
            state.update(render_pid=pid, heartbeat_at=datetime.now(timezone.utc).isoformat())
            atomic_json(status_path,state)
        result = run_logged(command,cwd=PROJECT,timeout=1800,env=environment,
                            log_dir=ROOT/f'startup-production{suffix}-logs',heartbeat=heartbeat)
        state.update(exit_code=result.returncode,finished_at=datetime.now(timezone.utc).isoformat(),
                     state='rendered_needs_qa' if result.returncode==0 and output.is_file() else 'failed')
        atomic_json(status_path,state)
        print(json.dumps(state))
        raise SystemExit(result.returncode or (0 if output.is_file() else 1))
    except Exception as exc:
        state.update(state='failed',error_type=type(exc).__name__)
        atomic_json(status_path,state)
        raise
    finally:
        lock.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
