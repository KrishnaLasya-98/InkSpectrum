"""Derive scoped visual cues and clean captions without resynthesizing speech.

This does not approve pronunciation or visual QA and never marks a checkpoint
complete. Original alignment is immutable; changes are documented in the audit.
"""
from copy import deepcopy
import json
import re
from pathlib import Path
import numpy as np
import soundfile as sf

from lib.production_runtime import atomic_json
from tools.analysis.narration_text_syncer import _build_word_captions, _ts

PROJECT = Path(__file__).resolve().parent
ROOT = PROJECT / 'artifacts/revision-v4'

# Each first spoken phrase starts the corresponding visual. Non-generated
# map views must use the source map and authored markers, never AI labels.
CUES = {
    's05-continents': [
        ('The Earth has seven continents', 'source-world-map', None),
        ('Asia the largest continent', 'source-map-asia', None),
        ("the world's highest mountain", 'everest', 'asia-everest-i2v-02.mp4'),
        ('and many different cultures', 'source-map-china-india', None),
        ('Africa is famous', 'sahara', 'africa-sahara-i2v-02.mp4'),
        ('and its wildlife', 'elephants-lions', 'africa-wildlife-02.mp4'),
        ('North America includes', 'source-map-north-america', None),
        ('with famous places', 'grand-canyon', 'grand-canyon-i2v-03.mp4'),
        ('Niagara Falls', 'niagara-falls', 'niagara-falls-i2v-03.mp4'),
        ('South America is known', 'amazon-rainforest', 'amazon-rainforest-i2v-03.mp4'),
        ('and the Andes Mountains', 'andes', 'andes-i2v-04.mp4'),
        ('Antarctica the coldest continent', 'antarctic-ice', 'antarctic-ice-i2v-05.mp4'),
        ('with no countries but many scientists', 'antarctic-researchers', 'antarctic-researchers-i2v-05.mp4'),
        ('Europe is home', 'source-map-europe', None),
        ('like the Eiffel Tower', 'eiffel-tower', 'eiffel-i2v-04.mp4'),
        ('and the Colosseum', 'colosseum', 'colosseum-i2v-04.mp4'),
        ('Australia the smallest continent', 'source-map-australia', None),
        ('is famous for its unique animals', 'kangaroos-koalas', 'australia-wildlife-02.mp4'),
        ('and its Great Barrier Reef', 'great-barrier-reef', 'great-barrier-reef-i2v-05.mp4'),
        ('It is the only continent', 'source-map-australia-island', None),
    ],
    's06-oceans': [
        ('The Earth has five major oceans', 'source-ocean-map', None),
        ('The Pacific Ocean', 'pacific-ocean', 'pacific-ocean-i2v-06.mp4'),
        ('stretching from Asia to the Americas', 'source-ocean-pacific-location', None),
        ('The Atlantic Ocean', 'source-ocean-atlantic-location', None),
        ('and it is known for its busy shipping routes', 'atlantic-shipping', 'atlantic-shipping-i2v-06.mp4'),
        ('The Indian Ocean', 'source-ocean-indian-location', None),
        ('and it is the warmest', 'indian-ocean', 'indian-ocean-i2v-06.mp4'),
        ('The Southern Ocean', 'source-ocean-antarctica-location', None),
        ('and is known for its cold waters', 'southern-ocean-ice-and-wind', 'southern-ocean-i2v-07.mp4'),
        ('The Arctic Ocean', 'source-ocean-arctic-location', None),
        ('and it is covered with ice', 'arctic-ocean-sea-ice', 'arctic-ocean-i2v-07.mp4'),
        ('These five oceans make up', 'source-ocean-area', None),
        ('travel trade and marine life', 'source-ocean-travel-and-trade', None),
        ('marine life', 'marine-life', 'ocean-marine-life-i2v-07.mp4'),
    ],
}


def lex(text):
    return re.sub(r'[^\w]+', '', text.casefold())


def phrase_index(words, phrase):
    target = [lex(token) for token in phrase.split()]
    source = [lex(word['word']) for word in words]
    hits = [i for i in range(len(source) - len(target) + 1)
            if source[i:i + len(target)] == target]
    if len(hits) != 1:
        raise ValueError(f'Cue must match exactly once: {phrase!r}: {hits}')
    return hits[0]


def caption_srt(segments):
    """Never extend captions across the four-second title pause."""
    groups = []
    for segment in segments:
        group = []
        for word in segment['words']:
            if group and (word['start_ms'] - group[-1]['end_ms'] > 700
                          or len(group) >= 10
                          or re.search(r'[.!?]$', group[-1]['word'])):
                groups.append(group)
                group = []
            group.append(word)
        if group:
            groups.append(group)
    lines = []
    for index, group in enumerate(groups):
        start = group[0]['start_ms']
        end = max(group[-1]['end_ms'], start + 200)
        if index + 1 < len(groups):
            end = min(end, groups[index + 1][0]['start_ms'])
        if end <= start:
            raise ValueError('Non-positive subtitle duration')
        text = [word['word'] for word in group]
        midpoint = (len(text) + 1) // 2
        body = ' '.join(text) if len(text) <= 7 else '\n'.join(
            (' '.join(text[:midpoint]), ' '.join(text[midpoint:])))
        lines.extend([str(index + 1), f'{_ts(start)} --> {_ts(end)}', body, ''])
    return '\n'.join(lines)


def main():
    read = lambda path: json.loads(path.read_text(encoding='utf-8'))
    raw = read(ROOT / 'alignment/narration_aligned.json')
    clean = deepcopy(raw)
    narration = read(ROOT / 'narration_manifest.json')['segments']
    plan = read(ROOT / 'educational_plan.json')['sections']
    figure_manifest = read(ROOT / 'source-figure-manifest.json')['figures']
    map_assets = {f['semantic_role']: f['asset'] for f in figure_manifest
                  if f['semantic_role'] in ('continent_map', 'ocean_map')}
    assert [s['section_id'] for s in plan] == [s['section_id'] for s in narration]
    assert [s['section_id'] for s in plan] == [s['section_id'] for s in clean['segments']]
    changes, failures, timing_notes, scenes, pause_evidence = [], [], [], [], []
    repairs_path=ROOT/'word-boundary-repairs.json'
    reviewed_repairs=read(repairs_path)['repairs'] if repairs_path.exists() else []
    for segment, voice, section in zip(clean['segments'], narration, plan):
        sid = segment['section_id']
        words = segment['words']
        source_tokens = [lex(x) for x in voice['text'].split()]
        if source_tokens != [lex(w['word']) for w in words]:
            failures.append({'section': sid, 'issue': 'source token mismatch'})
        for word in words:
            if ':.' in word['word']:
                changes.append({'section': sid, 'kind': 'display_punctuation',
                                'before': word['word'], 'after': word['word'].replace(':.', ':')})
                word['word'] = word['word'].replace(':.', ':')
        segment['text'] = segment['text'].replace(':.', ':')
        heading_tokens = len(voice.get('spoken_heading', '').split())
        body_ms = round((voice['start_seconds'] + voice['body_start_seconds']) * 1000)
        if heading_tokens:
            audio, rate = sf.read(voice['audio_path'])
            pause = audio[round(voice['heading_duration_seconds'] * rate):
                          round(voice['body_start_seconds'] * rate)]
            peak = float(np.max(np.abs(pause)))
            pause_evidence.append({'section': sid, 'duration_seconds': len(pause) / rate,
                                   'peak_amplitude': peak, 'threshold': 0.001})
            if peak >= 0.001:
                failures.append({'section': sid, 'issue': 'heading pause contains audible signal'})
            else:
                # Whisper sometimes stretches the first body word backwards
                # through known inserted silence. Clip only its silent prefix;
                # do not shift the section or invent new word durations.
                for word in words[heading_tokens:]:
                    if word['start_ms'] < body_ms:
                        if word['end_ms'] <= body_ms:
                            failures.append({'section': sid, 'issue': 'word lies wholly inside heading silence', 'word': word})
                        else:
                            changes.append({'section': sid, 'kind': 'verified_silent_prefix_trim',
                                            'word': word['word'], 'old_start_ms': word['start_ms'],
                                            'new_start_ms': body_ms, 'pause_peak_amplitude': peak})
                            word['start_ms'] = body_ms
        for left, right in zip(words, words[1:]):
            overlap = left['end_ms'] - right['start_ms']
            if overlap > 0:
                if overlap <= 80 and left['start_ms'] <= right['start_ms'] < right['end_ms']:
                    boundary = (left['end_ms'] + right['start_ms']) // 2
                    changes.append({'section': sid, 'kind': 'overlap_midpoint',
                                    'words': [left['word'], right['word']], 'overlap_ms': overlap,
                                    'new_boundary_ms': boundary})
                    left['end_ms'] = right['start_ms'] = boundary
                else:
                    failures.append({'section': sid, 'issue': 'large/non-monotonic overlap'})
        for repair in [r for r in reviewed_repairs if r['section']==sid]:
            matches=[w for w in words if w['word']==repair['word'] and
                     w['start_ms']==repair['old_start_ms'] and w['end_ms']==repair['old_end_ms']]
            if len(matches)!=1:
                raise ValueError('Reviewed boundary no longer matches input: '+repr(repair))
            matches[0].update(start_ms=repair['start_ms'],end_ms=repair['end_ms'])
            changes.append({'kind':'waveform_reviewed_boundary',**repair})
        if any(a['end_ms']>b['start_ms'] for a,b in zip(words,words[1:])):
            raise ValueError('Reviewed repair overlaps adjacent word')
        for word in words:
            if not segment['start_ms'] <= word['start_ms'] < word['end_ms'] <= segment['end_ms']:
                failures.append({'section': sid, 'issue': 'invalid word bounds', 'word': word})
            elif word['end_ms'] - word['start_ms'] < 80:
                timing_notes.append({'section': sid, 'issue': 'very short word requires listening review',
                                     'word': word, 'action': 'Check actual speech boundary before final encode'})
        if heading_tokens and len(words) > heading_tokens:
            observed = words[heading_tokens]['start_ms']
            if abs(observed - body_ms) > 100:
                timing_notes.append({'section': sid, 'issue': 'first body word vs measured body start',
                                     'delta_ms': observed - body_ms,
                                     'action': 'Listen/check waveform; do not blindly shift all captions'})
        holds = deepcopy(voice.get('heading_holds', []))
        if heading_tokens:
            holds.append({'title': section['title'],
                          'start_seconds': voice['heading_duration_seconds'],
                          'end_seconds': voice['body_start_seconds']})
        holds = [{**hold, 'start_seconds': round(hold['start_seconds'] + voice['start_seconds'], 3),
                  'end_seconds': round(hold['end_seconds'] + voice['start_seconds'], 3),
                  'show': 'title only; suppress panel and subtitle lane'} for hold in holds]
        visuals = []
        for cue, subject, file in CUES.get(sid, []):
            index = phrase_index(words, cue)
            source_map = subject.startswith('source-')
            asset = (map_assets['continent_map' if sid=='s05-continents' else 'ocean_map']
                     if source_map else f'assets/video/revision-v4/{file}' if file else None)
            visuals.append({'cue': cue, 'subject': subject, 'start_seconds': words[index]['start_ms'] / 1000,
                            'asset': asset,
                            'asset_status': ('source_figure_selected' if source_map else 'candidate')
                            if asset and (PROJECT/asset).is_file() else 'pending',
                            'reuse_allowed': source_map,
                            'reuse_reason': 'Persistent source teaching map, not replayed footage' if source_map else None})
        for i, visual in enumerate(visuals):
            visual['end_seconds'] = visuals[i + 1]['start_seconds'] if i + 1 < len(visuals) else voice['end_seconds']
            visual['duration_seconds'] = round(visual['end_seconds'] - visual['start_seconds'], 3)
            visual['continuous_motion_required'] = not visual['subject'].startswith('source-')
            visual['requires_additional_motion'] = bool(visual['continuous_motion_required'] and visual['duration_seconds'] > 5.062)
        scenes.append({'section_id': sid, 'title': section['title'],
                       'start_seconds': voice['start_seconds'], 'end_seconds': voice['end_seconds'],
                       'heading_holds': holds, 'source_block_ids': section['source_block_ids'],
                       'description': section['description'], 'visual_cues': visuals,
                       'coverage_status': 'incomplete; not approved for rendering'})
    if failures:
        atomic_json(ROOT / 'alignment-clean/qa.json', {'status': 'fail', 'failures': failures})
        raise SystemExit(json.dumps(failures))
    out = ROOT / 'alignment-clean'
    out.mkdir(exist_ok=True)
    clean['repairs'] = changes
    atomic_json(out / 'narration_aligned.json', clean)
    atomic_json(out / 'word_captions.json', _build_word_captions(clean['segments']))
    (out / 'formatted_subtitles.srt').write_text(caption_srt(clean['segments']), encoding='utf-8')
    report = {'structural_status': 'pass', 'word_count': sum(len(s['words']) for s in clean['segments']),
              'scope_sections': len(scenes), 'repairs': changes, 'timing_review_required': timing_notes,
              'heading_pause_waveform_evidence': pause_evidence,
              'listening_qa': 'pending', 'encoded_qa': 'not_rendered', 'chapter_complete': False}
    atomic_json(out / 'qa.json', report)
    atomic_json(ROOT / 'visual-cue-plan.json', {'timing_source': 'measured narration and faster_whisper words',
                'duration_seconds': narration[-1]['end_seconds'], 'render_ready': False, 'sections': scenes})
    print(json.dumps(report, ensure_ascii=True))


if __name__ == '__main__':
    main()
