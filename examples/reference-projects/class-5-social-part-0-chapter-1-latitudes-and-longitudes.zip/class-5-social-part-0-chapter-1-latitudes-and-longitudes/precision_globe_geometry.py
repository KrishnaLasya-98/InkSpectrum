"""Exact geographic-sphere geometry, independent of renderer and providers."""
import math


def point(latitude, longitude, radius=2.22):
    """Zero longitude faces the teaching camera; east is viewer-right."""
    lat, lon = math.radians(latitude), math.radians(longitude)
    return (radius*math.cos(lat)*math.sin(lon),
            -radius*math.cos(lat)*math.cos(lon), radius*math.sin(lat))


def visible_runs(points, phi=78, theta=-90):
    """Continuous visible curve portions for a fixed orthographic camera.

    Keep each connected run as one path to avoid false dashed-line seams.
    Camera parameters must agree with ThreeDScene orientation.
    """
    p, t = math.radians(phi), math.radians(theta)
    eye = (math.sin(p)*math.cos(t), math.sin(p)*math.sin(t), math.cos(p))
    runs, run = [], []
    for xyz in points:
        visible = sum(a*b for a,b in zip(xyz,eye)) >= -1e-9
        if visible:
            run.append(xyz)
        elif run:
            if len(run)>1:
                runs.append(run)
            run = []
    if len(run)>1:
        runs.append(run)
    return runs


def latitude_points(degrees):
    # East-to-west construction. Longitude starts at the rear seam.
    return [point(degrees,180-i*.5) for i in range(721)]


def longitude_points(degrees):
    return [point(90-i*.5,degrees) for i in range(361)]
