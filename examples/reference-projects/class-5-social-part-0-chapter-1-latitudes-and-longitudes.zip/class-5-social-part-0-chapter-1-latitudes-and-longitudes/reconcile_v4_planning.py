"""Reconcile this chapter's approved scope without regenerating audio or media."""
from copy import deepcopy
import json
from pathlib import Path

from lib.production_runtime import atomic_json
from schemas.artifacts import validate_artifact
from tools.analysis.educational_media_research_planner import build_media_research_plan
from tools.structure.educational_production_artifacts import build_production_artifacts
from tools.structure.educational_run_tracker import EducationalRunTracker


def main():
    project = Path(__file__).resolve().parent
    root = project / 'artifacts/revision-v4'
    read = lambda name: json.loads((root / name).read_text(encoding='utf-8'))
    plan = read('educational_plan.json')
    narration = read('narration_manifest.json')
    scope = read('scope_audit.json')
    config = json.loads((project / 'chapter_config.json').read_text(encoding='utf-8'))
    ids = [section['section_id'] for section in plan['sections']]
    if ids != scope['included_section_ids']:
        raise ValueError('Plan differs from the user-approved section sequence')
    if ids != [segment['section_id'] for segment in narration['segments']]:
        raise ValueError('Narration differs from the approved section sequence')
    measured = deepcopy(plan)
    cursor = 0.0
    for section, segment in zip(measured['sections'], narration['segments']):
        if abs(segment['start_seconds'] - cursor) > .002:
            raise ValueError('Narration contains a section gap or overlap')
        if not Path(segment['audio_path']).is_file():
            raise ValueError(f"Missing narration for {section['section_id']}")
        section['duration_seconds'] = segment['duration_seconds']
        cursor += segment['duration_seconds']
    measured['total_duration_seconds'] = cursor
    artifacts = build_production_artifacts(config, measured)
    scenes = artifacts['scene_plan']
    for scene, section in zip(scenes['scenes'], measured['sections']):
        figures = [f for f in section.get('source_fragments', [])
                   if f.get('block_type') == 'figure']
        scene['overlay_notes'] = (
            '6x6 grid: section tag A1-A2; compact source panel A5-C6; '
            'main visual A1-E4; subtitle lane F1-F6. '
            'Hide body panels during the four-second spoken-heading hold. '
            'Paginate verbatim text at narration cues; never shrink long paragraphs to fit.'
        )
        scene['required_assets'] = [{
            'type': 'video' if scene['render_mode'] == 'video_gen' else 'animation',
            'description': scene['description'],
            'source': 'generate',
        }]
        for figure in figures:
            scene['required_assets'].append({
                'type': 'source_figure', 'source': 'provided',
                'description': f"PDF block {figure['block_id']}: {figure['source_text']}",
            })
        if figures and scene['render_mode'] == 'hyperframes':
            scene['type'] = 'diagram'
        scene['movement'] = (
            'Unique topic-matched 3D motion shots; cut on aligned concept cues. No loops.'
            if scene['render_mode'] == 'video_gen' else
            'Author precise reveals and active-row highlights from aligned narration.'
        )
    scenes['metadata'].update({
        'scope_revision': 'v4', 'timing_authority': 'measured_narration',
        'duration_seconds': round(cursor, 3),
        'shot_level_media_coverage_status': 'incomplete',
    })
    research = build_media_research_plan(config['subject'], scenes['scenes'])
    for item, scene in zip(research['scenes'], scenes['scenes']):
        item.update({
            'recommended_treatment': 'source_figures_and_fresh_3d_animation',
            'search_required': False, 'queries': [], 'preferred_sources': [],
            'fallback_strategy': 'stop_for_missing_approved_media',
            'rationale': ('User explicitly selected fresh 3D animation, not documentary stock. '
                          'Use the supplied PDF for exact maps, labels, tables and factual coverage; '
                          'generated footage is illustrative, not geographic evidence.'),
            'selection_status': 'not_required',
        })
    research['search_scene_count'] = 0
    research['selection_policy']['user_approved_media_policy'] = 'fresh_3d_and_source_figures'
    for name, data in [('scene_plan', scenes), ('media_research_plan', research),
                       ('asset_strategy', artifacts['asset_strategy']),
                       ('asset_manifest', artifacts['asset_manifest'])]:
        validate_artifact(name, data)
    atomic_json(root / 'scene_plan.json', scenes)
    atomic_json(root / 'media_research_plan.json', research)
    atomic_json(root / 'asset_strategy.json', artifacts['asset_strategy'])
    # This remains a planned manifest; never represent it as acquired media.
    atomic_json(root / 'asset_manifest.planned.json', artifacts['asset_manifest'])
    tracker = EducationalRunTracker(project, title=config['title'],
                                    approval_policy=config['approval_policy'])
    tracker.begin('scene_plan', metadata={'scope_revision': 'v4'})
    tracker.finish('scene_plan', {'scene_plan': scenes},
                   metadata={'scope_revision': 'v4', 'measured_duration_seconds': cursor})
    tracker.begin('media_research', metadata={'scope_revision': 'v4'})
    tracker.finish('media_research', {'media_research_plan': research},
                   metadata={'stock_search_skipped_by_user_policy': True})
    tracker.begin('assets', metadata={'scope_revision': 'v4'})
    tracker.progress('assets', partial_progress={
        'planned_manifest_path': str(root / 'asset_manifest.planned.json'),
        'motion_qa_path': str(root / 'motion-qa-progress.json'),
        'all_required_assets_acquired': False,
        'next_action': 'Complete cue-level unique motion coverage and precise source diagrams.',
    })
    print(json.dumps({'scene_count': len(scenes['scenes']),
                      'duration_seconds': round(cursor, 3),
                      'scene_plan': 'completed', 'media_research': 'completed',
                      'assets': 'in_progress', 'chapter_complete': False}))


if __name__ == '__main__':
    main()
