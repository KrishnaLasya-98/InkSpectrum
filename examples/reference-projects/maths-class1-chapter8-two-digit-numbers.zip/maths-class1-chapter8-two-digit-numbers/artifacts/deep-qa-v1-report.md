# Maths Class 1 Chapter 8 — encoded v1 deep QA

Audit date: 2026-09-24  
Audited render: `hyperframes-final/renders/maths-class1-chapter8-two-digit-numbers-final-v1.mp4`  
Authoritative content: `RPS - MATHS - CLASS 1 - INDIVIDUAL - B (2026) PRINTFILE-pages-2.pdf`  
Authoritative appearance: English Class 1 `english-class1-at-the-beach-final-v7.mp4`

## Evidence and limits

- Machine QA decoded all 15,249 encoded frames. The file is 508.300 s, 1920×1080, 30 fps, H.264 with AAC stereo at 48 kHz. No black interval was detected.
- Audio waveform comparison found every section at its intended encoded start with correlation 0.95–1.00 and 0.00 s measured offset. This confirms placement of the audio files, not semantic synchronization with the displayed visual state.
- Visual judgment used all 509 one-second samples, organized into 21 contact sheets, plus full-resolution boundary/evidence frames and all 16 rendered PDF source pages. It is a dense visual audit, not a claim that a human watched each of the 15,249 frames individually.
- Machine artifacts: `D:/InkSpectrum/OpenMontage/.tmp/maths-v1-deep-audit/technical/encoded-qa.json` and `D:/InkSpectrum/OpenMontage/.tmp/maths-v1-deep-audit/maths-1fps/`.
- Exact evidence frames: `D:/InkSpectrum/OpenMontage/.tmp/maths-v1-deep-audit/exact/`.

## Release decision

**FAIL — do not treat v1 as final.** Content omissions and false answer-reveal states make the lesson educationally incomplete. The composition also does not follow the English-v7-only visual language requested by the user.

## Severity-ranked defects

### Critical

1. **Opening loses its story footage after five seconds.** At 00:01.2 the animated number garden is visible, but the footage ends at 00:05.067. From approximately 00:05.1 to 00:25.6, the rest of S01 is a mostly empty pale canvas with a static generic card. Machine QA identifies repeated story freezes at 00:05.066–00:25.600. Correction: provide continuous, semantically matched story footage for the complete opening narration and use the English-v7 overlay hierarchy over it.

2. **Subtitles omit punctuation and show no reliable active-word colour.** At 00:01.2 the caption reads `Hello young mathematicians Are you ready for`; at 00:06.5 it reads `Welcome to Class one Mathematics Chapter eight`. The expected punctuation is absent and every word appears dark/grey rather than one current word being highlighted. Correction: render punctuated display tokens while preserving measured word timings, and test the active state in the encoded output rather than only in browser data.

3. **S09 promises an answer check but never reveals answers (00:212.712–236.430).** At 00:233.0, while the narration says “Now check your numerals on the screen,” all 12 answer lines remain blank. Correction: show the source prompts first, then reveal all 12 correct numerals at the narrated cue.

4. **S10 promises animated matching lines but none appear (00:236.830–252.544).** At 00:250.5, no connected/revealed state is present. Correction: preserve the source’s shuffled columns and animate each of the five correct links or use a clearly staged paired-answer reveal.

5. **S11 promises a reveal but remains blank (00:252.944–279.988).** At 00:277.0 all 16 one-more/one-less fields are blank during the spoken comparison/reveal. Correction: paginate if needed and display every answer only at the answer-check cue.

6. **S12 clips source questions and never reveals the answers (00:280.388–310.805).** At 00:307.5 only 24 of 27 prompts are visible; `10 → ?`, `? → 19`, and `59 · ? · 61` fall below the panel. All visible fields remain blank during the promised answer check. Correction: paginate into readable pages; do not shrink or clip; show a timed reveal for all 27 answers.

7. **S07 does not reproduce the two source exercises (00:156.230–186.115; PDF p. 8/textbook p. 14).** It only shows a filled 1–100 grid with some givens styled differently. It omits the separate 51–100 five-column chart and fails to present the source missing-number chart as actual blanks followed by answers. Correction: present both charts as distinct paginated states. Exact source givens are 1, 3, 8, 20, 25, 32, 44, 56, 60, 63, 78, 81, 97, 100.

8. **S08 claims the complete chart but shows only nine examples (00:186.515–212.312; PDF p. 9/textbook p. 15).** The source contains numeral/name pairs 1–100; the video shows only 21, 32, 44, 56, 68, 75, 82, 99, and 100. Correction: paginate the full 1–100 source chart at a Class 1 readable size.

9. **S13/S14 omit the required recorded answer rows.** S13 (00:311.205–332.416) marks evens in the chart but omits “Now, write all the crossed numbers here.” S14 (00:332.816–364.019) marks multiples of 3 and 4 but omits both separate source rows that record the crossed and ticked numbers. Correction: preserve the chart interaction and add paginated written-result rows with timed completion.

10. **S15 omits four of nine source sequences and destroys exercise state (00:364.419–395.745; PDF p. 14/textbook p. 20).** At 00:393.0 only five already-completed rows are displayed. Missing rows are by-5 `[40…90]`, by-5 `[38…88]`, by-10 `[5…95]`, and by-10 `[9…99]`. Correction: show all nine rows; keep only source-given cells filled initially; reveal blank cells at the narrated cue.

11. **S17 conflates two activities and omits three matching numerals (00:423.963–454.725; PDF p. 15/textbook p. 21).** At 00:442.0, the screen contains only 52, 75, 39, 44, 61, 72, and 67. It omits 43, 16, and 54 and never presents the source’s shuffled three-column Brain Gym matching task. Correction: separate the five write-tens/ones questions from the five-item three-column match, preserving printed display order before revealing correct mappings.

12. **S19 changes the meaning of the source manipulative (00:477.978–507.887).** At 00:503.0 each blue bindi is drawn as a ten-dot rod. The source rule is one blue bindi/circle = one ten, not ten blue dots = one ten. All four results are also visible before the spoken build sequence. Correction: use a single blue circle per ten and a single yellow circle per one; build 54, 63, 75, and 82 progressively.

### High

13. **S16 narration and visual example disagree (00:396.145–423.563).** Around 00:400–406 the Manim insertion shows 68 (six tens and eight ones) while narration introduces place value and then names 12 as one ten and two ones. Correction: visually stage 12 when 12 is spoken, then 35, 68, 94, and 27 in source order.

14. **Most teaching sections are static cards rather than the requested English-v7 story template.** Brief motion appears at S03 00:47.35–52.42, S05 00:89.76–94.82, S06 00:115.96–121.03, S07 00:156.23–158.23, and S11 00:252.94–258.01; the remaining time is dominated by generic pale panels. Correction: retain full-frame child-friendly motion/illustration continuity and overlay compact cream textbook panels, matching English v7’s visual hierarchy.

15. **Large panels waste most of the frame and reduce mathematical readability.** S03–S08 place small cards or tiny rows at the panel top while leaving a large dead area. This is not equivalent to the English reference’s full-frame visual with compact, purposeful overlays. Correction: use page-level pagination and larger instructional elements; do not solve density by shrinking.

16. **Named numbers are not synchronized to visual state changes.** In S03–S06, narration advances through individual constructions while the same set of tiny cards remains on screen. Correction: highlight or build exactly the number currently spoken, then move to the next example.

### Medium / technical

17. **Encoded visual quality is lower than the English reference.** Approximate math video bitrate is 990 kb/s versus approximately 1,729 kb/s for English v7. Correction: use the same production-quality encode profile after content and layout are fixed.

18. **Static teaching sections are not flagged by the existing freeze gate.** The automated freeze failure only covers S01, although dense visual review shows prolonged static states elsewhere. Correction: extend motion QA to all narrative/teaching sections while allowing intentionally static exercise thinking time.

## Source-coverage matrix

| Section | Source | Required source state | v1 status |
|---|---|---|---|
| S02 | PDF 1 / book 7 | Recall text; groups 5–9 tens | Present, but static |
| S03–S04 | PDF 2–3 / book 8–9 | Every construction 51–60 | Numerically present; no spoken-number state sync |
| S05 | PDF 4–5 / book 10–11 | Every construction 61–70 | Present; no spoken-number state sync |
| S06 | PDF 6–7 / book 12–13 | Source-selected 71,75,80,81,85,90,91,95,99,100 | Present; no spoken-number state sync |
| S07 | PDF 8 / book 14 | 51–100 chart; missing-number 1–100 chart | **Incomplete / wrong state** |
| S08 | PDF 9 / book 15 | All numeral/name pairs 1–100 | **Only 9 shown** |
| S09 | PDF 10 / book 16 | 12 write-the-numeral items + reveal | Prompts present; **answers never reveal** |
| S10 | PDF 10 / book 16 | 5 shuffled matching items + links | Items present; **links never reveal** |
| S11 | PDF 10–11 / book 16–17 | 16 one-more/one-less items + reveal | Prompts present; **answers never reveal** |
| S12 | PDF 11 / book 17 | 27 after/before/between items + reveal | **3 clipped; no answers reveal** |
| S13 | PDF 12 / book 18 | Cross evens; write crossed-number row | Chart present; **record row omitted** |
| S14 | PDF 13 / book 19 | Cross multiples of 3; tick multiples of 4; record both rows | Chart present; **both record rows omitted** |
| S15 | PDF 14 / book 20 | 9 partial skip-count rows + reveal | **4 rows omitted; blanks prefilled** |
| S16 | PDF 14 / book 20 | Place-value definition; 12,35,68,94,27 | Present; **Manim state mismatched** |
| S17 | PDF 15 / book 21 | 5 expanded-form questions; separate 5-item 3-column match | **Conflated; 43,16,54 omitted** |
| S18 | PDF 16 / book 22 | Four partial rows with source givens + reveal | Values present; **all prefilled from start** |
| S19 | PDF 16 / book 22 | 1 blue bindi=1 ten; 1 yellow bindi=1 one; build 54,63,75,82 | **Manipulative representation wrong; all prefilled** |

## Required implementation data

The source-grounded, machine-readable replacement dataset is `artifacts/source_content_v2.json`. It includes exact page references, S02–S06 constructions, both S07 charts, all 100 number names, all S09–S12 exercise items and answers, S13/S14 chart and written-result lists, all nine S15 rows with zero-based given indices, all five S16 examples, separate S17 practice/matching structures, S18 givens, and the corrected S19 bindi key.

Validation: `python -m pytest tests/test_source_content_v2.py -q` → **9 passed**.

## Acceptance gates for the replacement render

1. Every source item in `source_content_v2.json` is visible at readable size; dense exercises are paginated.
2. Exercise screens first show only source givens/blanks, then visibly reveal answers at the matching narration cue.
3. When narration names a number or operation, that exact visual state is active.
4. All captions retain punctuation and show exactly one active spoken word in the approved highlight colour.
5. Full-frame visual continuity and compact textbook overlays match English v7; no empty pale-canvas story intervals remain.
6. Encoded-output QA is repeated on the final MP4, including frame decode, A/V offset, active-word sampling, page coverage, answer-state checks, and freeze checks across all teaching sections.
