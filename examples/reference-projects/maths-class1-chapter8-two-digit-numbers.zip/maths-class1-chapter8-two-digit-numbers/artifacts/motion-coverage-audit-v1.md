# Motion coverage audit - rendered v1

Video audited: `hyperframes-final/renders/maths-class1-chapter8-two-digit-numbers-final-v1.mp4`

Status: **failed - motion and semantic precision fixes required**

## Required-motion sections

| Section | Spoken interval | Authored motion interval(s) | Coverage | Finding |
| --- | ---: | ---: | ---: | --- |
| S01 - opening story | 0.0000-25.8556 | M01R 0.0000-5.0667 | 19.6% | Critical: 20.7889 s remain on a mostly static title canvas. Encoded freeze detection reports 11 spans from 5.0667 to 25.6000. |
| S02 - groups of ten | 26.2556-46.9500 | none | 0.0% | High: explanation uses only the teaching panel; no 3D object motion. |
| S03 - 51 to 55 | 47.3500-68.1356 | M02 47.3500-52.4167 | 24.4% | High: 15.7189 s of the explanation lack 3D object motion. |
| S04 - 56 to 60 | 68.5356-89.3565 | none | 0.0% | High: the regrouping-to-sixty explanation has no 3D object motion. |
| S05 - 61 to 70 | 89.7565-115.5648 | M03 89.7565-94.8232 | 19.6% | High: 20.7416 s of the explanation lack 3D object motion. |
| S06 - 71 to 100 | 115.9648-155.8297 | M04R 115.9648-121.0315 | 12.7% | High: 34.7982 s of the explanation lack 3D object motion. |
| S16 - expanded form | 396.1447-423.5633 | M08 396.1447-398.9447; P04 399.8756-407.5756 | 38.3% | Critical: P04 is semantically mistimed and 16.9186 s remain without precision motion. |

Stable chart, practice, and exercise sections are not failed merely for being static; they remain subject to subtitle and reveal QA.

## Precision-animation timing

| Clip | Authored interval | Spoken evidence | Result |
| --- | ---: | --- | --- |
| P01 - count by 2 | 314.4602-321.3602 | S13-02 is 314.4602-321.3492 | Pass; 0.0110 s tail only. |
| P02 - count by 3 and 4 | 333.0158-354.2158 | S14-03 continues to 356.1694 | Fail; the exact shared-twelve highlight disappears 1.9536 s before the phrase ends. Add approximately 2.0 s final hold. |
| P03 - count by 5 and 10 | 364.6190-389.8190 | S15-01 through S15-04 end at 389.8649 | Pass; 0.0459 s early exit is covered by the stable source-grounded UI. |
| P04 - place value | 399.8756-407.5756 | S16-03 says 12 from 404.4579-409.9740; 68 begins at 413.3140 | Critical fail; the clip displays 68 while the narration teaches 12. Replace with a deterministic 12, 35, 68, 94, 27 sequence aligned to S16-03 through S16-05. |

## Intro continuation status

- M01C1 is generated and visually accepted: 5.0625 s, 832x464, H.264, continuous motion, stable characters/environment, no malformed tail.
- Continuity seed: the actual final frame of accepted M01R.
- Provider receipt: `artifacts/provider-jobs-wan22/M01C1.json`.
- M01C2 was submitted immediately before the audit pause instruction arrived; local polling was terminated and no output or receipt was written. M01C3 and M01C4 were not submitted.
- Four approximately 5.06 s continuations after M01R provide about 25.32 s total raw motion. With short bounded crossfades, the final continuation requires a small safe tail hold or approximately 0.54 s of gentle retiming to reach S01 end at 25.8556 s; no loop or replay is permitted.

## Encoded evidence

- Intro 1 fps sheet: `output/encoded-qa/maths-final-v1/intro-1fps.jpg`
- Complete rendered contact sheets: `output/encoded-qa/maths-final-v1/frames/contact-sheet-01.jpg` and `contact-sheet-02.jpg`
- Full-frame decode log: `output/encoded-qa/maths-final-v1/frame-decode.log`
- Technical QA: 15,249 frames decoded, no black intervals, and all 19 narration sections aligned within 0.00044 s.

