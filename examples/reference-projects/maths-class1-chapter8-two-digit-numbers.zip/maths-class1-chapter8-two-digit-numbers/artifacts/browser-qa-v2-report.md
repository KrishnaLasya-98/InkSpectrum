# Maths v2 browser/DOM QA

Audit date: 2026-09-24  
Method: Playwright CLI, 1920×1080 viewport, deterministic GSAP timeline seeks  
Candidate duration: 517.8694 seconds

## Automated results

- 19/19 sections instantiated.
- 25/25 scheduled visual pages/states present: 3 intro states plus 22 exercise/teaching pages.
- All required source DOM counts pass: S07 charts 50 and 100 cells; S08 50+50 name pairs; S09 12 rows; S10 10 items/5 links; S11 16 rows; S12 27 rows; S15 9 rows; S16 5 rows; S17 5 practice rows/15 matching items/10 links; S18 4 rows; S19 4 cards with 26 blue and 14 yellow bindis.
- Exact recorded-number rows pass: S13 contains all 50 multiples of 2; S14 contains all 33 multiples of 3 and all 25 multiples of 4.
- Numeral-to-number-name minimum measured gap is 12 px.
- Zero unresolved narration cue mappings.
- 898/898 word midpoints pass: one expected active span, white active text, `#9f3528` active background, inactive neighbours `#425f6c`, and all word boxes inside the caption lane and canvas.
- The full deterministic state pass sampled all section starts, UI pages, page boundaries, reveal boundaries, and caption midpoints. After accounting for the three intentional intro pseudo-pages, it reports no empty visual state, missing page, clipping, source-count, reveal, or caption failures.

Machine-readable reports:

- `output/playwright/maths-v2-dom-qa/browser-dom-inventory-qa.json`
- `output/playwright/maths-v2-dom-qa/browser-dom-qa.json`

## Human visual review

The intro title, exact 51–100 range, source Recall card, S17 Brain Gym matching, and P01/P02/P04 precision states are visually coherent and readable. Evidence: `output/playwright/maths-v2-final-incremental/contact-key-8.jpg`.

The initial v2 candidate had one pre-render blocker: decorative non-intro story clips appeared only around the outside of opaque teaching cards, then ended after roughly 2–5 seconds. The rich 3D edge/background abruptly changed to the pale paper background while the instructional card remained unchanged. This recreated the user's reported “patchwork” effect.

Evidence: `output/playwright/maths-v2-final-incremental/contact-story-boundaries.jpg` at:

- S03: 52.35 → 52.45 seconds
- S05: 94.75 → 94.90 seconds
- S06: 120.95 → 121.10 seconds
- S11: 257.80 → 258.00 seconds

Resolution: the final browser candidate retains the two continuous intro clips and the source-grounded HTML/Manim teaching states, while removing non-intro decorative story layers `m02`, `m03`, `m04r`, `m05`, `m06`, `m07`, and `m08`. The English-v7 paper UI therefore remains stable throughout teaching sections.

## Final true-Range media gate

The final candidate was served from the verified Range-capable Node preview at `127.0.0.1:3110`. Every checked `video.currentTime` matched its requested source-relative target to less than 1 ms; seek timeout or mismatch is a hard QA failure.

- `MATHS_QA.missingCues`: 0
- `MATHS_QA.buildCues`: 44
- P01: 2, 4, 6, 8, and 10 are highlighted exactly at their measured spoken-word midpoints.
- P02: 3, 6, 9, 12, and 15; then 4, 8, 12, 16, and 20 are highlighted exactly at their measured spoken-word midpoints.
- The shared 12 is highlighted in both rows during the spoken shared-multiple explanation.
- P04 at 420.000 seconds displays 68 = 60 + 8 while the caption speaks that exact example.

Evidence: `output/playwright/maths-v2-final-cues/contact-all-cues.jpg` and `output/playwright/maths-v2-range-final/contact-range-verified.jpg`.

**Browser/pre-render decision: PASS. Approved for final encode.** Encoded-output QA remains mandatory after rendering.
