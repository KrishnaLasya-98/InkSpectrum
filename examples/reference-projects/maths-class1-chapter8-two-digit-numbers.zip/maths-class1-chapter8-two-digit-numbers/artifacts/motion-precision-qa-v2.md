# Motion and Precision Media QA v2

Status: accepted for HyperFrames integration on 2026-09-24.

## Intro motion schedule

The accepted 3D story footage ends at 9.9464 seconds. HyperFrames must bridge 9.9464-14.4054 with continuously animated Maths precision UI while retaining the class/chapter title, then transition to the source-grounded Recall card for S01-03.

| Cue | Timeline | Usable duration | QA result | Normalized file |
| --- | ---: | ---: | --- | --- |
| M01R | 0.0000-5.0667 | 5.0667 s | Accepted replacement opening | `assets/video/normalized/m01-number-adventure-v2.mp4` |
| M01C1 | 5.0667-9.9464 | 4.8797 s | Accepted clean interval, ending before the precision-UI bridge | `assets/video/normalized/m01-continuation-01.mp4` |

Evidence: `artifacts/intro-final-qa/` and `artifacts/m01-continuation-01-contact.jpg`.

Rejected material remains excluded:

- M01: original defective-tail clip; rejected and never used.
- M01C2: rejected in full; successive attempts produced malformed numerals or changed the boy's appearance.
- M01C3: the girl disappears, the boy runs away from the established action, and foreground numerals deform.
- M01C4: not generated after the approved short-intro policy.
- M01H: deterministic still-frame camera motion is excluded because it is not real 3D animated footage.

## Precision animation schedule

The schedule is derived from `assets/audio/narration-qwen-v1/narration_manifest.json` with SHA-256 `8f63e43e709eec064e45041055b6969da5a448e288b16e4cba4249bd95ea4976`.

| Cue | Timeline | Narration binding | QA result | File |
| --- | ---: | --- | --- | --- |
| P01 | 317.3431-324.2321 | S13-02 | Accepted; 2 pulses at every spoken `two`, then 4, 6, 8, 10 at measured word onsets | `assets/video/precision-v2/skip-count-by-2-v2.mp4` |
| P02 | 335.8986-359.0522 | S14-01 through S14-03 | Accepted; by-3 and by-4 value highlights occur at measured word onsets, with shared-12 emphasis | `assets/video/precision-v2/skip-count-by-3-and-4-v2.mp4` |
| P04 | 409.6408-427.4461 | S16-03 through S16-05 | Accepted; exact 12, 35, 68, 94, 27 sequence | `assets/video/precision-v2/place-value-expanded-form-v2.mp4` |
| P03 | excluded | S15 | Exercise has nine source rows; use synchronized HTML rows to avoid obstruction | n/a |

P04 local state changes are bound to word onsets: 12 at 0.0000, 35 at 6.5161, 68 at 9.3792, 94 at 12.5992, and 27 at 15.5992 seconds. States use clean cuts so two equations never overlap. The redundant generated subtitle was removed, singular grammar is `1 ten`, the title has a safe margin, and source text is at least 62 px in the 1920x1080 clip before inset scaling.

Evidence:

- `artifacts/precision-v2-qa/p01-contact.jpg`
- `artifacts/precision-v2-qa/p02-contact.jpg`
- `artifacts/precision-v2-qa/p04-contact-final.jpg`
- `artifacts/precision-v2-qa/word-cues/p01-word-cues.jpg`
- `artifacts/precision-v2-qa/word-cues/p02-word-cues.jpg`

## Technical checks

All accepted files are silent H.264, 1920x1080, yuv420p, 30 fps, with a 30-frame GOP and fast-start metadata. `artifacts/precision-media.json` is version 2.0, records the narration-manifest hash, and marks only independently reviewed cues accepted.
