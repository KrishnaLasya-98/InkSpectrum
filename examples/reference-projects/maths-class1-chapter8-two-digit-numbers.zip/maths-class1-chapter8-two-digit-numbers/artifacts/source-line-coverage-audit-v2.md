# Source line coverage audit - final-v2

Status: **not approved for delivery**. The numeric datasets are complete, but the video does not yet preserve all textbook lines and exercise states.

## Delivery blockers

1. **PDF page 1 / textbook page 7 / 14.405-25.856 s:** the second Recall bullet is missing: “We know that by adding 1, 2, 3 ..., 10 to a number, we get the next ten numbers.”
2. **PDF page 1 / S01-S02:** the two-line transition is not retained: “To start making numbers from 51-100,” and “Let us first make groups of ten.” Only the second line is currently spoken.
3. **PDF page 1:** the “Spiral Learning” label is absent, and “Concepts of Skip counting, Expanded form” is shortened to “Skip counting · Expanded form.”
4. **PDF page 8 / 155.517-185.998 s:** both chart instructions are absent from the persistent content UI: “Let us put together numbers 51-100.” and “Recall and fill in the missing numbers from 1-100.”
5. **PDF page 12 / 314.088-335.299 s:** the source record exercise is not preserved. The complete instruction and “Now, write all the crossed numbers here” label are reduced, and the initial 2, 4, 6, 8 + blank-cells state never appears.
6. **PDF page 13 / 335.699-366.902 s:** the complete by-three/by-four instruction and both record labels are reduced. The two initial partially filled rows never appear before the completed lists.
7. **PDF page 16 / 487.561-517.469 s:** the activity setup is mostly omitted: two packets of bindis, the blue/yellow sentence, “Now make these numbers using these circles,” “Ex:”, and the unsolved prompt state. All four solutions are visible from the start.

## Additional exact-text defects

- **PDF pages 2-7 / 47.350-155.117 s:** source headings are shortened/split. Every active construction needs its printed result name beside the equation; names currently exist only in subtitles.
- **PDF page 9 / 186.398-212.195 s:** use the source heading “Number names 1-100.” Pagination can remain secondary.
- **PDF pages 10-11 / 252.827-279.870 s:** all 16 one-more/one-less rows omit the source word “is” before the answer box.
- **PDF page 14 / 367.302-400.928 s:** use “Count by fives...” and “Count by tens...” instead of numeric shorthand in the source headings.
- **PDF page 14 / 401.328-428.746 s:** both place-value definition lines are only spoken, not retained in the content card; the source table headers Number, Tens, Ones, Expanded Form are also absent.

The machine-readable correction map is in `source-line-coverage-audit-v2.json`. Dataset verification remains green: all constructions, charts, number names, questions, sequences, matching maps, expanded-form rows, and circle quantities are present and mathematically correct. Four known PDF typos are intentionally corrected rather than reproduced.
