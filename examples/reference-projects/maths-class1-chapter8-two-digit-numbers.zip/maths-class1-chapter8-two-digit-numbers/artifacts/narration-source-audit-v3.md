# Maths Chapter 8: targeted narration source audit

**Current status: final source-preserving v3 narration and encoded render passed QA.** The earlier 546.0051-second sticker revision was provisional. The delivered bindis candidate has a 543.6125-second audio timeline and an independently checked 543.6333-second encoded MP4.

The encoded v2 draft passes audio-identity/placement QA, but it is not source-complete. This audit compares all 85 existing narration phrases with `source/extracted.txt`, focusing on explanatory sentences and exercise instructions rather than speaking every cell in the 1–100 charts. PDF visual layout verification is a separate task.

## Approved v3 narration changes

| Source evidence | Finding | Targeted action |
|---|---|---|
| PDF page 1, extracted lines 10 onward: Spiral Learning and introductory concepts | The original heading and source concept list were replaced by a generic adventure summary. | Replace S01-03/04 with the original Spiral Learning concepts. Keep greeting and subject/class/chapter introduction. |
| Page 1, lines 5–7: both Recall statements | First statement was paraphrased; second statement about adding 1 through 10 was absent. | Add S01-05/06 with both statements and 1.2-second pauses. |
| Page 1, lines 8–9 | Group-of-ten instruction omitted its explicit 51–100 range. | Replace S02-01 with the full instruction. |
| Page 13, lines 1064 and 1069 | Crossed and ticked result-list instructions were compressed into a general 'correct rows' instruction. | Replace S14-04 with two distinct recording instructions. Correct source typo 'ticketed' to 'ticked'. |
| Page 14, skip-by-five rows | The added claim that ones digits repeat five/zero was unqualified; source also has rows starting at 6 and 38. | S15-02 now qualifies the statement with 'In this row'. |
| Page 14, lines 1230–1231 | First place-value sentence is already present exactly. Second uses 'places' rather than source 'place values'. | Preserve S16-01; restore 'place values' in S16-02. |
| Page 16, lines 1373–1377 | Generic circles replaced the source material: two packets of bindis in blue and yellow. | Replace S19-01/02 with bindi materials, tens/ones meaning, and the instruction to make numbers with these circles. |

S13-04 and S14-04 receive five-second review pauses so learners can inspect their recorded-number answers. Existing S12, S15, and S17 review holds remain unchanged.

## Covered content that does not require wholesale voice regeneration

- Number-construction ranges 51–60, 61–70, and 71–100 are covered across S03–S06; range headings should match the textbook on screen.
- Missing-number chart, numeral writing, numeral/name matching, one more/less, and before/after/between instructions are present in equivalent child-friendly wording.
- Skip counting by 2, 3, 4, 5, and 10 and the separate crossed/ticked patterns are covered.
- Place value, expanded-form examples, matching expanded forms, all four final skip-counting rows, and the four circle-activity numbers are covered.
- The current 51–100 UI remains row-major; S07-02's 'read each row from left to right' therefore matches it. Restoring a column-major source arrangement would require revisiting that instruction.
- Heading and box omissions must be corrected in the composition independently of narration. Equivalent spoken instructions do not prove that the corresponding textbook box appears on screen.

## Isolation and QA contract

`scripts/prepare_narration_v3.py` creates `artifacts/narration_script_v3.json` and `assets/audio/narration-qwen-v3` without modifying v1/v2 audio. It targets ten changed/new phrase WAVs and reuses 77 unchanged WAVs after SHA256 checks. The resulting chapter has 87 phrases. Unchanged measured timing/ASR evidence is copied only if both source text and audio hash match.

Each new phrase must receive independent unprompted speech recognition plus measured acoustic word alignment. Recognizer agreement is not human listening approval. Every rebased subtitle event must be checked again, and the next encoded video needs its own output QA; passing the prior v2 audio gate does not approve a new render.

## Provisional clarity revision after the first QA pass

The first new candidate set failed strict QA on four phrases. Three independent recognizers did not reliably recognize 'Spiral', the past-tense 'crossed/ticked', and singular 'bindi'. 'One ten' was also ambiguously recognized as 110. These candidate WAVs and their failed acoustic/recognition evidence are preserved in `narration-qwen-v3/before-clear-wording-repair`; no human listening approval is claimed.

The provisional retry retained **Spiral Learning** and the full original **bindis** material instructions as literal on-screen textbook text, while the voice used equivalent child-friendly wording: 'We will learn about higher numbers', 'numbers marked with a cross/tick', and 'small round stickers'. The subsequent final S19 repair restored the spoken source term **bindis**; the sticker candidate is not the delivered voice. A blue circle represents one group of ten, and a yellow circle represents one.

S15-02's initial timing problem was resolved using independently measured unprompted word timestamps; its approved waveform is preserved without regeneration.

## Provisional sticker narration and subtitle-data QA

- Duration: **546.0051 seconds**, an increase of **28.1357 seconds** over v2.
- **87/87 phrases** pass the independent-recognition and measured-timing data gate.
- **955 source-punctuated display-word units**, **181 caption pages**.
- **16,381** authored frame-event times checked at 30 fps: no caption overlaps, no concurrent active words, and no words without visible highlight time. The shortest active word still receives two output frames.
- **77** unchanged WAVs remain byte-identical to the v2 source. All protected precision-animation cue WAVs remain unchanged.
- Current manifest SHA256: `b2754f6f6e5f9ec90b966852879fb5cb0d86ec1a905320ad4c9dedc0b68ec314`.
- Exact section/phrase rebase: `assets/audio/narration-qwen-v3/timeline-rebase-v3.json`.
- All **23** current project unit/regression tests pass.

The final four retry lines match small.en's unprompted transcription. Base.en independently matches S01-03 and S19-01; it produces low-confidence trailing hallucinations on S14-04 (four very short digits, first probability 0.0085) and S19-02 ('because', probability 0.0179). Those raw outputs remain in the acoustic evidence folder and QA report. They were not changed into exact transcripts or used as word timing. This is automated evidence, not a claim of human listening.

Reproducible data checks:

```powershell
python scripts/subtitle_v2.py build --audio-dir assets/audio/narration-qwen-v3
python scripts/prepare_narration_v3.py verify
python -m unittest discover -s tests
```

These metrics applied only to the provisional sticker candidate. They do not transfer to the delivered bindis candidate; its independent QA is recorded below.

## Final source-material listening check

On the independent reviewer's request, exactly two activity lines were attempted once with the original material term:

- S19-01: "Take two packets of bindis in two colours: blue and yellow. Let each blue circle stand for one group of ten."
- S19-02: "Let each yellow circle stand for one. Now make these numbers using these circles."

All **85 other phrase WAVs** match the previous v3 manifest SHA256 values exactly. The previous sticker candidates, manifest, script, and QA evidence are preserved in `assets/audio/narration-qwen-v3/before-bindi-source-refinement`.

Small.en transcribes the uncommon word as 'bindes'; base transcribes it as 'bindess'. Both match the rest of the sentence, and both match S19-02 completely. A spelling disagreement is **not proof of incorrect pronunciation**. Per the approved stop rule, no further synthesis retry was made and no human listening approval is claimed.

Two labelled MP3 comparisons are ready in `artifacts/listening-review-v3`:

- `activity-A-stickers.mp3`: prior clear sticker paraphrase, 17.5411 seconds.
- `activity-B-bindis.mp3`: source-preserving wording, 15.1485 seconds. The word requiring a listening decision begins about 1.5 seconds into the sample.
- `review.json`: full transcripts, source WAV hashes, and blocked review status.

The user replied “ok done” after the listening request, and work proceeded with the source-preserving candidate. The automated recognizers spelled the rare spoken term as `bindes`/`bindess`, while the source reads `bindis`; this is an ASR spelling difference, not proof of a spoken defect. The builder maps those spellings only for the exact reviewed WAV SHA256 `64dd68161e7e3f82c17150c35388316698a682c7c1af898ee4e56656d435dda4`, uses independent unprompted word timestamps, and rejects the alias for any other waveform. No claim is made that an automated recognizer constitutes a full human listening review.

## Delivered bindis narration and render QA

- Audio timeline: **543.6125 seconds**; final encoded video: **543.6333 seconds**.
- **87/87** phrases passed; **953** display words, **181** caption pages, and **16,309** authored frame-event times passed strict timing checks.
- Current manifest SHA256: `7d3ae4a85804243f8adc5f3cbb989d55ffd7693af5a252a4d16810d3b1abc220`.
- **46** project regression tests passed. The final hash-bound browser QA passed **19/19** source blocks and **953/953** word midpoints.
- The 1920x1080, 30-fps H.264/AAC final MP4 decoded all **16,309** frames, with no black intervals or detected story freezes. Encoded phrase QA passed **87/87**. Sampled visual review is documented in `artifacts/encoded-qa-v3/visual-review.md`.
