# Encoded Maths v2 audio verification

The completed `maths-class1-chapter8-two-digit-numbers-final-v2.mp4` passes the supplemental audio gate at its native 48 kHz delivery rate.

- All **85 complete phrases** and **954 overlapping speech windows** pass.
- Thresholds remain correlation at least **0.90** and absolute timing offset at most **50 ms**.
- Maximum observed absolute offset: **0.479 ms**.
- Against the mastered review chapter: minimum whole-phrase correlation **0.966373**; minimum window correlation **0.943385**.
- Against the exact unmastered source mix used by the renderer: minimum whole-phrase correlation **0.999813**; minimum window correlation **0.999134**.
- No failed/missing phrase, candidate misplaced duplicate, or unexpected audio in planned quiet gaps was detected.
- All 19 staged section WAV hashes match their source WAVs.

## Investigated initial diagnostic failures

The initial 16 kHz comparison passed every whole phrase but flagged short windows in S05-04 (111.315–112.115 seconds) and S14-02 (345.449–346.249 seconds). These were caused by reducing the sampling rate before integer-lag correlation. Small native-sample timing differences become fractional samples at 16 kHz, particularly affecting quiet high-frequency sounds.

At native 48 kHz the same two windows match the exact staged section WAVs with correlations **0.999582** and **0.999831**, respectively. Their offsets are **0.500 ms** and **0.396 ms** when compared with locally indexed section PCM. No clipped samples occur in these windows. Original phrase WAV comparisons agree. No composition, video, or narration change was needed.

The QA script now compares at 48 kHz by default. A regression test reproduces a native 23-sample delay that produces a false correlation failure after coarse 16 kHz downsampling. All eight supplemental QA tests pass. Neither the correlation threshold nor timing tolerance was relaxed.

## Evidence

- `phrase-audio-qa.json`: final native-rate comparison against the mastered review chapter.
- `exact-rendered-mix-48khz/phrase-audio-qa.json`: independent full check against the exact source mix.
- `raw-reference-diagnosis.json`: native-rate comparisons for both questioned windows against staged sections, original phrases, and both complete source mixes, including RMS and clipping measurements.
- `phrase-audio-qa-16khz-diagnostic.json`: retained initial diagnostic, including its two failures.

Waveform agreement verifies recorded audio identity, placement, and continuity. It does not validate pronunciation, accent, educational meaning, visual semantics, or subtitle word boundaries, and does not constitute human listening approval.
