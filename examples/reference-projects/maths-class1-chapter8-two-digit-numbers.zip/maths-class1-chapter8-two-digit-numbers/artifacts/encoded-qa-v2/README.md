# Encoded QA command, prepared for v2

Run from the Maths project directory **after** the v2 MP4 has finished encoding:

```powershell
& 'C:\Users\user\Miniconda3\python.exe' scripts\qa_encoded_video.py `
  --video 'hyperframes-final\renders\maths-class1-chapter8-two-digit-numbers-final-v2.mp4' `
  --manifest 'assets\audio\narration-qwen-v1\narration_manifest.json' `
  --reference-audio 'assets\audio\narration-qwen-v1\chapter-review.wav' `
  --composition-data 'hyperframes-final\production-data.js' `
  --out 'artifacts\encoded-qa-v2'
```

Expected timeline duration for the current revised narration is 517.8694 seconds. Rebuild the HyperFrames composition before rendering so its copied section audio and media offsets match this manifest.

The existing command decodes every video frame, validates container/codec/frame-rate/audio metadata, detects black frames and frozen story spans, and correlates the first 2.5 seconds of each narration section. It does **not** establish word alignment, complete phrase delivery, semantic picture correctness, or human listening approval. Its successful state is intentionally `technical-pass-visual-review-pending`.

For complete audio placement coverage, additionally correlate all 85 phrase intervals against the revised reference chapter. Each phrase's global interval is `section.start + phrase.start` to `section.start + phrase.end`. Word timing is separately recorded in `word_alignment.v2.json`; source-versus-encoded audio correlation cannot validate individual word boundaries.

No v2 encoded QA result is claimed by preparing this command or output directory.
