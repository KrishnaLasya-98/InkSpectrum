from __future__ import annotations

from manim import (
    AnimationGroup,
    Arrow,
    Circle,
    Create,
    FadeIn,
    FadeOut,
    Indicate,
    DOWN,
    LEFT,
    RIGHT,
    UP,
    LaggedStart,
    Line,
    RoundedRectangle,
    Scene,
    Text,
    VGroup,
    Write,
    config,
)


config.pixel_width = 1920
config.pixel_height = 1080
config.frame_rate = 30
config.background_color = "#F4FBF6"

NAVY = "#123047"
TEAL = "#159486"
MINT = "#DDF5EA"
CREAM = "#FFFCF5"
YELLOW = "#FFD45F"
CORAL = "#D45F48"
BLUE = "#2AA8DF"


def title_card(text: str, subtitle: str) -> VGroup:
    panel = RoundedRectangle(width=12.6, height=1.55, corner_radius=0.24)
    panel.set_fill(CREAM, opacity=0.98).set_stroke("#D7EDE4", width=2)
    heading = Text(text, font="Segoe UI", weight="BOLD", color=NAVY, font_size=44)
    detail = Text(subtitle, font="Segoe UI", color=TEAL, font_size=24)
    VGroup(heading, detail).arrange(direction=DOWN, buff=0.16).move_to(panel)
    return VGroup(panel, heading, detail).to_edge(UP, buff=0.34)


def count_row(step: int, maximum: int, color: str) -> VGroup:
    values = list(range(step, maximum + 1, step))
    nodes = VGroup()
    for value in values:
        disc = Circle(radius=0.34).set_fill(CREAM, opacity=1).set_stroke(color, width=5)
        number = Text(str(value), font="Segoe UI", weight="BOLD", color=NAVY, font_size=29)
        nodes.add(VGroup(disc, number))
    nodes.arrange(RIGHT, buff=0.35)
    arrows = VGroup(
        *[
            Arrow(nodes[index].get_right(), nodes[index + 1].get_left(), buff=0.08, color=color, stroke_width=5)
            for index in range(len(nodes) - 1)
        ]
    )
    return VGroup(arrows, nodes)


def step_label(step: int, color: str) -> VGroup:
    pill = RoundedRectangle(width=2.15, height=0.72, corner_radius=0.25)
    pill.set_fill(color, opacity=1).set_stroke(color, width=0)
    label = Text(f"Count by {step}", font="Segoe UI", weight="BOLD", color=CREAM, font_size=27)
    label.move_to(pill)
    return VGroup(pill, label)


def inset_card(title: str, subtitle: str, title_font_size: int = 70) -> VGroup:
    panel = RoundedRectangle(width=13.6, height=7.25, corner_radius=0.32)
    panel.set_fill(CREAM, opacity=1).set_stroke("#D7EDE4", width=3)
    heading = Text(title, font="Segoe UI", weight="BOLD", color=NAVY, font_size=title_font_size)
    if subtitle:
        detail = Text(subtitle, font="Segoe UI", weight="BOLD", color=TEAL, font_size=60)
        VGroup(heading, detail).arrange(DOWN, buff=0.16).move_to([0, 2.55, 0])
        return VGroup(panel, heading, detail)
    heading.move_to([0, 2.65, 0])
    return VGroup(panel, heading)


def inset_count_row(values: list[int], color: str) -> VGroup:
    nodes = VGroup()
    for value in values:
        disc = Circle(radius=0.62).set_fill(CREAM, opacity=1).set_stroke(color, width=7)
        number = Text(str(value), font="Segoe UI", weight="BOLD", color=NAVY, font_size=64)
        nodes.add(VGroup(disc, number))
    nodes.arrange(RIGHT, buff=0.68)
    arrows = VGroup(
        *[
            Arrow(nodes[index].get_right(), nodes[index + 1].get_left(), buff=0.10, color=color, stroke_width=8)
            for index in range(len(nodes) - 1)
        ]
    )
    return VGroup(arrows, nodes)


def inset_step_label(text: str, color: str) -> VGroup:
    pill = RoundedRectangle(width=3.15, height=1.05, corner_radius=0.28)
    pill.set_fill(color, opacity=1).set_stroke(color, width=0)
    label = Text(text, font="Segoe UI", weight="BOLD", color=CREAM, font_size=60)
    label.move_to(pill)
    return VGroup(pill, label)


class SkipBy2Path(Scene):
    def construct(self) -> None:
        card = inset_card("Skip Counting by 2", "Jump two spaces each time")
        row = inset_count_row([2, 4, 6, 8, 10], TEAL)
        label = inset_step_label("By 2", TEAL).next_to(row, direction=LEFT, buff=0.5)
        VGroup(label, row).move_to([0, -0.55, 0])
        self.add(card, label, row)
        # Local times are measured word onsets/ends from word_alignment.v2.json,
        # relative to P01's global start at 317.3431 seconds.
        pulses = [
            (22, 32, 0),   # 0.733-1.067: "two" in "Start at two"
            (49, 61, 0),   # 1.633-2.033: "two" in "jump two spaces"
            (122, 125, 0), # 4.067-4.167: spoken sequence: two
            (134, 148, 1), # 4.467-4.933: four
            (155, 167, 2), # 5.167-5.567: six
            (179, 182, 3), # 5.967-6.067: eight
            (187, 197, 4), # 6.233-6.567: ten
        ]
        cursor = 0
        for start, end, index in pulses:
            self.wait((start - cursor) / 30)
            row[1][index][0].set_fill(YELLOW, opacity=1)
            self.wait((end - start) / 30)
            row[1][index][0].set_fill(CREAM, opacity=1)
            cursor = end
        self.wait((207 - cursor) / 30)


class SkipBy3And4Paths(Scene):
    def construct(self) -> None:
        card = inset_card("Skip Counting by 3 and 4", "Compare the two jump patterns")
        row3 = inset_count_row([3, 6, 9, 12, 15], CORAL)
        row4 = inset_count_row([4, 8, 12, 16, 20], BLUE)
        label3 = inset_step_label("By 3", CORAL).next_to(row3, direction=LEFT, buff=0.5)
        label4 = inset_step_label("By 4", BLUE).next_to(row4, direction=LEFT, buff=0.5)
        VGroup(label3, row3).move_to([0, 0.45, 0])
        VGroup(label4, row4).move_to([0, -1.35, 0])
        self.add(card, label3, row3)
        # Exact acoustic word intervals relative to P02's 335.8986-second start.
        row3_pulses = [
            (125, 129, 0), # 4.167-4.300: three
            (141, 153, 1), # 4.700-5.100: six
            (177, 181, 2), # 5.900-6.033: nine
            (193, 202, 3), # 6.433-6.733: twelve
            (218, 224, 4), # 7.267-7.467: fifteen
        ]
        cursor = 0
        for start, end, index in row3_pulses:
            self.wait((start - cursor) / 30)
            row3[1][index][0].set_fill(YELLOW, opacity=1)
            self.wait((end - start) / 30)
            row3[1][index][0].set_fill(CREAM, opacity=1)
            cursor = end

        # The by-four row appears precisely when S14-02 begins.
        self.wait((275 - cursor) / 30)
        self.add(label4, row4)
        cursor = 275
        row4_pulses = [
            (431, 436, 0), # 14.367-14.533: four
            (447, 459, 1), # 14.900-15.300: eight
            (476, 484, 2), # 15.867-16.133: twelve
            (500, 510, 3), # 16.667-17.000: sixteen
            (528, 535, 4), # 17.600-17.833: twenty
        ]
        for start, end, index in row4_pulses:
            self.wait((start - cursor) / 30)
            row4[1][index][0].set_fill(YELLOW, opacity=1)
            self.wait((end - start) / 30)
            row4[1][index][0].set_fill(CREAM, opacity=1)
            cursor = end

        # S14-03 says "twelve" at 356.3348; emphasize its shared position.
        self.wait((613 - cursor) / 30)
        row3[1][3][0].set_fill(YELLOW, opacity=1)
        row4[1][2][0].set_fill(YELLOW, opacity=1)
        self.wait((623 - 613) / 30)
        row3[1][3][0].set_fill(CREAM, opacity=1)
        row4[1][2][0].set_fill(CREAM, opacity=1)
        cursor = 623
        self.wait((696 - cursor) / 30)


class SkipBy5And10Paths(Scene):
    def construct(self) -> None:
        title = title_card("Skip Counting Paths", "Notice the repeating pattern")
        row5 = count_row(5, 50, TEAL).scale(0.73).move_to([0.55, 0.6, 0])
        row10 = count_row(10, 100, CORAL).scale(0.73).move_to([0.55, -1.05, 0])
        label5 = step_label(5, TEAL).scale(0.9).next_to(row5, direction=LEFT, buff=0.35)
        label10 = step_label(10, CORAL).scale(0.9).next_to(row10, direction=LEFT, buff=0.35)
        self.play(FadeIn(title, shift=UP * 0.18), run_time=0.6)
        self.play(FadeIn(label5), LaggedStart(*[FadeIn(node, scale=0.7) for node in row5[1]], lag_ratio=0.07), LaggedStart(*[Create(a) for a in row5[0]], lag_ratio=0.07), run_time=2.4)
        self.wait(12.9)
        self.play(FadeIn(label10), LaggedStart(*[FadeIn(node, scale=0.7) for node in row10[1]], lag_ratio=0.07), LaggedStart(*[Create(a) for a in row10[0]], lag_ratio=0.07), run_time=2.4)
        self.play(LaggedStart(*[Indicate(node, color=YELLOW, scale_factor=1.12) for node in row10[1]], lag_ratio=0.07), run_time=1.4)
        self.wait(5.5)


def place_value_state(number: int, tens: int, ones_count: int) -> VGroup:
    number_text = Text(str(number), font="Segoe UI", weight="BOLD", color=CORAL, font_size=112)
    number_text.move_to([-5.25, -0.25, 0])
    rods = VGroup()
    for _ in range(tens):
        rod = RoundedRectangle(width=0.46, height=2.55, corner_radius=0.14)
        rod.set_fill("#DDF3FF", 1).set_stroke(BLUE, 3)
        rods.add(rod)
    rods.arrange(RIGHT, buff=0.12).move_to([-1.65, -0.25, 0])
    ones = VGroup(*[Circle(radius=0.23).set_fill(YELLOW, 1).set_stroke(CORAL, 3) for _ in range(ones_count)])
    if ones_count:
        ones.arrange_in_grid(rows=2, cols=max(1, (ones_count + 1) // 2), buff=0.22).move_to([3.25, -0.25, 0])
    labels = VGroup(
        Text(f"{tens} {'ten' if tens == 1 else 'tens'}", font="Segoe UI", weight="BOLD", color=TEAL, font_size=64).move_to([-1.65, 1.25, 0]),
        Text(f"{ones_count} ones", font="Segoe UI", weight="BOLD", color=CORAL, font_size=64).move_to([3.25, 1.25, 0]),
    )
    equation = Text(
        f"{number}  =  {tens * 10}  +  {ones_count}",
        font="Segoe UI",
        weight="BOLD",
        color=NAVY,
        font_size=82,
    ).move_to([0.45, -2.05, 0])
    return VGroup(number_text, rods, ones, labels, equation)


class PlaceValueExpandedForm(Scene):
    def construct(self) -> None:
        card = inset_card("Tens, Ones, and Expanded Form", "", title_font_size=62)
        states = [
            place_value_state(12, 1, 2),
            place_value_state(35, 3, 5),
            place_value_state(68, 6, 8),
            place_value_state(94, 9, 4),
            place_value_state(27, 2, 7),
        ]
        self.add(card, states[0])
        self.wait(6.5161)
        self.remove(states[0])
        self.add(states[1])
        self.wait(2.8631)
        self.remove(states[1])
        self.add(states[2])
        self.wait(3.2200)
        self.remove(states[2])
        self.add(states[3])
        self.wait(3.0000)
        self.remove(states[3])
        self.add(states[4])
        self.wait(2.2061)
