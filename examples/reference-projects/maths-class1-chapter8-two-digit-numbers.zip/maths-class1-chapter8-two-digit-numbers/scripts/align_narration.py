from __future__ import annotations

import json
import re
from difflib import SequenceMatcher
from pathlib import Path

from faster_whisper import WhisperModel

PROJECT = Path(__file__).resolve().parents[1]
OUT = PROJECT / "assets/audio/narration-qwen-v1"


def normalize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", text.lower().replace("'", ""))


def source_tokens(text: str) -> list[str]:
    return re.findall(r"[A-Za-z0-9]+(?:'[A-Za-z0-9]+)?", text)


def word_error_rate(reference: str, hypothesis: str) -> float:
    expected, actual = normalize(reference), normalize(hypothesis)
    if not expected:
        return 0.0 if not actual else 1.0
    previous = list(range(len(actual) + 1))
    for row, expected_word in enumerate(expected, start=1):
        current = [row]
        for column, actual_word in enumerate(actual, start=1):
            current.append(min(current[-1] + 1, previous[column] + 1, previous[column - 1] + (expected_word != actual_word)))
        previous = current
    return previous[-1] / len(expected)


def map_source(source: str, measured: list[dict]) -> list[dict]:
    tokens = source_tokens(source)
    source_norm = [(normalize(token) or [""])[0] for token in tokens]
    measured_norm = [(normalize(item["word"]) or [""])[0] for item in measured]
    aligned: list[dict | None] = [None] * len(tokens)
    matcher = SequenceMatcher(a=source_norm, b=measured_norm, autojunk=False)
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            for source_index, measured_index in zip(range(i1, i2), range(j1, j2)):
                aligned[source_index] = {**measured[measured_index], "word": tokens[source_index], "timing_source": "measured-asr"}
        elif tag in {"replace", "delete"} and i2 > i1:
            previous_end = aligned[i1 - 1]["end"] if i1 and aligned[i1 - 1] else 0.0
            span_start = measured[j1]["start"] if j1 < len(measured) else previous_end
            span_end = measured[j2 - 1]["end"] if j2 > j1 else span_start + 0.22 * (i2 - i1)
            step = max(0.04, (span_end - span_start) / (i2 - i1))
            for offset, source_index in enumerate(range(i1, i2)):
                aligned[source_index] = {
                    "word": tokens[source_index],
                    "start": round(span_start + offset * step, 3),
                    "end": round(span_start + (offset + 1) * step, 3),
                    "probability": 0.5,
                    "timing_source": "mapped-within-measured-span",
                }
    for index, item in enumerate(aligned):
        if item is not None:
            continue
        previous_end = aligned[index - 1]["end"] if index and aligned[index - 1] else 0.0
        next_start = next((candidate["start"] for candidate in aligned[index + 1 :] if candidate), previous_end + 0.22)
        aligned[index] = {
            "word": tokens[index],
            "start": round(previous_end, 3),
            "end": round(max(previous_end + 0.04, next_start), 3),
            "probability": 0.5,
            "timing_source": "neighbour-bounded",
        }
    return [item for item in aligned if item]


def main() -> int:
    manifest = json.loads((OUT / "narration_manifest.json").read_text(encoding="utf-8"))
    model = WhisperModel("small.en", device="cpu", compute_type="int8")
    words: list[dict] = []
    qa: list[dict] = []
    for section in manifest["sections"]:
        for phrase in section["phrases"]:
            wav = OUT / "phrases" / f"{phrase['id']}.wav"
            segments, _ = model.transcribe(
                str(wav), language="en", beam_size=5, word_timestamps=True,
                vad_filter=False, condition_on_previous_text=False,
            )
            measured: list[dict] = []
            transcript_parts = []
            for segment in segments:
                transcript_parts.append(segment.text.strip())
                for word in segment.words or []:
                    if word.word.strip():
                        measured.append({"word": word.word.strip(), "start": round(float(word.start), 3), "end": round(float(word.end), 3), "probability": round(float(word.probability), 4)})
            transcript = " ".join(part for part in transcript_parts if part)
            wer = word_error_rate(phrase["text"], transcript)
            offset = section["start"] + phrase["start"]
            mapped = map_source(phrase["text"], measured)
            for item in mapped:
                item.update(
                    {
                        "section_id": section["id"],
                        "phrase_id": phrase["id"],
                        "start": round(offset + item["start"], 3),
                        "end": round(offset + item["end"], 3),
                    }
                )
                words.append(item)
            mean_probability = sum(item["probability"] for item in measured) / max(1, len(measured))
            status = "pass" if wer <= 0.12 and mean_probability >= 0.70 else "review"
            qa.append({"phrase_id": phrase["id"], "expected": phrase["text"], "transcript": transcript, "wer": round(wer, 4), "mean_probability": round(mean_probability, 4), "status": status})
            print(f"{phrase['id']}: WER={wer:.3f} confidence={mean_probability:.3f} {status}", flush=True)
    (OUT / "word_alignment.json").write_text(json.dumps({"version": "1.0", "timestamp_basis": "phrase-local unprompted faster-whisper small.en", "words": words}, indent=2), encoding="utf-8")
    report = {"version": "1.0", "phrases": len(qa), "passed": sum(item["status"] == "pass" for item in qa), "review": sum(item["status"] == "review" for item in qa), "items": qa}
    (OUT / "alignment_qa.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({key: report[key] for key in ("phrases", "passed", "review")}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
