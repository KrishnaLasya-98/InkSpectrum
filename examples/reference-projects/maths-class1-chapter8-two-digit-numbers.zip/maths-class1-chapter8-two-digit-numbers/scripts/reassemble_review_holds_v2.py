"""Reassemble the approved answer-review holds from existing PCM; no provider calls."""
import json
import shutil
from generate_narration import OUT, SCRIPT, assemble, read_pcm, sha256, tasks


def main():
    manifest_path = OUT / "narration_manifest.json"
    old = json.loads(manifest_path.read_text(encoding="utf-8"))
    old_phrases = {p["id"]: p for s in old["sections"] for p in s["phrases"]}
    source = tasks()
    if set(old_phrases) != {str(t["id"]) for t in source}:
        raise ValueError("Pause-only assembly cannot add or remove phrases")
    results, changes = [], []
    for task in source:
        pid = str(task["id"])
        current = old_phrases[pid]
        wav = OUT / "phrases" / f"{pid}.wav"
        if current["text"] != task["text"] or sha256(wav) != current["sha256"]:
            raise ValueError(f"Pause-only assembly cannot change narration: {pid}")
        if current["pause_after"] != task["pause_after"]:
            changes.append({"phrase_id": pid, "old_pause": current["pause_after"], "new_pause": task["pause_after"]})
        results.append({**task, "file": str(wav), "samples": len(read_pcm(wav)), "sha256": current["sha256"]})
    if not changes:
        print("No new pause changes; assembly already current")
        return
    backup = OUT / "before-review-holds-v2"
    backup.mkdir(exist_ok=True)
    if not (backup / manifest_path.name).exists():
        shutil.copy2(manifest_path, backup / manifest_path.name)
    assemble(results)
    for result in results:
        if sha256(OUT / "phrases" / f"{result['id']}.wav") != result["sha256"]:
            raise ValueError(f"Phrase PCM unexpectedly changed: {result['id']}")
    new = json.loads(manifest_path.read_text(encoding="utf-8"))
    report = {"status": "reassembled-with-no-provider-calls", "changed_pauses": changes,
              "preserved_phrase_wavs": len(results), "previous_duration_seconds": old["duration_seconds"],
              "duration_seconds": new["duration_seconds"],
              "duration_delta_seconds": round(new["duration_seconds"] - old["duration_seconds"], 4)}
    (OUT / "review-holds-v2.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
