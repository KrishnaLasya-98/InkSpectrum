async (page) => {
const data = await page.evaluate(() => window.PRODUCTION_DATA);
const times = [];
for (const section of data.sections) {
  times.push(Number((section.start + 0.10).toFixed(3)));
  times.push(Number((section.end - 0.15).toFixed(3)));
}
for (const video of data.videos.filter((item) => item.kind === "precision")) {
  times.push(Number((video.start + 0.10).toFixed(3)));
  times.push(Number(((video.start + video.end) / 2).toFixed(3)));
  times.push(Number((video.end - 0.10).toFixed(3)));
}
const uniqueTimes = [...new Set(times)].sort((a, b) => a - b);
const captures = [];
for (let index = 0; index < uniqueTimes.length; index += 1) {
  const time = uniqueTimes[index];
  const state = await page.evaluate(async (seekTime) => {
    const timeline = window.__timelines && window.__timelines["maths-class1-chapter8-two-digit-numbers"];
    if (!timeline) throw new Error("Maths timeline is not registered");
    timeline.pause().seek(seekTime, false);
    const activeVideos = [];
    for (const media of document.querySelectorAll("video[data-start]")) {
      const start = Number(media.dataset.start);
      const duration = Number(media.dataset.duration);
      const active = seekTime >= start && seekTime < start + duration;
      media.pause();
      if (active) {
        const target = Math.max(0, Math.min(duration - 0.04, seekTime - start));
        if (Math.abs(media.currentTime - target) > 0.025) {
          await new Promise((resolve) => {
            const finish = () => resolve();
            media.addEventListener("seeked", finish, { once: true });
            media.currentTime = target;
            setTimeout(finish, 2500);
          });
        }
        activeVideos.push(media.id);
      }
    }
    await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    return {
      activeSections: [...document.querySelectorAll(".section")]
        .filter((element) => getComputedStyle(element).visibility !== "hidden" && Number(getComputedStyle(element).opacity) > 0.02)
        .map((element) => element.id),
      activeVideos,
      activeCaptions: [...document.querySelectorAll(".caption")]
        .filter((element) => getComputedStyle(element).visibility !== "hidden" && Number(getComputedStyle(element).opacity) > 0.02)
        .map((element) => element.id),
    };
  }, time);
  const stamp = time.toFixed(3).replace(".", "-").padStart(8, "0");
  const file = "frame-" + String(index + 1).padStart(3, "0") + "-" + stamp + ".png";
  await page.locator("#root").screenshot({ path: file });
  captures.push(Object.assign({ index: index + 1, time: time, file: file }, state));
}
return { captured: captures.length, captures };
}
