"""Isolated, resumable, targeted source-completeness narration revision.

The v1/v2 audio and reports are read-only inputs. Only approved changed/new
phrases call the existing voice provider. Unchanged WAVs and alignment evidence
are copied only after matching their text and SHA256 to the source manifest.
"""
from __future__ import annotations

import argparse
import copy
import json
import shutil
from pathlib import Path

import generate_narration as generator

PROJECT = Path(__file__).resolve().parents[1]
SOURCE_SCRIPT = PROJECT / "artifacts/narration_script.json"
SCRIPT = PROJECT / "artifacts/narration_script_v3.json"
SOURCE_AUDIO = PROJECT / "assets/audio/narration-qwen-v1"
OUT = PROJECT / "assets/audio/narration-qwen-v3"

REPLACEMENTS = {
    "S01-03": "We will learn about higher numbers, from fifty-one to one hundred.",
    "S01-04": "Concepts of skip counting and expanded form.",
    "S02-01": "To start making numbers from fifty-one to one hundred, let us first make groups of ten.",
    "S14-04": "Now, write all the numbers marked with a cross. Then write all the numbers marked with a tick.",
    "S15-02": "Five, ten, fifteen, twenty, twenty-five. In this row, the ones digits repeat five, zero, five, zero.",
    "S16-02": "In a two-digit number, the place values are tens and ones.",
    "S19-01": "Take two packets of bindis in two colours: blue and yellow. Let each blue circle stand for one group of ten.",
    "S19-02": "Let each yellow circle stand for one. Now make these numbers using these circles.",
}
ADDITIONS = [
    {"text": "Recall. We know how numbers are formed from twenty-one to fifty.", "pause_after": 1.5},
    {"text": "We know that by adding one, two, three, up to ten to a number, we get the next ten numbers.", "pause_after": 1.5},
]
PAUSES = {
    # Class 1 pacing: retain compact explanation beats, then provide real
    # thinking/review time before exercise answers and section transitions.
    "S01-05": 1.5,
    "S01-06": 1.5,
    "S07-05": 5.5,
    "S09-02": 2.0,
    "S09-03": 6.0,
    "S09-04": 2.0,
    "S10-02": 5.0,
    "S11-03": 6.0,
    "S12-05": 8.0,
    "S13-04": 7.0,
    "S14-04": 8.0,
    "S15-05": 7.0,
    "S17-03": 4.0,
    "S17-05": 8.0,
    "S18-03": 7.0,
    "S18-04": 5.0,
    "S19-03": 1.5,
    "S19-04": 3.0,
    "S19-05": 2.5,
}
APPROVED_RETRY_IDS = {"S01-03", "S14-04", "S19-01", "S19-02"}
APPROVED_BINDI_IDS = {"S19-01", "S19-02"}


def read(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def make_script(source: dict) -> dict:
    result = copy.deepcopy(source)
    result["version"] = "3.0-source-completeness"
    result["revision"] = "Targeted approved textbook wording; unchanged narration WAVs reused with SHA256 checks"
    found = set()
    for section in result["sections"]:
        for i, phrase in enumerate(section["phrases"], 1):
            pid = f"{section['id']}-{i:02d}"
            if pid in REPLACEMENTS:
                phrase["text"] = REPLACEMENTS[pid]
                found.add(pid)
            if pid in PAUSES:
                phrase["pause_after"] = PAUSES[pid]
        if section["id"] == "S01":
            if len(section["phrases"]) != 4:
                raise ValueError("Unexpected source intro structure; do not shift phrase IDs")
            section["phrases"].extend(copy.deepcopy(ADDITIONS))
    if found != set(REPLACEMENTS):
        raise ValueError(f"Missing expected source phrase IDs: {set(REPLACEMENTS) - found}")
    return result


def copy_verified(source: Path, target: Path):
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        if generator.sha256(source) != generator.sha256(target):
            raise ValueError(f"Existing target differs: {target}")
    else:
        shutil.copy2(source, target)
    if generator.sha256(source) != generator.sha256(target):
        raise ValueError(f"Copy hash mismatch: {target}")


def archive_approved_retry(script: dict, approved_ids=APPROVED_RETRY_IDS, backup_name="before-clear-wording-repair"):
    """Keep failed candidates/evidence before the explicitly approved retry."""
    if not SCRIPT.exists() or read(SCRIPT) == script:
        return
    previous = read(SCRIPT)
    old = {f"{s['id']}-{i:02d}": p for s in previous["sections"] for i, p in enumerate(s["phrases"], 1)}
    new = {f"{s['id']}-{i:02d}": p for s in script["sections"] for i, p in enumerate(s["phrases"], 1)}
    if old.keys() != new.keys() or {pid for pid in old if old[pid] != new[pid]} != approved_ids:
        raise ValueError("Retry script difference is not the exact approved phrase revision")
    backup = OUT / backup_name
    backup.mkdir(parents=True, exist_ok=True)
    copy_verified(SCRIPT, backup / SCRIPT.name)
    for name in ("narration_manifest.json", "revision-provenance.json", "subtitle-v2-qa.json", "captions.v2.json", "word_alignment.v2.json"):
        if (OUT / name).exists():
            copy_verified(OUT / name, backup / name)
    for pid in sorted(approved_ids):
        paths = list((OUT / "phrases").glob(f"{pid}.*")) + list((OUT / "subtitle-v2-acoustic").glob(f"{pid}.*.json"))
        for path in paths:
            if OUT.resolve() not in path.resolve().parents:
                raise ValueError(f"Archive target escapes revision audio directory: {path}")
            destination = backup / path.relative_to(OUT)
            copy_verified(path, destination)
            # Exact per-phrase files are recoverable from the checked backup.
            path.unlink()
    generator.write_json(SCRIPT, script)


def prepare(repair_approved_four=False, repair_bindi_two=False):
    manifest = read(SOURCE_AUDIO / "narration_manifest.json")
    baseline = {p["id"]: p for s in manifest["sections"] for p in s["phrases"]}
    script = make_script(read(SOURCE_SCRIPT))
    if repair_approved_four:
        archive_approved_retry(script)
    if repair_bindi_two:
        archive_approved_retry(script, APPROVED_BINDI_IDS, "before-bindi-source-refinement")
    if SCRIPT.exists() and read(SCRIPT) != script:
        raise ValueError("Existing v3 script differs; do not overwrite edits silently")
    generator.write_json(SCRIPT, script)
    generator.SCRIPT, generator.OUT = SCRIPT, OUT
    changed, reused, copied_cache_count = [], [], 0
    for task in generator.tasks():
        pid = str(task["id"])
        previous = baseline.get(pid)
        if not previous or previous["text"] != task["text"]:
            changed.append(pid)
            continue
        source_wav = SOURCE_AUDIO / "phrases" / f"{pid}.wav"
        if generator.sha256(source_wav) != previous["sha256"]:
            raise ValueError(f"Original WAV no longer matches source manifest: {pid}")
        copy_verified(source_wav, OUT / "phrases" / source_wav.name)
        reused.append({"id": pid, "sha256": previous["sha256"]})
        for cache in (SOURCE_AUDIO / "subtitle-v2-acoustic").glob(f"{pid}.*.json"):
            evidence = read(cache)
            if evidence.get("audio_sha256") == previous["sha256"] and evidence.get("source_text") == task["text"]:
                copy_verified(cache, OUT / "subtitle-v2-acoustic" / cache.name)
                copied_cache_count += 1
    # Legacy ASR may be trusted only against its ORIGINAL source hashes. These
    # files remain explicitly historical audit inputs, not v3 timing outputs.
    for relative in ("alignment_qa.json", "word_alignment.json", "before-subtitle-v2/narration_manifest.json"):
        copy_verified(SOURCE_AUDIO / relative, OUT / relative)
    audit = {"status": "prepared-awaiting-generation-and-qa", "source_script_sha256": generator.sha256(SOURCE_SCRIPT),
             "source_manifest_sha256": generator.sha256(SOURCE_AUDIO / "narration_manifest.json"),
             "source_duration_seconds": manifest["duration_seconds"], "generated_phrase_ids": changed,
             "reused_phrases": reused, "reused_alignment_cache_files": copied_cache_count,
             "pause_only_changes": PAUSES, "limits": "Reused evidence is SHA256/text checked; new phrases still require independent ASR and acoustic timing."}
    generator.write_json(OUT / "revision-provenance.json", audit)
    print(json.dumps({"new_or_changed": changed, "reused_wavs": len(reused), "reused_cache_files": copied_cache_count}), flush=True)
    return audit


def generate(audit, only_phrase_ids=None):
    voice = generator.approved_voice()
    key = generator._api_key()
    tasks = generator.tasks()
    selected = set(only_phrase_ids or audit["generated_phrase_ids"])
    results = []
    for task in tasks:
        pid = str(task["id"])
        if pid in selected:
            # Existing receipts/provider data make retries resumable without
            # requesting already completed paid generations again.
            result = generator.generate_phrase(task, key, voice)
        else:
            wav = OUT / "phrases" / f"{pid}.wav"
            result = {**task, "file": str(wav), "samples": len(generator.read_pcm(wav)), "sha256": generator.sha256(wav)}
        results.append(result)
    generator.assemble(results)
    manifest = read(OUT / "narration_manifest.json")
    if generator.sha256(SOURCE_SCRIPT) != audit["source_script_sha256"] or generator.sha256(SOURCE_AUDIO / "narration_manifest.json") != audit["source_manifest_sha256"]:
        raise ValueError("Source revision unexpectedly changed during generation")
    by_id = {p["id"]: p for s in manifest["sections"] for p in s["phrases"]}
    for record in audit["reused_phrases"]:
        if by_id[record["id"]]["sha256"] != record["sha256"]:
            raise ValueError(f"Reused audio changed: {record['id']}")
    audit.update({"status": "generated-awaiting-independent-asr-and-acoustic-qa", "duration_seconds": manifest["duration_seconds"],
                  "duration_delta_seconds": round(manifest["duration_seconds"] - audit["source_duration_seconds"], 4)})
    generator.write_json(OUT / "revision-provenance.json", audit)


def verify():
    from subtitle_v2 import load_verified_captions
    audit = read(OUT / "revision-provenance.json")
    manifest = read(OUT / "narration_manifest.json")
    captions = load_verified_captions(OUT, manifest)
    qa = read(OUT / "subtitle-v2-qa.json")
    if qa["status"] != "pass" or qa["phrases"] != 87:
        raise ValueError("Expected all 87 phrases to pass subtitle QA")
    source_manifest = read(SOURCE_AUDIO / "narration_manifest.json")
    if generator.sha256(SOURCE_SCRIPT) != audit["source_script_sha256"] or generator.sha256(SOURCE_AUDIO / "narration_manifest.json") != audit["source_manifest_sha256"]:
        raise ValueError("Original v1/v2 source revision changed")
    for record in audit["reused_phrases"]:
        filename = f"{record['id']}.wav"
        for audio_dir in (SOURCE_AUDIO, OUT):
            if generator.sha256(audio_dir / "phrases" / filename) != record["sha256"]:
                raise ValueError(f"Reused waveform changed: {filename}")
    previous = {s["id"]: s for s in source_manifest["sections"]}
    shifts = []
    for section in manifest["sections"]:
        old = previous[section["id"]]
        old_phrases = {p["id"]: p for p in old["phrases"]}
        shifts.append({"section_id": section["id"], "start": section["start"], "end": section["end"],
                       "start_delta": round(section["start"] - old["start"], 4),
                       "end_delta": round(section["end"] - old["end"], 4),
                       "phrases": [{"id": p["id"], "start": round(section["start"] + p["start"], 4),
                                    "end": round(section["start"] + p["end"], 4),
                                    "same_audio_as_v2": p["id"] in old_phrases and p["sha256"] == old_phrases[p["id"]]["sha256"]}
                                   for p in section["phrases"]]})
    generator.write_json(OUT / "timeline-rebase-v3.json", {"manifest_sha256": generator.sha256(OUT / "narration_manifest.json"),
        "duration_seconds": manifest["duration_seconds"], "delta_seconds": audit["duration_delta_seconds"], "sections": shifts})
    audit.update({"status": "verified-caption-data-awaiting-composition-and-encoded-qa", "caption_pages": len(captions),
                  "word_units": qa["words"], "frame_events_checked": qa["frame_event_audit"]["frames_checked"],
                  "clarity_retry_phrase_ids": sorted(APPROVED_RETRY_IDS),
                  "limits": "Independent ASR and measured timing passed; no human listening approval claimed. New composition/render still needs encoded-output QA."})
    generator.write_json(OUT / "revision-provenance.json", audit)
    print(json.dumps({k: audit[k] for k in ("status", "duration_seconds", "duration_delta_seconds", "caption_pages", "word_units", "frame_events_checked")}, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("prepare", "generate", "verify"))
    parser.add_argument("--repair-approved-four", action="store_true")
    parser.add_argument("--repair-bindi-two", action="store_true")
    args = parser.parse_args()
    if args.mode == "verify":
        verify()
        return
    if args.repair_approved_four and args.repair_bindi_two:
        raise ValueError("Select exactly one bounded repair scope")
    audit = prepare(args.repair_approved_four, args.repair_bindi_two)
    if args.mode == "generate":
        selected = APPROVED_BINDI_IDS if args.repair_bindi_two else APPROVED_RETRY_IDS if args.repair_approved_four else None
        generate(audit, selected)


if __name__ == "__main__":
    main()
