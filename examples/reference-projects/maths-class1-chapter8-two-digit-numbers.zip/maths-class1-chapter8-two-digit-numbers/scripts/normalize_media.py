from __future__ import annotations

import json
import subprocess
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]


def main() -> None:
    plan = json.loads((PROJECT / "artifacts/media_plan.json").read_text(encoding="utf-8"))
    results = []
    for scene in plan["scenes"]:
        if scene.get("use_in_composition", True) is False:
            continue
        source = PROJECT / scene["output"]
        if not source.exists():
            continue
        target = PROJECT / "assets/video/normalized" / source.name
        target.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(
            [
                "ffmpeg", "-y", "-v", "error", "-i", str(source), "-an",
                "-vf", "scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,fps=30,format=yuv420p",
                "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-movflags", "+faststart", str(target),
            ],
            check=True,
        )
        scene["normalized_output"] = str(target.relative_to(PROJECT)).replace("\\", "/")
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "stream=codec_name,width,height,r_frame_rate:format=duration", "-of", "json", str(target)],
            check=True, capture_output=True, text=True,
        )
        results.append({"scene_id": scene["id"], "source": scene["output"], "output": scene["normalized_output"], "probe": json.loads(probe.stdout)})
    (PROJECT / "artifacts/media_plan.json").write_text(json.dumps(plan, indent=2), encoding="utf-8")
    (PROJECT / "artifacts/normalized-media-qa.json").write_text(json.dumps({"items": results}, indent=2), encoding="utf-8")
    print(json.dumps({"normalized": len(results)}))


if __name__ == "__main__":
    main()
