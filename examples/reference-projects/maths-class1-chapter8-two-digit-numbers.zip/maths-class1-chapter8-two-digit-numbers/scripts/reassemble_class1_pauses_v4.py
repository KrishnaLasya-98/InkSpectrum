"""Reassemble approved Class 1 teaching pauses from existing phrase PCM.

No provider call is made and every approved phrase waveform must remain
byte-identical. Only silence, section offsets, and derived timeline files move.
"""
from __future__ import annotations

import json
import shutil
from pathlib import Path

import generate_narration as generator
from prepare_narration_v3 import PAUSES


PROJECT = Path(__file__).resolve().parents[1]
SCRIPT = PROJECT / "artifacts/narration_script_v3.json"
OUT = PROJECT / "assets/audio/narration-qwen-v3"
BACKUP = OUT / "before-class1-pauses-v4"


def read(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    generator.SCRIPT = SCRIPT
    generator.OUT = OUT
    old_manifest = read(OUT / "narration_manifest.json")
    old_by_id = {p["id"]: p for s in old_manifest["sections"] for p in s["phrases"]}
    tasks = generator.tasks()
    if set(old_by_id) != {str(task["id"]) for task in tasks}:
        raise ValueError("Pause-only revision cannot add or remove phrases")

    changes = []
    results = []
    for task in tasks:
        pid = str(task["id"])
        previous = old_by_id[pid]
        wav = OUT / "phrases" / f"{pid}.wav"
        if previous["text"] != task["text"]:
            raise ValueError(f"Pause-only revision cannot change text: {pid}")
        if generator.sha256(wav) != previous["sha256"]:
            raise ValueError(f"Approved phrase waveform changed: {pid}")
        if float(previous["pause_after"]) != float(task["pause_after"]):
            changes.append({
                "phrase_id": pid,
                "old_pause": previous["pause_after"],
                "new_pause": task["pause_after"],
            })
        results.append({
            **task,
            "file": str(wav),
            "samples": len(generator.read_pcm(wav)),
            "sha256": previous["sha256"],
        })

    if not changes:
        print("No pause changes; refreshing v4 pacing provenance")

    BACKUP.mkdir(parents=True, exist_ok=True)
    for path in (
        SCRIPT,
        OUT / "narration_manifest.json",
        OUT / "captions.v2.json",
        OUT / "word_alignment.v2.json",
        OUT / "subtitle-v2-qa.json",
        OUT / "timeline-rebase-v3.json",
        OUT / "revision-provenance.json",
    ):
        if path.exists():
            destination = BACKUP / path.name
            if not destination.exists():
                shutil.copy2(path, destination)

    generator.assemble(results)
    new_manifest = read(OUT / "narration_manifest.json")
    new_by_id = {p["id"]: p for s in new_manifest["sections"] for p in s["phrases"]}
    for pid, previous in old_by_id.items():
        if new_by_id[pid]["sha256"] != previous["sha256"]:
            raise ValueError(f"Phrase waveform hash changed after assembly: {pid}")

    prior_report_path = OUT / "class1-pauses-v4.json"
    prior_report = read(prior_report_path) if prior_report_path.exists() else None
    report = prior_report if not changes and prior_report else {
        "status": "reassembled-with-no-provider-calls",
        "revision": "v4-class1-pauses",
        "changed_pauses": changes,
        "preserved_phrase_wavs": len(results),
        "previous_duration_seconds": old_manifest["duration_seconds"],
        "duration_seconds": new_manifest["duration_seconds"],
        "duration_delta_seconds": round(
            new_manifest["duration_seconds"] - old_manifest["duration_seconds"], 4
        ),
    }
    generator.write_json(OUT / "class1-pauses-v4.json", report)
    provenance_path = OUT / "revision-provenance.json"
    if provenance_path.exists():
        provenance = read(provenance_path)
        provenance.update({
            "status": "v4-pauses-assembled-awaiting-caption-rebuild",
            "duration_seconds": new_manifest["duration_seconds"],
            "duration_delta_seconds": round(
                new_manifest["duration_seconds"]
                - float(provenance["source_duration_seconds"]), 4
            ),
            "pause_only_changes": PAUSES,
            "pacing_revision": "v4-class1-pauses",
            "limits": "Approved phrase WAVs are unchanged; captions, precision cues, composition, and encoded output require fresh QA.",
        })
        generator.write_json(provenance_path, provenance)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
