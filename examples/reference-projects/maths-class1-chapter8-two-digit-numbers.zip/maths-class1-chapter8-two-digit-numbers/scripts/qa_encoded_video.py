"""Run the technical QA gate for the rendered Maths chapter.

This decodes every encoded video frame, checks the delivery metadata, scans for
black/frozen spans, and correlates every rendered narration section against the
approved mastered chapter audio. Visual contact-sheet review is a separate gate.
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
from pathlib import Path

import numpy as np


def valid_cross_correlation(search: np.ndarray, target: np.ndarray) -> np.ndarray:
    """Return valid-mode cross correlation without requiring SciPy."""
    full_size = len(search) + len(target) - 1
    fft_size = 1 << (full_size - 1).bit_length()
    convolution = np.fft.irfft(
        np.fft.rfft(search, fft_size) * np.fft.rfft(target[::-1], fft_size),
        fft_size,
    )[:full_size]
    start = len(target) - 1
    return convolution[start : start + len(search) - len(target) + 1]


def decode_audio(path: Path) -> np.ndarray:
    result = subprocess.run(
        [
            "ffmpeg",
            "-v",
            "error",
            "-i",
            str(path),
            "-vn",
            "-ar",
            "16000",
            "-ac",
            "1",
            "-f",
            "f32le",
            "pipe:1",
        ],
        check=True,
        stdout=subprocess.PIPE,
    )
    return np.frombuffer(result.stdout, dtype="<f4").copy()


def section_sync(reference: np.ndarray, encoded: np.ndarray, sections: list[dict]) -> list[dict]:
    results = []
    for section in sections:
        section_start = float(section["start"])
        duration = float(section["duration"])
        start = int((section_start + 0.25) * 16000)
        size = min(40000, int(max(0.0, duration - 0.5) * 16000))
        if size <= 0:
            results.append({"section_id": section["id"], "status": "failed", "reason": "empty span"})
            continue
        target = reference[start : start + size]
        lower = max(0, start - 4000)
        upper = min(len(encoded), start + size + 4000)
        search = encoded[lower:upper]
        energy = float(np.dot(target, target))
        if len(search) < size or energy < 0.0001:
            results.append(
                {"section_id": section["id"], "status": "failed", "reason": "missing or silent audio"}
            )
            continue
        values = valid_cross_correlation(search, target)
        peak = int(np.argmax(values))
        matched = search[peak : peak + size]
        score = float(values[peak] / np.sqrt(energy * max(1e-15, float(np.dot(matched, matched)))))
        offset = (lower + peak - start) / 16000
        results.append(
            {
                "section_id": section["id"],
                "offset_seconds": round(offset, 5),
                "correlation": round(score, 5),
                "status": "passed" if abs(offset) <= 0.05 and score >= 0.9 else "failed",
            }
        )
    return results


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--video", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--reference-audio", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--composition-data", type=Path, help="Authored production-data.js, for explicit story/teaching sub-section intervals")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    timeline = json.loads(args.manifest.read_text(encoding="utf-8"))
    probe = json.loads(
        subprocess.check_output(
            [
                "ffprobe",
                "-v",
                "error",
                "-count_frames",
                "-show_format",
                "-show_streams",
                "-of",
                "json",
                str(args.video),
            ],
            text=True,
        )
    )
    (args.out / "ffprobe.json").write_text(json.dumps(probe, indent=2), encoding="utf-8")
    video = next(stream for stream in probe["streams"] if stream["codec_type"] == "video")
    audio = next(stream for stream in probe["streams"] if stream["codec_type"] == "audio")
    expected_duration = float(timeline["duration_seconds"])
    checks = {
        "h264": video["codec_name"] == "h264",
        "1080p": (video["width"], video["height"]) == (1920, 1080),
        "30fps": video["avg_frame_rate"] == "30/1",
        "aac": audio["codec_name"] == "aac",
        "stereo": audio["channels"] == 2,
        "48khz": audio["sample_rate"] == "48000",
        "duration": abs(float(probe["format"]["duration"]) - expected_duration) < 0.10,
    }

    decode = subprocess.run(
        [
            "ffmpeg",
            "-hide_banner",
            "-i",
            str(args.video),
            "-an",
            "-vf",
            "blackdetect=d=0.10:pix_th=0.03,freezedetect=n=-50dB:d=0.65",
            "-f",
            "null",
            "-",
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    (args.out / "frame-decode.log").write_text(decode.stderr, encoding="utf-8")
    blacks = [
        {"start": float(start), "end": float(end)}
        for start, end in re.findall(r"black_start:([\d.]+) black_end:([\d.]+)", decode.stderr)
    ]
    freezes = []
    pending = None
    for line in decode.stderr.splitlines():
        match = re.search(r"freeze_start: ([\d.]+)", line)
        if match:
            pending = float(match.group(1))
        match = re.search(r"freeze_end: ([\d.]+)", line)
        if match and pending is not None:
            freezes.append({"start": pending, "end": float(match.group(1))})
            pending = None
    if pending is not None:
        freezes.append({"start": pending, "end": float(probe["format"]["duration"])})

    story_sections = [section for section in timeline["sections"] if section["mode"] == "story"]
    if args.composition_data:
        raw = args.composition_data.read_text(encoding='utf-8').strip()
        composition = json.loads(raw.removeprefix('window.PRODUCTION_DATA=').removesuffix(';'))
        if abs(composition['duration'] - expected_duration) > 0.001:
            raise ValueError('Composition and narration durations differ; QA inputs are stale')
        story_sections = [{'start': start, 'end': end} for start, end in composition['visualCoverage']['continuousStory']]
    story_freezes = [
        freeze
        for freeze in freezes
        if any(
            min(freeze["end"], float(section["end"]))
            - max(freeze["start"], float(section["start"]))
            > 0.65
            for section in story_sections
        )
    ]
    checks.update(
        all_frames_decoded=decode.returncode == 0,
        no_black_intervals=not blacks,
        no_story_freezes=not story_freezes,
    )

    reference = decode_audio(args.reference_audio)
    encoded = decode_audio(args.video)
    sync = section_sync(reference, encoded, timeline["sections"])
    checks["audio_sync"] = all(item["status"] == "passed" for item in sync)
    report = {
        "status": "technical-pass-visual-review-pending" if all(checks.values()) else "failed",
        "video": str(args.video.resolve()),
        "checks": checks,
        "decoded_video_frames": int(video.get("nb_read_frames", 0)),
        "duration_seconds": float(probe["format"]["duration"]),
        "audio_channels": audio["channels"],
        "black_intervals": blacks,
        "story_freezes": story_freezes,
        "continuous_story_intervals": story_sections,
        "all_freeze_intervals": freezes,
        "audio_sync": sync,
        "semantic_frame_review": "pending encoded contact-sheet review",
        "human_listening_review": "approved source voice; encoded spot-listening pending",
    }
    (args.out / "encoded-qa.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(
        json.dumps(
            {"status": report["status"], "checks": checks, "frames": report["decoded_video_frames"]}
        ),
        flush=True,
    )
    return 0 if all(checks.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
