from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import fitz


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract and render every source PDF page.")
    parser.add_argument("pdf", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--scale", type=float, default=1.8)
    args = parser.parse_args()

    args.output.mkdir(parents=True, exist_ok=True)
    pages_dir = args.output / "pages"
    pages_dir.mkdir(parents=True, exist_ok=True)

    raw = args.pdf.read_bytes()
    document = fitz.open(args.pdf)
    records: list[dict[str, object]] = []
    text_parts: list[str] = []
    matrix = fitz.Matrix(args.scale, args.scale)

    for index, page in enumerate(document):
        number = index + 1
        text = page.get_text("text")
        png_path = pages_dir / f"page-{number:03d}.png"
        page.get_pixmap(matrix=matrix, alpha=False).save(png_path)
        text_parts.append(f"=== PAGE {number} ===\n{text.rstrip()}\n")
        records.append(
            {
                "page": number,
                "width_points": round(page.rect.width, 2),
                "height_points": round(page.rect.height, 2),
                "text_characters": len(text),
                "render": str(png_path.resolve()),
            }
        )

    (args.output / "extracted.txt").write_text("\n".join(text_parts), encoding="utf-8")
    manifest = {
        "source_pdf": str(args.pdf.resolve()),
        "source_sha256": hashlib.sha256(raw).hexdigest(),
        "page_count": len(document),
        "render_scale": args.scale,
        "pages": records,
    }
    (args.output / "source-manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )
    print(json.dumps({"page_count": len(document), "output": str(args.output.resolve())}))


if __name__ == "__main__":
    main()
