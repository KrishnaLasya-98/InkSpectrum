from __future__ import annotations

import hashlib
import json
import subprocess
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[1]
BUILD = PROJECT / "assets/video/manim-build-v2/videos/manim_precision_scenes/1080p30"
OUTPUT = PROJECT / "assets/video/precision-v2"
MANIFEST = PROJECT / "assets/audio/narration-qwen-v1/narration_manifest.json"

SCENES = [
    {
        "id": "P01", "file": "SkipBy2Path.mp4", "output": "skip-count-by-2-v2.mp4",
        "section_id": "S13", "start_phrase_id": "S13-02", "end_phrase_id": "S13-02",
        "media_duration": 6.9,
    },
    {
        "id": "P02", "file": "SkipBy3And4Paths.mp4", "output": "skip-count-by-3-and-4-v2.mp4",
        "section_id": "S14", "start_phrase_id": "S14-01", "end_phrase_id": "S14-03",
        "media_duration": 23.2,
    },
    {
        "id": "P04", "file": "PlaceValueExpandedForm.mp4", "output": "place-value-expanded-form-v2.mp4",
        "section_id": "S16", "start_phrase_id": "S16-03", "end_phrase_id": "S16-05",
        "media_duration": 17.833333,
    },
]


def probe(path: Path) -> dict:
    result = subprocess.run(
        [
            "ffprobe", "-v", "error", "-show_entries",
            "stream=codec_type,codec_name,width,height,pix_fmt,r_frame_rate:format=duration",
            "-of", "json", str(path),
        ],
        check=True, capture_output=True, text=True,
    )
    return json.loads(result.stdout)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def phrase_by_id(section: dict, phrase_id: str) -> dict:
    return next(item for item in section["phrases"] if item["id"] == phrase_id)


def main() -> None:
    narration = json.loads(MANIFEST.read_text(encoding="utf-8"))
    narration_sha256 = sha256(MANIFEST)
    sections = {section["id"]: section for section in narration["sections"]}
    OUTPUT.mkdir(parents=True, exist_ok=True)
    items = []
    for scene in SCENES:
        source = BUILD / scene["file"]
        if not source.exists():
            raise FileNotFoundError(source)
        target = OUTPUT / scene["output"]
        subprocess.run(
            [
                "ffmpeg", "-y", "-v", "error", "-i", str(source), "-map", "0:v:0", "-an",
                "-vf", "fps=30,format=yuv420p,tpad=stop_mode=clone:stop_duration=1.00",
                "-t", f'{scene["media_duration"]:.6f}', "-c:v", "libx264", "-preset", "medium",
                "-crf", "18", "-g", "30", "-keyint_min", "30", "-sc_threshold", "0",
                "-movflags", "+faststart", str(target),
            ],
            check=True,
        )
        media = probe(target)
        video_streams = [stream for stream in media["streams"] if stream["codec_type"] == "video"]
        audio_streams = [stream for stream in media["streams"] if stream["codec_type"] == "audio"]
        if len(video_streams) != 1 or audio_streams:
            raise ValueError(f"Precision media must contain one silent video stream: {target}")
        stream = video_streams[0]
        expected = ("h264", 1920, 1080, "yuv420p", "30/1")
        actual = (stream["codec_name"], stream["width"], stream["height"], stream["pix_fmt"], stream["r_frame_rate"])
        if actual != expected:
            raise ValueError(f"Unexpected precision media specification: {target}: {stream}")
        section = sections[scene["section_id"]]
        first_phrase = phrase_by_id(section, scene["start_phrase_id"])
        last_phrase = phrase_by_id(section, scene["end_phrase_id"])
        start = float(section["start"]) + float(first_phrase["start"])
        end = float(section["start"]) + float(last_phrase["end"])
        media_duration = float(media["format"]["duration"])
        if media_duration + 1 / 30 < end - start:
            raise ValueError(f"Precision clip is shorter than its narration interval: {scene['id']}")
        items.append(
            {
                **scene,
                "phrase_id": scene["start_phrase_id"],
                "source": str(source.relative_to(PROJECT)).replace("\\", "/"),
                "normalized_output": str(target.relative_to(PROJECT)).replace("\\", "/"),
                "start": round(start, 4), "end": round(end, 4), "duration": round(end - start, 4),
                "media_duration": round(media_duration, 4), "sha256": sha256(target), "probe": media,
                "review_status": "pending", "review_evidence": [],
            }
        )
    items.append(
        {
            "id": "P03", "section_id": "S15", "use_in_composition": False,
            "review_status": "excluded",
            "excluded_reason": "The source exercise has nine rows; synchronized HTML rows preserve every prompt without obstruction.",
        }
    )
    output = PROJECT / "artifacts/precision-media.json"
    output.write_text(
        json.dumps(
            {
                "version": "2.0", "engine": "manim-0.19.0",
                "narration_manifest": str(MANIFEST.relative_to(PROJECT)).replace("\\", "/"),
                "narration_manifest_sha256": narration_sha256, "review_status": "pending", "items": items,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print(json.dumps({"staged": len(SCENES), "manifest": str(output), "review_status": "pending"}, indent=2))


if __name__ == "__main__":
    main()
