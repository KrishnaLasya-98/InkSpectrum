async()=>{
  const composition="maths-class1-chapter8-two-digit-numbers";
  const timeline=window.__timelines&&window.__timelines[composition];
  if(!timeline)throw new Error("Maths timeline is not registered");
  const D=window.PRODUCTION_DATA,q=window.MATHS_QA||{};
  const visible=el=>{
    if(!el)return false;
    for(let node=el;node&&node.nodeType===1;node=node.parentElement){
      const s=getComputedStyle(node);
      if(s.visibility==="hidden"||s.display==="none"||Number(s.opacity)<=0.02)return false;
    }
    return true;
  };
  const rect=el=>{const r=el.getBoundingClientRect();return {left:r.left,top:r.top,right:r.right,bottom:r.bottom,width:r.width,height:r.height};};
  const outside=(a,b,t=2)=>a.left<b.left-t||a.top<b.top-t||a.right>b.right+t||a.bottom>b.bottom+t;
  const intersects=(a,b,t=2)=>a.left<b.right-t&&a.right>b.left+t&&a.top<b.bottom-t&&a.bottom>b.top+t;
  const clean=v=>String(v??"").replace(/\s+/g," ").trim();
  const escId=v=>window.CSS&&CSS.escape?CSS.escape(v):String(v).replace(/[^a-zA-Z0-9_-]/g,"\\$&");
  const sectionById=id=>(D.sections||[]).find(s=>s.id===id);
  const samples=[];
  const addSample=(time,kind,id)=>{
    if(!Number.isFinite(time))return;
    samples.push({time:Math.max(0,Math.min(D.duration-.02,time)),kind,id});
  };
  for(const s of D.sections||[]){
    const end=s.end??(s.start+s.duration);
    addSample(s.start+.06,"section-start",s.id);
    addSample((s.start+end)/2,"section-mid",s.id);
    addSample(end-.06,"section-end",s.id);
  }
  for(const p of q.pages||[]){addSample(p.start+.06,"page-start",p.id);addSample((p.start+p.end)/2,"page-mid",p.id);}
  for(const e of q.events||[]){addSample(e.time-.04,"reveal-before",e.target);addSample(e.time+.04,"reveal-after",e.target);}
  const unique=[...new Map(samples.sort((a,b)=>a.time-b.time).map(x=>[x.time.toFixed(4),x])).values()];
  const coverage={};
  for(const b of D.textbookBlocks.blocks){coverage[b.id]={expectedSections:[b.section_id,...(b.also_section_ids||[])],seenSections:new Set(),visibleTexts:new Set(),seenLines:new Set(),seenTableHeaders:new Set(),visibleTimes:[],clipping:[],precisionOverlaps:[]};}
  const stateFindings=[];
  const pageStates=[];
  for(const sample of unique){
    const state=await window.__mathsV2QaSeek(sample.time,false);
    pageStates.push({sample,state});
    timeline.pause().seek(sample.time,false);
    for(const b of D.textbookBlocks.blocks){
      const c=coverage[b.id],nodes=[...document.querySelectorAll(`[data-source-block="${escId(b.id)}"]`)];
      const shown=nodes.filter(visible);
      if(shown.length)c.visibleTimes.push(sample.time);
      for(const el of shown){
        const section=el.closest(".section")?.id?.replace(/^section-/,"")||null;
        if(section)c.seenSections.add(section);
        c.visibleTexts.add(clean(el.textContent));
        const rr=rect(el),card=el.closest(".teaching-card"),bound=card?rect(card):rect(document.getElementById("root"));
        if(outside(rr,bound))c.clipping.push({time:sample.time,element:el.id,rect:rr,bound});
        for(const cue of [...document.querySelectorAll(".precision-cue")].filter(visible)){
          const cr=rect(cue);if(intersects(rr,cr))c.precisionOverlaps.push({time:sample.time,element:el.id,cue:cue.id,rect:rr,cueRect:cr});
        }
      }
      for(let i=0;i<(b.lines||[]).length;i++){
        const el=document.querySelector(`[data-source-line="${escId(b.id)}-${i}"]`);
        if(el&&visible(el)&&clean(el.textContent)===clean(b.lines[i]))c.seenLines.add(i);
      }
      if(b.table_headers){
        for(const header of b.table_headers){
          if(shown.some(el=>[...el.querySelectorAll("span")].some(x=>visible(x)&&clean(x.textContent)===clean(header))))c.seenTableHeaders.add(header);
        }
      }
    }
  }
  const sourceResults=[];
  for(const b of D.textbookBlocks.blocks){
    const c=coverage[b.id],allNodes=[...document.querySelectorAll(`[data-source-block="${escId(b.id)}"]`)];
    const domText=clean(allNodes.map(x=>x.textContent).join(" ")),visibleText=clean([...c.visibleTexts].join(" "));
    const missing=[];
    if(!allNodes.length)missing.push("block-node");
    if(b.heading&&!domText.includes(clean(b.heading)))missing.push("heading-dom");
    else if(b.heading&&!visibleText.includes(clean(b.heading)))missing.push("heading-not-visible");
    if(b.subheading&&!domText.includes(clean(b.subheading)))missing.push("subheading-dom");
    else if(b.subheading&&!visibleText.includes(clean(b.subheading)))missing.push("subheading-not-visible");
    for(let i=0;i<(b.lines||[]).length;i++)if(!c.seenLines.has(i))missing.push(`visible-line-${i}`);
    for(const h of b.table_headers||[])if(!c.seenTableHeaders.has(h))missing.push(`visible-table-header:${h}`);
    const seenSections=[...c.seenSections].sort(),missingSections=c.expectedSections.filter(x=>!seenSections.includes(x));
    const wrongSections=seenSections.filter(x=>!c.expectedSections.includes(x));
    sourceResults.push({id:b.id,expectedSections:c.expectedSections,seenSections,missingSections,wrongSections,visibleTimes:c.visibleTimes,missing,clipping:c.clipping,precisionOverlaps:c.precisionOverlaps});
  }

  const scanSection=(sectionId,selector,measure)=>{
    const s=sectionById(sectionId),end=s.end??(s.start+s.duration),states=[];
    for(let t=s.start+.02;t<end;t+=.05){timeline.pause().seek(t,false);const el=document.querySelector(selector);if(el&&visible(el))states.push({time:t,...measure(el)});}
    return states;
  };
  const recordResults=[];
  for(const id of ["record-crossed-two","record-crossed-three","record-ticked-four"]){
    const block=(D.textbookBlocks.blocks||[]).find(x=>x.id===id),sectionId=block.section_id;
    const states=scanSection(sectionId,`[data-record-grid="${id}"]`,el=>{
      const cells=[...el.querySelectorAll(".record-cell")],givens=cells.filter(x=>x.classList.contains("source-given"));
      const answers=cells.filter(x=>x.classList.contains("source-blank")&&[...x.querySelectorAll(".answer-reveal")].some(visible));
      return {cellCount:cells.length,givenVisible:givens.filter(visible).length,answerVisible:answers.length};
    });
    const distinct=[...new Map(states.map(x=>[`${x.cellCount}/${x.givenVisible}/${x.answerVisible}`,x])).values()];
    const expected=block.response_grid;
    recordResults.push({id,expected,states:distinct,hasPrefillState:states.some(x=>x.cellCount===expected.required_answer_count&&x.givenVisible===expected.prefilled_count&&x.answerVisible===0),hasRevealState:states.some(x=>x.cellCount===expected.required_answer_count&&x.givenVisible===expected.prefilled_count&&x.answerVisible===expected.blank_count)});
  }
  const activityBlock=(D.textbookBlocks.blocks||[]).find(x=>x.id==="activity-setup"),activityStates=scanSection("S19","#S19-bindis",el=>{
    const cards=[...el.querySelectorAll(".circle-card")],revealed=cards.filter(card=>[...card.querySelectorAll(".answer-reveal")].some(visible));
    return {cardCount:cards.length,revealedCards:revealed.length};
  });
  const activityProgress=[...new Set(activityStates.map(x=>x.revealedCards))];
  const buildNames=[...document.querySelectorAll(".build-state")].map(el=>{
    const number=Number(el.dataset.number),nameEl=el.querySelector(".build-name"),expected=D.sourceContent.S08_number_names.number_names_1_to_100[number-1];
    return {number,actual:clean(nameEl?.textContent),expected:clean(expected),ok:Boolean(nameEl)&&clean(nameEl.textContent)===clean(expected)};
  });
  const wordQa=window.__mathsV2QaAllWords();
  return {
    version:"3.0",sampleCount:unique.length,pageStates,sourceResults,recordResults,
    activity:{expected:activityBlock.response_grid,progress:activityProgress,hasInitial:activityProgress.includes(0),hasSequential:[0,1,2,3,4].every(x=>activityProgress.includes(x))},
    buildNames:{checked:buildNames.length,failures:buildNames.filter(x=>!x.ok)},
    captions:wordQa,
    missingCues:q.missingCues||[],buildCueCount:(q.buildCues||[]).length
  };
}
