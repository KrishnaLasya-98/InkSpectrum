"""Create clearly labelled, bounded listening choices without new synthesis."""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

import numpy as np
from generate_narration import read_pcm, sha256, write_json, write_pcm

PROJECT = Path(__file__).resolve().parents[1]
AUDIO = PROJECT / "assets/audio/narration-qwen-v3"
DEST = PROJECT / "artifacts/listening-review-v3"


def main():
    choices = []
    for name, directory, label in (
        ("activity-A-stickers", AUDIO / "before-bindi-source-refinement", "Previously clear sticker paraphrase; textbook word bindis is not spoken"),
        ("activity-B-bindis", AUDIO, "Source-preserving bindis wording; pronunciation requires user listening"),
    ):
        manifest = json.loads((directory / "narration_manifest.json").read_text(encoding="utf-8"))
        phrases = [p for s in manifest["sections"] for p in s["phrases"] if p["id"] in {"S19-01", "S19-02"}]
        parts = [np.zeros(round(.2 * 48000), dtype="<i2")]
        evidence = []
        for phrase in phrases:
            wav = directory / "phrases" / f"{phrase['id']}.wav"
            if sha256(wav) != phrase["sha256"]:
                raise ValueError(f"Listening source hash mismatch: {wav}")
            parts.extend([read_pcm(wav), np.zeros(round(phrase["pause_after"] * 48000), dtype="<i2")])
            evidence.append({"id": phrase["id"], "text": phrase["text"], "sha256": phrase["sha256"]})
        output_wav, output_mp3 = DEST / f"{name}.wav", DEST / f"{name}.mp3"
        signal = np.concatenate(parts)
        write_pcm(output_wav, signal)
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(output_wav), "-af", "loudnorm=I=-16:TP=-1.5:LRA=7",
                        "-ar", "48000", "-ac", "1", "-c:a", "libmp3lame", "-b:a", "192k", str(output_mp3)], check=True)
        choices.append({"name": name, "label": label, "file": str(output_mp3), "duration_seconds": round(len(signal) / 48000, 4), "phrases": evidence})
    report = {"status": "blocked-pending-user-listening", "question": "In sample B, is bindis pronounced correctly and clearly? Sample A is the previous sticker paraphrase for comparison.",
              "candidate_attempts_per_phrase": 1, "new_provider_requests": 2, "no_further_retry_authorized": True,
              "recognition_disagreement": {"S19-01": {"small.en": "bindes", "base": "bindess"}},
              "limits": "Automatic recognition can miss uncommon words. No human listening approval is claimed. Do not render the new revision until this check is resolved.",
              "choices": choices}
    write_json(DEST / "review.json", report)
    provenance = json.loads((AUDIO / "revision-provenance.json").read_text(encoding="utf-8"))
    provenance.update({"status": "blocked-pending-user-listening", "material_refinement_phrase_ids": ["S19-01", "S19-02"],
                       "listening_review": str(DEST / "review.json"), "limits": report["limits"]})
    write_json(AUDIO / "revision-provenance.json", provenance)
    print(json.dumps({"status": report["status"], "choices": [{k: c[k] for k in ("name", "file", "duration_seconds")} for c in choices]}, indent=2))


if __name__ == "__main__":
    main()
