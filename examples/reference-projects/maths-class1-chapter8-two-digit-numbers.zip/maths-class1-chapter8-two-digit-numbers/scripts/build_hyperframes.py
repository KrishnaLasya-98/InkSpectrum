from __future__ import annotations

import json
import argparse
import hashlib
import shutil
import subprocess
from pathlib import Path
from subtitle_v2 import load_verified_captions

PROJECT = Path(__file__).resolve().parents[1]
HF = PROJECT / "hyperframes-final"
AUDIO = PROJECT / "assets/audio/narration-qwen-v1"


def probe_duration(path: Path) -> float:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nk=1:nw=1", str(path)],
        check=True,
        capture_output=True,
        text=True,
    )
    return float(result.stdout.strip())


def copy_file(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def coverage_gaps(intervals: list[tuple[float, float]], start: float, end: float) -> list[list[float]]:
    """Continuous coverage, not a count of files. Ignore intervals outside the window."""
    cursor = start
    gaps = []
    for left, right in sorted(intervals):
        if right <= start or left >= end:
            continue
        left, right = max(start, left), min(end, right)
        if left > cursor + 0.001:
            gaps.append([cursor, left])
        cursor = max(cursor, right)
    if cursor < end - 0.001:
        gaps.append([cursor, end])
    return gaps


def main() -> None:
    global AUDIO
    parser = argparse.ArgumentParser()
    parser.add_argument('--preview', action='store_true', help='Allow missing story media for UI QA; never labels output complete.')
    parser.add_argument('--revision', choices=['v2', 'v3'], default='v2')
    args = parser.parse_args()
    revision = args.revision
    if revision == 'v3':
        AUDIO = PROJECT / 'assets/audio/narration-qwen-v3'
    manifest = json.loads((AUDIO / "narration_manifest.json").read_text(encoding="utf-8"))
    captions = load_verified_captions(AUDIO, manifest)
    source_content = json.loads((PROJECT / 'artifacts/source_content_v2.json').read_text(encoding='utf-8'))
    ui = json.loads((PROJECT / "artifacts/ui_content.json").read_text(encoding="utf-8"))
    media_plan = json.loads((PROJECT / "artifacts/media_plan.json").read_text(encoding="utf-8"))
    precision_path = PROJECT / ('artifacts/precision-media-v3.json' if revision == 'v3' else 'artifacts/precision-media.json')
    precision_document = json.loads(precision_path.read_text(encoding="utf-8"))
    if precision_document.get('narration_manifest_sha256') != hashlib.sha256((AUDIO / 'narration_manifest.json').read_bytes()).hexdigest():
        raise ValueError('Precision media timing is stale for the current narration manifest')
    if precision_document.get('review_status') != 'accepted' and not args.preview:
        raise ValueError('Precision assets have not passed independent visual review')
    precision_media = precision_document['items']
    HF.mkdir(parents=True, exist_ok=True)
    copy_file(
        PROJECT.parent / "english-class1-lesson1-at-the-beach/hyperframes-final/vendor/gsap.min.js",
        HF / "vendor/gsap.min.js",
    )

    section_by_id = {section["id"]: section for section in manifest["sections"]}
    videos = []
    missing_media = []
    section_cursor = {}
    for scene in media_plan["scenes"]:
        if scene.get("use_in_composition", True) is False:
            continue
        source = PROJECT / scene.get("normalized_output", scene["output"])
        if not source.exists():
            missing_media.append(scene['id'])
            continue
        target = HF / "assets/video" / source.name
        copy_file(source, target)
        section = section_by_id[scene["sections"][0]]
        section_index = manifest['sections'].index(section)
        section_end = (manifest['sections'][section_index + 1]['start'] if section_index + 1 < len(manifest['sections']) else manifest['duration_seconds'])
        start = section['start'] + float(scene.get('start_offset', section_cursor.get(section['id'], 0)))
        duration = min(probe_duration(source), float(scene.get("usable_duration", 999)), section_end - start)
        if duration <= 0:
            raise ValueError(f"No usable interval for {scene['id']}")
        section_cursor[section['id']] = start + duration - section['start']
        videos.append(
            {
                "id": scene["id"].lower(),
                "src": f"assets/video/{source.name}",
                "start": start,
                "end": start + duration,
                "duration": duration,
                "section_id": section["id"],
                "kind": "story",
            }
        )

    for item in precision_media:
        if item.get('use_in_composition', True) is False or item['id'] == 'P03':
            continue  # S15 uses complete source exercise rows with synchronized HTML reveals.
        source = PROJECT / item["normalized_output"]
        if not source.exists():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != item['sha256']:
            raise ValueError(f"Precision clip changed after review: {item['id']}")
        target = HF / "assets/video" / source.name
        copy_file(source, target)
        videos.append(
            {
                "id": item["id"].lower(),
                "src": f"assets/video/{source.name}",
                "start": item["start"],
                "end": item["end"],
                "duration": item["duration"],
                "section_id": item["section_id"],
                "kind": "precision",
            }
        )

    sections = []
    audio_tags = []
    for index, section in enumerate(manifest["sections"]):
        source = PROJECT / section["audio"]
        target = HF / "assets/audio" / source.name
        copy_file(source, target)
        audio_tags.append(
            f'<audio data-hf-id="audio-{section["id"].lower()}" id="audio-{section["id"].lower()}" class="clip" src="assets/audio/{source.name}" preload="auto" data-start="{section["start"]:.4f}" data-duration="{section["duration"]:.4f}" data-track-index="{400 + index}" data-volume="1"></audio>'
        )
        sections.append({**section, "ui": ui[section["id"]]})

    video_tags = [
        f'<div data-hf-id="wrap-{video["id"]}" id="wrap-{video["id"]}" class="video-cue"><video data-hf-id="video-{video["id"]}" id="video-{video["id"]}" class="clip media" src="{video["src"]}" muted playsinline preload="auto" data-start="{video["start"]:.4f}" data-duration="{video["duration"]:.4f}" data-track-index="{100 + index}"></video></div>'
        for index, video in enumerate(videos) if video["kind"] == "story"
    ]
    precision_tags = [
        f'<div data-hf-id="wrap-{video["id"]}" id="wrap-{video["id"]}" class="video-cue precision-cue"><video data-hf-id="video-{video["id"]}" id="video-{video["id"]}" class="clip media" src="{video["src"]}" muted playsinline preload="auto" data-start="{video["start"]:.4f}" data-duration="{video["duration"]:.4f}" data-track-index="{200 + index}"></video></div>'
        for index, video in enumerate(videos) if video["kind"] == "precision"
    ]

    duration = float(manifest["duration_seconds"])
    # After the spoken chapter title, S01 deliberately enters source-grounded
    # recall/learning UI. Do not stretch a title shot over those teaching lines.
    title_word = next(w for page in captions for w in page['words'] if w['phrase_id'] == 'S01-02' and w['word'].lower() == 'two')
    intro_end = round(title_word['start'] - 0.2, 4)
    intro_intervals = sorted((v['start'], v['end']) for v in videos if v['section_id'] == 'S01')
    intro_gaps = coverage_gaps(intro_intervals, 0, intro_end)
    if not args.preview and (missing_media or intro_gaps):
        raise ValueError(f'Final media gate: missing={missing_media}, intro gaps={intro_gaps}')
    data = {"version": "2.0", "duration": duration, "sections": sections, "videos": videos, "captions": captions, "sourceContent": source_content,
            "visualCoverage": {"continuousStory": [[0, intro_end]], "intentionalTeaching": [[intro_end, duration]],
                               "reason": "After Class/Chapter introduction, exact animated 51-to-100 range, source Recall and exercises use English-v7 teaching UI."}}
    if revision == 'v3':
        data['version'] = '3.0'
        data['textbookBlocks'] = json.loads((PROJECT / 'artifacts/textbook-blocks-v3.json').read_text(encoding='utf-8'))
    (HF / "production-data.js").write_text(
        "window.PRODUCTION_DATA=" + json.dumps(data, ensure_ascii=False, separators=(",", ":")) + ";\n",
        encoding="utf-8",
    )
    (HF / "hyperframes.json").write_text(
        json.dumps(
            {
                "name": "Mathematics Class 1 - Chapter 8 - 2 Digit Numbers",
                "compositionId": "maths-class1-chapter8-two-digit-numbers",
                "width": 1920,
                "height": 1080,
                "fps": 30,
                "duration": duration,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    for filename in (f'maths-ui-{revision}.css', f'maths-ui-{revision}.js'):
        copy_file(PROJECT / 'scripts' / filename, HF / filename)
    template = (PROJECT / f"scripts/hyperframes-template-{revision}.html").read_text(encoding="utf-8")
    template = template.replace("__DURATION__", f"{duration:.4f}")
    template = template.replace("<!-- VIDEO_TAGS -->", "\n".join(video_tags))
    template = template.replace("<!-- PRECISION_TAGS -->", "\n".join(precision_tags))
    template = template.replace("<!-- AUDIO_TAGS -->", "\n".join(audio_tags))
    for filename in ('production-data.js', f'maths-ui-{revision}.js', f'maths-ui-{revision}.css'):
        file_revision = hashlib.sha256((HF / filename).read_bytes()).hexdigest()[:12]
        template = template.replace(f'"{filename}"', f'"{filename}?v={file_revision}"')
    (HF / "index.html").write_text(template, encoding="utf-8")
    planned_story_video_count = sum(scene.get("use_in_composition", True) is not False for scene in media_plan["scenes"])
    planned_video_count = planned_story_video_count + sum(i.get('use_in_composition', True) is not False and i['id'] != 'P03' for i in precision_media)
    coverage = {
        "revision": revision,
        "status": "preview-only" if args.preview else "built-awaiting-visual-and-encoded-QA",
        "missing_media": missing_media,
        "intro_motion_gaps": intro_gaps,
        "intro_story_end": intro_end,
        "subtitle_qa": "verified-v2-manifest-and-audio-hashes",
        "appearance_reference": "english-class1-at-the-beach-final-v7.mp4",
        "source_pages": list(range(1, 17)),
        "sections": len(sections),
        "audio_tracks": len(audio_tags),
        "video_assets_planned": planned_video_count,
        "video_assets_staged": len(videos),
        "story_video_assets": sum(video["kind"] == "story" for video in videos),
        "precision_video_assets": sum(video["kind"] == "precision" for video in videos),
        "video_assets_reused": 0,
        "captions": len(captions),
        "duration_seconds": duration,
        "input_sha256": {name: hashlib.sha256((HF / name).read_bytes()).hexdigest() for name in ('index.html', 'production-data.js', f'maths-ui-{revision}.js', f'maths-ui-{revision}.css')},
        "narration_manifest_sha256": hashlib.sha256((AUDIO / 'narration_manifest.json').read_bytes()).hexdigest(),
    }
    (PROJECT / "artifacts/composition-coverage.json").write_text(json.dumps(coverage, indent=2), encoding="utf-8")
    print(json.dumps(coverage, indent=2))


if __name__ == "__main__":
    main()
