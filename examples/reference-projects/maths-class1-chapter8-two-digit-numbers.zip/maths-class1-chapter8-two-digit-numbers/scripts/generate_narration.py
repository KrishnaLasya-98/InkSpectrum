from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
import wave
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import requests

PROJECT = Path(__file__).resolve().parents[1]
OPENMONTAGE = PROJECT.parents[1]
sys.path.insert(0, str(OPENMONTAGE))

from tools.voice.voice_synthesis_pipeline import _api_key, _download, _poll_for_audio  # noqa: E402

SCRIPT = PROJECT / "artifacts/narration_script.json"
OUT = PROJECT / "assets/audio/narration-qwen-v1"
REFERENCE_LOCK = (
    PROJECT.parent
    / "english-class1-lesson1-at-the-beach/assets/audio/narration-indian-qwen-v4/voice-lock.json"
)
REFERENCE_APPROVAL = (
    PROJECT.parent
    / "english-class1-lesson1-at-the-beach/assets/audio/delivery-review-indian-qwen-v1/review-status.json"
)
ENDPOINT = "https://modelslab.com/api/v6/voice/text_to_audio"


def write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_pcm(path: Path) -> np.ndarray:
    with wave.open(str(path), "rb") as source:
        if source.getframerate() != 48000 or source.getnchannels() != 1 or source.getsampwidth() != 2:
            raise ValueError(f"Unexpected PCM format: {path}")
        return np.frombuffer(source.readframes(source.getnframes()), dtype="<i2").copy()


def write_pcm(path: Path, signal: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as dest:
        dest.setparams((1, 2, 48000, 0, "NONE", "not compressed"))
        dest.writeframes(signal.astype("<i2").tobytes())


def approved_voice() -> dict[str, str]:
    approval = json.loads(REFERENCE_APPROVAL.read_text(encoding="utf-8"))
    if approval.get("status") != "user-approved-voice-sample":
        raise ValueError("The shared Indian-English reference voice is not user approved")
    lock = json.loads(REFERENCE_LOCK.read_text(encoding="utf-8"))
    if not lock.get("init_audio"):
        raise ValueError("Approved voice lock has no reference URL")
    write_json(
        OUT / "voice-provenance.json",
        {
            "identity": "user-approved Indian-English Qwen voice",
            "reference_lock": str(REFERENCE_LOCK),
            "reference_sha256": lock.get("reference_sha256"),
            "approval": str(REFERENCE_APPROVAL),
            "final_narration_is_new": True,
        },
    )
    return {"model_id": "qwen-tts", "init_audio": lock["init_audio"], "language": "english"}


def tasks() -> list[dict[str, object]]:
    script = json.loads(SCRIPT.read_text(encoding="utf-8"))
    result: list[dict[str, object]] = []
    for section in script["sections"]:
        for index, phrase in enumerate(section["phrases"], start=1):
            result.append(
                {
                    "id": f"{section['id']}-{index:02d}",
                    "section_id": section["id"],
                    "text": phrase["text"],
                    "pause_after": float(phrase["pause_after"]),
                }
            )
    return result


def generate_phrase(task: dict[str, object], key: str, voice: dict[str, str]) -> dict[str, object]:
    phrase_dir = OUT / "phrases"
    phrase_dir.mkdir(parents=True, exist_ok=True)
    phrase_id = str(task["id"])
    raw = phrase_dir / f"{phrase_id}.provider-audio"
    wav = phrase_dir / f"{phrase_id}.wav"
    receipt_path = phrase_dir / f"{phrase_id}.receipt.json"
    settings = {**voice, "prompt": task["text"]}
    receipt = json.loads(receipt_path.read_text(encoding="utf-8")) if receipt_path.exists() else None
    if receipt and receipt.get("request") != settings:
        raise ValueError(f"Cached request mismatch for {phrase_id}")
    if not raw.exists():
        if not receipt:
            response = requests.post(ENDPOINT, json={"key": key, **settings}, timeout=120)
            data = response.json()
            receipt = {
                "request": settings,
                "id": data.get("id"),
                "status": data.get("status"),
                "http_status": response.status_code,
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
            links = data.get("output") or data.get("url")
            if data.get("status") == "success":
                receipt["output_url"] = links[0] if isinstance(links, list) and links else links
            write_json(receipt_path, receipt)
        if receipt.get("status") == "success":
            url = receipt.get("output_url")
        elif receipt.get("status") == "processing" and receipt.get("id"):
            url = _poll_for_audio(str(receipt["id"]), key)
        else:
            raise RuntimeError(f"{phrase_id}: provider status {receipt.get('status')}")
        if not url:
            raise RuntimeError(f"{phrase_id}: provider returned no audio URL")
        _download(str(url), raw)
    subprocess.run(
        ["ffmpeg", "-y", "-v", "error", "-i", str(raw), "-af", "atempo=0.90", "-ar", "48000", "-ac", "1", "-c:a", "pcm_s16le", str(wav)],
        check=True,
    )
    signal = read_pcm(wav)
    active = np.flatnonzero(np.abs(signal.astype(np.int32)) > 140)
    if not len(active):
        raise ValueError(f"Silent provider output: {phrase_id}")
    signal = signal[max(0, int(active[0]) - 5760) : min(len(signal), int(active[-1]) + 5761)]
    write_pcm(wav, signal)
    print(f"Generated {phrase_id}: {len(signal) / 48000:.2f}s", flush=True)
    return {**task, "file": str(wav), "samples": len(signal), "sha256": sha256(wav)}


def assemble(results: list[dict[str, object]]) -> None:
    script = json.loads(SCRIPT.read_text(encoding="utf-8"))
    by_id = {str(item["id"]): item for item in results}
    chapter_parts: list[np.ndarray] = []
    chapter_cursor = 0.0
    section_manifests: list[dict[str, object]] = []
    alignment: list[dict[str, object]] = []

    for section in script["sections"]:
        section_parts = [np.zeros(round(0.20 * 48000), dtype="<i2")]
        section_start = chapter_cursor
        local_cursor = 0.20
        phrase_records = []
        for index, source_phrase in enumerate(section["phrases"], start=1):
            phrase_id = f"{section['id']}-{index:02d}"
            result = by_id[phrase_id]
            signal = read_pcm(Path(str(result["file"])))
            start = local_cursor
            end = start + len(signal) / 48000
            pause = float(source_phrase["pause_after"])
            phrase_record = {
                "id": phrase_id,
                "text": source_phrase["text"],
                "start": round(start, 4),
                "end": round(end, 4),
                "pause_after": pause,
                "sha256": result["sha256"],
            }
            phrase_records.append(phrase_record)
            words = list(re.finditer(r"\b[\w'-]+\b", source_phrase["text"]))
            weights = [max(1, len(match.group(0))) for match in words]
            total_weight = sum(weights) or 1
            weighted_cursor = start
            for match, weight in zip(words, weights):
                word_end = weighted_cursor + (end - start) * weight / total_weight
                alignment.append(
                    {
                        "section_id": section["id"],
                        "phrase_id": phrase_id,
                        "word": match.group(0),
                        "start": round(section_start + weighted_cursor, 4),
                        "end": round(section_start + word_end, 4),
                        "timing_source": "phrase-duration-weighted-pending-asr-refinement",
                    }
                )
                weighted_cursor = word_end
            section_parts.extend([signal, np.zeros(round(pause * 48000), dtype="<i2")])
            local_cursor = end + pause
        section_signal = np.concatenate(section_parts)
        section_wav = OUT / f"{section['id']}.wav"
        write_pcm(section_wav, section_signal)
        section_end = section_start + len(section_signal) / 48000
        section_manifests.append(
            {
                "id": section["id"],
                "heading": section["heading"],
                "mode": section["mode"],
                "source_pages": section["source_pages"],
                "start": round(section_start, 4),
                "end": round(section_end, 4),
                "duration": round(section_end - section_start, 4),
                "audio": str(section_wav.relative_to(PROJECT)).replace("\\", "/"),
                "phrases": phrase_records,
            }
        )
        chapter_parts.extend([section_signal, np.zeros(round(0.40 * 48000), dtype="<i2")])
        chapter_cursor = section_end + 0.40

    unmastered = OUT / "chapter-unmastered.wav"
    write_pcm(unmastered, np.concatenate(chapter_parts))
    final = OUT / "chapter-review.wav"
    subprocess.run(
        ["ffmpeg", "-y", "-v", "error", "-i", str(unmastered), "-af", "loudnorm=I=-16:TP=-1.5:LRA=7", "-ar", "48000", "-ac", "1", str(final)],
        check=True,
    )
    subprocess.run(
        ["ffmpeg", "-y", "-v", "error", "-i", str(final), "-c:a", "libmp3lame", "-b:a", "192k", str(OUT / "chapter-review.mp3")],
        check=True,
    )
    manifest = {
        "status": "generated-awaiting-listening-review",
        "source_script": str(SCRIPT),
        "duration_seconds": round(len(read_pcm(final)) / 48000, 4),
        "sample_rate": 48000,
        "channels": 1,
        "sections": section_manifests,
        "phrases": len(results),
        "word_alignment_status": "provisional; refine with local ASR",
        "delivery_tempo": 0.90,
    }
    write_json(OUT / "narration_manifest.json", manifest)
    write_json(OUT / "word_alignment.provisional.json", {"words": alignment})
    print(f"Narration ready: {final} ({manifest['duration_seconds']:.2f}s)", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--section", action="append")
    parser.add_argument("--replace-phrase", action="append")
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    voice = approved_voice()
    key = _api_key()
    all_tasks = tasks()
    replace_ids = set(args.replace_phrase or [])
    known_ids = {str(task["id"]) for task in all_tasks}
    unknown_ids = replace_ids - known_ids
    if unknown_ids:
        raise ValueError(f"Unknown phrase ids: {sorted(unknown_ids)}")
    if replace_ids:
        backup_dir = OUT / "phrases-before-repair-v1"
        backup_dir.mkdir(parents=True, exist_ok=True)
        for phrase_id in sorted(replace_ids):
            for suffix in (".provider-audio", ".receipt.json", ".wav"):
                source = OUT / "phrases" / f"{phrase_id}{suffix}"
                if not source.exists():
                    continue
                target = backup_dir / source.name
                if not target.exists():
                    shutil.copy2(source, target)
                source.unlink()
    selected = [
        task
        for task in all_tasks
        if (not args.section or task["section_id"] in set(args.section))
        and (not replace_ids or task["id"] in replace_ids)
    ]
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        generated = list(pool.map(lambda task: generate_phrase(task, key, voice), selected))
    if args.section and not replace_ids:
        print("Partial generation complete; run without --section to assemble the chapter.")
        return
    if replace_ids:
        generated_by_id = {str(item["id"]): item for item in generated}
        for task in all_tasks:
            phrase_id = str(task["id"])
            if phrase_id in generated_by_id:
                continue
            wav = OUT / "phrases" / f"{phrase_id}.wav"
            if not wav.exists():
                raise FileNotFoundError(f"Missing cached phrase audio: {wav}")
            generated_by_id[phrase_id] = {
                **task,
                "file": str(wav),
                "samples": len(read_pcm(wav)),
                "sha256": sha256(wav),
            }
        assemble([generated_by_id[str(task["id"])] for task in all_tasks])
    else:
        assemble(generated)


if __name__ == "__main__":
    main()
