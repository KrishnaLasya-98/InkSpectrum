from __future__ import annotations

import json
import re
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
QA = PROJECT / "assets/audio/narration-qwen-v1/alignment_qa.json"

ONES = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"]
TENS = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]


def number_words(value: int) -> str:
    if value < 20:
        return ONES[value]
    if value < 100:
        return TENS[value // 10] + (" " + ONES[value % 10] if value % 10 else "")
    if value == 100:
        return "one hundred"
    return str(value)


def canonical_text(text: str) -> str:
    """Normalize only meaning-preserving number/ASR notation variants.

    The recognizers commonly emit ``7-10s`` for "seven tens", ``2s`` for
    "twos", and digits for spoken number names.  Keep ordinary lexical words
    intact so errors such as "and" -> "in" or "make" -> "makes" still fail.
    """
    value = text.lower().replace("colour", "color").replace("neighbour", "neighbor")
    value = re.sub(r"\bone['’]s\b", "ones", value)
    value = re.sub(
        r"\b(\d{1,3})\s*[- ]\s*10s\b",
        lambda match: f"{number_words(int(match.group(1)))} tens",
        value,
    )
    value = re.sub(
        r"\b(\d{1,3})\s*[- ]\s*1s\b",
        lambda match: f"{number_words(int(match.group(1)))} ones",
        value,
    )
    value = re.sub(
        r"\b(\d{1,3})\s*[- ]\s*1\b",
        lambda match: f"{number_words(int(match.group(1)))} one",
        value,
    )
    value = re.sub(
        r"\b(\d{1,2})s\b",
        lambda match: f"{number_words(int(match.group(1)))}s",
        value,
    )
    value = re.sub(r"\b\d{1,3}\b", lambda match: number_words(int(match.group(0))), value)
    # A "100 chart" is the standard short name for a one-to-one-hundred
    # chart.  Limit this equivalence to the chart noun; do not drop ranges in
    # general narration.
    value = re.sub(r"\bone[\s-]+to[\s-]+one[\s-]+hundred\s+chart\b", "one hundred chart", value)
    return value


def tokens(text: str) -> list[str]:
    return re.findall(r"[a-z]+", canonical_text(text))


def wer(reference: str, hypothesis: str) -> float:
    expected, actual = tokens(reference), tokens(hypothesis)
    previous = list(range(len(actual) + 1))
    for row, expected_word in enumerate(expected, start=1):
        current = [row]
        for column, actual_word in enumerate(actual, start=1):
            current.append(min(current[-1] + 1, previous[column] + 1, previous[column - 1] + (expected_word != actual_word)))
        previous = current
    return previous[-1] / max(1, len(expected))


def main() -> None:
    report = json.loads(QA.read_text(encoding="utf-8"))
    for item in report["items"]:
        item["canonical_wer"] = round(wer(item["expected"], item["transcript"]), 4)
        item["status"] = "pass" if item["canonical_wer"] <= 0.12 and item["mean_probability"] >= 0.70 else "review"
        item["equivalence"] = (
            "Digits, spoken number names, numeric plurals, ASR count notation, "
            "and limited spelling variants are treated as equivalent"
        )
    report["passed"] = sum(item["status"] == "pass" for item in report["items"])
    report["review"] = sum(item["status"] == "review" for item in report["items"])
    report["status"] = "pass" if report["review"] == 0 else "listening-review-required"
    QA.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({"phrases": report["phrases"], "passed": report["passed"], "review": report["review"]}))


if __name__ == "__main__":
    main()
