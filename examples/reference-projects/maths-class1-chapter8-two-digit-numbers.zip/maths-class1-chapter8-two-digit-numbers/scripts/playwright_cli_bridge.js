'use strict';

// Windows PowerShell can rewrite quotes inside native command arguments. This
// tiny bridge preserves each Playwright CLI argument exactly while continuing
// to use the repository-approved CLI wrapper.
const {spawnSync}=require('child_process');
const bash='C:\\Program Files\\Git\\bin\\bash.exe';
const wrapper='/c/Users/user/.codex/skills/playwright/scripts/playwright_cli.sh';
const [session,...args]=process.argv.slice(2);
if(!session||!args.length){
  process.stderr.write('usage: node playwright_cli_bridge.js SESSION COMMAND [ARGS...]\n');
  process.exit(64);
}
const result=spawnSync(bash,[wrapper,'--session',session,...args],{encoding:'utf8',stdio:['ignore','pipe','pipe']});
if(result.stdout)process.stdout.write(result.stdout);
if(result.stderr)process.stderr.write(result.stderr);
if(result.error){process.stderr.write(String(result.error));process.exit(1);}
process.exit(result.status??1);
