async()=>{
  const visible=(el)=>{
    if(!el)return false;
    for(let node=el;node&&node.nodeType===1;node=node.parentElement){
      const s=getComputedStyle(node);
      if(s.visibility==="hidden"||s.display==="none"||Number(s.opacity)<=0.02)return false;
    }
    return true;
  };
  const rect=(el)=>{
    const r=el.getBoundingClientRect();
    return {left:r.left,top:r.top,right:r.right,bottom:r.bottom,width:r.width,height:r.height};
  };
  const outside=(inner,outer,tolerance=1)=>inner.left<outer.left-tolerance||inner.top<outer.top-tolerance||inner.right>outer.right+tolerance||inner.bottom>outer.bottom+tolerance;
  window.__mathsV2QaSeek=async(t,seekMedia=true)=>{
    const composition="maths-class1-chapter8-two-digit-numbers";
    const timeline=window.__timelines&&window.__timelines[composition];
    if(!timeline)throw new Error("Maths timeline is not registered");
    timeline.pause().seek(t,false);
    const activeVideos=[];
    const mediaSeekFailures=[];
    for(const media of document.querySelectorAll("video[data-start]")){
      const start=Number(media.dataset.start),duration=Number(media.dataset.duration);
      media.pause();
      if(t>=start&&t<start+duration){
        const target=Math.max(0,Math.min(duration-.04,t-start));
        if(seekMedia&&Number.isFinite(target)&&Math.abs(media.currentTime-target)>.025){
          await new Promise(resolve=>{
            let done=false;
            const finish=()=>{if(!done){done=true;resolve();}};
            media.addEventListener("seeked",finish,{once:true});
            try{media.currentTime=target;}catch(_){finish();}
            setTimeout(finish,2500);
          });
        }
        if(seekMedia&&Math.abs(media.currentTime-target)>.08)mediaSeekFailures.push({id:media.id,target,actual:media.currentTime,readyState:media.readyState,networkState:media.networkState});
        activeVideos.push(media.id);
      }
    }
    await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
    const root=document.getElementById("root"),rootRect=rect(root);
    const activeSections=[...document.querySelectorAll(".section")].filter(visible);
    const activePages=[...document.querySelectorAll(".ui-page")].filter(visible);
    const activeCaptions=[...document.querySelectorAll(".caption")].filter(visible);
    const activeWords=[...document.querySelectorAll(".caption .word")].filter(el=>{
      if(!visible(el))return false;
      const s=getComputedStyle(el),bg=s.backgroundColor.replace(/\s/g,"");
      return bg!=="rgba(0,0,0,0)"&&bg!=="transparent";
    });
    const clipped=[];
    for(const page of activePages){
      const card=page.closest(".teaching-card"),pageRect=rect(page),cardRect=card?rect(card):rootRect;
      if(outside(pageRect,cardRect,2))clipped.push({id:page.id,type:"page-outside-card",rect:pageRect,container:cardRect});
      for(const el of page.querySelectorAll(".exercise-row,.match-item,.sequence,.expanded-row,.circle-card,.number-chart,.names-grid,.record-lists,.build-state")){
        if(!visible(el))continue;
        const r=rect(el);
        if(outside(r,cardRect,2))clipped.push({id:el.id||el.className,type:"element-outside-card",rect:r,container:cardRect});
        const style=getComputedStyle(el);
        if(style.overflowX!=="visible"&&el.clientWidth&&el.scrollWidth>el.clientWidth+2)clipped.push({id:el.id||el.className,type:"horizontal-overflow",client:el.clientWidth,scroll:el.scrollWidth});
        if(style.overflowY!=="visible"&&el.clientHeight&&el.scrollHeight>el.clientHeight+2)clipped.push({id:el.id||el.className,type:"vertical-overflow",client:el.clientHeight,scroll:el.scrollHeight});
      }
    }
    for(const el of [...activeCaptions,...document.querySelectorAll(".section-tab")].filter(visible)){
      const r=rect(el);
      if(outside(r,rootRect,2))clipped.push({id:el.id||el.className,type:"outside-root",rect:r,container:rootRect});
    }
    const expectedCaptions=(window.PRODUCTION_DATA.captions||[]).filter(c=>t>=c.start&&t<c.end);
    const expectedActiveWords=expectedCaptions.flatMap(c=>c.words.filter(w=>t>=w.start&&t<w.end).map(w=>w.word||w.text));
    return {
      time:t,
      activeSections:activeSections.map(el=>el.id),
      activePages:activePages.map(el=>el.id),
      activeVideos,
      mediaSeekFailures,
      activeCaptions:activeCaptions.map(el=>el.id),
      activeWords:activeWords.map(el=>el.textContent.trim()),
      expectedCaptions:expectedCaptions.map(c=>c.id),
      expectedActiveWords,
      clipped,
      blank:activeSections.length===0,
      pageMissing:activeSections.some(el=>el.id!=="section-S01")&&activePages.length===0
    };
  };
  window.__mathsV2QaBulkStates=async(samples)=>{
    const states=[];
    for(const sample of samples)states.push(await window.__mathsV2QaSeek(sample.time,false));
    return states;
  };
  window.__mathsV2QaInventory=()=>{
    const q=window.MATHS_QA||{};
    const textNumbers=(el)=>el?((el.textContent.match(/\d+/g)||[]).map(Number)):[];
    const pages=(q.pages||[]).map(p=>({id:p.id,start:p.start,end:p.end}));
    const uniqueRevealTimes=[...new Set((q.events||[]).filter(e=>e.type==="reveal").map(e=>Number(e.time.toFixed(4))))].sort((a,b)=>a-b);
    const counts={
      sections:document.querySelectorAll(".section").length,
      pages:document.querySelectorAll(".ui-page").length,
      captions:document.querySelectorAll(".caption").length,
      s07FirstCells:document.querySelectorAll("#S07-51-100 .cell").length,
      s07MissingCells:document.querySelectorAll("#S07-missing-chart .cell").length,
      s08Names1:document.querySelectorAll("#S08-names-1 .name-pair").length,
      s08Names51:document.querySelectorAll("#S08-names-51 .name-pair").length,
      s09Rows:document.querySelectorAll("#S09-questions .exercise-row").length,
      s10Items:document.querySelectorAll("#S10-match .match-item").length,
      s10Lines:document.querySelectorAll("#S10-match .match-line").length,
      s11Rows:document.querySelectorAll("#S11-questions .exercise-row").length,
      s12Rows:document.querySelectorAll("#S12-questions .exercise-row").length,
      s13Cells:document.querySelectorAll("#S13-count-chart .cell").length,
      s14Cells:document.querySelectorAll("#S14-count-chart .cell").length,
      s15Rows:document.querySelectorAll("#section-S15 .sequence").length,
      s16Rows:document.querySelectorAll("#S16-expanded .expanded-row").length,
      s17PracticeRows:document.querySelectorAll("#S17-expanded-practice .expanded-row").length,
      s17MatchItems:document.querySelectorAll("#S17-expanded-matching .match-item").length,
      s17Lines:document.querySelectorAll("#S17-expanded-matching .match-line").length,
      s18Rows:document.querySelectorAll("#S18-sequences .sequence").length,
      s19Cards:document.querySelectorAll("#S19-bindis .circle-card").length,
      s19BlueBindis:document.querySelectorAll("#S19-bindis .circle-card .bindi.blue").length,
      s19YellowBindis:document.querySelectorAll("#S19-bindis .circle-card .bindi.yellow").length
    };
    const nameGaps=[...document.querySelectorAll(".name-pair")].map(el=>{
      const a=el.querySelector("b"),b=el.querySelector("span");
      return a&&b?rect(b).left-rect(a).right:null;
    }).filter(Number.isFinite);
    return {
      duration:window.PRODUCTION_DATA.duration,
      sections:(window.PRODUCTION_DATA.sections||[]).map(s=>({id:s.id,start:s.start,end:s.end})),
      captions:(window.PRODUCTION_DATA.captions||[]).map(c=>({id:c.id,start:c.start,end:c.end,words:c.words})),
      pages,
      revealTimes:uniqueRevealTimes,
      missingCues:q.missingCues||[],
      buildCues:q.buildCues||[],
      counts,
      numberNameMinGap:nameGaps.length?Math.min(...nameGaps):null,
      s13Recorded:textNumbers(document.querySelector("#S13-count-chart .number-list")),
      s14Recorded:[...document.querySelectorAll("#S14-count-chart .number-list")].map(textNumbers)
    };
  };
  window.__mathsV2QaAllWords=()=>{
    const timeline=window.__timelines&&window.__timelines["maths-class1-chapter8-two-digit-numbers"];
    if(!timeline)throw new Error("Maths timeline is not registered");
    const rootRect=rect(document.getElementById("root")),laneRect=rect(document.getElementById("caption-lane"));
    const failures=[];
    let checked=0;
    for(const caption of window.PRODUCTION_DATA.captions||[]){
      for(let index=0;index<caption.words.length;index++){
        const word=caption.words[index],time=(word.start+word.end)/2;
        timeline.pause().seek(time,false);
        const captionEl=document.getElementById(caption.id),target=document.getElementById(`${caption.id}-w-${index}`);
        const active=[...document.querySelectorAll(".caption .word")].filter(el=>{
          if(!visible(el))return false;
          const bg=getComputedStyle(el).backgroundColor.replace(/\s/g,"");
          return bg!=="rgba(0,0,0,0)"&&bg!=="transparent";
        });
        const style=target?getComputedStyle(target):null,targetRect=target?rect(target):null;
        const siblings=captionEl?[...captionEl.querySelectorAll(".word")].filter(el=>el!==target):[];
        const badSibling=siblings.find(el=>{
          const s=getComputedStyle(el),bg=s.backgroundColor.replace(/\s/g,"");
          return s.color!=="rgb(66, 95, 108)"||(bg!=="rgba(0,0,0,0)"&&bg!=="transparent");
        });
        const reasons=[];
        if(!captionEl||!visible(captionEl))reasons.push("caption-not-visible");
        if(!target)reasons.push("target-span-missing");
        if(active.length!==1||active[0]!==target)reasons.push("active-span-count-or-identity");
        if(style&&style.color!=="rgb(255, 255, 255)")reasons.push("active-color");
        if(style&&style.backgroundColor!=="rgb(159, 53, 40)")reasons.push("active-background");
        if(badSibling)reasons.push("inactive-neighbor-style");
        if(targetRect&&outside(targetRect,laneRect,2))reasons.push("word-outside-caption-lane");
        if(targetRect&&outside(targetRect,rootRect,2))reasons.push("word-outside-canvas");
        if(reasons.length)failures.push({caption:caption.id,index,word:word.word||word.text,time,reasons,active:active.map(el=>el.id),color:style?.color,background:style?.backgroundColor,rect:targetRect,lane:laneRect});
        checked++;
      }
    }
    return {checked,failures};
  };
  return "maths-v2-qa-probe-installed";
}
