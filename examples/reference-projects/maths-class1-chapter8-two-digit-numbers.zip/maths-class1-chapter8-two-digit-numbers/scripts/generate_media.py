from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from dotenv import load_dotenv

PROJECT = Path(__file__).resolve().parents[1]
OPENMONTAGE = PROJECT.parents[1]
sys.path.insert(0, str(OPENMONTAGE))
load_dotenv(OPENMONTAGE / ".env")

from tools.video.agnes_video import AgnesVideo  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scene", action="append")
    parser.add_argument("--model", default="agnes-video-2.5-flash")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    os.environ.setdefault("OPENMONTAGE_ALLOW_NETWORK", "1")
    plan = json.loads((PROJECT / "artifacts/media_plan.json").read_text(encoding="utf-8"))
    requested = set(args.scene or [])
    scenes = [scene for scene in plan["scenes"] if not requested or scene["id"] in requested]
    unknown = requested - {scene["id"] for scene in scenes}
    if unknown:
        raise SystemExit(f"Unknown scene IDs: {sorted(unknown)}")

    receipts_dir = PROJECT / "artifacts/provider-jobs"
    receipts_dir.mkdir(parents=True, exist_ok=True)
    generator = AgnesVideo()
    failures = 0
    for scene in scenes:
        output = PROJECT / scene["output"]
        receipt_path = receipts_dir / f"{scene['id']}.json"
        if output.exists() and output.stat().st_size and not args.force:
            print(f"SKIP {scene['id']}: {output}", flush=True)
            continue
        request = {
            "operation": "text_to_video",
            "model_id": args.model,
            "prompt": f"{plan['style']}. {scene['prompt']}",
            "negative_prompt": plan["negative_prompt"],
            "duration": str(scene["duration"]),
            "resolution": "720P",
            "aspect_ratio": "16:9",
            "seed": scene["seed"],
            "output_path": str(output),
        }
        result = generator.execute(request)
        receipt = {
            "scene_id": scene["id"],
            "sections": scene["sections"],
            "provider": "agnes",
            "model": args.model,
            "operation": "text_to_video",
            "submitted_at": datetime.now(timezone.utc).isoformat(),
            "request": {key: value for key, value in request.items() if key != "output_path"},
            "success": result.success,
            "output": scene["output"],
            "result": result.data if result.success else None,
            "error": result.error if not result.success else None,
        }
        receipt_path.write_text(json.dumps(receipt, indent=2), encoding="utf-8")
        if result.success:
            print(f"OK {scene['id']}: {output}", flush=True)
        else:
            failures += 1
            print(f"FAIL {scene['id']}: {result.error}", flush=True)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
