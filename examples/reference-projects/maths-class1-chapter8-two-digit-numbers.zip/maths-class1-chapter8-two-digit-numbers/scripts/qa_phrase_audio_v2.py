"""Verify placement and continuity of every complete rendered narration phrase.

This compares measured waveforms, not words or pronunciation. It supplements the
encoded video/metadata gate and the independently measured subtitle alignment.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path

import numpy as np

from qa_encoded_video import valid_cross_correlation


def decode_audio(path: Path, sample_rate: int = 48000) -> np.ndarray:
    """Keep native delivery-rate timing resolution for waveform comparison.

    Downsampling 48 kHz audio to 16 kHz before integer-lag matching can turn a
    one-native-sample phase difference into a spurious low correlation, notably
    for quiet high-frequency consonants. The thresholds do not change.
    """
    raw = subprocess.check_output(["ffmpeg", "-v", "error", "-i", str(path), "-vn",
                                   "-ar", str(sample_rate), "-ac", "1", "-f", "f32le", "pipe:1"])
    return np.frombuffer(raw, dtype="<f4").copy()


def phrase_intervals(manifest: dict) -> list[dict]:
    result = []
    seen = set()
    for section in manifest["sections"]:
        for phrase in section["phrases"]:
            pid = phrase["id"]
            if pid in seen:
                raise ValueError(f"Duplicate phrase id in reference manifest: {pid}")
            seen.add(pid)
            start = float(section["start"]) + float(phrase["start"])
            end = float(section["start"]) + float(phrase["end"])
            if end <= start:
                raise ValueError(f"Invalid phrase interval: {pid}")
            if result and start < result[-1]["end"] - 0.0001:
                raise ValueError(f"Overlapping reference phrases: {pid}")
            result.append({"id": pid, "section_id": section["id"], "text": phrase["text"],
                           "start": start, "end": end, "sha256": phrase.get("sha256")})
    return result


def match_window(reference: np.ndarray, encoded: np.ndarray, start: int, end: int,
                 sample_rate: int, search_seconds: float = .25, expected_start: int | None = None) -> dict:
    """Normalized FFT correlation across the entire supplied interval."""
    target = np.asarray(reference[start:end], dtype=np.float64)
    if end > len(reference) or len(target) != end - start or len(target) < 2:
        return {"status": "failed", "reason": "reference interval is missing"}
    energy = float(np.dot(target, target))
    if energy / len(target) < 1e-9:
        return {"status": "skipped", "reason": "reference interval is silent"}
    nominal = start if expected_start is None else expected_start
    margin = round(search_seconds * sample_rate)
    lower = max(0, nominal - margin)
    upper = min(len(encoded), nominal + len(target) + margin)
    search = np.asarray(encoded[lower:upper], dtype=np.float64)
    if len(search) < len(target):
        return {"status": "failed", "reason": "encoded interval is truncated or missing"}
    convolution = valid_cross_correlation(search, target)
    cumulative = np.concatenate(([0.0], np.cumsum(search * search)))
    candidate_energy = cumulative[len(target):] - cumulative[:-len(target)]
    denominator = np.sqrt(energy * np.maximum(candidate_energy, 1e-20))
    correlation = np.clip(convolution / denominator, -1.0, 1.0)
    peak = int(np.argmax(correlation))
    score = float(correlation[peak])
    offset = (lower + peak - nominal) / sample_rate
    rms = float(np.sqrt(max(0.0, candidate_energy[peak]) / len(target)))
    reason = "missing-or-silent-speech" if rms < 1e-5 else "low-correlation" if score < .9 else "timing-offset" if abs(offset) > .05 else None
    result = {"status": "passed" if reason is None else "failed", "offset_seconds": round(offset, 6),
              "correlation": round(score, 6), "matched_start_seconds": round((lower + peak) / sample_rate, 6),
              "duration_seconds": round(len(target) / sample_rate, 6), "encoded_rms": round(rms, 7)}
    if reason:
        result["reason"] = reason
    return result


def covering_windows(start: int, end: int, sample_rate: int) -> list[tuple[int, int]]:
    """Overlapping windows cover all of the phrase, including its final sample."""
    width = round(.8 * sample_rate)
    step = round(.4 * sample_rate)
    if end - start <= width:
        return [(start, end)]
    starts = list(range(start, end - width + 1, step))
    if starts[-1] != end - width:
        starts.append(end - width)
    return [(at, at + width) for at in starts]


def unexpected_gap_audio(reference: np.ndarray, encoded: np.ndarray, phrases: list[dict],
                         duration: float, sample_rate: int) -> list[dict]:
    """Find added sound in planned silent gaps, excluding AAC boundary padding."""
    gaps = []
    intervals = [(0.0, phrases[0]["start"])] if phrases else [(0.0, duration)]
    intervals += [(left["end"], right["start"]) for left, right in zip(phrases, phrases[1:])]
    if phrases:
        intervals.append((phrases[-1]["end"], duration))
    for start_s, end_s in intervals:
        start, end = round((start_s + .15) * sample_rate), round((end_s - .15) * sample_rate)
        if end - start < round(.12 * sample_rate):
            continue
        width = round(.2 * sample_rate)
        for at in range(start, end, width):
            stop = min(end, at + width)
            if stop > len(encoded) or stop > len(reference) or stop - at < round(.1 * sample_rate):
                continue
            ref_rms = float(np.sqrt(np.mean(reference[at:stop].astype(np.float64) ** 2)))
            out_rms = float(np.sqrt(np.mean(encoded[at:stop].astype(np.float64) ** 2)))
            if ref_rms < .002 and out_rms > max(.006, ref_rms * 3):
                gaps.append({"start": round(at / sample_rate, 4), "end": round(stop / sample_rate, 4),
                             "reference_rms": round(ref_rms, 6), "encoded_rms": round(out_rms, 6),
                             "reason": "unexpected-audio-in-planned-silence"})
    return gaps


def audit(reference: np.ndarray, encoded: np.ndarray, manifest: dict, sample_rate: int = 48000) -> dict:
    phrases = phrase_intervals(manifest)
    if not phrases:
        raise ValueError("No phrases in reference manifest")
    rows = []
    for phrase in phrases:
        start, end = round(phrase["start"] * sample_rate), round(phrase["end"] * sample_rate)
        whole = match_window(reference, encoded, start, end, sample_rate)
        windows = []
        for first, last in covering_windows(start, end, sample_rate):
            windows.append({"start": round(first / sample_rate, 6), "end": round(last / sample_rate, 6),
                            **match_window(reference, encoded, first, last, sample_rate)})
        failed = [item for item in windows if item["status"] == "failed"]
        passed = whole["status"] == "passed" and not failed
        row = {**phrase, "status": "passed" if passed else "failed", "whole_phrase": whole,
               "window_count": len(windows), "failed_windows": failed,
               "silent_windows": sum(item["status"] == "skipped" for item in windows), "windows": windows}
        # A wrong full phrase may be another source phrase copied into its slot.
        # Identify only a high-correlation candidate; do not infer semantic identity.
        if not passed:
            duplicates = []
            for candidate in phrases:
                if candidate["id"] == phrase["id"]:
                    continue
                first, last = round(candidate["start"] * sample_rate), round(candidate["end"] * sample_rate)
                match = match_window(reference, encoded, first, last, sample_rate, expected_start=start)
                if match.get("correlation", 0) >= .95 and abs(match.get("offset_seconds", 1)) <= .05:
                    duplicates.append({"source_phrase_id": candidate["id"], "correlation": match["correlation"],
                                       "offset_seconds": match["offset_seconds"]})
            row["possible_wrong_phrase_copies"] = sorted(duplicates, key=lambda item: -item["correlation"])
        rows.append(row)
    duration = float(manifest["duration_seconds"])
    gaps = unexpected_gap_audio(reference, encoded, phrases, duration, sample_rate)
    failed_rows = [row for row in rows if row["status"] != "passed"]
    ref_complete = len(reference) / sample_rate >= phrases[-1]["end"] - .001
    encoded_complete = len(encoded) / sample_rate >= phrases[-1]["end"] - .001
    passed = not failed_rows and not gaps and ref_complete and encoded_complete
    return {"status": "passed" if passed else "failed", "phrases_checked": len(rows),
            "phrases_passed": len(rows) - len(failed_rows), "phrases_failed": len(failed_rows),
            "sample_rate": sample_rate, "correlation_threshold": .9, "offset_tolerance_seconds": .05,
            "window_seconds": .8, "window_overlap_seconds": .4,
            "reference_complete": ref_complete, "encoded_complete": encoded_complete,
            "unexpected_gap_audio": gaps, "items": rows,
            "limits": [
                "Waveform agreement validates audio identity, placement and continuity, not pronunciation, meaning, accent or word boundaries.",
                "A 0.9 correlation threshold tolerates some waveform differences; it is not sample-perfect equality or a hearing test.",
                "Potential duplicated phrases are reported only when another source waveform matches the failed phrase slot with at least 0.95 correlation.",
                "Added sound is checked only in planned quiet gaps; background noise below the stated threshold may not be detected.",
                "Visual correctness, subtitle word timing and final listening review are separate gates."
            ]}


def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--video", type=Path, required=True, help="Encoded MP4, or the reference WAV for an explicitly labelled self-test")
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--reference-audio", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--sample-rate", type=int, default=48000, help="Use native 48000 Hz delivery rate; 16000 is retained for reproducing coarse-lag diagnostics")
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    reference = decode_audio(args.reference_audio, args.sample_rate)
    encoded = decode_audio(args.video, args.sample_rate)
    report = audit(reference, encoded, manifest, args.sample_rate)
    self_test = args.video.resolve() == args.reference_audio.resolve()
    report.update({"mode": "reference-self-test" if self_test else "encoded-audio-verification",
                   "video": str(args.video.resolve()), "reference_audio": str(args.reference_audio.resolve()),
                   "manifest_sha256": file_hash(args.manifest), "reference_audio_sha256": file_hash(args.reference_audio),
                   "video_sha256": file_hash(args.video)})
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "phrase-audio-qa.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: report[key] for key in ("status", "mode", "phrases_checked", "phrases_passed", "phrases_failed", "unexpected_gap_audio")}))
    raise SystemExit(0 if report["status"] == "passed" else 1)


if __name__ == "__main__":
    main()
