from __future__ import annotations

import json
from pathlib import Path

from faster_whisper import WhisperModel

PROJECT = Path(__file__).resolve().parents[1]
OUT = PROJECT / "assets/audio/narration-qwen-v1"


def main() -> None:
    qa_path = OUT / "alignment_qa.json"
    report = json.loads(qa_path.read_text(encoding="utf-8"))
    pending = [item for item in report["items"] if item["status"] == "review"]
    model = WhisperModel("base.en", device="cpu", compute_type="int8")
    results = []
    for item in pending:
        wav = OUT / "phrases" / f"{item['phrase_id']}.wav"
        segments, _ = model.transcribe(
            str(wav), language="en", beam_size=5, word_timestamps=True,
            vad_filter=False, condition_on_previous_text=False,
        )
        segments = list(segments)
        transcript = " ".join(segment.text.strip() for segment in segments if segment.text.strip())
        item["second_opinion"] = {"model": "faster-whisper-base.en", "transcript": transcript}
        results.append({"phrase_id": item["phrase_id"], "expected": item["expected"], "small_en": item["transcript"], "base_en": transcript})
        print(f"{item['phrase_id']}: {transcript}", flush=True)
    qa_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    (OUT / "alignment-second-opinion.json").write_text(json.dumps({"items": results}, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
