from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[1]
EPSILON_SECONDS = 0.0001


def project_path(value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else PROJECT / path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def require_close(label: str, expected: float, actual: float) -> None:
    if abs(float(expected) - float(actual)) > EPSILON_SECONDS:
        raise ValueError(f"{label} changed: expected {expected}, got {actual}")


def phrase_index(manifest: dict) -> tuple[dict[str, dict], dict[str, dict]]:
    sections = {section["id"]: section for section in manifest["sections"]}
    phrases: dict[str, dict] = {}
    for section in manifest["sections"]:
        for phrase in section["phrases"]:
            if phrase["id"] in phrases:
                raise ValueError(f"Duplicate phrase id: {phrase['id']}")
            phrases[phrase["id"]] = phrase
    return sections, phrases


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Rebase accepted precision media onto a shifted narration timeline."
    )
    parser.add_argument("--precision", default="artifacts/precision-media.json")
    parser.add_argument("--baseline", default="artifacts/precision-timing-baseline-v2.json")
    parser.add_argument("--narration", default="assets/audio/narration-qwen-v1/narration_manifest.json")
    parser.add_argument("--output", default="artifacts/precision-media-v3.json")
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()

    precision_path = project_path(args.precision)
    baseline_path = project_path(args.baseline)
    narration_path = project_path(args.narration)
    output_path = project_path(args.output)

    precision = load_json(precision_path)
    baseline = load_json(baseline_path)
    narration = load_json(narration_path)
    sections, phrases = phrase_index(narration)

    if sha256(precision_path) != baseline["precision_manifest_sha256"]:
        raise ValueError("Precision v2 manifest changed after its timing baseline was frozen")
    if precision.get("review_status") != "accepted":
        raise ValueError("Precision v2 manifest is not accepted")

    accepted = {
        item["id"]: item
        for item in precision["items"]
        if item.get("review_status") == "accepted"
    }
    rebased = copy.deepcopy(precision)
    rebased_items = {item["id"]: item for item in rebased["items"]}
    changes = []

    for item_id, binding in baseline["bindings"].items():
        if item_id not in accepted or item_id not in rebased_items:
            raise ValueError(f"Missing accepted precision item: {item_id}")
        item = accepted[item_id]
        if item.get("section_id") != binding["section_id"]:
            raise ValueError(f"{item_id} section binding changed")
        if item.get("start_phrase_id") != binding["start_phrase_id"]:
            raise ValueError(f"{item_id} start phrase binding changed")
        if item.get("end_phrase_id") != binding["end_phrase_id"]:
            raise ValueError(f"{item_id} end phrase binding changed")

        section = sections.get(binding["section_id"])
        if section is None:
            raise ValueError(f"Missing narration section: {binding['section_id']}")
        expected_phrases = binding["phrases"]
        first_expected = expected_phrases[0]
        first_actual = phrases.get(first_expected["id"])
        if first_actual is None:
            raise ValueError(f"Missing narration phrase: {first_expected['id']}")
        local_translation = round(
            float(first_actual["start"]) - float(first_expected["start"]), 4
        )
        for expected in expected_phrases:
            actual = phrases.get(expected["id"])
            if actual is None:
                raise ValueError(f"Missing narration phrase: {expected['id']}")
            if actual.get("sha256") != expected["sha256"]:
                raise ValueError(f"{expected['id']} audio hash changed; precision clip must be regenerated")
            require_close(
                f"{expected['id']} translated local start",
                float(expected["start"]) + local_translation,
                actual["start"],
            )
            require_close(
                f"{expected['id']} translated local end",
                float(expected["end"]) + local_translation,
                actual["end"],
            )

        first = phrases[binding["start_phrase_id"]]
        last = phrases[binding["end_phrase_id"]]
        new_start = round(float(section["start"]) + float(first["start"]), 4)
        new_end = round(float(section["start"]) + float(last["end"]), 4)
        new_duration = round(new_end - new_start, 4)
        require_close(f"{item_id} interval duration", item["duration"], new_duration)
        if float(item["media_duration"]) + (1 / 30) < new_duration:
            raise ValueError(f"{item_id} media is shorter than its rebased narration interval")

        target = rebased_items[item_id]
        old_start = float(target["start"])
        target["start"] = new_start
        target["end"] = new_end
        target["duration"] = new_duration
        changes.append({
            "id": item_id,
            "old_start": old_start,
            "new_start": new_start,
            "offset_delta": round(new_start - old_start, 4),
            "local_translation": local_translation,
        })

    narration_sha = sha256(narration_path)
    rebased["version"] = "3.0"
    rebased["narration_manifest"] = str(narration_path.relative_to(PROJECT)).replace("\\", "/")
    rebased["narration_manifest_sha256"] = narration_sha
    rebased["rebase"] = {
        "baseline": str(baseline_path.relative_to(PROJECT)).replace("\\", "/"),
        "baseline_narration_manifest_sha256": baseline["narration_manifest_sha256"],
        "verified_phrase_audio_hashes_and_local_timings": True,
        "changes": changes,
    }

    result = {
        "status": "validated" if args.check_only else "written",
        "narration_manifest_sha256": narration_sha,
        "changes": changes,
    }
    if not args.check_only:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(rebased, indent=2) + "\n", encoding="utf-8")
        result["output"] = str(output_path)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
