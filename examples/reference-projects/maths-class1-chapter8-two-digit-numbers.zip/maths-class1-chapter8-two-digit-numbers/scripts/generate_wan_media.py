from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from dotenv import load_dotenv

PROJECT = Path(__file__).resolve().parents[1]
OPENMONTAGE = PROJECT.parents[1]
sys.path.insert(0, str(OPENMONTAGE))
load_dotenv(OPENMONTAGE / ".env")

from tools.video._modelslab_shared import (  # noqa: E402
    download_modelslab_output,
    poll_modelslab,
    submit_modelslab,
    upload_modelslab_media,
)
from tools.video._shared import probe_output  # noqa: E402


WAN22_I2V_URL = "https://modelslab.com/api/v6/video/img2video_ultra"


def write_receipt(path: Path, receipt: dict) -> None:
    temporary = path.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    temporary.replace(path)


def execute_resume_safe(request: dict, receipt_path: Path, receipt: dict) -> dict:
    """Submit once, persist the request ID, then poll a resumable Wan job."""
    api_key = os.environ.get("MODELSLAB_API_KEY")
    if not api_key:
        raise RuntimeError("MODELSLAB_API_KEY is not set")

    pending = None
    if receipt_path.exists():
        previous = json.loads(receipt_path.read_text(encoding="utf-8"))
        if previous.get("status") == "processing" and previous.get("request_id"):
            pending = previous

    if pending is None:
        init_image = upload_modelslab_media(request["image_path"], api_key)
        payload = {
            "key": api_key,
            "prompt": request["prompt"],
            "negative_prompt": request["negative_prompt"],
            "model_id": request["model_id"],
            "fps": max(16, min(20, int(request["fps"]))),
            "num_frames": max(82, min(122, int(request["num_frames"]))),
            "resolution": "480",
            "output_type": "mp4",
            "seed": request["seed"],
            "init_image": init_image,
        }
        if str(init_image).startswith("data:"):
            payload["base64"] = True
        submitted = submit_modelslab(WAN22_I2V_URL, api_key, payload, timeout=30)
        request_id = submitted.get("id") or submitted.get("request_id")
        if not request_id:
            raise RuntimeError(f"ModelsLab did not return a request ID: {submitted}")
        pending = {
            **receipt,
            "status": "processing",
            "request_id": str(request_id),
            "poll_endpoint": "video",
        }
        write_receipt(receipt_path, pending)

    provider_result = poll_modelslab(pending["request_id"], api_key, endpoint="video")
    output = Path(request["output_path"])
    download_modelslab_output(provider_result, output)
    completed = {
        **pending,
        "status": "succeeded",
        "success": True,
        "result": {
            "provider": "modelslab",
            "model": request["model_id"],
            "operation": request["operation"],
            "output": str(output),
            "output_path": str(output),
            "format": "mp4",
            **probe_output(output),
        },
        "error": None,
    }
    write_receipt(receipt_path, completed)
    return completed


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scene", action="append")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    os.environ.setdefault("OPENMONTAGE_ALLOW_NETWORK", "1")
    plan = json.loads((PROJECT / "artifacts/media_plan.json").read_text(encoding="utf-8"))
    selected = set(args.scene or [])
    scenes = [scene for scene in plan["scenes"] if not selected or scene["id"] in selected]
    unknown = selected - {scene["id"] for scene in scenes}
    if unknown:
        raise SystemExit(f"Unknown scenes: {sorted(unknown)}")
    receipts_dir = PROJECT / "artifacts/provider-jobs-wan22"
    receipts_dir.mkdir(parents=True, exist_ok=True)
    failures = 0
    for scene in scenes:
        keyframe = PROJECT / scene["keyframe"]
        output = PROJECT / scene["output"]
        output.parent.mkdir(parents=True, exist_ok=True)
        receipt_path = receipts_dir / f"{scene['id']}.json"
        if output.exists() and output.stat().st_size and not args.force:
            print(f"SKIP {scene['id']}: {output}", flush=True)
            continue
        if not keyframe.exists():
            print(f"WAIT {scene['id']}: seed missing {keyframe}", flush=True)
            failures += 1
            continue
        request = {
            "operation": "image_to_video",
            "model_id": "wan-2.2-i2v",
            "prompt": scene["prompt"] + " Smooth continuous motion; preserve character identity and object counts; mute visual-only clip.",
            "negative_prompt": plan["negative_prompt"],
            "image_path": str(keyframe),
            "fps": 18,
            "num_frames": 90,
            "seed": scene["seed"],
            "generate_audio": False,
            "output_path": str(output),
        }
        receipt = {
            "scene_id": scene["id"],
            "provider": "modelslab",
            "model": "wan-2.2-i2v",
            "submitted_at": datetime.now(timezone.utc).isoformat(),
            "seed_image": scene["keyframe"],
            "request": {key: value for key, value in request.items() if key not in {"image_path", "output_path"}},
            "output": scene["output"],
        }
        try:
            completed = execute_resume_safe(request, receipt_path, receipt)
            print(f"OK {scene['id']}: {output}", flush=True)
        except Exception as error:
            failures += 1
            failed = {
                **receipt,
                "status": "failed",
                "success": False,
                "result": None,
                "error": str(error),
            }
            write_receipt(receipt_path, failed)
            print(f"FAIL {scene['id']}: {error}", flush=True)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
