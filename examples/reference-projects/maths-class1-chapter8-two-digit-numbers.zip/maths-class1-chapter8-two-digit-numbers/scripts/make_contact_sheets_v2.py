from __future__ import annotations

import argparse
import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


THUMB = (384, 216)
GRID = (5, 5)


def font() -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    try:
        return ImageFont.truetype("arial.ttf", 18)
    except OSError:
        return ImageFont.load_default()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--pattern", default="frame-*.jpg")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--prefix", required=True)
    args = parser.parse_args()

    files = sorted(args.source.glob(args.pattern))
    if not files:
        raise ValueError(f"No input frames matched {args.source / args.pattern}")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    label_font = font()
    per_sheet = GRID[0] * GRID[1]
    for sheet_index in range(math.ceil(len(files) / per_sheet)):
        group = files[sheet_index * per_sheet : (sheet_index + 1) * per_sheet]
        sheet = Image.new("RGB", (THUMB[0] * GRID[0], THUMB[1] * GRID[1]), "#101010")
        draw = ImageDraw.Draw(sheet)
        for index, path in enumerate(group):
            image = Image.open(path).convert("RGB")
            image.thumbnail(THUMB, Image.Resampling.LANCZOS)
            x = (index % GRID[0]) * THUMB[0]
            y = (index // GRID[0]) * THUMB[1]
            sheet.paste(image, (x, y))
            label = path.stem.replace("frame-", "#")
            draw.rounded_rectangle((x + 7, y + 7, x + 164, y + 35), radius=6, fill="#0a1922")
            draw.text((x + 13, y + 10), label, fill="white", font=label_font)
        output = args.output_dir / f"{args.prefix}-{sheet_index + 1:03d}.jpg"
        sheet.save(output, quality=92)
        print(output)


if __name__ == "__main__":
    main()
