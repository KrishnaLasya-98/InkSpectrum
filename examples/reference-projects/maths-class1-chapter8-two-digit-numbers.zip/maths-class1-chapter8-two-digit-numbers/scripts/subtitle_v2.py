"""Measured, source-punctuated captions for the Maths chapter.

Unprompted ASR is pronunciation evidence. Supplied-text acoustic alignment is
only timing evidence. Neither is treated as human listening approval. Numeric
compound words stay intact; no word times are divided or estimated uniformly.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from collections import Counter
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
DEFAULT_AUDIO = PROJECT / "assets/audio/narration-qwen-v1"
# The Class 1 chapter activity sample was reviewed with the user. Both
# recognizers phonetically transcribe the textbook word "bindis" with a
# different spelling. Limit that spelling equivalence to this exact waveform;
# any regenerated audio must pass a fresh review.
REVIEWED_BINDIS_AUDIO_SHA256 = "64dd68161e7e3f82c17150c35388316698a682c7c1af898ee4e56656d435dda4"


def reviewed_asr_spelling(value: str, audio_sha256: str | None = None) -> str:
    if audio_sha256 == REVIEWED_BINDIS_AUDIO_SHA256:
        return re.sub(r"\bbind(?:es|ess)\b", "bindis", value, flags=re.IGNORECASE)
    return value


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def lexical(text: str) -> str:
    return re.sub(r"[^a-z0-9]", "", text.lower())


def source_tokens(text: str) -> list[str]:
    return text.split()


def canonical_numbers(text: str) -> str:
    """Only orthography and numeric notation; never delete spoken range words."""
    from reassess_alignment import number_words
    value = text.lower().replace("colour", "color").replace("neighbour", "neighbor")
    value = re.sub(r"\bone['’]s\b", "ones", value)
    value = re.sub(r"\b(\d{1,3})\s*[- ]\s*10s\b", lambda m: number_words(int(m[1])) + " tens", value)
    value = re.sub(r"\b(\d{1,3})\s*[- ]\s*1s\b", lambda m: number_words(int(m[1])) + " ones", value)
    value = re.sub(r"\b(\d{1,3})\s*[- ]\s*1\b", lambda m: number_words(int(m[1])) + " one", value)
    value = re.sub(r"\b(\d{1,2})s\b", lambda m: number_words(int(m[1])) + "s", value)
    return re.sub(r"\b\d{1,3}\b", lambda m: number_words(int(m[0])), value)


def transcript_matches(expected: str, actual: str, audio_sha256: str | None = None) -> bool:
    actual = reviewed_asr_spelling(actual, audio_sha256)
    return re.findall(r"[a-z0-9]+", canonical_numbers(expected)) == re.findall(r"[a-z0-9]+", canonical_numbers(actual))


def map_exact_tokens(text: str, measured: list[dict]) -> list[dict]:
    """Join acoustic subwords into source whitespace tokens without inventing times."""
    measured = [item for item in measured if lexical(item["word"])]
    result = []
    cursor = 0
    for token in source_tokens(text):
        wanted = lexical(token)
        matched = ""
        selected = []
        while cursor < len(measured) and matched != wanted:
            item = measured[cursor]
            matched += lexical(item["word"])
            selected.append(item)
            cursor += 1
            if not wanted.startswith(matched):
                raise ValueError(f"Acoustic token mismatch: expected {token!r}, got {matched!r}")
        if matched != wanted or not selected:
            raise ValueError(f"Missing acoustic word for {token!r}")
        start, end = selected[0]["start"], selected[-1]["end"]
        if not math.isfinite(start) or not math.isfinite(end) or end <= start:
            raise ValueError(f"Invalid acoustic span for {token!r}: {start}..{end}")
        result.append({"word": token, "text": token, "start": start, "end": end,
                       "probability": min(w["probability"] for w in selected),
                       "timing_source": "supplied-text-acoustic-dtw",
                       "acoustic_parts": len(selected)})
    if cursor != len(measured):
        raise ValueError("Unconsumed acoustic words")
    for left, right in zip(result, result[1:]):
        if left["end"] > right["start"] + 0.001:
            raise ValueError(f"Overlapping acoustic words: {left['word']} / {right['word']}")
    return result


def collect(audio_dir: Path, model_name: str, selected_ids: list[str] | None = None):
    from faster_whisper import WhisperModel
    from faster_whisper.audio import decode_audio, pad_or_trim
    from faster_whisper.tokenizer import Tokenizer
    from faster_whisper.transcribe import merge_punctuations

    model = WhisperModel(model_name, device="cpu", compute_type="int8", cpu_threads=3)
    tokenizer = Tokenizer(model.hf_tokenizer, multilingual=False, task="transcribe", language="en")
    manifest = read_json(audio_dir / "narration_manifest.json")
    selected = set(selected_ids or [])
    for section in manifest["sections"]:
        for phrase in section["phrases"]:
            pid = phrase["id"]
            if selected and pid not in selected:
                continue
            wav = audio_dir / "phrases" / f"{pid}.wav"
            audio_hash = digest(wav)
            if audio_hash != phrase["sha256"]:
                raise ValueError(f"Manifest/audio hash mismatch: {pid}")
            dest = audio_dir / "subtitle-v2-acoustic" / f"{pid}.{model_name}.json"
            if dest.exists():
                cached = read_json(dest)
                if cached.get("audio_sha256") == audio_hash and cached.get("source_text") == phrase["text"]:
                    print(f"{pid}: cached {model_name}", flush=True)
                    continue
            signal = decode_audio(str(wav), sampling_rate=16000)
            if len(signal) > 29 * 16000:
                raise ValueError(f"Phrase exceeds acoustic alignment window: {pid}")
            features = model.feature_extractor(signal)
            encoded = model.encode(pad_or_trim(features))
            encoded_text = tokenizer.encode(" " + phrase["text"])
            measured = model.find_alignment(tokenizer, [encoded_text], encoded, min(features.shape[-1], 3000))[0]
            merge_punctuations(measured, "\"'“¿([{-", "\"'.。,，!！?？:：”)]}、")
            words = [{"word": w["word"].strip(), "start": round(float(w["start"]), 4),
                      "end": round(float(w["end"]), 4), "probability": round(float(w["probability"]), 4)}
                     for w in measured if w["word"].strip()]
            result = {"phrase_id": pid, "source_text": phrase["text"], "audio_sha256": audio_hash,
                      "model": model_name, "algorithm": "faster-whisper supplied-text cross-attention DTW",
                      "status": "timing-evidence-only", "words": words}
            write_json(dest, result)
            try:
                checked = map_exact_tokens(phrase["text"], words)
                summary = f"{len(checked)} source tokens"
            except ValueError as exc:
                summary = str(exc)
            print(f"{pid}: {model_name}: {summary}", flush=True)


def collect_asr(audio_dir: Path, model_name: str, selected_ids: list[str]):
    from faster_whisper import WhisperModel
    model = WhisperModel(model_name, device="cpu", compute_type="int8", cpu_threads=3)
    manifest = read_json(audio_dir / "narration_manifest.json")
    for section in manifest["sections"]:
        for phrase in section["phrases"]:
            if phrase["id"] not in set(selected_ids):
                continue
            wav = audio_dir / "phrases" / f"{phrase['id']}.wav"
            segments, _ = model.transcribe(str(wav), language="en", beam_size=5,
                word_timestamps=True, vad_filter=False, condition_on_previous_text=False)
            measured, transcripts = [], []
            for segment in segments:
                transcripts.append(segment.text.strip())
                measured.extend({"word": w.word.strip(), "start": round(w.start, 4), "end": round(w.end, 4),
                                 "probability": round(w.probability, 4)} for w in (segment.words or []) if w.word.strip())
            result = {"phrase_id": phrase["id"], "source_text": phrase["text"], "audio_sha256": digest(wav),
                      "model": model_name, "algorithm": "unprompted faster-whisper transcription",
                      "transcript": " ".join(transcripts), "words": measured}
            write_json(audio_dir / "subtitle-v2-acoustic" / f"{phrase['id']}.{model_name}.asr.json", result)
            print(f"{phrase['id']}: {result['transcript']}", flush=True)


def map_numeric_asr(text: str, measured: list[dict], audio_sha256: str | None = None) -> list[dict]:
    """Map exact number notation only; never split a digit's measured duration."""
    source = source_tokens(text)
    # Source whitespace units must correspond to entire acoustic units. This
    # intentionally rejects splitting ASR '100' into invented one/hundred spans.
    canonical_source = " ".join(lexical(canonical_numbers(token)) for token in source)
    canonical_words = [{**w, "word": lexical(canonical_numbers(reviewed_asr_spelling(w["word"], audio_sha256)))} for w in measured]
    mapped = map_exact_tokens(canonical_source, canonical_words)
    for token, word in zip(source, mapped):
        word.update({"word": token, "text": token, "timing_source": "unprompted-asr-numeric-notation"})
    return mapped


def paginate(words: list[dict], max_words: int = 7, max_characters: int = 70) -> list[list[dict]]:
    """Break at sentences and retain hyphenated numbers as a single display unit."""
    sentences = []
    sentence = []
    for word in words:
        sentence.append(word)
        if re.search(r"[.!?][\"'’”)]*$", word["text"]):
            sentences.append(sentence)
            sentence = []
    if sentence:
        sentences.append(sentence)
    pages = []
    for sentence in sentences:
        page = []
        for word in sentence:
            projected = " ".join(item["text"] for item in [*page, word])
            if page and (len(page) == max_words or len(projected) > max_characters):
                pages.append(page)
                page = []
            page.append(word)
        if page:
            # Avoid a one-word tail when shifting one word preserves both limits.
            if len(page) == 1 and pages and pages[-1][-1] in sentence and len(pages[-1]) >= 4:
                page.insert(0, pages[-1].pop())
            pages.append(page)
    return pages


def old_alignment_audit(audio_dir: Path) -> dict:
    old = read_json(audio_dir / "word_alignment.json")["words"]
    old_pages = sum(math.ceil(count / 7) for count in Counter(w["phrase_id"] for w in old).values())
    return {"word_count": len(old), "timing_sources": dict(Counter(w["timing_source"] for w in old)),
            "nonpositive_spans": sum(w["end"] <= w["start"] for w in old), "seven_word_pages": old_pages,
            "punctuation_retained_tokens": sum(bool(re.search(r"[.!?,:;-]", w["word"])) for w in old)}


def audit_frame_events(captions: list[dict], duration: float, fps: int = 30) -> dict:
    """Check the authored caption/word visibility schedule at every output frame.

    This is event-data QA, not a claim that encoded pixels or speech were watched.
    """
    overlap_frames, word_overlap_frames = [], []
    visible_word_frames = Counter()
    for frame in range(math.ceil(duration * fps)):
        at = frame / fps
        visible = [p for p in captions if p["start"] <= at < p["end"]]
        if len(visible) > 1:
            overlap_frames.append(frame)
        active = [(p["id"], i) for p in visible for i, w in enumerate(p["words"]) if w["start"] <= at < w["end"]]
        if len(active) > 1:
            word_overlap_frames.append(frame)
        visible_word_frames.update(active)
    missing = [(p["id"], i) for p in captions for i in range(len(p["words"])) if not visible_word_frames[(p["id"], i)]]
    return {"frames_checked": math.ceil(duration * fps), "fps": fps, "caption_overlap_frames": overlap_frames,
            "active_word_overlap_frames": word_overlap_frames, "words_without_highlight_frames": missing,
            "minimum_active_word_frames": min(visible_word_frames.values(), default=0),
            "method": "authored event intervals sampled at each output frame; encoded visual QA is separate"}


def assert_source_manifest_match(manifest: dict):
    path = Path(manifest["source_script"]) if manifest.get("source_script") else None
    if path and path.exists():
        source = read_json(path)
        expected = [(s["id"], [p["text"] for p in s["phrases"]]) for s in source["sections"]]
        actual = [(s["id"], [p["text"] for p in s["phrases"]]) for s in manifest["sections"]]
        if expected != actual:
            raise ValueError("Narration script and assembled audio manifest differ")


def build(audio_dir: Path, preferred_model: str = "small.en") -> dict:
    manifest_path = audio_dir / "narration_manifest.json"
    manifest = read_json(manifest_path)
    assert_source_manifest_match(manifest)
    qa = read_json(audio_dir / "alignment_qa.json")
    qa_by_id = {item["phrase_id"]: item for item in qa["items"]}
    baseline_manifest = audio_dir / "before-subtitle-v2/narration_manifest.json"
    original_hashes = {p["id"]: p["sha256"] for s in read_json(baseline_manifest)["sections"] for p in s["phrases"]} if baseline_manifest.exists() else {}
    captions, aligned, issues, phrase_checks = [], [], [], []
    for section in manifest["sections"]:
        for phrase in section["phrases"]:
            pid = phrase["id"]
            wav = audio_dir / "phrases" / f"{pid}.wav"
            audio_hash = digest(wav)
            if audio_hash != phrase["sha256"]:
                raise ValueError(f"Manifest/audio hash mismatch: {pid}")
            selected, attempts = None, []
            for model_name in dict.fromkeys([preferred_model, "base.en", "small.en"]):
                path = audio_dir / "subtitle-v2-acoustic" / f"{pid}.{model_name}.json"
                if not path.exists():
                    attempts.append(f"{model_name}: not collected")
                    continue
                evidence = read_json(path)
                if evidence["audio_sha256"] != audio_hash or evidence["source_text"] != phrase["text"]:
                    attempts.append(f"{model_name}: stale evidence")
                    continue
                try:
                    selected = map_exact_tokens(phrase["text"], evidence["words"])
                    if any(w["end"] - w["start"] < 0.055 for w in selected):
                        raise ValueError("Word span is shorter than 55ms; needs independent timing review")
                    if selected[-1]["end"] > phrase["end"] - phrase["start"] + 0.025:
                        raise ValueError("Last word extends beyond actual phrase PCM")
                    break
                except ValueError as exc:
                    selected = None
                    attempts.append(f"{model_name}: {exc}")
            if selected is None:
                for asr_model in ("small.en", "base.en"):
                    path = audio_dir / "subtitle-v2-acoustic" / f"{pid}.{asr_model}.asr.json"
                    if not path.exists():
                        continue
                    evidence = read_json(path)
                    if evidence["audio_sha256"] != audio_hash or evidence["source_text"] != phrase["text"]:
                        continue
                    try:
                        selected = map_numeric_asr(phrase["text"], evidence["words"], audio_hash)
                        if any(w["end"] - w["start"] < .055 for w in selected):
                            raise ValueError("Unprompted ASR also has subframe-length word")
                        model_name = asr_model + "-unprompted"
                        break
                    except ValueError as exc:
                        selected = None
                        attempts.append(f"{asr_model} unprompted: {exc}")
            if selected is None:
                issues.append({"phrase_id": pid, "issue": "unusable-acoustic-alignment", "details": attempts})
                continue
            original_qa = qa_by_id.get(pid)
            transcript_evidence = []
            if original_qa and original_qa["expected"] == phrase["text"] and original_hashes.get(pid) == audio_hash:
                transcript_evidence.append({"model": "small.en-original", "transcript": original_qa["transcript"]})
            for asr_model in ("small.en", "base.en", "base"):
                path = audio_dir / "subtitle-v2-acoustic" / f"{pid}.{asr_model}.asr.json"
                if path.exists():
                    raw = read_json(path)
                    if raw["audio_sha256"] == audio_hash and raw["source_text"] == phrase["text"]:
                        transcript_evidence.append({"model": asr_model, "transcript": raw["transcript"]})
            exact_transcripts = [entry for entry in transcript_evidence if transcript_matches(phrase["text"], entry["transcript"], audio_hash)]
            if not exact_transcripts:
                issues.append({"phrase_id": pid, "issue": "transcript-disagreement" if transcript_evidence else "missing-independent-transcript-evidence", "evidence": transcript_evidence})
            offset = section["start"] + phrase["start"]
            for word in selected:
                word.update({"phrase_id": pid, "section_id": section["id"], "alignment_model": model_name,
                             "start": round(offset + word["start"], 4), "end": round(offset + word["end"], 4)})
                word.update({"startMs": round(word["start"] * 1000), "endMs": round(word["end"] * 1000)})
                aligned.append(word)
            phrase_checks.append({"phrase_id": pid, "audio_sha256": audio_hash, "text": phrase["text"],
                                  "timing_model": model_name, "source_token_count": len(selected),
                                  "unprompted_transcripts": transcript_evidence,
                                  "exact_transcript_match": bool(exact_transcripts),
                                  "reviewed_spelling_equivalence": "bindes/bindess → bindis" if audio_hash == REVIEWED_BINDIS_AUDIO_SHA256 else None,
                                  "minimum_word_seconds": round(min(w["end"] - w["start"] for w in selected), 4)})
            for page in paginate(selected):
                captions.append({"id": f"caption-{len(captions) + 1:03d}", "section_id": section["id"],
                                 "phrase_id": pid, "start": page[0]["start"], "end": page[-1]["end"],
                                 "words": page, "text": " ".join(w["text"] for w in page)})
    sections_by_id = {s["id"]: s for s in manifest["sections"]}
    for i, page in enumerate(captions):
        next_start = captions[i + 1]["start"] if i + 1 < len(captions) else manifest["duration_seconds"]
        if next_start < page["end"] - 0.001:
            issues.append({"phrase_id": page["phrase_id"], "issue": "overlapping-caption-pages"})
        page["end"] = round(min(page["end"] + 0.16, next_start, sections_by_id[page["section_id"]]["end"]), 4)
        page.update({"startMs": round(page["start"] * 1000), "endMs": round(page["end"] * 1000)})
    frame_audit = audit_frame_events(captions, manifest["duration_seconds"])
    for field in ("caption_overlap_frames", "active_word_overlap_frames", "words_without_highlight_frames"):
        if frame_audit[field]:
            issues.append({"issue": field, "details": frame_audit[field]})
    report = {"status": "pass" if not issues else "blocked", "version": "2.0",
              "source_manifest_sha256": digest(manifest_path), "duration_seconds": manifest["duration_seconds"],
              "phrases": len(phrase_checks), "words": len(aligned), "caption_pages": len(captions),
              "old_alignment": old_alignment_audit(audio_dir), "issues": issues, "phrase_checks": phrase_checks,
              "frame_event_audit": frame_audit,
              "limits": "Acoustic DTW is timing evidence only. Unprompted ASR is separate evidence; full human listening is not claimed."}
    write_json(audio_dir / "subtitle-v2-qa.json", report)
    write_json(audio_dir / "word_alignment.v2.json", {"version": "2.0", "status": report["status"],
               "source_manifest_sha256": report["source_manifest_sha256"], "timestamp_basis": "phrase-local acoustic DTW plus PCM manifest offsets", "words": aligned})
    payload = {"version": "2.0", "status": report["status"], "source_manifest_sha256": report["source_manifest_sha256"],
               "duration_seconds": manifest["duration_seconds"], "captions": captions}
    write_json(audio_dir / "captions.v2.json", payload)
    print(json.dumps({k: report[k] for k in ("status", "phrases", "words", "caption_pages", "issues")}, indent=2))
    return report


def load_verified_captions(audio_dir: Path, manifest: dict | None = None) -> list[dict]:
    """Builder integration: fail closed for missing, stale, or blocked timing."""
    payload = read_json(audio_dir / "captions.v2.json")
    if payload["status"] != "pass":
        raise ValueError("Subtitle v2 timing QA has unresolved issues")
    path = audio_dir / "narration_manifest.json"
    if payload["source_manifest_sha256"] != digest(path):
        raise ValueError("Subtitle v2 captions were built for a different narration manifest")
    if manifest is not None and manifest != read_json(path):
        raise ValueError("Builder supplied a different narration manifest")
    assert_source_manifest_match(read_json(path))
    for section in read_json(path)["sections"]:
        for phrase in section["phrases"]:
            if digest(audio_dir / "phrases" / f"{phrase['id']}.wav") != phrase["sha256"]:
                raise ValueError(f"Changed phrase audio: {phrase['id']}")
    return payload["captions"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["collect", "collect-asr", "build"])
    parser.add_argument("--audio-dir", type=Path, default=DEFAULT_AUDIO)
    parser.add_argument("--model", default="small.en")
    parser.add_argument("--phrases", nargs="*")
    args = parser.parse_args()
    if args.mode == "collect":
        collect(args.audio_dir, args.model, args.phrases)
    elif args.mode == "collect-asr":
        if not args.phrases:
            raise ValueError("Explicit phrase ids are required for independent ASR")
        collect_asr(args.audio_dir, args.model, args.phrases)
    else:
        report = build(args.audio_dir, args.model)
        raise SystemExit(0 if report["status"] == "pass" else 2)


if __name__ == "__main__":
    main()
