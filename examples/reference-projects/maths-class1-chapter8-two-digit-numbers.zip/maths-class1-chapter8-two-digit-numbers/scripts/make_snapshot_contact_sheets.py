from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


THUMB = (384, 216)
GRID = (5, 5)


def make_sheet(files: list[Path], output: Path) -> None:
    sheet = Image.new("RGB", (THUMB[0] * GRID[0], THUMB[1] * GRID[1]), "#101010")
    font = ImageFont.truetype("arial.ttf", 18)
    for index, path in enumerate(files):
        image = Image.open(path).convert("RGB")
        image.thumbnail(THUMB, Image.Resampling.LANCZOS)
        x = (index % GRID[0]) * THUMB[0]
        y = (index // GRID[0]) * THUMB[1]
        sheet.paste(image, (x, y))
        label = path.stem.replace("frame-", "").replace("-", " ", 1)
        draw = ImageDraw.Draw(sheet)
        draw.rounded_rectangle((x + 7, y + 7, x + 148, y + 34), radius=6, fill=(10, 25, 34, 220))
        draw.text((x + 13, y + 10), label, fill="white", font=font)
    sheet.save(output, quality=92)


def main() -> None:
    project = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--source",
        type=Path,
        default=project / "output/playwright/maths-pre-render",
    )
    args = parser.parse_args()
    files = sorted(args.source.glob("frame-*.png"))
    if len(files) != 50:
        raise ValueError(f"Expected 50 screenshots, found {len(files)}")
    first = args.source / "contact-sheet-01.jpg"
    second = args.source / "contact-sheet-02.jpg"
    make_sheet(files[:25], first)
    make_sheet(files[25:], second)
    print(first)
    print(second)


if __name__ == "__main__":
    main()
