# Storyboard - 2 Digit Numbers (51 to 100)

## Current source-completeness repair: v3

The v3 browser preview restores all 19 audited textbook blocks, including the complete Spiral Learning box and both Recall statements. The persistent UI now retains the chart/record instructions, full response boxes, partially given exercise grids, place-value definitions and headings, and activity setup. Exercise answers reveal after their prompt/review intervals rather than appearing immediately. See `artifacts/textbook-blocks-v3.json` and the hash-bound `artifacts/source-ui-qa-v3.json`.

The source-preserving activity narration says **bindis**. After the user's continuation approval, the rare-word ASR spelling equivalence was pinned to the exact reviewed S19 waveform; the independent word timing and strict subtitle gates passed. The v3 MP4 is rendered at `hyperframes-final/renders/maths-class1-chapter8-two-digit-numbers-final-v3.mp4`. The old v2 file remains a source-incomplete draft and must not be delivered as corrected final output.

The implemented chapter ends with the textbook activity. There is no extra closing-recap card. The final v3 encoded technical and sampled visual QA passed; see `artifacts/delivery-status.json` and `artifacts/encoded-qa-v3/visual-review.md`. The Spiral Learning concepts now mix upright and italic text selectively, rather than italicizing whole lines.

## Repair revision v2

The rejected v1 MP4 is retained for comparison, not approved delivery. Current composition is built from `scripts/hyperframes-template-v2.html`, `scripts/maths-ui-v2.js`, and `artifacts/source_content_v2.json`. The appearance authority is English Class 1 `english-class1-at-the-beach-final-v7.mp4`, not the old EVS render. Only UI conventions and the existing GSAP library are shared; chapter media and narration remain separate.

The measured narration manifest and `captions.v2.json` govern every word and scene cue. Two short lines were repaired for reliable speech; answer-review holds were added to S12, S15, and S17. Source exercise prompts remain visible before answers. Missing, stale, or failed caption alignment blocks the final build.

V2 acceptance requires all source chart cells, 100 number names, 12 numeral-writing items, 5 numeral/name matches, 16 more/less items, 27 after/before/between items, all skip-count record lists, all 9 by-five/by-ten rows, 5 expanded examples, 5 expanded practice rows, separate 3-column matching, 4 final sequences, and all 4 bindi builds. One blue bindi represents one ten. Cross and tick marks can coexist on a cell.

Manim demonstrations are teaching-card insets, not opaque full-screen overlays hiding exercises. P03 is intentionally not composed: S15 must display every source exercise row instead. S16 must display 12, 35, 68, 94, and 27 at their spoken cues. No clip is reused to fill a motion gap.

Status is **v2 rendered draft - blocked by source-text omissions**, not final delivery. The 517.9-second v2 MP4 passed technical encoded QA, but the user correctly identified the missing second Recall statement and reduced Spiral Learning box. Exercise/item counts are not proof of complete textbook text coverage. See `artifacts/delivery-status.json`; every source sentence and labelled teaching box must be mapped to a visible UI state and matching narration before a new final render.

The final v2 visual policy retains two real 3D intro clips through 9.9464 seconds. The remaining title words use an exact animated 51-to-100 comparison, followed by the PDF Recall and Spiral Learning content. Short decorative story backgrounds under opaque teaching cards are excluded because they caused abrupt edge changes. No still-frame camera pan is substituted for generated 3D video. The rest of the Maths lesson uses the approved precision-animation approach within the English teaching UI.

## Visual system

- Polished toy-like 3D classroom world with warm sunlight, rounded number blocks, bead rods, counters, and a friendly child guide.
- Navy, teal, coral, and warm cream UI. One compact source heading, one focused teaching panel, and one subtitle lane.
- Maths objects animate in direct response to the narration: rods group into tens, ones slide into place, number paths light up, and exercise marks draw on screen.
- No empty title cards, repeated footage, embedded generated text, or decorative narration.

## Sequence

1. **Chapter introduction, Spiral Learning, and Recall** - short 3D intro footage and exact title/range graphics introduce the subject, class, and chapter. Separate labelled source boxes retain both learning concepts and both Recall points before the groups-of-ten transition.
2. **Make 51-60** - five ten-rods remain fixed while ones arrive one at a time.
3. **Make 61-70** - six ten-rods and moving ones demonstrate the next decade.
4. **Make 71-100** - short object-led examples for 71, 75, 80, 81, 85, 90, 91, 95, 99, and 100.
5. **Number charts** - 51-100 and 1-100 grids animate row by row; missing cells invite a pause, then reveal.
6. **Number names** - numeral/name pairs highlight by decade and spelling pattern.
7. **Brain Gym** - write numerals, match names, one more/less, and before/after/between with timed answer reveals.
8. **Skip counting** - precise number-chart animations mark twos and threes with crosses and fours with ticks. Source record grids begin with their given values and blank answer cells before revealing the completed sets. Fives and tens retain all source exercise rows.
9. **Expanded form** - ten-rods and ones split apart into equations such as 60 + 8.
10. **Practice and activity** - matching lines animate; blue tens circles and yellow ones circles build 54, 63, 75, and 82.
