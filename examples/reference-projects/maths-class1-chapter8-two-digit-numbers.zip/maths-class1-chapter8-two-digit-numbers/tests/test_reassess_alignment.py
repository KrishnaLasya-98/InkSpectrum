from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "reassess_alignment.py"
SPEC = importlib.util.spec_from_file_location("reassess_alignment", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


class CanonicalAlignmentTests(unittest.TestCase):
    def test_digit_and_count_notation_equivalence(self) -> None:
        self.assertEqual(MODULE.wer("Nine tens and ten ones", "9-10s and 10-1s"), 0.0)
        self.assertEqual(MODULE.wer("Count by twos", "Count by 2s"), 0.0)

    def test_number_word_equivalence(self) -> None:
        self.assertEqual(MODULE.wer("fifty-one to one hundred", "51 to 100"), 0.0)
        self.assertEqual(MODULE.wer("one-to-one-hundred chart", "100 chart"), 0.0)

    def test_lexical_pronunciation_errors_remain_visible(self) -> None:
        self.assertGreater(MODULE.wer("Seven tens and one one make seventy-one", "Seven tens in one one makes 71"), 0.12)
        self.assertGreater(MODULE.wer("one ten", "110"), 0.12)


if __name__ == "__main__":
    unittest.main()
