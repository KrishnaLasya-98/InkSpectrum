import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from build_hyperframes import coverage_gaps


def test_file_count_cannot_hide_motion_gap():
    assert coverage_gaps([(0, 5), (0, 5), (0, 5)], 0, 14) == [[5, 14]]


def test_contiguous_clips_cover_title():
    assert coverage_gaps([(10, 15), (0, 5), (5, 10)], 0, 14.4) == []


def test_initial_internal_and_tail_gaps_are_reported():
    assert coverage_gaps([(1, 3), (4, 5)], 0, 6) == [[0, 1], [3, 4], [5, 6]]


def test_out_of_window_assets_do_not_claim_coverage():
    assert coverage_gaps([(-5, -1), (12, 15)], 0, 10) == [[0, 10]]
