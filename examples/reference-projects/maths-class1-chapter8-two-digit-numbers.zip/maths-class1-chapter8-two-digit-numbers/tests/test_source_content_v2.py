import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DATA = json.loads((ROOT / "artifacts" / "source_content_v2.json").read_text(encoding="utf-8"))


def test_missing_chart_partition_is_exact():
    chart = DATA["S07_number_charts"]["missing_number_chart_1_to_100"]
    given = set(chart["given_indices"])
    blank = set(chart["blank_indices"])
    assert given == {1, 3, 8, 20, 25, 32, 44, 56, 60, 63, 78, 81, 97, 100}
    assert given.isdisjoint(blank)
    assert given | blank == set(range(1, 101))


def test_all_number_names_are_present_and_key_spellings_are_correct():
    names = DATA["S08_number_names"]["number_names_1_to_100"]
    assert len(names) == 100
    assert names[39] == "forty"
    assert names[50] == "fifty-one"
    assert names[98] == "ninety-nine"
    assert names[99] == "one hundred"


def test_number_constructions_match_source_scope_and_arithmetic():
    groups = DATA["S02_groups_of_ten"]["groups"]
    assert [row["value"] for row in groups] == [50, 60, 70, 80, 90]
    for section in (
        "S03_S04_numbers_51_to_60",
        "S05_numbers_61_to_70",
        "S06_selected_numbers_71_to_100",
    ):
        for row in DATA[section]["constructions"]:
            assert row["base"] + row["added_ones"] == row["number"]
    selected = DATA["S06_selected_numbers_71_to_100"]
    assert [row["number"] for row in selected["constructions"]] == [71, 75, 80, 81, 85, 90, 91, 95, 99, 100]


def test_skip_counting_record_rows_are_complete():
    by2 = DATA["S13_skip_counting_by_2"]
    assert by2["crossed_numbers"] == list(range(2, 101, 2))
    by34 = DATA["S14_skip_counting_by_3_and_4"]
    assert by34["crossed_by_3"] == list(range(3, 100, 3))
    assert by34["ticked_by_4"] == list(range(4, 101, 4))


def test_brain_gym_exercises_are_complete_and_correct():
    numerals = DATA["S09_write_numerals"]["items"]
    assert len(numerals) == 12
    assert [row["answer"] for row in numerals] == [64, 53, 99, 40, 56, 94, 36, 100, 75, 28, 82, 16]

    matching = DATA["S10_match_numerals_and_names"]
    assert len(matching["correct"]) == 5
    assert {row["number"] for row in matching["correct"]} == set(matching["numerals_display_order"])
    assert {row["name"] for row in matching["correct"]} == set(matching["names_display_order"])

    one_more_less = DATA["S11_one_more_one_less"]["items"]
    assert len(one_more_less) == 16
    for row in one_more_less:
        base = int(row["prompt"].split()[3])
        delta = 1 if row["prompt"].startswith("1 more") else -1
        assert row["answer"] == base + delta

    before_after_between = DATA["S12_after_before_between"]["items"]
    assert len(before_after_between) == 27
    assert [row["kind"] for row in before_after_between] == ["after", "before", "between"] * 9


def test_expanded_form_source_examples_are_correct():
    rows = DATA["S16_expanded_form_examples"]["rows"]
    assert [row["number"] for row in rows] == [12, 35, 68, 94, 27]
    for row in rows:
        assert row["number"] == row["tens"] * 10 + row["ones"]
        assert row["expanded"] == f'{row["tens"] * 10} + {row["ones"]}'


def test_every_sequence_is_arithmetically_correct_and_givens_are_valid():
    for section in ("S15_count_by_5_and_10", "S18_final_skip_counting"):
        for row in DATA[section]["rows"]:
            assert all(b - a == row["step"] for a, b in zip(row["values"], row["values"][1:]))
            assert row["given_indices"]
            assert min(row["given_indices"]) >= 0
            assert max(row["given_indices"]) < len(row["values"])
    assert len(DATA["S15_count_by_5_and_10"]["rows"]) == 9


def test_expanded_form_practice_and_matching_are_consistent():
    section = DATA["S17_expanded_form_practice"]
    for row in section["write_tens_ones"]:
        assert row["number"] == row["tens"] * 10 + row["ones"]
        assert row["expanded"] == f'{row["tens"] * 10} + {row["ones"]}'
    matching = section["matching"]
    assert {item["number"] for item in matching["correct"]} == set(matching["numbers_display_order"])
    assert {item["expanded"] for item in matching["correct"]} == set(matching["expanded_options_display_order"])
    assert {item["words"] for item in matching["correct"]} == set(matching["words_options_display_order"])


def test_circle_key_and_examples_are_mathematically_correct():
    section = DATA["S19_number_with_circles"]
    assert section["key"][0]["display_rule"] == "one blue bindi = one ten"
    assert section["key"][0]["value"] == 10
    assert section["key"][1]["value"] == 1
    for row in section["examples"]:
        assert row["number"] == row["blue_tens"] * 10 + row["yellow_ones"]
