from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "scripts/subtitle_v2.py"
sys.path.insert(0, str(SCRIPT.parent))
SPEC = importlib.util.spec_from_file_location("subtitle_v2", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


def word(text, start, end):
    return {"word": text, "text": text, "start": start, "end": end, "probability": .9}


class MeasuredCaptionTests(unittest.TestCase):
    def test_number_compound_keeps_punctuation_and_actual_outer_span(self):
        measured = [word("Fifty", .1, .34), word("-one,", .34, .72), word("then", .9, 1.1),
                    word("one", 1.2, 1.32), word("hundred!", 1.32, 1.9)]
        actual = MODULE.map_exact_tokens("Fifty-one, then one hundred!", measured)
        self.assertEqual([w["text"] for w in actual], ["Fifty-one,", "then", "one", "hundred!"])
        self.assertEqual((actual[0]["start"], actual[0]["end"]), (.1, .72))
        self.assertEqual((actual[2]["start"], actual[2]["end"]), (1.2, 1.32))

    def test_wrong_or_missing_words_are_not_estimated(self):
        with self.assertRaisesRegex(ValueError, "mismatch"):
            MODULE.map_exact_tokens("Seven tens", [word("Seven", 0, .3), word("ones", .3, .6)])
        with self.assertRaisesRegex(ValueError, "Missing"):
            MODULE.map_exact_tokens("Seven tens", [word("Seven", 0, .3)])

    def test_numeric_notation_preserves_actual_timing(self):
        actual = MODULE.map_numeric_asr("Fifty plus two is fifty-two.", [word("50", 0, .4), word("plus", .4, .6), word("2", .6, .9), word("is", .9, 1.0), word("52.", 1, 1.7)])
        self.assertEqual(actual[-1]["text"], "fifty-two.")
        self.assertEqual((actual[-1]["start"], actual[-1]["end"]), (1, 1.7))
        with self.assertRaises(ValueError):
            MODULE.map_numeric_asr("one hundred", [word("100", 0, .7)])

    def test_semantic_equivalence_does_not_hide_missing_spoken_words(self):
        self.assertTrue(MODULE.transcript_matches("Nine tens and ten ones", "9-10s and 10-1s"))
        self.assertFalse(MODULE.transcript_matches("one-to-one-hundred chart", "100 chart"))
        self.assertFalse(MODULE.transcript_matches("one make seventy-one", "one makes 71"))

    def test_reviewed_bindi_spelling_is_pinned_to_approved_waveform(self):
        phrase = "Take two packets of bindis."
        heard = "Take two packets of bindes."
        approved_hash = MODULE.REVIEWED_BINDIS_AUDIO_SHA256
        self.assertTrue(MODULE.transcript_matches(phrase, heard, approved_hash))
        self.assertFalse(MODULE.transcript_matches(phrase, heard))
        self.assertFalse(MODULE.transcript_matches(phrase, heard, "other-waveform"))
        measured = [word("Take", 0, .2), word("two", .2, .4), word("packets", .4, .7),
                    word("of", .7, .8), word("bindes.", .8, 1.3)]
        self.assertEqual(MODULE.map_numeric_asr(phrase, measured, approved_hash)[-1]["text"], "bindis.")
        with self.assertRaises(ValueError):
            MODULE.map_numeric_asr(phrase, measured)

    def test_every_output_frame_has_at_most_one_active_word(self):
        pages = [{"id": "a", "start": 0, "end": 1, "words": [word("One", 0, .5), word("two.", .5, 1)]},
                 {"id": "b", "start": 1, "end": 1.5, "words": [word("Three.", 1, 1.5)]}]
        report = MODULE.audit_frame_events(pages, 1.5)
        self.assertEqual(report["frames_checked"], 45)
        self.assertEqual(report["caption_overlap_frames"], [])
        self.assertEqual(report["active_word_overlap_frames"], [])
        self.assertEqual(report["minimum_active_word_frames"], 15)
        pages[0]["words"][0]["end"] = .7
        self.assertTrue(MODULE.audit_frame_events(pages, 1.5)["active_word_overlap_frames"])

    def test_zero_negative_and_overlapping_times_are_rejected(self):
        for end in [0, -.1, float("nan")]:
            with self.assertRaisesRegex(ValueError, "Invalid"):
                MODULE.map_exact_tokens("Seven", [word("Seven", 0, end)])
        with self.assertRaisesRegex(ValueError, "Overlapping"):
            MODULE.map_exact_tokens("Seven tens", [word("Seven", 0, .4), word("tens", .3, .6)])

    def test_sentence_breaks_and_compounds_survive_pagination(self):
        text = "Hello, young mathematicians! Are you ready for a number adventure?"
        words = [word(token, i, i + .9) for i, token in enumerate(text.split())]
        pages = MODULE.paginate(words)
        self.assertEqual([w["text"] for w in pages[0]], ["Hello,", "young", "mathematicians!"])
        self.assertEqual(" ".join(w["text"] for p in pages for w in p), text)
        self.assertTrue(all(len(p) <= 7 for p in pages))

    def test_stale_manifest_never_reaches_composition(self):
        with tempfile.TemporaryDirectory() as root:
            folder = Path(root)
            MODULE.write_json(folder / "narration_manifest.json", {"sections": [], "duration_seconds": 5})
            MODULE.write_json(folder / "captions.v2.json", {"status": "pass", "source_manifest_sha256": "wrong", "captions": []})
            with self.assertRaisesRegex(ValueError, "different narration manifest"):
                MODULE.load_verified_captions(folder)

    def test_failed_alignment_never_reaches_composition(self):
        with tempfile.TemporaryDirectory() as root:
            folder = Path(root)
            MODULE.write_json(folder / "captions.v2.json", {"status": "blocked", "captions": []})
            with self.assertRaisesRegex(ValueError, "unresolved"):
                MODULE.load_verified_captions(folder)


if __name__ == "__main__":
    unittest.main()
