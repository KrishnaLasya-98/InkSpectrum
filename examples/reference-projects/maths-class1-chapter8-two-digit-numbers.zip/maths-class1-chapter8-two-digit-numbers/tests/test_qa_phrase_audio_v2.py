import sys
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from qa_phrase_audio_v2 import audit, covering_windows, match_window


class PhraseAudioGateTests(unittest.TestCase):
    def setUp(self):
        self.rate = 1000
        rng = np.random.default_rng(71)
        self.source = np.zeros(8500, dtype=np.float32)
        self.source[500:3500] = rng.normal(0, .2, 3000)
        self.source[4500:7500] = rng.normal(0, .2, 3000)
        self.manifest = {"duration_seconds": 8.5, "sections": [{"id": "S01", "start": 0,
            "phrases": [{"id": "P1", "text": "First phrase", "start": .5, "end": 3.5},
                        {"id": "P2", "text": "Second phrase", "start": 4.5, "end": 7.5}]}]}

    def test_whole_phrases_and_gain_change_pass(self):
        report = audit(self.source, self.source * .45, self.manifest, self.rate)
        self.assertEqual(report["status"], "passed")
        self.assertEqual(report["phrases_checked"], 2)
        self.assertEqual(report["items"][0]["whole_phrase"]["duration_seconds"], 3)

    def test_eighty_millisecond_delay_fails(self):
        encoded = np.concatenate((np.zeros(80), self.source[:-80]))
        report = audit(self.source, encoded, self.manifest, self.rate)
        self.assertEqual(report["status"], "failed")
        self.assertEqual(report["items"][0]["whole_phrase"]["reason"], "timing-offset")
        self.assertAlmostEqual(report["items"][0]["whole_phrase"]["offset_seconds"], .08)

    def test_missing_middle_speech_is_caught_by_full_coverage(self):
        encoded = self.source.copy()
        encoded[2200:2900] = 0
        report = audit(self.source, encoded, self.manifest, self.rate)
        self.assertEqual(report["items"][0]["status"], "failed")
        self.assertTrue(report["items"][0]["failed_windows"])

    def test_duplicate_wrong_phrase_is_identified(self):
        encoded = self.source.copy()
        encoded[4500:7500] = self.source[500:3500]
        report = audit(self.source, encoded, self.manifest, self.rate)
        self.assertEqual(report["items"][1]["status"], "failed")
        self.assertEqual(report["items"][1]["possible_wrong_phrase_copies"][0]["source_phrase_id"], "P1")

    def test_truncated_final_phrase_fails(self):
        report = audit(self.source, self.source[:6800], self.manifest, self.rate)
        self.assertEqual(report["status"], "failed")
        self.assertFalse(report["encoded_complete"])

    def test_extra_speech_in_silent_gap_fails(self):
        encoded = self.source.copy()
        encoded[3800:4200] = self.source[600:1000]
        report = audit(self.source, encoded, self.manifest, self.rate)
        self.assertEqual(report["phrases_passed"], 2)
        self.assertTrue(report["unexpected_gap_audio"])
        self.assertEqual(report["status"], "failed")

    def test_windows_cover_both_ends_and_all_interior_samples(self):
        windows = covering_windows(517, 3954, self.rate)
        self.assertEqual(windows[0][0], 517)
        self.assertEqual(windows[-1][1], 3954)
        self.assertTrue(all(right[0] <= left[1] for left, right in zip(windows, windows[1:])))

    def test_native_rate_avoids_fractional_resampling_false_failure(self):
        rate = 48000
        size = rate * 2
        rng = np.random.default_rng(13)
        spectrum = np.fft.rfft(rng.normal(0, 1, size))
        hz = np.fft.rfftfreq(size, 1 / rate)
        spectrum[(hz < 4500) | (hz > 7000)] = 0
        source = np.fft.irfft(spectrum, size).astype(np.float32)
        # Native23-sample delay is 7.666... samples after downsampling to16k.
        delayed = np.concatenate((np.zeros(23, dtype=np.float32), source[:-23]))
        native = match_window(source, delayed, 12000, 60000, rate)
        coarse = match_window(source[::3], delayed[::3], 4000, 20000, 16000)
        self.assertEqual(native["status"], "passed")
        self.assertGreater(native["correlation"], .999)
        self.assertAlmostEqual(native["offset_seconds"], 23 / rate, places=5)
        self.assertLess(coarse["correlation"], .9)


if __name__ == "__main__":
    unittest.main()
