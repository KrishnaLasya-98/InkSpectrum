import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BLOCKS = json.loads((ROOT / "artifacts" / "textbook-blocks-v3.json").read_text(encoding="utf-8"))
SOURCE = json.loads((ROOT / "artifacts" / "source_content_v2.json").read_text(encoding="utf-8"))
BY_ID = {block["id"]: block for block in BLOCKS["blocks"]}


def test_schema_and_stable_order():
    assert BLOCKS["schema_version"] == "3.0"
    ids = [block["id"] for block in BLOCKS["blocks"]]
    assert len(ids) == len(set(ids))
    assert ids == [
        "spiral-learning",
        "recall",
        "groups-transition",
        "make-51-60",
        "make-61-70",
        "make-71-100",
        "chart-51-100",
        "chart-missing-1-100",
        "number-names",
        "count-by-two",
        "record-crossed-two",
        "count-by-three-four",
        "record-crossed-three",
        "record-ticked-four",
        "count-by-five",
        "count-by-ten",
        "expanded-definition",
        "expanded-table",
        "activity-setup",
    ]
    assert all(block["section_id"].startswith("S") for block in BLOCKS["blocks"])
    assert all(1 <= block["pdf_page"] <= 16 for block in BLOCKS["blocks"])


def test_page_1_preserves_every_required_line():
    spiral = BY_ID["spiral-learning"]
    recall = BY_ID["recall"]
    transition = BY_ID["groups-transition"]
    assert spiral["heading"] == "Spiral Learning"
    assert spiral["lines"] == [
        "Introduction of higher numbers (51 to 100)",
        "Concepts of Skip counting, Expanded form",
    ]
    assert recall["heading"] == "RECALL"
    assert recall["lines"] == SOURCE["S02_groups_of_ten"]["source_intro"][:2]
    assert "51 to 100" in transition["lines"][0]
    assert "groups of ten" in transition["lines"][1]


def test_construction_headings_and_names_are_required():
    cases = [
        ("make-51-60", "S03_S04_numbers_51_to_60", 10),
        ("make-61-70", "S05_numbers_61_to_70", 10),
        ("make-71-100", "S06_selected_numbers_71_to_100", 10),
    ]
    for block_id, source_key, count in cases:
        block = BY_ID[block_id]
        assert block["heading"] == SOURCE[source_key]["source_heading"]
        assert block["required_item_count"] == len(SOURCE[source_key]["constructions"]) == count
        assert block["required_result_fields"] == ["number", "name"]


def test_page_8_charts_preserve_instructions_and_source_state():
    chart = BY_ID["chart-51-100"]
    missing = BY_ID["chart-missing-1-100"]
    assert chart["lines"] == ["Let us put together numbers 51-100."]
    assert missing["lines"] == ["Recall and fill in the missing numbers from 1-100."]
    grid = missing["response_grid"]
    source_grid = SOURCE["S07_number_charts"]["missing_number_chart_1_to_100"]
    assert grid["prefilled_values"] == source_grid["given_indices"]
    assert grid["prefilled_count"] == len(source_grid["given_indices"]) == 14
    assert grid["blank_count"] == len(source_grid["blank_indices"]) == 86
    assert grid["total_cells"] == grid["prefilled_count"] + grid["blank_count"] == 100


def test_page_9_requires_all_number_names():
    block = BY_ID["number-names"]
    assert block["heading"] == "Number names 1-100."
    assert block["required_item_count"] == len(SOURCE["S08_number_names"]["number_names_1_to_100"]) == 100


def test_skip_counting_instructions_prefills_and_box_counts():
    by2 = BY_ID["count-by-two"]
    assert by2["lines"] == ["Let us count by two. Cross every second number."]
    record2 = BY_ID["record-crossed-two"]
    assert record2["lines"] == ["Now, write all the crossed numbers here."]
    grid = record2["response_grid"]
    assert grid["prefilled_values"] == SOURCE["S13_skip_counting_by_2"]["record_row_source_prefill"]
    assert grid["required_answer_count"] == len(SOURCE["S13_skip_counting_by_2"]["crossed_numbers"]) == 50
    assert grid["blank_count"] == grid["required_answer_count"] - grid["prefilled_count"] == 46

    dual = BY_ID["count-by-three-four"]
    assert dual["lines"] == [
        "Let us count by threes and fours. Cross every third number.",
        "Tick every fourth number.",
    ]
    cross_block = BY_ID["record-crossed-three"]
    tick_block = BY_ID["record-ticked-four"]
    assert cross_block["lines"] == ["Now, write all the crossed numbers here."]
    assert tick_block["lines"] == ["Write all the ticked numbers here."]
    cross, tick = cross_block["response_grid"], tick_block["response_grid"]
    assert cross["prefilled_values"] == SOURCE["S14_skip_counting_by_3_and_4"]["crossed_row_source_prefill"]
    assert tick["prefilled_values"] == SOURCE["S14_skip_counting_by_3_and_4"]["ticked_row_source_prefill"]
    assert cross["required_answer_count"] == len(SOURCE["S14_skip_counting_by_3_and_4"]["crossed_by_3"]) == 33
    assert tick["required_answer_count"] == len(SOURCE["S14_skip_counting_by_3_and_4"]["ticked_by_4"]) == 25
    assert cross["blank_count"] == 29 and tick["blank_count"] == 21


def test_page_14_sequences_and_expanded_form_text():
    rows = SOURCE["S15_count_by_5_and_10"]["rows"]
    for block_id, step in [("count-by-five", 5), ("count-by-ten", 10)]:
        block = BY_ID[block_id]
        expected = [row for row in rows if row["step"] == step]
        grid = block["response_grid"]
        assert grid["row_count"] == len(expected)
        assert grid["total_cells"] == sum(len(row["values"]) for row in expected)
        assert grid["prefilled_count"] == sum(len(row["given_indices"]) for row in expected)
        assert grid["blank_count"] == grid["total_cells"] - grid["prefilled_count"]

    definition = BY_ID["expanded-definition"]
    table = BY_ID["expanded-table"]
    assert definition["lines"] == SOURCE["S16_expanded_form_examples"]["source_intro"]
    assert table["table_headers"] == ["Number", "Tens", "Ones", "Expanded Form"]
    assert table["required_item_count"] == len(SOURCE["S16_expanded_form_examples"]["rows"]) == 5


def test_page_16_activity_setup_and_unsolved_then_reveal_contract():
    block = BY_ID["activity-setup"]
    assert block["heading"] == "ACTIVITY"
    assert block["subheading"] == "Number with circles"
    joined = " ".join(block["lines"]).lower()
    for phrase in ["two packets of bindis", "blue and yellow", "1 ten", "1 one", "make these numbers", "example"]:
        assert phrase in joined
    grid = block["response_grid"]
    expected = SOURCE["S19_number_with_circles"]["examples"]
    assert grid["prompt_values"] == [item["number"] for item in expected] == [54, 63, 75, 82]
    assert grid["prompt_count"] == len(expected) == 4
    assert grid["initial_state"] == "prompts_without_completed_circle_answers"
    assert grid["reveal_state"] == "reveal_each_completed_circle_answer_in_sequence"


def test_no_publisher_footer_or_uncorrected_known_errata():
    serialized = json.dumps(BLOCKS)
    assert "SV Rockland" not in serialized
    assert "Seventy Six" not in serialized
    assert "Eight-two" not in serialized
    assert "Thrity" not in serialized
    assert "1 tens" not in serialized
    assert "1 ones" not in serialized
