import copy
import json
import sys
import unittest
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "scripts"))
from prepare_narration_v3 import ADDITIONS, PAUSES, REPLACEMENTS, make_script


class RevisionTests(unittest.TestCase):
    def setUp(self):
        self.source = json.loads((PROJECT / "artifacts/narration_script.json").read_text(encoding="utf-8"))

    def test_only_approved_text_changes_and_additions(self):
        before = copy.deepcopy(self.source)
        revised = make_script(self.source)
        self.assertEqual(self.source, before)
        source = {f"{s['id']}-{i:02}": p for s in before["sections"] for i, p in enumerate(s["phrases"], 1)}
        after = {f"{s['id']}-{i:02}": p for s in revised["sections"] for i, p in enumerate(s["phrases"], 1)}
        self.assertEqual(len(after), 87)
        self.assertEqual(set(after) - set(source), {"S01-05", "S01-06"})
        for pid, phrase in source.items():
            self.assertEqual(after[pid]["text"], REPLACEMENTS.get(pid, phrase["text"]))
            self.assertEqual(after[pid]["pause_after"], PAUSES.get(pid, phrase["pause_after"]))
        self.assertEqual(after["S01-05"], ADDITIONS[0])
        self.assertEqual(after["S01-06"], ADDITIONS[1])

    def test_precision_animation_phrase_audio_contract_preserved(self):
        revised = make_script(self.source)
        a = {f"{s['id']}-{i:02}": p for s in self.source["sections"] for i, p in enumerate(s["phrases"], 1)}
        b = {f"{s['id']}-{i:02}": p for s in revised["sections"] for i, p in enumerate(s["phrases"], 1)}
        for pid in ("S13-02", "S14-01", "S14-02", "S14-03", "S16-03", "S16-04", "S16-05"):
            self.assertEqual(a[pid], b[pid])

    def test_class1_review_holds_preserved(self):
        revised = make_script(self.source)
        by_id = {f"{s['id']}-{i:02}": p for s in revised["sections"] for i, p in enumerate(s["phrases"], 1)}
        for pid, duration in {"S12-05": 8.0, "S15-05": 7.0, "S17-05": 8.0}.items():
            self.assertEqual(by_id[pid]["pause_after"], duration)


if __name__ == "__main__":
    unittest.main()
