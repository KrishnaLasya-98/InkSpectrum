'use strict';
const D=window.PRODUCTION_DATA, SRC=D.sourceContent, tl=gsap.timeline({paused:true});
const BLOCKS=Object.fromEntries(D.textbookBlocks.blocks.map(b=>[b.id,b]));
const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const range=(a,b)=>Array.from({length:b-a+1},(_,i)=>a+i);
const words=D.captions.flatMap(p=>p.words), norm=s=>String(s).toLowerCase().replace(/[^a-z0-9]/g,'');
const phrase=(s,i)=>s.phrases[i-1], pt=(s,i)=>s.start+phrase(s,i).start, pe=(s,i)=>s.start+phrase(s,i).end;
const name=n=>SRC.S08_number_names.number_names_1_to_100[n-1];
window.MATHS_QA={pages:[],events:[],buildCues:[],missingCues:[],sourceBlocks:[]};
function sourceLineHtml(id,line){
 let html=esc(line);
 if(id==='spiral-learning'){
  for(const term of ['higher numbers','Skip counting','Expanded form'])html=html.replace(term,`<em>${term}</em>`);
 }
 return html;
}
function sourceBlock(id,showHeading=true,extra=''){
 const b=BLOCKS[id];if(!b)throw new Error(`Missing textbook block: ${id}`);
 return `<div class="source-block ${extra}" data-source-block="${id}">${showHeading&&b.heading?`<h2 class="source-heading">${esc(b.heading)}</h2>`:''}${b.lines.map((line,i)=>`<p data-source-line="${id}-${i}">${sourceLineHtml(id,line)}</p>`).join('')}</div>`;
}
function responseGrid(id,values){const given=BLOCKS[id].response_grid.prefilled_values;return `<div class="record-exercise" data-record-grid="${id}">${sourceBlock(id)}<div class="record-grid">${values.map(n=>`<div class="record-cell ${given.includes(n)?'source-given':'source-blank'}" data-number="${n}"><span class="${given.includes(n)?'':'answer-reveal'}">${n}</span></div>`).join('')}</div></div>`;}
function wordTime(s,i,text,occurrence=0){const p=phrase(s,i), start=s.start+p.start,end=s.start+p.end,ws=words.filter(w=>w.start>=start-.05&&w.end<=end+.08),needle=norm(text);let match=0;for(let j=0;j<ws.length;j++){let t='';for(let k=j;k<Math.min(j+5,ws.length);k++){t+=norm(ws[k].word||ws[k].text);if(t===needle&&match++===occurrence)return ws[j].start;}}window.MATHS_QA.missingCues.push({section:s.id,phrase:p.id,text,occurrence});return start;}
function visible(el,start,end){gsap.set(el,{visibility:'hidden',opacity:0});tl.set(el,{visibility:'visible',opacity:1},start);if(end<D.duration)tl.set(el,{visibility:'hidden',opacity:0},end);}
function reveal(el,time){tl.set(el,{visibility:'visible',opacity:1},time);window.MATHS_QA.events.push({type:'reveal',time,target:el.id||el.className});}
function focus(el,time,end){tl.set(el,{backgroundColor:'#fff0b9',borderColor:'#be6c36'},time);if(end)tl.set(el,{backgroundColor:'#fff',borderColor:'#dae9e5'},end);}
function page(s,id,html,start,end){const el=document.createElement('div');el.className='ui-page';el.id=`${s.id}-${id}`;el.innerHTML=html;document.querySelector(`#section-${s.id} .exercise-body`).append(el);const next=D.sections[D.sections.indexOf(s)+1]?.start;const visibleEnd=end===next?Math.min(end+.2,D.duration):end;visible(el,start,visibleEnd);window.MATHS_QA.pages.push({id:el.id,start,end:visibleEnd});return el;}
function chart(values,missing=[],marks=false){return `<div class="number-chart">${values.map(n=>`<div class="cell" data-number="${n}"><span class="${missing.includes(n)?'answer-reveal':''}">${n}</span>${marks?'<span class="mark-cross answer-reveal">×</span><span class="mark-tick answer-reveal">✓</span>':''}</div>`).join('')}</div>`;}
function rowQuestions(u,cls=''){return `<div class="question-grid ${cls}">${u.prompts.map((v,i)=>{const answer=`<span class="answer-box"><span class="answer-reveal">${u.answers[i]}</span></span>`;const body=cls==='three'?esc(v).replace('?',answer):`<span class="row-text">${esc(v)}</span>${answer}`;return `<div class="exercise-row" data-item="${i}">${body}</div>`;}).join('')}</div>`;}
function seqRows(rows){return rows.map(r=>`<div class="sequence" data-source-id="${r.id}"><span class="sequence-label">By ${r.step}</span>${r.values.map((n,i)=>`<div class="sequence-cell ${r.given_indices.includes(i)?'':'empty'}" data-number="${n}"><span class="${r.given_indices.includes(i)?'':'answer-reveal'}">${n}</span></div>`).join('')}</div>`).join('');}
function expanded(rows,blank=false){const slot=n=>`<span class="answer-slot"><span class="answer-reveal">${n}</span></span>`;return rows.map(r=>`<div class="expanded-row" data-number="${r.number}"><b>${r.number}</b><span>${blank?slot(r.tens):r.tens} ${r.tens===1?'ten':'tens'} and ${blank?slot(r.ones):r.ones} ${r.ones===1?'one':'ones'}</span><span>${blank?`${slot(r.tens*10)} + ${slot(r.ones)}`:esc(r.expanded)}</span></div>`).join('');}
function matching(columns,triple=false){return `<div class="match-layout ${triple?'triple':''}"><svg class="match-lines"></svg>${columns.map((col,j)=>`<div class="match-column">${col.map((x,i)=>`<div class="match-item" data-col="${j}" data-row="${i}">${esc(x)}</div>`).join('')}</div>`).join('')}</div>`;}
function connect(root,a,b,time){const box=root.querySelector('.match-layout'),left=box.querySelector(`[data-col="${a[0]}"][data-row="${a[1]}"]`),right=box.querySelector(`[data-col="${b[0]}"][data-row="${b[1]}"]`);const r=box.getBoundingClientRect(),l=left.getBoundingClientRect(),q=right.getBoundingClientRect();const line=document.createElementNS('http://www.w3.org/2000/svg','path');line.setAttribute('d',`M ${l.right-r.left} ${l.top+l.height/2-r.top} L ${q.left-r.left} ${q.top+q.height/2-r.top}`);line.setAttribute('class','match-line');box.querySelector('svg').append(line);const length=line.getTotalLength();gsap.set(line,{strokeDasharray:length,strokeDashoffset:length});tl.set(line,{opacity:1},time).to(line,{strokeDashoffset:0,duration:.34,ease:'none'},time);focus(left,time);focus(right,time);}
function teaching(s,heading,instruction=''){const el=document.createElement('section');el.id=`section-${s.id}`;el.className='section teaching-section';el.innerHTML=`<div class="section-tab">${esc(s.ui.label.replace(' · Brain Gym',''))}</div><div class="teaching-card"><h1 class="teaching-heading">${esc(heading)}</h1>${instruction?`<p class="exercise-instruction">${esc(instruction)}</p>`:''}<div class="exercise-body"></div></div>`;document.getElementById('ui-layer').append(el);return el;}
function allReveals(p,t){p.querySelectorAll('.answer-reveal').forEach(el=>reveal(el,t));}

D.sections.forEach((s,index)=>{
 const end=D.sections[index+1]?.start??D.duration;let el,p;
 if(s.id==='S01'){el=document.createElement('section');el.id=`section-${s.id}`;el.className='section hero';el.innerHTML='<div class="title-card"><div class="eyebrow">Mathematics · Class 1</div><div class="lesson-number">Chapter 8</div><h1>2 Digit<br>Numbers</h1><p>51 to 100</p></div>';document.getElementById('ui-layer').append(el);}
 else {const headingBlocks={S03:'make-51-60',S04:'make-51-60',S05:'make-61-70',S06:'make-71-100',S08:'number-names',S16:'expanded-definition'};const sourceHeadings={S09:SRC.S09_write_numerals.source_heading,S10:SRC.S10_match_numerals_and_names.source_heading,S11:SRC.S11_one_more_one_less.source_heading,S12:SRC.S12_after_before_between.source_heading,S18:'2. Write the following skip counting.'};if(['S09','S10','S11','S12','S18'].includes(s.id))s.ui.label='Brain Gym';el=teaching(s,headingBlocks[s.id]?BLOCKS[headingBlocks[s.id]].heading:sourceHeadings[s.id]||s.ui.title);if(headingBlocks[s.id])el.querySelector('.teaching-heading').dataset.sourceBlock=headingBlocks[s.id];}
 // Incoming card crossfades over opaque outgoing card; no empty 0.4-second gaps.
 visible(el,s.start,Math.min(end+.2,D.duration));if(index)tl.fromTo(el,{opacity:0},{opacity:1,duration:.2},s.start);
 if(s.id==='S01'){
  const change=pt(s,3),recallStart=pt(s,5),storyEnd=D.visualCoverage.continuousStory[0][1];visible(el.querySelector('.title-card'),s.start,storyEnd);
  const demo=document.createElement('div');demo.className='intro-range';demo.innerHTML=`<div class="section-tab">Mathematics · Class 1 · Chapter 8</div><div class="teaching-card"><h1 class="teaching-heading">2 Digit Numbers · 51 to 100</h1><div class="range-cards">${[51,100].map(n=>`<div class="range-number" data-number="${n}"><strong>${n}</strong><div class="range-demo-objects">${range(1,Math.floor(n/10)).map(()=>`<span class="mini-rod">${'<i></i>'.repeat(10)}</span>`).join('')}${n===51?'<i class="one"></i>':''}</div><p>${Math.floor(n/10)} tens${n===51?' and 1 one':''}</p></div>`).join('')}</div></div>`;el.append(demo);visible(demo,storyEnd,change);tl.fromTo(demo.querySelectorAll('.mini-rod,.one'),{y:25,opacity:0},{y:0,opacity:1,duration:.35,stagger:.04,ease:'power2.out'},storyEnd);focus(demo.querySelector('[data-number="51"]'),wordTime(s,2,'fifty-one'));focus(demo.querySelector('[data-number="100"]'),wordTime(s,2,'one hundred'));
  const spiral=document.createElement('div');spiral.className='intro-source-box';spiral.innerHTML=`<div class="section-tab">Mathematics · Class 1 · Chapter 8</div><div class="teaching-card">${sourceBlock('spiral-learning',true,'textbook-box')}</div>`;el.append(spiral);visible(spiral,change,recallStart);
  const recall=document.createElement('div');recall.className='intro-recall';recall.innerHTML=`<div class="section-tab">Mathematics · Class 1 · Chapter 8</div><div class="teaching-card">${sourceBlock('recall',true,'textbook-box recall-box')}${chart(range(21,50))}</div>`;el.append(recall);visible(recall,recallStart,end+.2);focus(recall.querySelector('[data-source-line="recall-0"]'),pt(s,5),pt(s,6));focus(recall.querySelector('[data-source-line="recall-1"]'),pt(s,6));window.MATHS_QA.pages.push({id:'intro-story-title',start:s.start,end:storyEnd},{id:'intro-exact-range',start:storyEnd,end:change},{id:'intro-source-spiral',start:change,end:recallStart},{id:'intro-source-recall',start:recallStart,end:end+.2});return;
 }
 if(s.id==='S02'){
  p=page(s,'groups',`${sourceBlock('groups-transition',false)}<div class="tens-rows">${range(5,9).map(n=>`<div class="tens-row" data-number="${n*10}"><span>${n} tens</span><div class="tens-count">${range(1,n).map(()=>`<span class="mini-rod">${'<i></i>'.repeat(10)}</span>`).join('')}</div><strong>${n*10}</strong></div>`).join('')}</div>`,s.start,end);
  [50,60,70,80,90].forEach((n,i)=>focus(p.querySelector(`[data-number="${n}"]`),wordTime(s,[2,3,3,4,4][i],name(n))));
 }else if(['S03','S04','S05','S06'].includes(s.id)){
  const mapping={S03:[[50,1,'fifty'],[51,2,'one'],[52,3,'two'],[53,4,'three'],[54,4,'four'],[55,4,'five'],[53,4],[54,4],[55,4]],S04:[[56,1,'six'],[57,1,'seven'],[58,1,'eight'],[59,1,'nine'],[56,2],[57,2],[58,2],[59,2],[60,4]],S05:[[60,1],[61,2],[62,2],[63,2],[64,2],[65,2],[66,3],[67,3],[68,3],[69,3],[70,4]],S06:[[71,1],[75,2,'five'],[80,3],[81,4,'one'],[85,4,'five'],[90,5],[91,6,'one'],[95,6,'five'],[99,6,'nine',1],[100,7]]}[s.id];
  const cues=mapping.map(([n,i,w,occurrence],j)=>({n,time:j===0?s.start:wordTime(s,i,w||name(n),occurrence||0)}));
  const regroup={S03:[],S04:[[60,3,5]],S05:[[70,4,6]],S06:[[80,3,7],[90,5,8],[100,7,9]]}[s.id];
  regroup.forEach(([n,i,tens])=>cues.push({n,time:pt(s,i),tens,ones:10}));
  cues.sort((a,b)=>a.time-b.time);
  const choices=[...new Set(mapping.map(x=>x[0]))];
  p=page(s,'build','',s.start,end);
  cues.forEach((c,j)=>{const tens=c.tens??Math.floor(c.n/10),ones=c.ones??c.n%10,div=document.createElement('div');div.className='build-state';div.dataset.number=c.n;div.innerHTML=`<div class="build-number">${c.n}<div class="build-equation">${tens*10} + ${ones}</div></div><div class="build-objects">${range(1,tens).map(()=>`<div class="rod">${'<i class="bead"></i>'.repeat(10)}</div>`).join('')}<div class="loose-ones">${'<i class="one"></i>'.repeat(ones)}</div></div><div class="build-description">${tens} tens${ones?` and ${ones} ${ones===1?'one':'ones'}`:''}</div><div class="build-strip">${choices.map(n=>`<span class="build-choice" style="${n===c.n?'background:#fff0b9;border-color:#be6c36':''}">${n}</span>`).join('')}</div>`;p.append(div);visible(div,c.time,cues[j+1]?.time??end);tl.fromTo(div.querySelector('.loose-ones'),{y:12,opacity:.3},{y:0,opacity:1,duration:.25},c.time);window.MATHS_QA.buildCues.push({section_id:s.id,time:c.time,end:cues[j+1]?.time??end,number:c.n,tens,ones});});
 }else if(s.id==='S07'){
  const change=pt(s,3);el.querySelector('.section-tab').dataset.sourceBlock='chart-51-100';page(s,'51-100',sourceBlock('chart-51-100',false)+chart(SRC.S07_number_charts.numbers_51_to_100.values),s.start,change);
  p=page(s,'missing-chart',sourceBlock('chart-missing-1-100',false)+chart(range(1,100),SRC.S07_number_charts.missing_number_chart_1_to_100.blank_indices),change,end);allReveals(p,wordTime(s,5,'revealed'));
 }else if(s.id==='S08'){
  [0,50].forEach((offset,i)=>{const q=page(s,`names-${offset+1}`,`<h2 class="page-title">Number names ${offset+1}–${offset+50}</h2><div class="names-grid">${range(offset+1,offset+50).map(n=>`<div class="name-pair" data-number="${n}"><b>${n}</b><span class="${i?'':'answer-reveal'}">${esc(name(n))}</span></div>`).join('')}</div><div class="decades">${range(2,9).map(n=>`<span data-decade="${n*10}">${n*10} ${name(n*10)}</span>`).join('')}</div>`,i?pt(s,3):s.start,i?end:pt(s,3));if(!i){allReveals(q,pt(s,2));range(2,9).forEach(n=>focus(q.querySelector(`[data-decade="${n*10}"]`),wordTime(s,2,name(n*10))));}else focus(q.querySelector('[data-number="64"]'),wordTime(s,3,'sixty-four'));});
 }else if(['S09','S11','S12'].includes(s.id)){
  const cls=s.id==='S11'?'dense':s.id==='S12'?'three':'';
  const questionData=s.id==='S11'?{prompts:SRC.S11_one_more_one_less.items.map(r=>r.prompt),answers:SRC.S11_one_more_one_less.items.map(r=>r.answer)}:s.ui;
  p=page(s,'questions',(s.id==='S12'?'<div class="column-headings"><span>After</span><span>Before</span><span>Between</span></div>':'')+rowQuestions(questionData,cls),s.start,end);
  if(s.id==='S09'){s.ui.answers.forEach((n,i)=>focus(p.querySelector(`[data-item="${i}"]`),wordTime(s,i<6?2:3,name(n))));allReveals(p,pt(s,4));}
  if(s.id==='S11'){[0,1].forEach((i)=>reveal(p.querySelector(`[data-item="${i}"] .answer-reveal`),wordTime(s,2,name(s.ui.answers[i]))));allReveals(p,pt(s,4));}
  if(s.id==='S12'){[0,1,2].forEach((i)=>reveal(p.querySelector(`[data-item="${i}"] .answer-reveal`),wordTime(s,i===2?4:3,name(s.ui.answers[i]))));allReveals(p,wordTime(s,5,'reveal'));}
 }else if(s.id==='S10'){
  p=page(s,'match',matching([s.ui.left,s.ui.right]),s.start,end);s.ui.pairs.forEach(([a,b],i)=>connect(p,[0,a],[1,b],pt(s,3)+i*.48));
 }else if(s.id==='S13'||s.id==='S14'){
  const dual=s.id==='S14',instructionId=dual?'count-by-three-four':'count-by-two';if(!dual)el.querySelector('.section-tab').dataset.sourceBlock=instructionId;
  p=page(s,'count-chart',`<div class="split-left">${chart(range(1,100),[],true)}</div><div class="split-right">${sourceBlock(instructionId,false)}<div class="record-lists">${dual?responseGrid('record-crossed-three',SRC.S14_skip_counting_by_3_and_4.crossed_by_3)+responseGrid('record-ticked-four',SRC.S14_skip_counting_by_3_and_4.ticked_by_4):responseGrid('record-crossed-two',SRC.S13_skip_counting_by_2.crossed_numbers)}</div></div>`,s.start,end);
  visible(p.querySelector('.record-lists'),pt(s,4),end);allReveals(p.querySelector('.record-lists'),pe(s,4)+2);
  const marks=dual?[[3,'cross',1],[4,'tick',2]]:[[2,'cross',2]];
  marks.forEach(([step,kind,pi])=>range(1,Math.floor(100/step)).forEach((k)=>{const n=k*step;const t=k<=5?wordTime(s,pi,name(n)):pt(s,dual?4:3);reveal(p.querySelector(`[data-number="${n}"] .mark-${kind}`),t);}));
 }else if(s.id==='S15'){
  const rows=SRC.S15_count_by_5_and_10.rows,change=pt(s,3);
  el.querySelector('.section-tab').dataset.sourceBlock='count-by-five';p=page(s,'by-five',`${sourceBlock('count-by-five',false)}${seqRows(rows.filter(r=>r.step===5))}`,s.start,change);allReveals(p,wordTime(s,2,'ones'));
  [5,10,15,20,25].forEach(n=>focus(p.querySelector(`.sequence [data-number="${n}"]`),wordTime(s,2,name(n))));
  p=page(s,'by-ten',`${sourceBlock('count-by-ten',false)}${seqRows(rows.filter(r=>r.step===10))}`,change,end);allReveals(p,pe(s,5)+.3);
 }else if(s.id==='S16'){
  const rows=SRC.S16_expanded_form_examples.rows;p=page(s,'expanded',`${sourceBlock('expanded-definition',false)}<div class="split-left expanded-source-table" data-source-block="expanded-table"><div class="expanded-headers">${BLOCKS['expanded-table'].table_headers.map(x=>`<span>${esc(x)}</span>`).join('')}</div>${rows.map(r=>`<div class="expanded-source-row" data-number="${r.number}"><b>${r.number}</b><span>${r.tens}</span><span>${r.ones}</span><span>${r.expanded}<small>${esc(r.words)}</small></span></div>`).join('')}</div>`,s.start,end);
  rows.forEach((r,i)=>focus(p.querySelector(`[data-number="${r.number}"]`),wordTime(s,[3,4,4,5,5][i],name(r.number))));
 }else if(s.id==='S17'){
  const data=SRC.S17_expanded_form_practice,change=pt(s,4);p=page(s,'expanded-practice','<h2 class="page-title">Write the tens, ones and expanded form.</h2>'+expanded(data.write_tens_ones,true),s.start,change);p.querySelectorAll('[data-number="52"] .answer-reveal').forEach(x=>reveal(x,pt(s,2)));allReveals(p,pe(s,3)+.3);
  const m=data.matching;p=page(s,'expanded-matching','<h2 class="page-title">1. Match the number with its expanded form.</h2>'+matching([m.numbers_display_order,m.expanded_options_display_order,m.words_options_display_order],true),change,end);
  const tab=el.querySelector('.section-tab');tab.innerHTML='<span>Let\'s Do</span><span class="matching-label">Brain Gym</span>';visible(tab.children[0],s.start,change);visible(tab.children[1],change,end+.2);
  m.correct.forEach((r,i)=>{const t=i===0?wordTime(s,5,'seventy-two'):pe(s,5)+.08*(i-1);connect(p,[0,m.numbers_display_order.indexOf(r.number)],[1,m.expanded_options_display_order.indexOf(r.expanded)],t);connect(p,[1,m.expanded_options_display_order.indexOf(r.expanded)],[2,m.words_options_display_order.indexOf(r.words)],t+.15);});
 }else if(s.id==='S18'){
  p=page(s,'sequences',seqRows(SRC.S18_final_skip_counting.rows),s.start,end);allReveals(p,wordTime(s,4,'reveal'));
 }else if(s.id==='S19'){
  const data=SRC.S19_number_with_circles,setup=BLOCKS['activity-setup'];el.querySelector('.section-tab').textContent=setup.heading;el.querySelector('.section-tab').dataset.sourceBlock='activity-setup';el.querySelector('.teaching-heading').textContent=setup.subheading;el.querySelector('.teaching-heading').dataset.sourceBlock='activity-setup';
  p=page(s,'bindis',`<div class="activity-instructions" data-source-block="activity-setup">${setup.lines.map((line,i)=>`<p data-source-line="activity-setup-${i}">${esc(line)}</p>`).join('')}</div><div class="circle-grid">${data.examples.map(r=>`<div class="circle-card" data-number="${r.number}"><h3>${r.number}<span class="answer-reveal"> = ${r.blue_tens} tens + ${r.yellow_ones} ones</span></h3><div class="bindis answer-reveal">${'<i class="bindi blue"></i>'.repeat(r.blue_tens)}<span class="ones-gap"></span>${'<i class="bindi yellow"></i>'.repeat(r.yellow_ones)}</div></div>`).join('')}</div>`,s.start,end);
  data.examples.forEach((r,i)=>{const card=p.querySelector(`[data-number="${r.number}"]`),t=wordTime(s,i?4:3,name(r.number));focus(card,t);allReveals(card,t);});
 }
});

// Names are textbook content, not a substitute supplied only by subtitles.
document.querySelectorAll('.build-state').forEach(el=>{const n=Number(el.dataset.number);el.querySelector('.build-number').insertAdjacentHTML('beforeend',`<p class="build-name" data-result-name="${n}">${esc(name(n))}</p>`);});
document.querySelectorAll('[data-source-block]').forEach((el,i)=>{if(!el.id)el.id=`source-block-${i}`;window.MATHS_QA.sourceBlocks.push({id:el.dataset.sourceBlock,element_id:el.id});});

// Statically declared video/audio nodes remain the renderer's authoritative tracks.
D.videos.forEach(v=>{const wrap=document.getElementById(`wrap-${v.id}`);visible(wrap,v.start,v.end);if(v.kind==='precision')tl.fromTo(wrap,{opacity:0},{opacity:1,duration:.18},v.start);});
D.captions.forEach(p=>{const el=document.createElement('div');el.id=p.id;el.className='caption';p.words.forEach((w,i)=>el.insertAdjacentHTML('beforeend',`<span id="${p.id}-w-${i}" class="word">${esc(w.word||w.text)}</span>`));document.getElementById('caption-lane').append(el);visible(el,p.start,p.end);p.words.forEach((w,i)=>{const target=`#${p.id}-w-${i}`;tl.set(target,{color:'#fff',backgroundColor:'#9f3528',scale:1.07,boxShadow:'0 2px 6px #17384b22'},w.start).set(target,{color:'#425f6c',backgroundColor:'transparent',scale:1,boxShadow:'none'},w.end);});});
tl.set({}, {}, D.duration);
window.MATHS_TIMELINE=tl;
window.__timelines=window.__timelines||{};window.__timelines['maths-class1-chapter8-two-digit-numbers']=tl;
