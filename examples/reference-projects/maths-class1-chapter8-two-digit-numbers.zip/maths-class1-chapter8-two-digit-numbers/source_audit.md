# Source audit - Mathematics Class 1, Chapter 8

Source: `RPS - MATHS - CLASS 1 - INDIVIDUAL - B (2026) PRINTFILE-pages-2.pdf`

The source contains 16 pages, printed as textbook pages 7-22. Every page was text-extracted and visually inspected from rendered PNGs. The chapter is **2 Digit Numbers (51 to 100)**.

## Complete coverage map

| PDF page | Textbook page | Required coverage |
| --- | --- | --- |
| 1 | 7 | Chapter title; recall of 21-50; adding 1-10; grouping 5, 6, 7, 8, and 9 tens as 50-90; skip counting and expanded-form preview. |
| 2-3 | 8-9 | Build 51-60 from 5 tens plus 1-10 ones. |
| 4-5 | 10-11 | Build 61-70 from 6 tens plus 1-10 ones. |
| 6-7 | 12-13 | Selected constructions from 71-100: 71, 75, 80, 81, 85, 90, 91, 95, 99, and 100. |
| 8 | 14 | Assemble 51-100 chart; fill missing numbers in a 1-100 chart. |
| 9 | 15 | Number-name chart from 1-100. |
| 10 | 16 | Write 12 numerals; match five numerals to names; first four one-more/one-less questions. |
| 11 | 17 | Remaining 12 one-more/one-less questions; 27 after/before/between blanks. |
| 12 | 18 | Skip counting by 2; cross every second number; record the crossed numbers. |
| 13 | 19 | Skip counting by 3 and 4; cross multiples of 3 and tick multiples of 4; record each sequence. |
| 14 | 20 | Complete skip-counting sequences by 5 and 10; place value and expanded-form examples for 12, 35, 68, 94, and 27. |
| 15 | 21 | Write tens, ones, and expanded forms for 52, 75, 39, 44, and 61; match 72, 67, 43, 16, and 54 to two expanded forms each. |
| 16 | 22 | Complete skip-counting rows by 2, 3, 5, and 10; bindi-circle activity for 54, 63, 75, and 82. |

## Teaching decisions

- The chapter opens over fresh 3D animated number blocks; narration starts immediately.
- Counting and place-value demonstrations use moving groups of ten objects plus individual ones.
- Dense workbook pages use stable teaching screens with animated highlights, circles, crosses, ticks, and answer reveals.
- Source headings are preserved. Decorative labels are not read aloud.
- Every spoken phrase receives word-highlight subtitles in the bottom safe lane.
- All obvious source errors are corrected in teaching and display and logged in `artifacts/source-errata.json`.

## Answer expectations

- Write numerals: 64, 53, 99, 40, 56, 94, 36, 100, 75, 28, 82, 16.
- Match names: 64-Sixty Four; 21-Twenty One; 18-Eighteen; 53-Fifty Three; 39-Thirty Nine.
- One more/one less: 63, 74, 30, 19, 42, 50, 99, 35, 37, 99, 54, 43, 75, 88, 83, 62.
- After/before/between: 70, 89, 16, 43, 75, 37, 22, 34, 54, 39, 67, 71, 54, 46, 45, 96, 80, 62, 70, 51, 99, 85, 29, 27, 11, 18, 60.
- By 2: 2, 4, 6, ... 100. By 3: 3, 6, 9, ... 99. By 4: 4, 8, 12, ... 100.
- Final rows: by 2 from 7 to 25; by 3 from 30 to 57; by 5 from 40 to 85; by 10 from 6 to 96.
- Circle activity: 54 = 5 tens + 4 ones; 63 = 6 tens + 3 ones; 75 = 7 tens + 5 ones; 82 = 8 tens + 2 ones.
